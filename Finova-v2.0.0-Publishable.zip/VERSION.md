# Finova Version Tracking

## Current Version: 2.0.0
## Release Date: November 23, 2026

## Version History

### v2.0.0 — November 23, 2026
**Major Release — Full Multi-Jurisdictional Platform**

#### New Modules (8 added)
- **LLM Hub** — Connect to 300+ AI models across 15 providers (31 free models)
- **Market Data** — 85 data points: FX, risk-free rates, ERP, credit spreads, tax rates
- **Payroll** — 15 employees across USA/UK/EU/Canada with statutory deductions
- **Board Pack** — Executive KPI dashboard with traffic-light status
- **LRP** — 10-Year Long-Range Plan (FY2025E-FY2034E)
- **Scenario Engine** — 4 scenarios × 14 drivers + 2 sensitivity tables
- **Budget Variance** — Monthly variance analysis with F/U flags
- **M&A Deal Tracker** — 5 complex deals with full PPA

#### Enhanced Modules
- **Financial Reports**: Added OCI Report tab, Concepts Glossary (115 terms), GAAP vs IFRS (32 comparisons), Concepts Applied panel (55 applications)
- **Tax Center**: Added Normal Tax + Deferred Tax tabs with 10 journal entries, IAS 12 / ASC 740 / FRS 102 s29
- **Corporate Finance**: Expanded to 9 tabs (added Valuation, FMVA, 3-Statement, Scenario, Board Pack, LRP, Loans)
- **Payroll**: Added Canada (CPP/EI/ITA) alongside USA/UK/EU
- **Clients**: Added Canada country option

#### New Data Files (17 lib files)
- `concepts-glossary.ts` — 115 terms across 11 categories
- `concepts-applied.ts` — 55 concept applications
- `gaap-vs-ifrs.ts` — 32 comparison rows across 13 areas
- `market-data.ts` — 85 data points from primary sources
- `payroll-data.ts` — 15 employees × 4 countries
- `three-statement-model.ts` — 8-year IS/BS/CF
- `loan-portfolio.ts` — 8 loans with amortization, DSCR/LTV/ECL
- `fmva-data.ts` — 9 valuation methodologies
- `driver-tree-scenarios.ts` — 4 scenarios × 14 drivers
- `budget-variance.ts` — Monthly variance analysis
- `ma-deals-data.ts` — 5 M&A deals with PPA
- `valuation-reports.ts` — Multi-jurisdictional valuation
- `lrp-data.ts` — 10-year long-range plan
- `llm-hub-data.ts` — 15 providers × 55 models

#### Legal & Security
- MIT License
- Privacy Policy (GDPR / CCPA compliant)
- Terms of Service
- Security Policy (SOC 2 / ISO 27001 aligned)
- Contributing Guidelines
- All personal names removed from source code

#### Mathematical Verification
- Trial Balance: Dr = Cr = £2,965,683 ✓
- OCI: Net = Gross − Tax ✓
- Total Comp Income = NI + OCI ✓
- Deferred Tax JEs: Dr = Cr ✓
- WACC formula verified ✓

### v1.0.0 — November 19, 2026
**Initial Release**
- Core accounting modules (Dashboard, Clients, Transactions, Journal, Invoices)
- AI Agents (CEO/CFO/Accountant/Tax) via z-ai-web-dev-sdk
- Tax Center with calculator
- Financial Reports (P&L, BS, CF, TB, Equity, VAT, Payroll)
- Consolidation, Corporate Finance, Disclosures
- Bank Accounts, Automations, Integrations
- API & Webhooks
- Import Files (PDF/Excel/CSV)
- Prisma schema with 17 data models
- SQLite database with seed data
