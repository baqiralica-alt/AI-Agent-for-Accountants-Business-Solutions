# Terms of Service — Finova

**Last Updated: November 23, 2026**

## Acceptance of Terms

By installing, configuring, or using Finova ("the Software"), you agree to be bound by these Terms of Service. If you do not agree, do not use the Software.

## License

The Software is licensed under the MIT License (see [LICENSE](LICENSE)). For commercial SaaS deployment, a commercial license may be required.

## Disclaimer of Warranty

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

## Limitation of Liability

IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Professional Disclaimer

- All financial data in this Software is **fictional** and for educational/demonstration purposes
- The Software does **not** constitute professional accounting, tax, legal, or investment advice
- Always consult a **licensed professional** (CPA, tax adviser, lawyer, financial adviser) before making business decisions
- The Software's calculations, while mathematically verified, should be **independently validated** for real-world use
- Tax laws change frequently — always verify current rates and rules with official sources

## Compliance with Laws

Users are responsible for ensuring their use of the Software complies with:
- **USA**: IRC, SEC regulations, state accounting board rules, AICPA standards
- **UK**: Companies Act 2006, HMRC requirements, ICAEW standards, FCA regulations
- **EU**: National accounting laws, EU Audit Regulation, national tax codes
- **Canada**: Canada Income Tax Act, CPA Canada standards, provincial regulations
- **All jurisdictions**: Applicable data protection laws (GDPR, CCPA, etc.)

## Acceptable Use

You agree NOT to:
- Use the Software for illegal activities
- Process real customer financial data without proper licensing and consent
- Represent the Software's output as certified audit or professional advice
- Reverse engineer or redistribute the Software without proper attribution
- Use the Software to evade taxes or violate financial regulations

## Data Responsibility

- You are solely responsible for the data you input into the Software
- You must comply with all applicable data protection laws
- You must secure your deployment (API keys, database, server access)
- The Software developers are not responsible for data breaches on your deployment

## AI/LLM Usage

- When using AI features, you are responsible for the content of your prompts
- Do not send confidential client data to third-party LLM APIs without proper authorization
- Use local LLM models (Ollama) for sensitive data processing
- AI outputs should be reviewed by a qualified professional before action

## Governing Law

These Terms shall be governed by and construed in accordance with applicable international commercial law principles, with due consideration for:
- US Uniform Commercial Code (UCC)
- UK Contracts (Rights of Third Parties) Act 1999
- EU Rome I Regulation (Regulation 593/2008)

## Changes to Terms

We reserve the right to update these Terms at any time. Continued use of the Software constitutes acceptance of updated Terms.

## Contact

For questions about these Terms, please open an issue on the GitHub repository.
