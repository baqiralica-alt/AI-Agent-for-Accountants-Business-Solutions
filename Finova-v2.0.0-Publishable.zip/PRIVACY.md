# Privacy Policy — Finova

**Last Updated: November 23, 2026**

## Overview

Finova is a finance and accounting platform that processes financial data for business use. This Privacy Policy explains how we handle data in compliance with:

- **USA**: CCPA (California Consumer Privacy Act), state privacy laws
- **UK**: UK GDPR, Data Protection Act 2018
- **EU**: GDPR (General Data Protection Regulation), ePrivacy Directive

## Data We Process

### Financial Data
- Company financial statements (P&L, Balance Sheet, Cash Flow)
- Transaction records and journal entries
- Tax computations and filings
- Payroll information
- Loan portfolio data
- Valuation models and M&A deal data

### User Data
- Email address (for authentication)
- Company name and industry
- Country/jurisdiction selection
- API keys (stored locally in browser, never sent to our servers)

## Data Storage

- **Database**: SQLite local database (stored on your server/machine)
- **No cloud data transmission**: All data stays on your infrastructure
- **API keys**: Stored in browser localStorage (LLM Hub) or server environment variables
- **No third-party data sharing**: We do not sell or share your data

## Your Rights (GDPR / CCPA)

### Right to Access
You can access all your data through the app's export functions (Excel, CSV, PDF).

### Right to Erasure
Delete the SQLite database file to remove all data. Use `npx prisma db reset` to clear the database.

### Right to Portability
Export all financial reports in Excel/CSV/PDF format from any report tab.

### Right to Object
Disable AI agent features by not configuring LLM API keys. The app works fully without AI.

## AI/LLM Data Processing

When you connect an LLM provider via the LLM Hub:
- **Your prompts** are sent to the LLM provider's API (e.g., Google, OpenAI, DeepSeek)
- **Your financial data** may be included in prompts to the AI agent
- **Responses** are received from the LLM provider
- **No data is stored by Finova** beyond the local SQLite database

**For sensitive data**: Use local LLM models (Ollama) to keep all data on your machine.

## Data Security

- All API communications use HTTPS
- Prisma ORM prevents SQL injection attacks
- Input validation on all API endpoints
- No hardcoded credentials in source code
- Database file excluded from version control
- See [SECURITY.md](SECURITY.md) for full security measures

## Children's Privacy

This software is designed for business use only. We do not knowingly collect data from anyone under 18.

## Changes to This Policy

We will update this Privacy Policy as needed. The "Last Updated" date at the top reflects the most recent revision.

## Contact

For privacy concerns, please open an issue on the GitHub repository.

## Legal Compliance

This Privacy Policy is designed to comply with:
- EU GDPR (Articles 13-14)
- UK GDPR and Data Protection Act 2018
- California CCPA (Cal. Civ. Code §1798.100)
- Other applicable state and national privacy laws
