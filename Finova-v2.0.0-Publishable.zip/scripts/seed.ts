// Finova — seed script
// Seeds the DB with 6 demo companies spanning Construction, Real Estate, Retail,
// SaaS, AI and Manufacturing across USA, UK, Germany, France and Ireland.

import { db } from "../src/lib/db"

const COMPANIES = [
  // MANUFACTURING — USA
  {
    id: "co_usa_mfg",
    name: "Atlas Manufacturing Co.",
    industry: "Manufacturing",
    country: "USA",
    currency: "USD",
    taxId: "EIN 47-2918372",
  },
  // CONSTRUCTION — USA
  {
    id: "co_usa_con",
    name: "Bridgepoint Construction LLC",
    industry: "Construction",
    country: "USA",
    currency: "USD",
    taxId: "EIN 82-1140987",
  },
  // REAL ESTATE — UK
  {
    id: "co_uk_re",
    name: "Thames Property Holdings Ltd",
    industry: "Real Estate",
    country: "UK",
    currency: "GBP",
    taxId: "CRN 09813472",
  },
  // RETAIL — Germany
  {
    id: "co_de_ret",
    name: "Mitte Retail GmbH",
    industry: "Retail",
    country: "Germany",
    currency: "EUR",
    taxId: "VAT DE-287164921",
  },
  // SAAS — Ireland
  {
    id: "co_ie_saas",
    name: "Liffey SaaS Ltd",
    industry: "SaaS",
    country: "Ireland",
    currency: "EUR",
    taxId: "VAT IE-9876543T",
  },
  // AI STARTUP — USA
  {
    id: "co_usa_ai",
    name: "Cortex AI Labs Inc.",
    industry: "AI",
    country: "USA",
    currency: "USD",
    taxId: "EIN 92-4455667",
  },
]

const INTEGRATIONS_BY_COMPANY: Record<string, Array<{ provider: string; label: string; scope?: string; accountEmail?: string }>> = {
  co_usa_mfg: [
    { provider: "gmail", label: "CFO Gmail Inbox", accountEmail: "cfo@atlasmfg.com", scope: "read,send" },
    { provider: "quickbooks", label: "QuickBooks Online", accountEmail: "books@atlasmfg.com" },
    { provider: "stripe", label: "Stripe Payments", scope: "charges,refunds" },
    { provider: "plaid", label: "Chase Business Banking", accountEmail: "ops@atlasmfg.com" },
  ],
  co_usa_con: [
    { provider: "gmail", label: "Project Gmail", accountEmail: "ap@bridgepoint.com", scope: "read,send" },
    { provider: "quickbooks", label: "QuickBooks Online", accountEmail: "books@bridgepoint.com" },
    { provider: "plaid", label: "Bank of America Operating", accountEmail: "ops@bridgepoint.com" },
    { provider: "stripe", label: "Stripe ACH", scope: "charges,refunds" },
  ],
  co_uk_re: [
    { provider: "gmail", label: "Property Gmail", accountEmail: "accounts@thamesprop.co.uk", scope: "read,send" },
    { provider: "xero", label: "Xero UK", accountEmail: "books@thamesprop.co.uk" },
    { provider: "plaid", label: "Barclays Business", accountEmail: "ops@thamesprop.co.uk" },
  ],
  co_de_ret: [
    { provider: "gmail", label: "Retail Gmail", accountEmail: "kasse@mitte-retail.de", scope: "read,send" },
    { provider: "xero", label: "Xero DE" },
    { provider: "shopify", label: "Shopify Store" },
    { provider: "stripe", label: "Stripe SEPA", scope: "charges,refunds" },
  ],
  co_ie_saas: [
    { provider: "gmail", label: "Finance Gmail", accountEmail: "finance@liffeysaas.ie", scope: "read,send" },
    { provider: "xero", label: "Xero IE" },
    { provider: "stripe", label: "Stripe Billing", scope: "subscriptions,invoices" },
    { provider: "plaid", label: "AIB Business" },
  ],
  co_usa_ai: [
    { provider: "gmail", label: "CFO Gmail", accountEmail: "cfo@cortexai.com", scope: "read,send" },
    { provider: "quickbooks", label: "QuickBooks Online" },
    { provider: "stripe", label: "Stripe Billing", scope: "subscriptions,invoices" },
    { provider: "plaid", label: "Mercury Bank" },
    { provider: "aws", label: "AWS (for R&D credit tracking)" },
  ],
}

// Industry-specific transaction descriptions & categories
const INDUSTRY_DATA: Record<string, {
  incomeCats: string[];
  expenseCats: string[];
  descriptions: string[];
}> = {
  Manufacturing: {
    incomeCats: ["Product Revenue", "Service Revenue", "Equipment Sales"],
    expenseCats: ["COGS", "Payroll", "Rent", "Software", "Marketing", "Utilities", "Travel", "Tax", "Insurance", "Office Supplies", "Raw Materials", "Equipment Maintenance"],
    descriptions: ["Customer invoice paid", "Stripe payout", "Raw steel purchase", "Factory payroll run", "Equipment maintenance", "AWS infrastructure", "Vendor payment — supplies", "Insurance premium", "Annual software license", "Equipment purchase", "Trade show marketing", "Utilities — plant"],
  },
  Construction: {
    incomeCats: ["Contract Revenue", "Progress Billing", "Service Revenue", "Change Order Revenue"],
    expenseCats: ["Materials", "Subcontractors", "Payroll", "Equipment Rental", "Permits", "Insurance", "Bond Premium", "Fuel", "Travel", "Office Supplies", "Software", "Utilities"],
    descriptions: ["Progress billing — Project #2148", "Change order approved", "Concrete delivery", "Subcontractor payment — framing", "Crane rental", "Permit fee — city", "Performance bond premium", "Fuel — fleet", "Payroll — field crew", "Tool purchase", "PPE order", "Project insurance"],
  },
  "Real Estate": {
    incomeCats: ["Rental Income", "Property Sales", "Management Fees", "Service Revenue"],
    expenseCats: ["Property Maintenance", "Payroll", "Mortgage Interest", "Property Tax", "Insurance", "Utilities", "Marketing", "Software", "Legal Fees", "HOA Fees", "Repairs", "Cleaning"],
    descriptions: ["Monthly rent collection — Unit 4B", "Property sale closing", "Maintenance — HVAC repair", "Mortgage interest payment", "Property tax installment", "Building insurance", "Marketing — listing", "Legal fees — lease review", "Cleaning service", "Property management software", "Repairs — plumbing", "Landscape service"],
  },
  Retail: {
    incomeCats: ["Product Revenue", "Online Sales", "In-Store Sales", "Gift Card Revenue"],
    expenseCats: ["COGS", "Payroll", "Rent", "Inventory", "Marketing", "Utilities", "Software", "Shipping", "Packaging", "Insurance", "Office Supplies", "Returns"],
    descriptions: ["POS daily sales", "Shopify online order", "Inventory restock", "Stripe payout", "Store payroll", "Retail rent", "Instagram ad spend", "Shipping — DHL", "Packaging supplies", "Returns processed", "Seasonal inventory", "Store utilities"],
  },
  SaaS: {
    incomeCats: ["Subscription Revenue", "Service Revenue", "Implementation", "Usage Revenue"],
    expenseCats: ["Payroll", "Hosting", "Software", "Marketing", "Sales Commission", "Customer Success", "Legal Fees", "Insurance", "Office Supplies", "Travel", "Utilities", "R&D"],
    descriptions: ["Monthly MRR batch", "Annual subscription renewal", "AWS infrastructure", "Implementation fee", "Sales commission payout", "HubSpot subscription", "Google Ads spend", "Customer success tools", "Payroll — engineering", "Datadog monitoring", "Annual conference sponsorship", "Stripe billing fees"],
  },
  AI: {
    incomeCats: ["API Revenue", "Subscription Revenue", "Service Revenue", "Research Grant"],
    expenseCats: ["Compute (GPU)", "Payroll", "Hosting", "Software", "Marketing", "R&D", "Data Licensing", "Legal Fees", "Insurance", "Office Supplies", "Travel", "Utilities"],
    descriptions: ["API usage billing", "Enterprise subscription", "GPU cluster — AWS p5", "Research compute spend", "Engineer payroll", "HuggingFace subscription", "OpenAI API spend", "Data licensing — corpus", "Patent filing fees", "Conference travel — NeurIPS", "R&D credit-eligible spend", "Vector DB subscription"],
  },
}

const SOURCES = ["quickbooks", "xero", "sage", "stripe", "wave", "gmail", "plaid", "shopify", "aws", "manual"]

function randomFrom<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)] }
function randomAmount(min: number, max: number): number { return Math.round((Math.random() * (max - min) + min) * 100) / 100 }
function daysAgo(days: number): Date {
  const d = new Date(); d.setDate(d.getDate() - days)
  d.setHours(9 + Math.floor(Math.random() * 8), Math.floor(Math.random() * 60), 0, 0)
  return d
}
function daysFromNow(days: number): Date { const d = new Date(); d.setDate(d.getDate() + days); return d }

async function main() {
  console.log("Seeding Finova database (6 industries, 5 countries)...")

  await db.chatMessage.deleteMany()
  await db.chatSession.deleteMany()
  await db.taxRecord.deleteMany()
  await db.integration.deleteMany()
  await db.automation.deleteMany()
  await db.transaction.deleteMany()
  await db.journalEntry.deleteMany()
  await db.company.deleteMany()

  for (const c of COMPANIES) {
    await db.company.create({ data: c })

    // Integrations
    for (const i of INTEGRATIONS_BY_COMPANY[c.id] ?? []) {
      await db.integration.create({
        data: {
          companyId: c.id,
          provider: i.provider,
          label: i.label,
          status: "connected",
          scope: i.scope,
          accountEmail: i.accountEmail,
          lastSyncAt: daysAgo(Math.floor(Math.random() * 12) + 1),
        },
      })
    }

    const ind = INDUSTRY_DATA[c.industry]
    // Transactions — 60 random across last 90 days, industry-flavored
    for (let k = 0; k < 60; k++) {
      const isIncome = Math.random() < 0.4
      const category = isIncome ? randomFrom(ind.incomeCats) : randomFrom(ind.expenseCats)
      const amount = isIncome ? randomAmount(2000, 48000) : randomAmount(120, 12000)
      await db.transaction.create({
        data: {
          companyId: c.id,
          date: daysAgo(Math.floor(Math.random() * 90)),
          description: randomFrom(ind.descriptions),
          category,
          type: isIncome ? "income" : "expense",
          amount,
          currency: c.currency,
          source: randomFrom(SOURCES),
          status: randomFrom(["posted", "reconciled", "pending"]),
        },
      })
    }

    // Industry-flavored automations
    const autoMap: Record<string, Array<{ name: string; description: string; trigger: string; action: string; agentRole: string }>> = {
      Manufacturing: [
        { name: "Daily Production Cost Report", description: "CFO agent emails the COO with yesterday's COGS vs. plan.", trigger: "daily", action: "send-report", agentRole: "cfo" },
        { name: "Raw Material Reorder Alert", description: "When inventory drops below reorder point, Accountant agent opens a PO task.", trigger: "on-event", action: "categorize", agentRole: "accountant" },
        { name: "Sales Tax Reminder", description: "30 days before each filing deadline the Tax agent drafts the return.", trigger: "monthly", action: "remind-tax", agentRole: "tax" },
      ],
      Construction: [
        { name: "Weekly Progress Billing", description: "Accountant agent drafts AIA-style progress billings every Friday from project data.", trigger: "weekly", action: "send-report", agentRole: "accountant" },
        { name: "Percent-Complete Revenue Recognition", description: "CFO agent recalculates % complete on each project monthly and posts the entry.", trigger: "monthly", action: "categorize", agentRole: "cfo" },
        { name: "Lien Deadline Tracking", description: "Tax agent tracks preliminary lien notice deadlines per state.", trigger: "on-event", action: "remind-tax", agentRole: "tax" },
      ],
      "Real Estate": [
        { name: "Monthly Rent Roll Report", description: "CFO agent emails the owner with rent roll, vacancies and NOI.", trigger: "monthly", action: "send-report", agentRole: "cfo" },
        { name: "Lease Renewal Triage (Gmail)", description: "Accountant agent scans Gmail for renewal notices and drafts new leases.", trigger: "email-received", action: "categorize", agentRole: "accountant" },
        { name: "UK VAT / SDLT Reminder", description: "Tax agent opens a task for VAT and any SDLT payments 30 days out.", trigger: "monthly", action: "remind-tax", agentRole: "tax" },
      ],
      Retail: [
        { name: "Daily POS Reconciliation", description: "Accountant agent reconciles Shopify + Stripe + POS to bank each night.", trigger: "daily", action: "reconcile", agentRole: "accountant" },
        { name: "Inventory Shrinkage Alert", description: "CFO agent flags if inventory adjustment > 2% of COGS.", trigger: "on-event", action: "categorize", agentRole: "cfo" },
        { name: "EU VAT OSS Recap", description: "Tax agent prepares the One Stop Shop VAT return for cross-border EU sales.", trigger: "monthly", action: "remind-tax", agentRole: "tax" },
      ],
      SaaS: [
        { name: "Daily MRR / Churn Digest", description: "CFO agent emails CEO with MRR, net new logos and churn.", trigger: "daily", action: "send-report", agentRole: "cfo" },
        { name: "Stripe Billing Sync", description: "Accountant agent posts new invoices and refunds from Stripe to Xero.", trigger: "on-event", action: "categorize", agentRole: "accountant" },
        { name: "Irish CT / VAT Reminder", description: "Tax agent opens tasks for Irish CT and VAT (ROS) filings.", trigger: "monthly", action: "remind-tax", agentRole: "tax" },
      ],
      AI: [
        { name: "Weekly GPU Spend Forecast", description: "CFO agent forecasts the next GPU bill from run-rate and flags if it breaches budget.", trigger: "weekly", action: "send-report", agentRole: "cfo" },
        { name: "R&D Credit Tracker", description: "Accountant agent tags qualifying wages, compute and contractor spend for the US R&D credit.", trigger: "monthly", action: "categorize", agentRole: "accountant" },
        { name: "Section 174 / R&D Capitalization", description: "Tax agent models the Section 174 capitalization impact quarterly.", trigger: "monthly", action: "remind-tax", agentRole: "tax" },
      ],
    }
    const automations = autoMap[c.industry] ?? []
    for (const a of automations) {
      await db.automation.create({
        data: {
          companyId: c.id,
          ...a,
          enabled: Math.random() < 0.85,
          lastRunAt: daysAgo(Math.floor(Math.random() * 5) + 1),
          nextRunAt: daysFromNow(Math.floor(Math.random() * 3) + 1),
          runsCount: Math.floor(Math.random() * 240) + 12,
        },
      })
    }

    // Tax records — country specific
    let taxRecords: Array<{ taxType: string; period: string; dueDate: Date; amount?: number }> = []
    if (c.country === "USA") {
      taxRecords = [
        { taxType: "federal-income", period: "2026-Q1 Estimated", dueDate: daysFromNow(28), amount: 42500 },
        { taxType: "state-income", period: `${c.industry === "Construction" ? "Texas" : "California"} 2026-Q1`, dueDate: daysFromNow(28), amount: 9800 },
        { taxType: "sales-tax", period: "March 2026", dueDate: daysFromNow(12), amount: 15200 },
        { taxType: "payroll", period: "Q1 941", dueDate: daysFromNow(45), amount: 38600 },
        ...(c.industry === "AI" ? [{ taxType: "federal-income", period: "R&D Credit Form 6765", dueDate: daysFromNow(120), amount: 0 }] : []),
      ]
    } else if (c.country === "UK") {
      taxRecords = [
        { taxType: "vat", period: "2026-Q1 VAT", dueDate: daysFromNow(18), amount: 18200 },
        { taxType: "corporation-tax", period: "FY2024-25", dueDate: daysFromNow(72), amount: 64500 },
        { taxType: "payroll", period: "PAYE/NI March", dueDate: daysFromNow(7), amount: 12400 },
        { taxType: "self-assessment", period: "SA 2024-25", dueDate: daysFromNow(110), amount: 0 },
      ]
    } else if (c.country === "Germany") {
      taxRecords = [
        { taxType: "vat", period: "2026-Q1 Umsatzsteuer", dueDate: daysFromNow(10), amount: 21400 },
        { taxType: "corporation-tax", period: "Gewerbesteuer Q1", dueDate: daysFromNow(33), amount: 17800 },
        { taxType: "payroll", period: "Lohnsteuer March", dueDate: daysFromNow(6), amount: 14600 },
      ]
    } else if (c.country === "Ireland") {
      taxRecords = [
        { taxType: "vat", period: "2026-Q1 VAT (ROS)", dueDate: daysFromNow(19), amount: 12800 },
        { taxType: "corporation-tax", period: "CT FY2025", dueDate: daysFromNow(60), amount: 38500 },
        { taxType: "payroll", period: "PAYE/PRSI March", dueDate: daysFromNow(14), amount: 9200 },
      ]
    } else if (c.country === "France") {
      taxRecords = [
        { taxType: "vat", period: "2026-Q1 TVA", dueDate: daysFromNow(15), amount: 19200 },
        { taxType: "corporation-tax", period: "IS FY2025", dueDate: daysFromNow(80), amount: 41200 },
        { taxType: "payroll", period: "Cotisations March", dueDate: daysFromNow(10), amount: 16400 },
      ]
    }
    for (const t of taxRecords) {
      const isOverdue = t.dueDate < new Date()
      await db.taxRecord.create({
        data: {
          companyId: c.id, country: c.country, taxType: t.taxType, period: t.period,
          dueDate: t.dueDate,
          filingStatus: isOverdue ? "filed" : randomFrom(["pending", "pending", "paid"]),
          amount: t.amount,
        },
      })
    }

    // Starter chat session + sample decision
    const session = await db.chatSession.create({
      data: { companyId: c.id, role: "cfo", title: `${c.industry} finance review` },
    })
    await db.chatMessage.create({
      data: { sessionId: session.id, role: "user", content: `Give me a finance summary for ${c.name} (${c.industry}, ${c.country}).` },
    })
    await db.chatMessage.create({
      data: {
        sessionId: session.id,
        role: "assistant",
        content: `Here's the snapshot for **${c.name}** (${c.industry}, ${c.country}):\n\n- Cash position healthy, runway > 18 months\n- One upcoming filing to watch in the Tax Center\n- Recommended action: schedule the monthly ${c.industry}-specific review with the team.\n\nAsk the Accountant agent to post any journal entry, or the Tax agent to model the next filing.`,
        isDecision: true,
        decisionTag: "monthly-review",
      },
    })

    // One sample journal entry per company (industry-flavored)
    const jeSamples: Record<string, { memo: string; reference?: string; lines: Array<{ account: string; debit: number; credit: number }> }> = {
      Manufacturing: {
        memo: "Record raw material purchase (steel)",
        reference: "PO-2814",
        lines: [
          { account: "1400 Raw Materials Inventory", debit: 18400, credit: 0 },
          { account: "2000 Accounts Payable", debit: 0, credit: 18400 },
        ],
      },
      Construction: {
        memo: "Progress billing — Project #2148 (35% complete)",
        reference: "AIA-2148-3",
        lines: [
          { account: "1200 Accounts Receivable", debit: 62500, credit: 0 },
          { account: "4000 Contract Revenue", debit: 0, credit: 62500 },
        ],
      },
      "Real Estate": {
        memo: "Record monthly rent income — Unit 4B",
        reference: "LEASE-4B-2026",
        lines: [
          { account: "1200 Rent Receivable", debit: 4200, credit: 0 },
          { account: "4000 Rental Income", debit: 0, credit: 4200 },
        ],
      },
      Retail: {
        memo: "Daily POS sales — Mitte store",
        reference: "POS-2026-03-15",
        lines: [
          { account: "1000 Cash & Bank", debit: 8920, credit: 0 },
          { account: "4000 Sales Revenue", debit: 0, credit: 7487 },
          { account: "2300 VAT Payable (19%)", debit: 0, credit: 1433 },
        ],
      },
      SaaS: {
        memo: "Monthly MRR billing batch — March",
        reference: "BILL-MAR-2026",
        lines: [
          { account: "1200 Accounts Receivable", debit: 42800, credit: 0 },
          { account: "4000 Subscription Revenue", debit: 0, credit: 42800 },
        ],
      },
      AI: {
        memo: "Record GPU compute (AWS p5) — March",
        reference: "AWS-INV-33218",
        lines: [
          { account: "5100 Compute Expense", debit: 36200, credit: 0 },
          { account: "1000 Cash & Bank", debit: 0, credit: 36200 },
        ],
      },
    }
    const je = jeSamples[c.industry]
    if (je) {
      const totalDebit = je.lines.reduce((s, l) => s + l.debit, 0)
      const totalCredit = je.lines.reduce((s, l) => s + l.credit, 0)
      await db.journalEntry.create({
        data: {
          companyId: c.id,
          date: daysAgo(Math.floor(Math.random() * 14) + 1),
          memo: je.memo,
          reference: je.reference,
          source: "agent",
          postedBy: "accountant-agent",
          linesJson: JSON.stringify(je.lines),
          totalDebit,
          totalCredit,
          status: "posted",
        },
      })
    }
  }

  console.log("Seed complete.")
  const counts = await Promise.all([
    db.company.count(), db.transaction.count(), db.automation.count(),
    db.integration.count(), db.taxRecord.count(), db.chatSession.count(),
    db.chatMessage.count(), db.journalEntry.count(),
  ])
  console.log({
    companies: counts[0], transactions: counts[1], automations: counts[2],
    integrations: counts[3], taxRecords: counts[4], chatSessions: counts[5],
    chatMessages: counts[6], journalEntries: counts[7],
  })
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(async () => { await db.$disconnect() })
