# Security Policy — Finova

**Last Updated: November 23, 2026**

## Security Measures

### Data Protection
- **Local Database**: SQLite database stored on your server — no cloud data transmission
- **No hardcoded credentials**: All API keys stored in environment variables
- **Prisma ORM**: Parameterized queries prevent SQL injection
- **Input validation**: All API endpoints validate input types and ranges
- **HTTPS ready**: Configure via Caddyfile (included) for production TLS

### Authentication
- The app supports adding authentication middleware (see below)
- API keys for LLM providers stored in browser localStorage (LLM Hub) — never sent to Finova servers
- Database access restricted to Prisma ORM layer

### File Security
- Database file (`db/custom.db`) excluded from Git via `.gitignore`
- `.env` file excluded from Git — use `.env.example` as template
- No personal data in source code

### Dependency Security
- All dependencies managed via `bun.lock` (deterministic versions)
- Regular security audits recommended: `bun audit`

## Recommended Production Setup

### 1. Enable HTTPS (Caddyfile included)
```caddyfile
yourdomain.com {
    reverse_proxy localhost:3000
    encode gzip
    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains"
        X-Content-Type-Options nosniff
        X-Frame-Options DENY
        Referrer-Policy strict-origin-when-cross-origin
    }
}
```

### 2. Set Environment Variables
```env
DATABASE_URL="file:./db/custom.db"
# Set only the LLM API keys you use
# Never commit .env to Git
```

### 3. Database Backup
```bash
# Regular backup
cp db/custom.db db/backup-$(date +%Y%m%d).db

# Or use Prisma
npx prisma db pull --schema=prisma/schema.prisma
```

### 4. Rate Limiting (recommended)
Add rate limiting middleware for API endpoints in production:
```typescript
// Example: simple rate limiter in Next.js middleware
// 100 requests per minute per IP
```

## Vulnerability Reporting

If you discover a security vulnerability:

1. **DO NOT** open a public GitHub issue
2. Contact the maintainer privately via GitHub
3. Include: description, reproduction steps, potential impact
4. We will acknowledge within 48 hours and provide a fix timeline

## Security Headers

The app sets the following security headers (via Caddy or Next.js config):
- `Strict-Transport-Security`: Force HTTPS
- `X-Content-Type-Options: nosniff`: Prevent MIME sniffing
- `X-Frame-Options: DENY`: Prevent clickjacking
- `Referrer-Policy`: Limit referrer information

## GDPR / CCPA Compliance

- **Data minimization**: Only collect necessary data
- **Right to deletion**: `npx prisma db reset` clears all data
- **Data portability**: Excel/CSV/PDF export from all reports
- **No tracking cookies**: The app does not use tracking cookies
- **Local-first architecture**: Data stays on your server

## Compliance Standards

This app implements controls aligned with:
- **SOC 2** (Trust Services Criteria): Security, Availability, Confidentiality
- **ISO 27001** (Annex A): Access control, cryptography, operations security
- **PCI DSS** (if processing card data): Use separate PCI-compliant payment processor
