// Loan Portfolio — Comprehensive loan-level reporting with amortization schedules,
// covenant compliance, and FP&A formulas. All loans are fictitious but realistic.
//
// FORMULAS LINKED:
//   Monthly Payment (P&I) = P × (r/12) / (1 − (1 + r/12)^(−n))
//   Interest Component = Balance × (r/12)
//   Principal Component = Monthly Payment − Interest Component
//   Ending Balance = Beginning Balance − Principal Component
//   DSCR = NOI / (Principal + Interest) annual
//   LTV = Loan Principal / Appraised Collateral Value
//   Debt Yield = NOI / Loan Principal
//   Interest Coverage = EBITDA / Interest Expense
//   Weighted Avg Rate (Portfolio) = Σ(Loan Balance × Loan Rate) / Σ(Loan Balance)
//   NPL % = Σ(NPL Balances) / Σ(Total Balances)
//   Recovery Rate = 1 − LGD
//   Expected Loss = PD × LGD × EAD

export type LoanType = "CRE-Office" | "CRE-Retail" | "CRE-Industrial" | "CRE-Multifamily" | "C&I-Manufacturing" | "C&I-Tech" | "Construction";
export type AmortizationType = "P&I" | "Interest-Only" | "Balloon" | "Bullet";
export type RiskStage = "Performing" | "Watchlist" | "Substandard" | "Doubtful" | "Loss";

export type Loan = {
  loanId: string;
  borrower: string;
  propertyOrProject: string;
  loanType: LoanType;
  originationDate: string;
  maturityDate: string;
  originalPrincipal: number;
  currentBalance: number;
  interestRate: number;       // annual %, e.g. 6.50
  rateType: "Fixed" | "Floating-SOFR" | "Floating-SONIA";
  spread?: number;            // bps over benchmark if floating
  termMonths: number;
  amortizationType: AmortizationType;
  monthlyPayment: number;     // computed
  collateralValue: number;
  ltv: number;                // computed
  noi: number;                // annual NOI (for DSCR, debt yield)
  dscr: number;               // computed
  debtYield: number;          // computed
  interestCoverage: number;   // computed (where applicable)
  ebitda?: number;            // for C&I loans
  riskStage: RiskStage;
  daysPastDue: number;
  covenantDSCRMin: number;
  covenantLTVMax: number;
  covenantDebtYieldMin: number;
  covenantIntCovMin: number;
  covenantsCompliant: boolean;
  pd: number;                 // probability of default %
  lgd: number;                // loss given default %
  ead: number;                // exposure at default = current balance
  expectedLoss: number;       // computed = PD × LGD × EAD
};

// ============ HELPER: Monthly Payment P&I formula ============
// P × (r/12) / (1 − (1 + r/12)^(−n))
function monthlyPaymentPI(principal: number, annualRatePct: number, termMonths: number): number {
  const r = annualRatePct / 100 / 12;
  if (r === 0) return principal / termMonths;
  const factor = Math.pow(1 + r, termMonths);
  return Math.round((principal * r / (1 - 1 / factor)) * 100) / 100;
}

// ============ HELPER: LTV ============
function ltv(loan: number, collateral: number): number {
  return Math.round((loan / collateral) * 1000) / 10;
}

// ============ HELPER: DSCR ============
function dscr(noi: number, annualDebtService: number): number {
  if (annualDebtService === 0) return 0;
  return Math.round((noi / annualDebtService) * 100) / 100;
}

// ============ HELPER: Debt Yield ============
function debtYield(noi: number, loan: number): number {
  if (loan === 0) return 0;
  return Math.round((noi / loan) * 1000) / 10;
}

// ============ HELPER: Expected Loss ============
function expectedLoss(pd: number, lgd: number, ead: number): number {
  return Math.round((pd / 100) * (lgd / 100) * ead);
}

// ============ LOAN PORTFOLIO (8 fictitious loans) ============
const rawLoans: Omit<Loan, "monthlyPayment" | "ltv" | "dscr" | "debtYield" | "interestCoverage" | "covenantsCompliant" | "expectedLoss">[] = [
  {
    loanId: "L-001",
    borrower: "Sterling Property Holdings Ltd",
    propertyOrProject: "Citypoint Tower — 250,000 sqft Class A Office, London EC2",
    loanType: "CRE-Office",
    originationDate: "2024-03-15",
    maturityDate: "2027-03-15",
    originalPrincipal: 85000000,
    currentBalance: 82000000,
    interestRate: 6.50,
    rateType: "Fixed",
    termMonths: 36,
    amortizationType: "Interest-Only",
    collateralValue: 110000000,
    noi: 6800000,
    riskStage: "Watchlist",
    daysPastDue: 0,
    covenantDSCRMin: 1.25,
    covenantLTVMax: 75.0,
    covenantDebtYieldMin: 8.0,
    covenantIntCovMin: 0,
    pd: 1.5,
    lgd: 35,
    ead: 82000000,
  },
  {
    loanId: "L-002",
    borrower: "Cascade Retail Group LP",
    propertyOrProject: "Westgate Shopping Centre — 450,000 sqft regional mall, Manchester",
    loanType: "CRE-Retail",
    originationDate: "2023-06-30",
    maturityDate: "2028-06-30",
    originalPrincipal: 120000000,
    currentBalance: 112000000,
    interestRate: 5.75,
    rateType: "Fixed",
    termMonths: 60,
    amortizationType: "P&I",
    collateralValue: 155000000,
    noi: 11800000,
    riskStage: "Performing",
    daysPastDue: 0,
    covenantDSCRMin: 1.40,
    covenantLTVMax: 75.0,
    covenantDebtYieldMin: 8.0,
    covenantIntCovMin: 0,
    pd: 1.2,
    lgd: 25,
    ead: 112000000,
  },
  {
    loanId: "L-003",
    borrower: "Northbank Logistics LLC",
    propertyOrProject: "Phoenix Industrial Park — 1.2M sqft distribution, Arizona",
    loanType: "CRE-Industrial",
    originationDate: "2024-01-20",
    maturityDate: "2034-01-20",
    originalPrincipal: 95000000,
    currentBalance: 92000000,
    interestRate: 5.50,
    rateType: "Floating-SOFR",
    spread: 175,
    termMonths: 120,
    amortizationType: "P&I",
    collateralValue: 135000000,
    noi: 8900000,
    riskStage: "Performing",
    daysPastDue: 0,
    covenantDSCRMin: 1.40,
    covenantLTVMax: 70.0,
    covenantDebtYieldMin: 8.0,
    covenantIntCovMin: 0,
    pd: 0.5,
    lgd: 20,
    ead: 92000000,
  },
  {
    loanId: "L-004",
    borrower: "Maplewood Apartments Trust",
    propertyOrProject: "Riverside Multifamily — 320 units, Toronto ON",
    loanType: "CRE-Multifamily",
    originationDate: "2023-09-15",
    maturityDate: "2033-09-15",
    originalPrincipal: 65000000,
    currentBalance: 62000000,
    interestRate: 5.25,
    rateType: "Fixed",
    termMonths: 120,
    amortizationType: "P&I",
    collateralValue: 88000000,
    noi: 5600000,
    riskStage: "Performing",
    daysPastDue: 0,
    covenantDSCRMin: 1.25,
    covenantLTVMax: 75.0,
    covenantDebtYieldMin: 7.0,
    covenantIntCovMin: 0,
    pd: 0.6,
    lgd: 20,
    ead: 62000000,
  },
  {
    loanId: "L-005",
    borrower: "Atlas Manufacturing Co",
    propertyOrProject: "Working capital facility — secured by AR + inventory, Ohio",
    loanType: "C&I-Manufacturing",
    originationDate: "2024-04-01",
    maturityDate: "2027-04-01",
    originalPrincipal: 45000000,
    currentBalance: 38000000,
    interestRate: 6.00,
    rateType: "Floating-SOFR",
    spread: 200,
    termMonths: 36,
    amortizationType: "Bullet",
    collateralValue: 60000000,
    noi: 0,
    ebitda: 14500000,
    riskStage: "Performing",
    daysPastDue: 0,
    covenantDSCRMin: 0,
    covenantLTVMax: 75.0,
    covenantDebtYieldMin: 0,
    covenantIntCovMin: 3.0,
    pd: 0.8,
    lgd: 35,
    ead: 38000000,
  },
  {
    loanId: "L-006",
    borrower: "Cortex AI Labs Inc",
    propertyOrProject: "Growth term loan — venture debt, Series B startup, San Francisco",
    loanType: "C&I-Tech",
    originationDate: "2024-08-15",
    maturityDate: "2027-08-15",
    originalPrincipal: 25000000,
    currentBalance: 23500000,
    interestRate: 9.50,
    rateType: "Floating-SOFR",
    spread: 550,
    termMonths: 36,
    amortizationType: "Interest-Only",
    collateralValue: 30000000,
    noi: 0,
    ebitda: 4200000,
    riskStage: "Performing",
    daysPastDue: 0,
    covenantDSCRMin: 0,
    covenantLTVMax: 80.0,
    covenantDebtYieldMin: 0,
    covenantIntCovMin: 2.5,
    pd: 2.0,
    lgd: 60,
    ead: 23500000,
  },
  {
    loanId: "L-007",
    borrower: "Bridgepoint Construction LLC",
    propertyOrProject: "Highway 427 expansion — P3 infrastructure project, Ontario",
    loanType: "Construction",
    originationDate: "2024-05-01",
    maturityDate: "2027-05-01",
    originalPrincipal: 75000000,
    currentBalance: 72000000,
    interestRate: 7.00,
    rateType: "Fixed",
    termMonths: 36,
    amortizationType: "Interest-Only",
    collateralValue: 95000000,
    noi: 0,
    ebitda: 0,
    riskStage: "Performing",
    daysPastDue: 0,
    covenantDSCRMin: 0,
    covenantLTVMax: 80.0,
    covenantDebtYieldMin: 0,
    covenantIntCovMin: 0,
    pd: 2.5,
    lgd: 30,
    ead: 72000000,
  },
  {
    loanId: "L-008",
    borrower: "Westside Office Holdings",
    propertyOrProject: "One Bryant Park Office — 180,000 sqft, downtown Chicago",
    loanType: "CRE-Office",
    originationDate: "2022-11-30",
    maturityDate: "2027-11-30",
    originalPrincipal: 95000000,
    currentBalance: 90000000,
    interestRate: 6.75,
    rateType: "Fixed",
    termMonths: 60,
    amortizationType: "P&I",
    collateralValue: 105000000,
    noi: 6100000,
    riskStage: "Substandard",
    daysPastDue: 35,
    covenantDSCRMin: 1.25,
    covenantLTVMax: 75.0,
    covenantDebtYieldMin: 8.0,
    covenantIntCovMin: 0,
    pd: 8.0,
    lgd: 45,
    ead: 90000000,
  },
];

// Compute derived fields for each loan
// Industry practice: CRE P&I loans amortize on 25-30 year schedule even if loan term is shorter (balloon at maturity)
const AMORT_MONTHS_BY_TYPE: Record<LoanType, number> = {
  "CRE-Office": 360,        // 30-year amortization
  "CRE-Retail": 300,        // 25-year amortization
  "CRE-Industrial": 300,
  "CRE-Multifamily": 360,
  "C&I-Manufacturing": 60,  // C&I typically matches term (bullet)
  "C&I-Tech": 36,
  "Construction": 0,        // interest-only during construction
};

const LOANS: Loan[] = rawLoans.map((l) => {
  // Determine amortization period
  const amortMonths = l.amortizationType === "P&I"
    ? (AMORT_MONTHS_BY_TYPE[l.loanType] || l.termMonths)
    : l.termMonths;

  const monthlyPayment = l.amortizationType === "Interest-Only"
    ? Math.round(l.currentBalance * (l.interestRate / 100) / 12 * 100) / 100
    : l.amortizationType === "Bullet"
    ? Math.round(l.currentBalance * (l.interestRate / 100) / 12 * 100) / 100
    : l.amortizationType === "Balloon"
    ? monthlyPaymentPI(l.currentBalance, l.interestRate, Math.min(amortMonths, 360))
    : monthlyPaymentPI(l.currentBalance, l.interestRate, amortMonths);

  // Annual debt service = monthly payment × 12 (for P&I amortizing loans)
  // For interest-only/bullet: just interest expense
  const annualDebtService = l.amortizationType === "Interest-Only" || l.amortizationType === "Bullet"
    ? Math.round(l.currentBalance * (l.interestRate / 100) * 100) / 100
    : Math.round(monthlyPayment * 12 * 100) / 100;

  const computedLTV = ltv(l.currentBalance, l.collateralValue);
  const computedDSCR = l.noi > 0 ? dscr(l.noi, annualDebtService) : 0;
  const computedDebtYield = l.noi > 0 ? debtYield(l.noi, l.currentBalance) : 0;
  const annualInterest = Math.round(l.currentBalance * (l.interestRate / 100) * 100) / 100;
  const computedIntCov = l.ebitda && l.ebitda > 0
    ? Math.round((l.ebitda / annualInterest) * 100) / 100
    : 0;

  // Covenant compliance check
  const covCompliant =
    (l.covenantDSCRMin === 0 || computedDSCR >= l.covenantDSCRMin) &&
    (computedLTV <= l.covenantLTVMax) &&
    (l.covenantDebtYieldMin === 0 || computedDebtYield >= l.covenantDebtYieldMin) &&
    (l.covenantIntCovMin === 0 || computedIntCov >= l.covenantIntCovMin);

  const computedEL = expectedLoss(l.pd, l.lgd, l.ead);

  return {
    ...l,
    monthlyPayment,
    ltv: computedLTV,
    dscr: computedDSCR,
    debtYield: computedDebtYield,
    interestCoverage: computedIntCov,
    covenantsCompliant: covCompliant,
    expectedLoss: computedEL,
  };
});

export const LOAN_PORTFOLIO: Loan[] = LOANS;

// ============ AMORTIZATION SCHEDULES — generate for each P&I loan ============
export type AmortizationRow = {
  month: number;
  date: string;
  beginningBalance: number;
  payment: number;
  interest: number;
  principal: number;
  endingBalance: number;
  cumulativeInterest: number;
  cumulativePrincipal: number;
};

export type LoanAmortizationSchedule = {
  loanId: string;
  borrower: string;
  rows: AmortizationRow[];
  totalPayments: number;
  totalInterest: number;
  totalPrincipal: number;
};

function generateAmortizationSchedule(loan: Loan): LoanAmortizationSchedule {
  const rows: AmortizationRow[] = [];
  let balance = loan.currentBalance;
  const monthlyRate = loan.interestRate / 100 / 12;
  let cumInt = 0;
  let cumPrin = 0;
  const startDate = new Date(loan.originationDate);
  // Use industry-standard amortization months (30-year for CRE) but cap rows at term for display
  const amortMonths = AMORT_MONTHS_BY_TYPE[loan.loanType] || loan.termMonths;
  const rowsToShow = Math.min(amortMonths, loan.termMonths * 12 > 360 ? 360 : 60); // cap display at 60 rows

  for (let m = 1; m <= rowsToShow; m++) {
    const date = new Date(startDate.getFullYear(), startDate.getMonth() + m, 15);
    const interest = Math.round(balance * monthlyRate * 100) / 100;
    let principal: number;
    let payment: number;
    if (loan.amortizationType === "Interest-Only") {
      payment = interest;
      principal = 0;
    } else if (loan.amortizationType === "Bullet") {
      payment = interest;
      principal = 0;
      if (m === rowsToShow) principal = balance;
    } else {
      // P&I based on amortization schedule (e.g., 30 years for CRE) — balloon at loan maturity
      payment = loan.monthlyPayment;
      principal = Math.round((payment - interest) * 100) / 100;
      if (principal > balance) principal = balance;
      // At maturity (loan term months), pay off remaining balance as balloon
      if (m === loan.termMonths) principal = balance;
    }
    const endingBalance = Math.round((balance - principal) * 100) / 100;
    cumInt = Math.round((cumInt + interest) * 100) / 100;
    cumPrin = Math.round((cumPrin + principal) * 100) / 100;
    rows.push({
      month: m,
      date: date.toISOString().slice(0, 10),
      beginningBalance: balance,
      payment,
      interest,
      principal,
      endingBalance,
      cumulativeInterest: cumInt,
      cumulativePrincipal: cumPrin,
    });
    balance = endingBalance;
    if (balance <= 0) break;
  }

  const totalPayments = Math.round(rows.reduce((s, r) => s + r.payment, 0) * 100) / 100;
  const totalInterest = Math.round(rows.reduce((s, r) => s + r.interest, 0) * 100) / 100;
  const totalPrincipal = Math.round(rows.reduce((s, r) => s + r.principal, 0) * 100) / 100;

  return {
    loanId: loan.loanId,
    borrower: loan.borrower,
    rows,
    totalPayments,
    totalInterest,
    totalPrincipal,
  };
}

// Generate schedules only for P&I and Balloon loans (the long ones)
export const AMORTIZATION_SCHEDULES: LoanAmortizationSchedule[] = LOANS
  .filter((l) => l.amortizationType === "P&I" || l.amortizationType === "Balloon")
  .map((l) => generateAmortizationSchedule(l));

// ============ PORTFOLIO SUMMARY ============
export const PORTFOLIO_SUMMARY = (() => {
  const totalCommitted = LOANS.reduce((s, l) => s + l.originalPrincipal, 0);
  const totalOutstanding = LOANS.reduce((s, l) => s + l.currentBalance, 0);
  const weightedAvgRate = Math.round(
    (LOANS.reduce((s, l) => s + l.currentBalance * l.interestRate, 0) / totalOutstanding) * 100
  ) / 100;
  const weightedAvgLTV = Math.round(
    (LOANS.reduce((s, l) => s + l.currentBalance * l.ltv, 0) / totalOutstanding) * 100
  ) / 100;
  const weightedAvgDSCR = (() => {
    const creLoans = LOANS.filter((l) => l.dscr > 0);
    const sumNOI = creLoans.reduce((s, l) => s + l.noi, 0);
    const sumDS = creLoans.reduce((s, l) => s + (l.monthlyPayment * (l.amortizationType === "P&I" ? 12 : 12) + l.currentBalance * (l.interestRate / 100) * (l.amortizationType === "Interest-Only" ? 1 : 0)), 0);
    return Math.round((sumNOI / sumDS) * 100) / 100;
  })();
  const totalExpectedLoss = LOANS.reduce((s, l) => s + l.expectedLoss, 0);
  const totalCollateral = LOANS.reduce((s, l) => s + l.collateralValue, 0);
  const nplCount = LOANS.filter((l) => l.daysPastDue > 90 || l.riskStage === "Substandard" || l.riskStage === "Doubtful" || l.riskStage === "Loss").length;
  const nplBalance = LOANS
    .filter((l) => l.daysPastDue > 90 || l.riskStage === "Substandard" || l.riskStage === "Doubtful" || l.riskStage === "Loss")
    .reduce((s, l) => s + l.currentBalance, 0);
  const nplPct = Math.round((nplBalance / totalOutstanding) * 1000) / 10;
  const covenantBreaches = LOANS.filter((l) => !l.covenantsCompliant).length;
  const watchlistCount = LOANS.filter((l) => l.riskStage === "Watchlist" || l.riskStage === "Substandard").length;
  const portfolioLGD = Math.round(
    (LOANS.reduce((s, l) => s + l.currentBalance * l.lgd, 0) / totalOutstanding) * 100
  ) / 100;
  const portfolioPD = Math.round(
    (LOANS.reduce((s, l) => s + l.currentBalance * l.pd, 0) / totalOutstanding) * 100
  ) / 100;

  return {
    loanCount: LOANS.length,
    totalCommitted,
    totalOutstanding,
    weightedAvgRate,
    weightedAvgLTV,
    weightedAvgDSCR,
    totalExpectedLoss,
    totalCollateral,
    nplCount,
    nplBalance,
    nplPct,
    covenantBreaches,
    watchlistCount,
    portfolioLGD,
    portfolioPD,
  };
})();

// ============ COVENANT COMPLIANCE MATRIX ============
export const COVENANT_MATRIX = LOANS.map((l) => ({
  loanId: l.loanId,
  borrower: l.borrower,
  loanType: l.loanType,
  // DSCR
  dscrActual: l.dscr,
  dscrCovenant: l.covenantDSCRMin,
  dscrHeadroom: l.covenantDSCRMin > 0 ? Math.round((l.dscr - l.covenantDSCRMin) * 100) / 100 : 0,
  dscrStatus: l.covenantDSCRMin === 0 ? "N/A" : l.dscr >= l.covenantDSCRMin ? "Compliant" : "BREACH",
  // LTV
  ltvActual: l.ltv,
  ltvCovenant: l.covenantLTVMax,
  ltvHeadroom: Math.round((l.covenantLTVMax - l.ltv) * 100) / 100,
  ltvStatus: l.ltv <= l.covenantLTVMax ? "Compliant" : "BREACH",
  // Debt Yield
  debtYieldActual: l.debtYield,
  debtYieldCovenant: l.covenantDebtYieldMin,
  debtYieldHeadroom: l.covenantDebtYieldMin > 0 ? Math.round((l.debtYield - l.covenantDebtYieldMin) * 100) / 100 : 0,
  debtYieldStatus: l.covenantDebtYieldMin === 0 ? "N/A" : l.debtYield >= l.covenantDebtYieldMin ? "Compliant" : "BREACH",
  // Interest Coverage
  intCovActual: l.interestCoverage,
  intCovCovenant: l.covenantIntCovMin,
  intCovHeadroom: l.covenantIntCovMin > 0 ? Math.round((l.interestCoverage - l.covenantIntCovMin) * 100) / 100 : 0,
  intCovStatus: l.covenantIntCovMin === 0 ? "N/A" : l.interestCoverage >= l.covenantIntCovMin ? "Compliant" : "BREACH",
  // Overall
  overallStatus: l.covenantsCompliant ? "Compliant" : "BREACH",
}));

// ============ FORMULAS REFERENCE ============
export const LOAN_FORMULAS = {
  monthlyPaymentPI: "P × (r/12) / (1 − (1 + r/12)^(−n))   [P = principal, r = annual rate %, n = term months]",
  interestComponent: "Interest = Beginning Balance × (r/12)",
  principalComponent: "Principal = Monthly Payment − Interest",
  endingBalance: "Ending Balance = Beginning Balance − Principal Component",
  annualDebtService: "Annual Debt Service = Monthly Payment × 12 (for P&I) OR Principal × r (for I/O)",
  dscr: "DSCR = NOI / Annual Debt Service    [covenant min 1.25x typical]",
  ltv: "LTV = Loan Principal / Appraised Collateral Value    [covenant max 75% CRE typical]",
  debtYield: "Debt Yield = NOI / Loan Principal    [covenant min 8% typical]",
  interestCoverage: "Interest Coverage = EBITDA / Interest Expense    [covenant min 3.0x typical]",
  weightedAvgRate: "Portfolio Wtd Avg Rate = Σ(Balance × Rate) / Σ(Balance)",
  weightedAvgLTV: "Portfolio Wtd Avg LTV = Σ(Balance × LTV) / Σ(Balance)",
  nplPct: "NPL % = Σ(NPL Balances) / Σ(Total Balances)",
  expectedLoss: "Expected Loss = PD × LGD × EAD",
  recoveryRate: "Recovery Rate = 1 − LGD",
  pd: "PD = Probability of Default (12-month for Stage 1, lifetime for Stage 2/3)",
  lgd: "LGD = Loss Given Default (% of exposure lost after recoveries)",
  ead: "EAD = Exposure at Default (= current balance for funded loans)",
  covenantHeadroom: "Covenant Headroom = Actual − Covenant Threshold (positive = compliant)",
};

export const LOAN_PORTFOLIO_META = {
  portfolioName: "Meridian Capital Holdings — Loan Portfolio",
  asOfDate: "2026-11-20",
  methodology: "All loans computed using formulas: monthly payment, amortization schedule, DSCR/LTV/Debt Yield/Interest Coverage, expected loss (PD × LGD × EAD), covenant headroom",
  standardsApplied: "IFRS 9 (3-stage ECL) · ASC 326 CECL · FRS 102 s35 · Basel III risk weights · IFRS-EU",
  disclaimer: "All loans fictitious but realistic. Rates as of November 2026 market data. Covenant thresholds per typical loan agreement; modify in covenant column for scenario testing.",
};
