// SAP FICO-style chart of accounts.
// Maps a transaction category (free text) to a GL account code + group.
// Used by the import flow, transactions API, journal entries, and trial balance.

export type AccountGroup = "asset" | "liability" | "equity" | "revenue" | "expense";

export type GLAccount = {
  code: string;        // "1000"
  name: string;        // "Cash & Bank"
  group: AccountGroup; // "asset"
  isContra?: boolean;  // e.g. Accumulated Depreciation is contra-asset (credit balance)
};

// Full SAP FICO-style chart of accounts (1000-9999).
// 1000-1999 Assets, 2000-2999 Liabilities, 3000-3999 Equity,
// 4000-4999 Revenue, 5000-5999 Operating Expenses, 6000-6999 Other Income/Expense, 7000+ Tax
export const CHART_OF_ACCOUNTS: GLAccount[] = [
  // ASSETS (1000-1999) — debit balances
  { code: "1000", name: "Cash & Bank", group: "asset" },
  { code: "1010", name: "Petty Cash", group: "asset" },
  { code: "1020", name: "Checking Account", group: "asset" },
  { code: "1030", name: "Savings Account", group: "asset" },
  { code: "1100", name: "Accounts Receivable", group: "asset" },
  { code: "1150", name: "Allowance for Doubtful Accounts", group: "asset", isContra: true },
  { code: "1200", name: "Notes Receivable", group: "asset" },
  { code: "1300", name: "Interest Receivable", group: "asset" },
  { code: "1400", name: "Inventory / Raw Materials", group: "asset" },
  { code: "1410", name: "Work in Progress", group: "asset" },
  { code: "1420", name: "Finished Goods", group: "asset" },
  { code: "1500", name: "Prepaid Expenses", group: "asset" },
  { code: "1510", name: "Prepaid Insurance", group: "asset" },
  { code: "1600", name: "Property, Plant & Equipment", group: "asset" },
  { code: "1610", name: "Land", group: "asset" },
  { code: "1620", name: "Buildings", group: "asset" },
  { code: "1630", name: "Machinery & Equipment", group: "asset" },
  { code: "1640", name: "Vehicles", group: "asset" },
  { code: "1650", name: "Furniture & Fixtures", group: "asset" },
  { code: "1700", name: "Accumulated Depreciation", group: "asset", isContra: true },
  { code: "1800", name: "Intangible Assets", group: "asset" },
  { code: "1810", name: "Goodwill", group: "asset" },
  { code: "1820", name: "Software & Licenses", group: "asset" },
  { code: "1900", name: "Deferred Tax Asset", group: "asset" },
  // LIABILITIES (2000-2999) — credit balances
  { code: "2000", name: "Accounts Payable", group: "liability" },
  { code: "2100", name: "Accrued Expenses", group: "liability" },
  { code: "2110", name: "Accrued Payroll", group: "liability" },
  { code: "2120", name: "Accrued Interest", group: "liability" },
  { code: "2200", name: "VAT / Sales Tax Payable", group: "liability" },
  { code: "2210", name: "Output VAT", group: "liability" },
  { code: "2220", name: "Input VAT", group: "liability", isContra: true },
  { code: "2300", name: "Payroll Liabilities", group: "liability" },
  { code: "2310", name: "PAYE / Withholding Tax", group: "liability" },
  { code: "2320", name: "Pension Contributions Payable", group: "liability" },
  { code: "2400", name: "Deferred Revenue", group: "liability" },
  { code: "2500", name: "Long-Term Debt", group: "liability" },
  { code: "2510", name: "Bank Loan", group: "liability" },
  { code: "2520", name: "Mortgage Payable", group: "liability" },
  { code: "2600", name: "Lease Liability (IFRS 16)", group: "liability" },
  { code: "2700", name: "Deferred Tax Liability", group: "liability" },
  { code: "2800", name: "Provisions", group: "liability" },
  { code: "2810", name: "Provision for Warranties", group: "liability" },
  { code: "2820", name: "Provision for Litigation", group: "liability" },
  // EQUITY (3000-3999) — credit balances
  { code: "3000", name: "Share Capital", group: "equity" },
  { code: "3100", name: "Retained Earnings", group: "equity" },
  { code: "3200", name: "Share Premium", group: "equity" },
  { code: "3300", name: "Treasury Stock", group: "equity", isContra: true },
  { code: "3400", name: "Other Reserves", group: "equity" },
  { code: "3500", name: "Current Year Net Profit", group: "equity" },
  { code: "3600", name: "Non-Controlling Interest", group: "equity" },
  // REVENUE (4000-4999) — credit balances
  { code: "4000", name: "Product Revenue", group: "revenue" },
  { code: "4010", name: "Service Revenue", group: "revenue" },
  { code: "4020", name: "Subscription Revenue", group: "revenue" },
  { code: "4030", name: "Contract Revenue", group: "revenue" },
  { code: "4040", name: "Rental Income", group: "revenue" },
  { code: "4050", name: "Consulting Revenue", group: "revenue" },
  { code: "4060", name: "Interest Income", group: "revenue" },
  { code: "4070", name: "API Revenue", group: "revenue" },
  { code: "4080", name: "Online Sales", group: "revenue" },
  { code: "4090", name: "In-Store Sales", group: "revenue" },
  { code: "4100", name: "Change Order Revenue", group: "revenue" },
  { code: "4110", name: "Implementation", group: "revenue" },
  { code: "4120", name: "Usage Revenue", group: "revenue" },
  { code: "4130", name: "Progress Billing", group: "revenue" },
  { code: "4140", name: "Equipment Sales", group: "revenue" },
  { code: "4150", name: "Gift Card Revenue", group: "revenue" },
  { code: "4160", name: "Property Sales", group: "revenue" },
  { code: "4170", name: "Management Fees", group: "revenue" },
  { code: "4180", name: "Research Grant", group: "revenue" },
  // EXPENSES — COGS (5000-5199)
  { code: "5000", name: "Cost of Goods Sold (COGS)", group: "expense" },
  { code: "5010", name: "Raw Materials", group: "expense" },
  { code: "5020", name: "Direct Labor", group: "expense" },
  { code: "5030", name: "Manufacturing Overhead", group: "expense" },
  { code: "5040", name: "Materials", group: "expense" },
  { code: "5050", name: "Subcontractors", group: "expense" },
  { code: "5060", name: "Equipment Rental", group: "expense" },
  { code: "5070", name: "Inventory", group: "expense" },
  { code: "5080", name: "Compute (GPU)", group: "expense" },
  // OPERATING EXPENSES (5200-5999)
  { code: "5200", name: "Payroll & Salaries", group: "expense" },
  { code: "5210", name: "Employee Benefits", group: "expense" },
  { code: "5300", name: "Rent", group: "expense" },
  { code: "5400", name: "Utilities", group: "expense" },
  { code: "5500", name: "Marketing & Advertising", group: "expense" },
  { code: "5510", name: "Sales Commission", group: "expense" },
  { code: "5600", name: "Software & Subscriptions", group: "expense" },
  { code: "5610", name: "Hosting & Infrastructure", group: "expense" },
  { code: "5620", name: "AWS Infrastructure", group: "expense" },
  { code: "5700", name: "Insurance", group: "expense" },
  { code: "5710", name: "Bond Premium", group: "expense" },
  { code: "5720", name: "Permits", group: "expense" },
  { code: "5730", name: "Fuel", group: "expense" },
  { code: "5800", name: "Travel & Entertainment", group: "expense" },
  { code: "5900", name: "Office Supplies", group: "expense" },
  { code: "5910", name: "Bank Fees", group: "expense" },
  { code: "5920", name: "Payment Processing Fees", group: "expense" },
  { code: "5930", name: "Returns", group: "expense" },
  { code: "5940", name: "Packaging", group: "expense" },
  { code: "5950", name: "Shipping", group: "expense" },
  { code: "5960", name: "Cleaning", group: "expense" },
  { code: "5970", name: "Repairs & Maintenance", group: "expense" },
  { code: "5980", name: "Property Maintenance", group: "expense" },
  { code: "5985", name: "Landscape", group: "expense" },
  { code: "5990", name: "HOA Fees", group: "expense" },
  // OTHER INCOME / EXPENSE (6000-6999)
  { code: "6000", name: "Tax Expense", group: "expense" },
  { code: "6010", name: "Corporation Tax", group: "expense" },
  { code: "6020", name: "VAT Expense", group: "expense" },
  { code: "6030", name: "Payroll Tax", group: "expense" },
  { code: "6100", name: "Interest Expense", group: "expense" },
  { code: "6110", name: "Mortgage Interest", group: "expense" },
  { code: "6200", name: "Depreciation Expense", group: "expense" },
  { code: "6300", name: "Amortization Expense", group: "expense" },
  { code: "6400", name: "R&D", group: "expense" },
  { code: "6410", name: "Data Licensing", group: "expense" },
  { code: "6500", name: "Legal Fees", group: "expense" },
  { code: "6600", name: "Customer Success", group: "expense" },
  { code: "6700", name: "Office Supplies (Alt)", group: "expense" },
];

// Build a lookup map by name (case-insensitive) for fast category → GL account mapping.
const NAME_INDEX: Map<string, GLAccount> = new Map(
  CHART_OF_ACCOUNTS.map((a) => [a.name.toLowerCase(), a])
);
// Also index common aliases / partial matches
const ALIAS_MAP: Array<{ test: RegExp; account: GLAccount }> = [
  { test: /payroll|salary|wage/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5200")! },
  { test: /aws|google cloud|azure|cloud|hosting|server|infrastructure/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5620")! },
  { test: /stripe|paypal|square|payout/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "4010")! },
  { test: /rent.*property|office rent|retail rent|store rent/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5300")! },
  { test: /advertis|marketing|google ads|facebook|instagram/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5500")! },
  { test: /travel|uber|flight|hotel|taxi/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5800")! },
  { test: /utility|electric|water|gas.*bill/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5400")! },
  { test: /insurance/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5700")! },
  { test: /raw material|steel|concrete|inventory.*purchase/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5040")! },
  { test: /subcontractor/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5050")! },
  { test: /equipment rental|crane|forklift/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5060")! },
  { test: /permit/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5720")! },
  { test: /bond/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5710")! },
  { test: /fuel/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5730")! },
  { test: /refund/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5930")! },
  { test: /annual.*license|software.*license|subscription.*fee/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5600")! },
  { test: /bank fee|wire fee|ach fee/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5910")! },
  { test: /consulting/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "4050")! },
  { test: /equipment.*purchase|machinery/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "1630")! },
  { test: /mortgage interest|interest.*mortgage/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "6110")! },
  { test: /cleaning/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5960")! },
  { test: /plumb|hvac|repair/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5970")! },
  { test: /landscape/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5985")! },
  { test: /datadog|monitoring|saas.*tool/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5600")! },
  { test: /gpu|compute.*spend|p5|p4\.24xlarge/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5080")! },
  { test: /openai|anthropic|api.*spend|huggingface/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5600")! },
  { test: /patent|legal.*fee/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "6500")! },
  { test: /conference|neurips|travel.*conference/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "5800")! },
  { test: /progress.*billing|aia/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "4130")! },
  { test: /shopify|pos.*sales|daily.*sales/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "4090")! },
  { test: /monthly.*mrr|annual.*sub.*renew|enterprise.*sub/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "4020")! },
  { test: /api.*usage|api.*billing/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "4070")! },
  { test: /monthly.*rent.*unit|rent.*collection/i, account: CHART_OF_ACCOUNTS.find((a) => a.code === "4040")! },
];

export function categoryToGLAccount(category: string): GLAccount {
  const lower = category.toLowerCase();
  // Exact match first
  const exact = NAME_INDEX.get(lower);
  if (exact) return exact;
  // Alias regex match
  for (const alias of ALIAS_MAP) {
    if (alias.test.test(category)) return alias.account;
  }
  // Default: revenue if it's an income-ish name, else office supplies
  if (/revenue|sales|income/i.test(category)) {
    return CHART_OF_ACCOUNTS.find((a) => a.code === "4000")!;
  }
  return CHART_OF_ACCOUNTS.find((a) => a.code === "5900")!; // Office Supplies as fallback
}

export function glCodeForCategory(category: string): string {
  return categoryToGLAccount(category).code;
}

export const ACCOUNT_GROUP_LABELS: Record<AccountGroup, string> = {
  asset: "Assets",
  liability: "Liabilities",
  equity: "Equity",
  revenue: "Revenue",
  expense: "Expenses",
};

export const ACCOUNT_GROUP_COLOR: Record<AccountGroup, string> = {
  asset: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
  liability: "bg-rose-500/15 text-rose-700 dark:text-rose-300",
  equity: "bg-violet-500/15 text-violet-700 dark:text-violet-300",
  revenue: "bg-blue-500/15 text-blue-700 dark:text-blue-300",
  expense: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
};
