// Driver Tree & Scenario Engine
// Macro drivers → Revenue/Cost/OpEx → EBITDA & Net Income | 4 scenarios: Base, Bull, Bear, Stress
//
// All outputs driven by the 14 blue-cell assumptions per scenario.
// Modify any assumption to see downstream impact on revenue, profitability, and cash flow.
//
// SEED: Meridian Capital Holdings FY2023A segment revenues (from 3-statement model):
//   Lending $290.34M, Construction $249.25M, Real Estate $122.83M, AI SaaS $197.68M

export type Scenario = "Base" | "Bull" | "Bear" | "Stress";

export type ScenarioAssumption = {
  driver: string;
  category: "Macro" | "Segment Growth" | "Cost Structure" | "Capital & Tax";
  base: number;
  bull: number;
  bear: number;
  stress: number;
  unit: string;
  formula: string;
};

// ============ SCENARIO ASSUMPTIONS (14 drivers × 4 scenarios) ============
export const SCENARIO_ASSUMPTIONS: ScenarioAssumption[] = [
  // Macro Drivers
  { driver: "Real GDP Growth", category: "Macro", base: 2.5, bull: 3.5, bear: 1.0, stress: -2.0, unit: "%", formula: "Macro input — informs segment growth via elasticity" },
  { driver: "Inflation (CPI)", category: "Macro", base: 3.0, bull: 2.0, bear: 4.5, stress: 7.0, unit: "%", formula: "Macro input — informs cost structure via price inflation" },
  { driver: "Fed Funds Rate", category: "Macro", base: 4.5, bull: 3.0, bear: 6.0, stress: 7.5, unit: "%", formula: "Macro input — informs cost of debt via spread + benchmark" },
  { driver: "USD/GBP FX", category: "Macro", base: 0.79, bull: 0.82, bear: 0.76, stress: 0.72, unit: "GBP/USD", formula: "Macro input — informs FX translation on UK sub" },

  // Segment Growth
  { driver: "Lending Segment Growth", category: "Segment Growth", base: 7.0, bull: 10.0, bear: 3.0, stress: -5.0, unit: "%", formula: "Lending Rev[t] = Lending Rev[t-1] × (1 + Growth[t])" },
  { driver: "Construction Segment Growth", category: "Segment Growth", base: 10.0, bull: 13.0, bear: 5.0, stress: -3.0, unit: "%", formula: "Construction Rev[t] = Construction Rev[t-1] × (1 + Growth[t])" },
  { driver: "Real Estate NOI Growth", category: "Segment Growth", base: 5.0, bull: 7.0, bear: 2.0, stress: -4.0, unit: "%", formula: "Real Estate NOI[t] = Real Estate NOI[t-1] × (1 + Growth[t])" },
  { driver: "AI SaaS Segment Growth", category: "Segment Growth", base: 30.0, bull: 40.0, bear: 20.0, stress: 5.0, unit: "%", formula: "AI SaaS Rev[t] = AI SaaS Rev[t-1] × (1 + Growth[t])" },

  // Cost Structure
  { driver: "Direct Cost % of Revenue", category: "Cost Structure", base: 42.0, bull: 40.0, bear: 45.0, stress: 50.0, unit: "%", formula: "Direct Costs[t] = Direct Cost %[t] × Total Revenue[t]" },
  { driver: "S&M % of Revenue", category: "Cost Structure", base: 15.0, bull: 13.0, bear: 17.0, stress: 20.0, unit: "%", formula: "S&M[t] = S&M %[t] × Total Revenue[t]" },
  { driver: "G&A % of Revenue", category: "Cost Structure", base: 8.0, bull: 7.0, bear: 10.0, stress: 12.0, unit: "%", formula: "G&A[t] = G&A %[t] × Total Revenue[t]" },
  { driver: "D&A % of Revenue", category: "Cost Structure", base: 4.0, bull: 3.5, bear: 4.5, stress: 5.0, unit: "%", formula: "D&A[t] = D&A %[t] × Total Revenue[t]" },

  // Capital & Tax
  { driver: "Effective Tax Rate", category: "Capital & Tax", base: 24.5, bull: 23.5, bear: 26.5, stress: 28.0, unit: "%", formula: "Tax[t] = ETR[t] × EBT[t]" },
  { driver: "Cost of Debt", category: "Capital & Tax", base: 6.0, bull: 5.0, bear: 7.5, stress: 9.0, unit: "%", formula: "Interest Exp[t] = Cost of Debt[t] × Avg Debt[t]" },
];

// ============ SEED REVENUES (FY2023A from 3-statement model) ============
const SEED = {
  lending: 290.34,
  construction: 249.25,
  realEstate: 122.83,
  aiSaaS: 197.68,
};

// ============ CONSTANTS ============
const FIXED_RD = 70;        // $M R&D fixed
const TOTAL_DEBT = 400;     // $M total debt for interest calc
const CAPEX_PCT_REV = 0.06; // 6% capex
const NWC_PCT_REV = 0.10;   // 10% NWC change as % of revenue change

// ============ COMPUTE SCENARIO OUTPUTS ============
function computeScenario(scenario: Scenario) {
  const s = scenario;
  const getVal = (a: ScenarioAssumption) =>
    s === "Base" ? a.base : s === "Bull" ? a.bull : s === "Bear" ? a.bear : a.stress;

  const assumptions = SCENARIO_ASSUMPTIONS;
  const lendingGrowth = getVal(assumptions[4]) / 100;
  const constructionGrowth = getVal(assumptions[5]) / 100;
  const realEstateGrowth = getVal(assumptions[6]) / 100;
  const aiSaasGrowth = getVal(assumptions[7]) / 100;
  const directCostPct = getVal(assumptions[8]) / 100;
  const smPct = getVal(assumptions[9]) / 100;
  const gaPct = getVal(assumptions[10]) / 100;
  const daPct = getVal(assumptions[11]) / 100;
  const etr = getVal(assumptions[12]) / 100;
  const costOfDebt = getVal(assumptions[13]) / 100;

  // Segment revenues FY2024E = FY2023A × (1 + growth)
  const lendingRev = Math.round(SEED.lending * (1 + lendingGrowth) * 100) / 100;
  const constructionRev = Math.round(SEED.construction * (1 + constructionGrowth) * 100) / 100;
  const realEstateRev = Math.round(SEED.realEstate * (1 + realEstateGrowth) * 100) / 100;
  const aiSaaSRev = Math.round(SEED.aiSaaS * (1 + aiSaasGrowth) * 100) / 100;
  const totalRevenue = Math.round((lendingRev + constructionRev + realEstateRev + aiSaaSRev) * 100) / 100;

  // Cost structure
  const directCosts = Math.round(totalRevenue * directCostPct * 100) / 100;
  const grossProfit = Math.round((totalRevenue - directCosts) * 100) / 100;
  const grossMarginPct = Math.round((grossProfit / totalRevenue) * 1000) / 10;

  // OpEx
  const sm = Math.round(totalRevenue * smPct * 100) / 100;
  const ga = Math.round(totalRevenue * gaPct * 100) / 100;
  const rd = FIXED_RD; // fixed
  const totalOpEx = Math.round((sm + ga + rd) * 100) / 100;

  // EBITDA
  const ebitda = Math.round((grossProfit - totalOpEx) * 100) / 100;
  const ebitdaMarginPct = Math.round((ebitda / totalRevenue) * 1000) / 10;

  // D&A and EBIT
  const da = Math.round(totalRevenue * daPct * 100) / 100;
  const ebit = Math.round((ebitda - da) * 100) / 100;

  // Interest and Pre-tax
  const interestExpense = Math.round(TOTAL_DEBT * costOfDebt * 100) / 100;
  const ebt = Math.round((ebit - interestExpense) * 100) / 100;

  // Tax and Net Income
  const tax = ebt > 0 ? Math.round(ebt * etr * 100) / 100 : 0;
  const netIncome = Math.round((ebt - tax) * 100) / 100;
  const netMarginPct = Math.round((netIncome / totalRevenue) * 1000) / 10;

  // FCF (simplified): EBITDA - Cash Taxes - Capex - ΔNWC
  const cashTaxes = tax;
  const capex = Math.round(totalRevenue * CAPEX_PCT_REV * 100) / 100;
  const seedTotalRevenue = SEED.lending + SEED.construction + SEED.realEstate + SEED.aiSaaS;
  const deltaNWC = Math.round((totalRevenue - seedTotalRevenue) * NWC_PCT_REV * 100) / 100;
  const fcf = Math.round((ebitda - cashTaxes - capex - deltaNWC) * 100) / 100;

  return {
    scenario: s,
    segmentRevenue: {
      lending: lendingRev,
      construction: constructionRev,
      realEstate: realEstateRev,
      aiSaaS: aiSaaSRev,
    },
    totalRevenue,
    directCosts,
    grossProfit,
    grossMarginPct,
    sm, ga, rd, totalOpEx,
    ebitda, ebitdaMarginPct,
    da, ebit,
    interestExpense,
    ebt,
    tax,
    netIncome,
    netMarginPct,
    capex,
    deltaNWC,
    fcf,
  };
}

export const SCENARIO_OUTPUTS: Record<Scenario, ReturnType<typeof computeScenario>> = {
  Base: computeScenario("Base"),
  Bull: computeScenario("Bull"),
  Bear: computeScenario("Bear"),
  Stress: computeScenario("Stress"),
};

// ============ SCENARIO COMPARISON TABLE (with deltas vs Base) ============
export type ScenarioComparisonRow = {
  lineItem: string;
  base: number | string;
  bull: number | string;
  bear: number | string;
  stress: number | string;
  bullVsBase: number | string;
  bearVsBase: number | string;
  stressVsBase: number | string;
  unit: string;
  isTotal?: boolean;
  isMargin?: boolean;
};

function delta(val: number, base: number): number {
  return Math.round((val - base) * 100) / 100;
}

export const SCENARIO_COMPARISON: ScenarioComparisonRow[] = [
  // Revenue
  { lineItem: "Lending Segment Revenue", base: SCENARIO_OUTPUTS.Base.segmentRevenue.lending, bull: SCENARIO_OUTPUTS.Bull.segmentRevenue.lending, bear: SCENARIO_OUTPUTS.Bear.segmentRevenue.lending, stress: SCENARIO_OUTPUTS.Stress.segmentRevenue.lending, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.segmentRevenue.lending, SCENARIO_OUTPUTS.Base.segmentRevenue.lending), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.segmentRevenue.lending, SCENARIO_OUTPUTS.Base.segmentRevenue.lending), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.segmentRevenue.lending, SCENARIO_OUTPUTS.Base.segmentRevenue.lending), unit: "$M" },
  { lineItem: "Construction Segment Revenue", base: SCENARIO_OUTPUTS.Base.segmentRevenue.construction, bull: SCENARIO_OUTPUTS.Bull.segmentRevenue.construction, bear: SCENARIO_OUTPUTS.Bear.segmentRevenue.construction, stress: SCENARIO_OUTPUTS.Stress.segmentRevenue.construction, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.segmentRevenue.construction, SCENARIO_OUTPUTS.Base.segmentRevenue.construction), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.segmentRevenue.construction, SCENARIO_OUTPUTS.Base.segmentRevenue.construction), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.segmentRevenue.construction, SCENARIO_OUTPUTS.Base.segmentRevenue.construction), unit: "$M" },
  { lineItem: "Real Estate NOI Revenue", base: SCENARIO_OUTPUTS.Base.segmentRevenue.realEstate, bull: SCENARIO_OUTPUTS.Bull.segmentRevenue.realEstate, bear: SCENARIO_OUTPUTS.Bear.segmentRevenue.realEstate, stress: SCENARIO_OUTPUTS.Stress.segmentRevenue.realEstate, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.segmentRevenue.realEstate, SCENARIO_OUTPUTS.Base.segmentRevenue.realEstate), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.segmentRevenue.realEstate, SCENARIO_OUTPUTS.Base.segmentRevenue.realEstate), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.segmentRevenue.realEstate, SCENARIO_OUTPUTS.Base.segmentRevenue.realEstate), unit: "$M" },
  { lineItem: "AI SaaS Segment Revenue", base: SCENARIO_OUTPUTS.Base.segmentRevenue.aiSaaS, bull: SCENARIO_OUTPUTS.Bull.segmentRevenue.aiSaaS, bear: SCENARIO_OUTPUTS.Bear.segmentRevenue.aiSaaS, stress: SCENARIO_OUTPUTS.Stress.segmentRevenue.aiSaaS, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.segmentRevenue.aiSaaS, SCENARIO_OUTPUTS.Base.segmentRevenue.aiSaaS), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.segmentRevenue.aiSaaS, SCENARIO_OUTPUTS.Base.segmentRevenue.aiSaaS), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.segmentRevenue.aiSaaS, SCENARIO_OUTPUTS.Base.segmentRevenue.aiSaaS), unit: "$M" },
  { lineItem: "Total Revenue", base: SCENARIO_OUTPUTS.Base.totalRevenue, bull: SCENARIO_OUTPUTS.Bull.totalRevenue, bear: SCENARIO_OUTPUTS.Bear.totalRevenue, stress: SCENARIO_OUTPUTS.Stress.totalRevenue, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.totalRevenue, SCENARIO_OUTPUTS.Base.totalRevenue), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.totalRevenue, SCENARIO_OUTPUTS.Base.totalRevenue), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.totalRevenue, SCENARIO_OUTPUTS.Base.totalRevenue), unit: "$M", isTotal: true },

  // Costs
  { lineItem: "Direct Costs", base: SCENARIO_OUTPUTS.Base.directCosts, bull: SCENARIO_OUTPUTS.Bull.directCosts, bear: SCENARIO_OUTPUTS.Bear.directCosts, stress: SCENARIO_OUTPUTS.Stress.directCosts, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.directCosts, SCENARIO_OUTPUTS.Base.directCosts), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.directCosts, SCENARIO_OUTPUTS.Base.directCosts), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.directCosts, SCENARIO_OUTPUTS.Base.directCosts), unit: "$M" },
  { lineItem: "Gross Profit", base: SCENARIO_OUTPUTS.Base.grossProfit, bull: SCENARIO_OUTPUTS.Bull.grossProfit, bear: SCENARIO_OUTPUTS.Bear.grossProfit, stress: SCENARIO_OUTPUTS.Stress.grossProfit, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.grossProfit, SCENARIO_OUTPUTS.Base.grossProfit), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.grossProfit, SCENARIO_OUTPUTS.Base.grossProfit), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.grossProfit, SCENARIO_OUTPUTS.Base.grossProfit), unit: "$M", isTotal: true },

  // OpEx
  { lineItem: "Sales & Marketing", base: SCENARIO_OUTPUTS.Base.sm, bull: SCENARIO_OUTPUTS.Bull.sm, bear: SCENARIO_OUTPUTS.Bear.sm, stress: SCENARIO_OUTPUTS.Stress.sm, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.sm, SCENARIO_OUTPUTS.Base.sm), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.sm, SCENARIO_OUTPUTS.Base.sm), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.sm, SCENARIO_OUTPUTS.Base.sm), unit: "$M" },
  { lineItem: "G&A", base: SCENARIO_OUTPUTS.Base.ga, bull: SCENARIO_OUTPUTS.Bull.ga, bear: SCENARIO_OUTPUTS.Bear.ga, stress: SCENARIO_OUTPUTS.Stress.ga, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.ga, SCENARIO_OUTPUTS.Base.ga), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.ga, SCENARIO_OUTPUTS.Base.ga), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.ga, SCENARIO_OUTPUTS.Base.ga), unit: "$M" },
  { lineItem: "R&D (fixed $70M)", base: SCENARIO_OUTPUTS.Base.rd, bull: SCENARIO_OUTPUTS.Bull.rd, bear: SCENARIO_OUTPUTS.Bear.rd, stress: SCENARIO_OUTPUTS.Stress.rd, bullVsBase: 0, bearVsBase: 0, stressVsBase: 0, unit: "$M" },
  { lineItem: "Total OpEx", base: SCENARIO_OUTPUTS.Base.totalOpEx, bull: SCENARIO_OUTPUTS.Bull.totalOpEx, bear: SCENARIO_OUTPUTS.Bear.totalOpEx, stress: SCENARIO_OUTPUTS.Stress.totalOpEx, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.totalOpEx, SCENARIO_OUTPUTS.Base.totalOpEx), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.totalOpEx, SCENARIO_OUTPUTS.Base.totalOpEx), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.totalOpEx, SCENARIO_OUTPUTS.Base.totalOpEx), unit: "$M", isTotal: true },

  // EBITDA
  { lineItem: "EBITDA", base: SCENARIO_OUTPUTS.Base.ebitda, bull: SCENARIO_OUTPUTS.Bull.ebitda, bear: SCENARIO_OUTPUTS.Bear.ebitda, stress: SCENARIO_OUTPUTS.Stress.ebitda, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.ebitda, SCENARIO_OUTPUTS.Base.ebitda), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.ebitda, SCENARIO_OUTPUTS.Base.ebitda), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.ebitda, SCENARIO_OUTPUTS.Base.ebitda), unit: "$M", isTotal: true },
  { lineItem: "EBITDA Margin %", base: SCENARIO_OUTPUTS.Base.ebitdaMarginPct, bull: SCENARIO_OUTPUTS.Bull.ebitdaMarginPct, bear: SCENARIO_OUTPUTS.Bear.ebitdaMarginPct, stress: SCENARIO_OUTPUTS.Stress.ebitdaMarginPct, bullVsBase: Math.round((SCENARIO_OUTPUTS.Bull.ebitdaMarginPct - SCENARIO_OUTPUTS.Base.ebitdaMarginPct) * 10) / 10, bearVsBase: Math.round((SCENARIO_OUTPUTS.Bear.ebitdaMarginPct - SCENARIO_OUTPUTS.Base.ebitdaMarginPct) * 10) / 10, stressVsBase: Math.round((SCENARIO_OUTPUTS.Stress.ebitdaMarginPct - SCENARIO_OUTPUTS.Base.ebitdaMarginPct) * 10) / 10, unit: "%", isMargin: true },

  // EBIT
  { lineItem: "D&A", base: SCENARIO_OUTPUTS.Base.da, bull: SCENARIO_OUTPUTS.Bull.da, bear: SCENARIO_OUTPUTS.Bear.da, stress: SCENARIO_OUTPUTS.Stress.da, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.da, SCENARIO_OUTPUTS.Base.da), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.da, SCENARIO_OUTPUTS.Base.da), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.da, SCENARIO_OUTPUTS.Base.da), unit: "$M" },
  { lineItem: "EBIT", base: SCENARIO_OUTPUTS.Base.ebit, bull: SCENARIO_OUTPUTS.Bull.ebit, bear: SCENARIO_OUTPUTS.Bear.ebit, stress: SCENARIO_OUTPUTS.Stress.ebit, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.ebit, SCENARIO_OUTPUTS.Base.ebit), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.ebit, SCENARIO_OUTPUTS.Base.ebit), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.ebit, SCENARIO_OUTPUTS.Base.ebit), unit: "$M", isTotal: true },

  // Interest and Tax
  { lineItem: "Interest Expense (on $400M debt)", base: SCENARIO_OUTPUTS.Base.interestExpense, bull: SCENARIO_OUTPUTS.Bull.interestExpense, bear: SCENARIO_OUTPUTS.Bear.interestExpense, stress: SCENARIO_OUTPUTS.Stress.interestExpense, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.interestExpense, SCENARIO_OUTPUTS.Base.interestExpense), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.interestExpense, SCENARIO_OUTPUTS.Base.interestExpense), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.interestExpense, SCENARIO_OUTPUTS.Base.interestExpense), unit: "$M" },
  { lineItem: "Pre-Tax Income", base: SCENARIO_OUTPUTS.Base.ebt, bull: SCENARIO_OUTPUTS.Bull.ebt, bear: SCENARIO_OUTPUTS.Bear.ebt, stress: SCENARIO_OUTPUTS.Stress.ebt, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.ebt, SCENARIO_OUTPUTS.Base.ebt), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.ebt, SCENARIO_OUTPUTS.Base.ebt), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.ebt, SCENARIO_OUTPUTS.Base.ebt), unit: "$M", isTotal: true },
  { lineItem: "Tax Expense", base: SCENARIO_OUTPUTS.Base.tax, bull: SCENARIO_OUTPUTS.Bull.tax, bear: SCENARIO_OUTPUTS.Bear.tax, stress: SCENARIO_OUTPUTS.Stress.tax, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.tax, SCENARIO_OUTPUTS.Base.tax), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.tax, SCENARIO_OUTPUTS.Base.tax), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.tax, SCENARIO_OUTPUTS.Base.tax), unit: "$M" },
  { lineItem: "Net Income", base: SCENARIO_OUTPUTS.Base.netIncome, bull: SCENARIO_OUTPUTS.Bull.netIncome, bear: SCENARIO_OUTPUTS.Bear.netIncome, stress: SCENARIO_OUTPUTS.Stress.netIncome, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.netIncome, SCENARIO_OUTPUTS.Base.netIncome), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.netIncome, SCENARIO_OUTPUTS.Base.netIncome), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.netIncome, SCENARIO_OUTPUTS.Base.netIncome), unit: "$M", isTotal: true },
  { lineItem: "Net Margin %", base: SCENARIO_OUTPUTS.Base.netMarginPct, bull: SCENARIO_OUTPUTS.Bull.netMarginPct, bear: SCENARIO_OUTPUTS.Bear.netMarginPct, stress: SCENARIO_OUTPUTS.Stress.netMarginPct, bullVsBase: Math.round((SCENARIO_OUTPUTS.Bull.netMarginPct - SCENARIO_OUTPUTS.Base.netMarginPct) * 10) / 10, bearVsBase: Math.round((SCENARIO_OUTPUTS.Bear.netMarginPct - SCENARIO_OUTPUTS.Base.netMarginPct) * 10) / 10, stressVsBase: Math.round((SCENARIO_OUTPUTS.Stress.netMarginPct - SCENARIO_OUTPUTS.Base.netMarginPct) * 10) / 10, unit: "%", isMargin: true },

  // FCF
  { lineItem: "Free Cash Flow (approx)", base: SCENARIO_OUTPUTS.Base.fcf, bull: SCENARIO_OUTPUTS.Bull.fcf, bear: SCENARIO_OUTPUTS.Bear.fcf, stress: SCENARIO_OUTPUTS.Stress.fcf, bullVsBase: delta(SCENARIO_OUTPUTS.Bull.fcf, SCENARIO_OUTPUTS.Base.fcf), bearVsBase: delta(SCENARIO_OUTPUTS.Bear.fcf, SCENARIO_OUTPUTS.Base.fcf), stressVsBase: delta(SCENARIO_OUTPUTS.Stress.fcf, SCENARIO_OUTPUTS.Base.fcf), unit: "$M", isTotal: true },
];

// ============ SENSITIVITY TABLE — Revenue Growth × Direct Cost % ============
// Computes FY2024E Net Income for each combination
const SENS_GROWTH_VALUES = [-5, 0, 5, 8, 10, 15, 20];  // %
const SENS_DC_VALUES = [38, 40, 42, 44, 46, 48];       // %
const BASE_GROWTH = 12.5;  // weighted avg segment growth (base case)
const BASE_DC = 42;        // base case DC%

function computeNetIncomeAtParams(revGrowthPct: number, dcPct: number): number {
  // Use base case for all other assumptions; vary only revGrowth and DC%
  const totalRevSeed = SEED.lending + SEED.construction + SEED.realEstate + SEED.aiSaaS;
  const revenue = totalRevSeed * (1 + revGrowthPct / 100);
  const directCosts = revenue * (dcPct / 100);
  const grossProfit = revenue - directCosts;
  const sm = revenue * 0.15;  // base S&M
  const ga = revenue * 0.08;  // base G&A
  const rd = FIXED_RD;
  const ebitda = grossProfit - sm - ga - rd;
  const da = revenue * 0.04;  // base D&A
  const ebit = ebitda - da;
  const interest = TOTAL_DEBT * 0.06;  // base cost of debt
  const ebt = ebit - interest;
  const tax = ebt > 0 ? ebt * 0.245 : 0;  // base ETR
  return Math.round((ebt - tax) * 100) / 100;
}

export const SENSITIVITY_TABLE = {
  title: "FY2024E Net Income ($M) — Revenue Growth (rows) × Direct Cost % (cols)",
  rowVariable: "Revenue Growth %",
  colVariable: "Direct Cost % of Revenue",
  rowValues: SENS_GROWTH_VALUES,
  colValues: SENS_DC_VALUES,
  baseCaseRow: 10,  // closest to base weighted growth
  baseCaseCol: 42,
  matrix: SENS_GROWTH_VALUES.map(g =>
    SENS_DC_VALUES.map(dc => computeNetIncomeAtParams(g, dc))
  ),
};

// Second sensitivity table: EBITDA Margin × Interest Rate
const SENS_EBITDA_MARGIN_VALUES = [20, 25, 30, 35, 40];  // %
const SENS_INT_RATE_VALUES = [5.0, 6.0, 7.0, 8.0, 9.0];  // %

function computeFCFAtParams(ebitdaMarginPct: number, intRatePct: number): number {
  const totalRevSeed = SEED.lending + SEED.construction + SEED.realEstate + SEED.aiSaaS;
  const revenue = totalRevSeed * 1.10; // 10% growth (base-ish)
  const ebitda = revenue * (ebitdaMarginPct / 100);
  const da = revenue * 0.04;
  const ebit = ebitda - da;
  const interest = TOTAL_DEBT * (intRatePct / 100);
  const ebt = ebit - interest;
  const tax = ebt > 0 ? ebt * 0.245 : 0;
  const capex = revenue * 0.06;
  const fcf = ebitda - tax - capex;
  return Math.round(fcf * 100) / 100;
}

export const SENSITIVITY_TABLE_2 = {
  title: "FY2024E Free Cash Flow ($M) — EBITDA Margin (rows) × Interest Rate (cols)",
  rowVariable: "EBITDA Margin %",
  colVariable: "Interest Rate %",
  rowValues: SENS_EBITDA_MARGIN_VALUES,
  colValues: SENS_INT_RATE_VALUES,
  baseCaseRow: 27,
  baseCaseCol: 6.0,
  matrix: SENS_EBITDA_MARGIN_VALUES.map(m =>
    SENS_INT_RATE_VALUES.map(r => computeFCFAtParams(m, r))
  ),
};

// ============ DRIVER TREE — 5-Level Hierarchy ============
export const DRIVER_TREE = {
  level1: {
    title: "Level 1: Macro Drivers",
    nodes: [
      { name: "GDP Growth", description: "Real GDP growth informs demand elasticity across all segments. +1% GDP → ~+0.8% segment growth (base elasticity).", currentValue: "2.5% (Base)" },
      { name: "Inflation (CPI)", description: "CPI informs cost structure inflation — direct costs, wages, occupancy. +1% CPI → ~+0.6% direct cost ratio.", currentValue: "3.0% (Base)" },
      { name: "Fed Funds Rate", description: "Policy rate informs cost of debt via benchmark + spread. +100bps Fed → +100bps cost of debt (1:1 pass-through).", currentValue: "4.5% (Base)" },
      { name: "USD/GBP FX", description: "FX rate informs UK sub translation. GBP weakening → USD-translated UK revenue increases (translation gain to OCI).", currentValue: "0.79 (Base)" },
    ],
  },
  level2: {
    title: "Level 2: Segment Drivers",
    nodes: [
      { name: "Lending Volume", description: "Loan originations volume — driven by GDP (demand) + Fed rate (pricing). Volume × Yield = Lending Revenue.", formula: "Lending Rev = Avg Loan Balance × Avg Yield" },
      { name: "Construction Backlog", description: "Backlog value × % completion = recognised revenue. Per ASC 606 / IFRS 15 input method (cost-to-cost).", formula: "Construction Rev = Backlog × % Complete" },
      { name: "Property Occupancy", description: "Occupancy × ADR × SQFT = Rental Revenue. NOI = Rental Rev − Property OpEx. Per NAREIT/EPRA definitions.", formula: "NOI = (Occupancy × ADR × SQFT) − Property OpEx" },
      { name: "SaaS ARR Growth", description: "MRR × 12 = ARR. Net new ARR = New + Expansion − Contraction − Churn. NRR >120% top quartile.", formula: "ARR = MRR × 12; NRR = (Start + Exp − Cont − Churn) / Start" },
    ],
  },
  level3: {
    title: "Level 3: Revenue",
    nodes: [
      { name: "Total Revenue", description: "Sum of segment revenues. Revenue = Σ (Volume × Price × Mix) by segment.", formula: "Total Revenue = Lending + Construction + Real Estate + AI SaaS" },
    ],
  },
  level4: {
    title: "Level 4: Profitability",
    nodes: [
      { name: "Gross Profit", description: "Revenue × (1 − Direct Cost %).", formula: "GP = Revenue × (1 − DC%)" },
      { name: "EBITDA", description: "Gross Profit − Operating Expenses (S&M + R&D + G&A).", formula: "EBITDA = GP − (S&M + R&D + G&A)" },
      { name: "EBIT", description: "EBITDA − Depreciation & Amortisation.", formula: "EBIT = EBITDA − D&A" },
      { name: "EBT", description: "EBIT − Interest Expense + Interest Income.", formula: "EBT = EBIT − Int Exp + Int Inc" },
      { name: "Net Income", description: "EBT × (1 − Tax Rate).", formula: "NI = EBT × (1 − ETR)" },
    ],
  },
  level5: {
    title: "Level 5: Cash Flow",
    nodes: [
      { name: "Free Cash Flow", description: "EBITDA − Cash Taxes − Capex − ΔNWC. Cash available to debt & equity holders.", formula: "FCF = EBITDA − Cash Taxes − Capex − ΔNWC" },
    ],
  },
};

// ============ SCENARIO LAWS & STANDARDS APPLIED ============
export const SCENARIO_LAWS = [
  { law: "IAS 1.82 — Presentation of Comprehensive Income", application: "Scenario results presented per IAS 1 — Net Income flows to retained earnings; FCF is non-GAAP but reconciled to CFO." },
  { law: "IAS 7 — Cash Flow Statement (Indirect Method)", application: "FCF computed as EBITDA − Cash Taxes − Capex − ΔNWC per IAS 7 indirect method." },
  { law: "IFRS 15 / ASC 606 — Revenue Recognition", application: "Segment revenue recognised per 5-step model. Construction uses input method (cost-to-cost) per IFRS 15.35." },
  { law: "IAS 21 — Foreign Currency Translation", application: "USD/GBP FX assumption drives translation of UK sub results. CTA routed to OCI (recyclable on disposal)." },
  { law: "IAS 12.47 — Deferred Tax at Enacted Rate", application: "Effective Tax Rate scenario assumption applied at enacted rate per IAS 12.47." },
  { law: "ASC 740-30 — Current Tax Provision", application: "Tax expense computed as EBT × ETR per scenario. Stress case 28% reflects higher rate environment." },
  { law: "IAS 16 / ASC 360 — Property, Plant & Equipment", application: "D&A computed as % of revenue (simplified). Full PP&E roll-forward in 3-Statement Model tab." },
  { law: "IFRS 9 — Financial Instruments (Loan Portfolio)", application: "Cost of Debt scenario assumption feeds into loan portfolio ECL discounting. Stress case 9% increases ECL provisions." },
  { law: "Basel III — CET1 Capital", application: "Stress scenario tests bank capital adequacy. Fed Funds 7.5% + Cost of Debt 9% stress tests portfolio resilience." },
  { law: "OECD Pillar Two — Global Minimum Tax", application: "ETR scenarios respect 15% global minimum. Base 24.5%, Bull 23.5%, Bear 26.5%, Stress 28% — all above 15% Pillar Two floor." },
  { law: "IFRS 9.5.5 — Expected Credit Loss (ECL)", application: "Macro drivers (GDP, Fed rate, inflation) feed into PD/LGD models. Stress case PD × LGD × EAD produces higher expected loss." },
  { law: "FRS 102 s29 — Income Tax (UK)", application: "UK sub scenarios apply FRS 102 s29 for current + deferred tax. Same methodology as IAS 12." },
];

export const DRIVER_TREE_META = {
  title: "Driver Tree & Scenario Engine",
  description: "Macro drivers → Revenue/Cost/OpEx → EBITDA & Net Income | 4 scenarios: Base, Bull, Bear, Stress",
  methodology: "All projections driven by 14 blue-cell scenario assumptions. Modify any assumption to recalculate all four scenarios. Sensitivity tables show Net Income and FCF across two-variable combinations.",
  seedData: "Meridian Capital Holdings FY2023A segment revenues (Lending $290.34M, Construction $249.25M, Real Estate $122.83M, AI SaaS $197.68M) from 3-Statement Model.",
  lastUpdated: "November 2026",
  standards: "IFRS (IAS 1, 7, 12, 16, 21, IFRS 9, 15) · US GAAP (ASC 606, 740, 360) · UK FRS 102 s29 · Basel III · OECD Pillar Two",
};
