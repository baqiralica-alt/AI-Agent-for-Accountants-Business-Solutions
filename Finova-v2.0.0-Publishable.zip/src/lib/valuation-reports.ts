// Comprehensive Valuation Reports — Multi-jurisdictional (USA/UK/EU/Canada)
// Complex tabular reports for CFA, FRM, CA professionals
// Includes: DCF, WACC, Comparables, Precedent Tx, Sensitivity, Football Field
// Per: IFRS (IAS 36 impairment), US GAAP (ASC 350/360/820), UK FRS 102, EU IFRS-EU, Canada ASPE

export type ValReportRow = {
  lineItem: string;
  usa: number | string;
  uk: number | string;
  eu: number | string;
  canada: number | string;
  formula: string;
  standard: string;
  note: string;
};

export type ValSection = {
  title: string;
  standard: string;
  rows: ValReportRow[];
};

// Target company: "TechFlow Solutions UK Ltd" for UK, "Cortex AI Labs Inc" for US,
// "Liffey SaaS Ltd" for EU (Ireland), "MapleTech Solutions Inc" for Canada

export const VALUATION_TARGETS = {
  usa: { name: "Cortex AI Labs Inc", country: "USA", currency: "USD", revenue: 50, ebitda: -3, netIncome: -10, shares: 20, netDebt: 60, pricePerShare: 20 },
  uk: { name: "TechFlow Solutions UK Ltd", country: "UK", currency: "GBP", revenue: 1.195, ebitda: 0.647, netIncome: 0.489, shares: 0.001, netDebt: -0.387, pricePerShare: 489.846 },
  eu: { name: "Liffey SaaS Ltd", country: "Ireland (EU)", currency: "EUR", revenue: 35, ebitda: 7, netIncome: 5, shares: 5, netDebt: 10, pricePerShare: 12 },
  canada: { name: "MapleTech Solutions Inc", country: "Canada", currency: "CAD", revenue: 45, ebitda: 9, netIncome: 6.5, shares: 8, netDebt: 8, pricePerShare: 15 },
};

// ============ 1. WACC COMPUTATION (per jurisdiction) ============
export const WACC_SECTION: ValSection = {
  title: "WACC Computation — CAPM Cost of Equity + After-Tax Cost of Debt",
  standard: "CAPM (Sharpe 1964) · IAS 24 related party · ASC 470-10 disclosure",
  rows: [
    { lineItem: "Risk-Free Rate (10Y Government Bond)", usa: 4.30, uk: 4.15, eu: 2.85, canada: 3.45, formula: "Rf = yield on 10Y sovereign bond at valuation date", standard: "Market data: US Treasury / UK DMO / German Bund / Canada Bond", note: "US 10Y 4.30% (Nov 2026); UK 10Y Gilt 4.15%; German Bund 2.85%; Canada 10Y 3.45%" },
    { lineItem: "Equity Risk Premium (ERP)", usa: 4.41, uk: 4.35, eu: 4.35, canada: 4.35, formula: "ERP = Rm − Rf (implied ERP from Damodaran Nov 2026)", standard: "Damodaran NYU Stern implied ERP methodology", note: "US 4.41% (Nov 1, 2026 update); UK/EU/Canada 4.35% (developed market average)" },
    { lineItem: "Beta (β) — 2yr weekly vs market index", usa: 1.20, uk: 1.15, eu: 1.10, canada: 1.05, formula: "β = Cov(Ri, Rm) / Var(Rm)", standard: "Bloomberg / Refinitiv beta calculation", note: "US: SaaS mature β=1.20; UK: consulting β=1.15; EU: SaaS β=1.10; Canada: tech β=1.05" },
    { lineItem: "Size Premium (by market cap)", usa: 1.10, uk: 2.60, eu: 2.60, canada: 2.60, formula: "Size premium from Kroll 2025 Cost of Capital", standard: "Kroll (formerly Duff & Phelps) 2025", note: "US: Large cap $5-25B → 1.10%; UK/EU/Canada: Mid cap $1-5B → 2.60%" },
    { lineItem: "Country Risk Premium (CRP)", usa: 0.25, uk: 0.30, eu: 0.30, canada: 0.20, formula: "CRP = Sovereign Spread × (σ_equity / σ_sovereign)", standard: "Damodaran country risk methodology", note: "Developed markets: minimal CRP. US 0.25%, UK 0.30% (post-Brexit), EU 0.30%, Canada 0.20%" },
    { lineItem: "Cost of Equity (Re)", usa: 9.59, uk: 9.80, eu: 9.20, canada: 8.85, formula: "Re = Rf + β × ERP + Size Premium + CRP", standard: "CAPM (Sharpe 1964) — CFA Institute methodology", note: "US: 4.30 + 1.20×4.41 + 1.10 + 0.25 = 9.59%; UK: 4.15 + 1.15×4.35 + 2.60 + 0.30 = 9.80%" },
    { lineItem: "Pre-Tax Cost of Debt (Rd)", usa: 6.50, uk: 6.00, eu: 4.50, canada: 5.50, formula: "Rd = Risk-Free + Credit Spread (by rating)", standard: "S&P/Moody's credit spread methodology", note: "US BBB 250bps over 10Y; UK BBB 185bps; EU BBB 165bps; Canada BBB 205bps" },
    { lineItem: "Statutory Tax Rate (T)", usa: 24.5, uk: 25.0, eu: 12.5, canada: 26.5, formula: "Enacted rate at valuation date per IAS 12.47", standard: "IRC §11 / CTA 2010 / Irish TCA / ITA Canada", note: "US: 21% federal + ~5% state; UK: 25% main; Ireland: 12.5% trading; Canada: 15% fed + 11.5% Ontario" },
    { lineItem: "After-Tax Cost of Debt", usa: 4.91, uk: 4.50, eu: 3.94, canada: 4.04, formula: "Rd × (1 − T)", standard: "Modigliani-Miller after-tax adjustment", note: "US: 6.50%×(1−0.245)=4.91%; UK: 6.00%×(1−0.25)=4.50%; Ireland: 4.50%×(1−0.125)=3.94%" },
    { lineItem: "Equity Weight (E/V)", usa: 80, uk: 75, eu: 70, canada: 78, formula: "E/V = Market Cap / (Market Cap + Debt at market)", standard: "WACC weights at market values per Damodaran", note: "US: 80% equity (tech company); UK: 75%; EU: 70% (growth SaaS); Canada: 78%" },
    { lineItem: "Debt Weight (D/V)", usa: 20, uk: 25, eu: 30, canada: 22, formula: "D/V = Debt / (Market Cap + Debt)", standard: "WACC weights at market values", note: "US: 20%; UK: 25%; EU: 30%; Canada: 22%" },
    { lineItem: "WACC", usa: 8.65, uk: 8.40, eu: 7.62, canada: 7.88, formula: "WACC = (E/V × Re) + (D/V × Rd × (1−T))", standard: "WACC formula (Modigliani-Miller) — CFA Level II", note: "US: 0.80×9.59 + 0.20×4.91 = 8.65%; UK: 0.75×9.80 + 0.25×4.50 = 8.40%; EU: 0.70×9.20 + 0.30×3.94 = 7.62%" },
  ],
};

// ============ 2. DCF VALUATION (5-year FCFF + Gordon Growth) ============
export const DCF_SECTION: ValSection = {
  title: "DCF Valuation — 5-Year FCFF + Gordon Growth Terminal Value",
  standard: "FCFF methodology (Damodaran) · IAS 36 impairment test · ASC 350-20 goodwill impairment",
  rows: [
    // Year 1 projection
    { lineItem: "FY1 Revenue ($M)", usa: 65.0, uk: 1.276, eu: 42.0, canada: 52.2, formula: "Revenue[t] = Revenue[t-1] × (1 + Growth[t])", standard: "IFRS 15 / ASC 606 revenue recognition", note: "US: $50M×1.30=$65M (30% SaaS growth); UK: £1.195M×1.067 (6.7%); EU: €35M×1.20; CA: C$45M×1.16" },
    { lineItem: "FY1 EBITDA ($M)", usa: 3.25, uk: 0.667, eu: 6.30, canada: 5.22, formula: "EBITDA = Revenue × EBITDA Margin", standard: "IAS 1.105 presentation", note: "US: 5% margin (early-stage); UK: 52.3% (mature consulting); EU: 15% (SaaS scaling); CA: 10%" },
    { lineItem: "FY1 EBIT ($M)", usa: 0.65, uk: 0.619, eu: 4.62, canada: 3.65, formula: "EBIT = EBITDA − D&A", standard: "IAS 16 depreciation / IAS 38 amortization", note: "D&A: US 4% of rev; UK £48k; EU 4%; CA 3%" },
    { lineItem: "FY1 NOPAT ($M)", usa: 0.49, uk: 0.464, eu: 4.04, canada: 2.68, formula: "NOPAT = EBIT × (1 − Tax Rate)", standard: "IAS 12 enacted rate", note: "US: 0.65×(1−0.245); UK: 0.619×(1−0.25); EU: 4.62×(1−0.125); CA: 3.65×(1−0.265)" },
    { lineItem: "FY1 FCFF ($M)", usa: -2.76, uk: 0.419, eu: 1.24, canada: 0.58, formula: "FCFF = NOPAT + D&A − Capex − ΔNWC", standard: "FCFF methodology (Damodaran) — CFA Level II", note: "US negative (high growth capex); UK positive (mature); EU positive (moderate growth)" },
    // Terminal
    { lineItem: "Terminal FCFF ($M)", usa: 11.8, uk: 0.512, eu: 8.5, canada: 6.2, formula: "FCFF at terminal year (Year 5)", standard: "Gordon Growth Model", note: "Stabilized cash flow at end of explicit forecast" },
    { lineItem: "Terminal Growth Rate (g)", usa: 3.0, uk: 2.5, eu: 2.0, canada: 2.5, formula: "Perpetual growth rate < WACC", standard: "Gordon Growth: g < WACC required", note: "US 3% (long-term GDP); UK 2.5%; EU 2% (lower EU growth); Canada 2.5%" },
    { lineItem: "Terminal Value ($M)", usa: 215.0, uk: 8.53, eu: 152.0, canada: 111.0, formula: "TV = FCFF × (1+g) / (WACC − g)", standard: "Gordon Growth Model — CFA Level I", note: "US: 11.8×1.03/(8.65%−3%)=$215M; UK: 0.512×1.025/(8.40%−2.5%)=£8.53M" },
    { lineItem: "PV of Terminal Value ($M)", usa: 142.0, uk: 5.71, eu: 105.0, canada: 76.0, formula: "PV(TV) = TV / (1+WACC)^5", standard: "Time value of money — CFA Level I", note: "Discount at WACC for 5 years" },
    { lineItem: "Sum of PV(FCFF) ($M)", usa: 10.1, uk: 1.75, eu: 4.2, canada: 2.8, formula: "Σ PV(FCFF_t) for t=1 to 5", standard: "DCF explicit period", note: "Sum of discounted cash flows for 5 explicit years" },
    { lineItem: "Enterprise Value ($M)", usa: 152.1, uk: 7.46, eu: 109.2, canada: 78.8, formula: "EV = Σ PV(FCFF) + PV(TV)", standard: "DCF Enterprise Value", note: "US: 10.1+142.0=152.1; UK: 1.75+5.71=7.46; EU: 4.2+105.0=109.2" },
    { lineItem: "Less: Net Debt ($M)", usa: 60, uk: -0.387, eu: 10, canada: 8, formula: "Net Debt = Total Debt − Cash", standard: "IFRS / ASC 210 balance sheet", note: "US: $60M debt; UK: net cash £0.387M; EU: €10M; CA: C$8M" },
    { lineItem: "Equity Value ($M)", usa: 92.1, uk: 7.85, eu: 99.2, canada: 70.8, formula: "Equity Value = EV − Net Debt", standard: "DCF Equity Value bridge", note: "US: 152.1−60=92.1; UK: 7.46+0.387=7.85 (net cash adds); EU: 109.2−10=99.2" },
    { lineItem: "Value per Share", usa: 4.61, uk: 7850, eu: 19.84, canada: 8.85, formula: "Per Share = Equity Value / Shares Outstanding", standard: "Per share valuation", note: "US: $92.1M/20M=$4.61; UK: £7.85M/0.001M=£7,850 (1,000 shares); EU: €99.2M/5M=€19.84" },
  ],
};

// ============ 3. TRADING COMPARABLES (per jurisdiction peer sets) ============
export const COMPS_SECTION: ValSection = {
  title: "Trading Comparables — EV/Revenue & EV/EBITDA by Jurisdiction",
  standard: "Relative valuation — CFA Level I/II · ASC 820 fair value hierarchy Level 2",
  rows: [
    { lineItem: "Peer Set Size", usa: 5, uk: 4, eu: 5, canada: 4, formula: "Number of comparable public companies", standard: "CFA comparable company analysis", note: "US: SNOW, PLTR, DDOG, MDB, ESTC; UK: SaaS peers on AIM; EU: European SaaS; CA: TSX tech" },
    { lineItem: "EV/Revenue — Low", usa: 7.5, uk: 3.2, eu: 4.0, canada: 3.5, formula: "Min(EV/Revenue) across peer set", standard: "Relative valuation", note: "Lowest multiple in peer set" },
    { lineItem: "EV/Revenue — Mean", usa: 15.8, uk: 5.5, eu: 6.8, canada: 5.0, formula: "Average(EV/Revenue) across peer set", standard: "Mean multiple methodology", note: "US higher (SaaS growth premium); UK/EU/CA more conservative" },
    { lineItem: "EV/Revenue — High", usa: 26.8, uk: 8.0, eu: 10.0, canada: 7.0, formula: "Max(EV/Revenue) across peer set", standard: "Relative valuation", note: "Highest multiple — usually highest-growth peer" },
    { lineItem: "Target Revenue ($M)", usa: 65.0, uk: 1.276, eu: 42.0, canada: 52.2, formula: "Target FY1E Revenue", standard: "IFRS 15 recognized revenue", note: "From DCF projection Year 1" },
    { lineItem: "Implied EV (Low) ($M)", usa: 488, uk: 4.08, eu: 168, canada: 183, formula: "EV = Low Multiple × Target Revenue", standard: "Relative valuation application", note: "US: 7.5×65=$488M; UK: 3.2×1.276=£4.08M" },
    { lineItem: "Implied EV (Mean) ($M)", usa: 1027, uk: 7.02, eu: 286, canada: 261, formula: "EV = Mean Multiple × Target Revenue", standard: "Mean multiple application", note: "US: 15.8×65=$1,027M; EU: 6.8×42=€286M" },
    { lineItem: "Implied EV (High) ($M)", usa: 1742, uk: 10.21, eu: 420, canada: 365, formula: "EV = High Multiple × Target Revenue", standard: "Relative valuation", note: "US: 26.8×65=$1,742M" },
    { lineItem: "Implied Equity (Mean) ($M)", usa: 967, uk: 7.41, eu: 276, canada: 253, formula: "Equity = Implied EV − Net Debt", standard: "Equity bridge", note: "US: 1027−60=967; UK: 7.02+0.387=7.41 (net cash)" },
    { lineItem: "Implied Price/Share (Mean)", usa: 48.35, uk: 7410, eu: 55.20, canada: 31.63, formula: "Price = Implied Equity / Shares", standard: "Per share from comps", note: "US: $967M/20M=$48.35/share; CA: C$253M/8M=C$31.63" },
  ],
};

// ============ 4. PRECEDENT TRANSACTIONS ============
export const PRECEDENT_SECTION: ValSection = {
  title: "Precedent Transactions — M&A Multiples with Control Premium",
  standard: "IFRS 3 business combinations · ASC 805 · Control premium per CFA methodology",
  rows: [
    { lineItem: "Number of Precedent Deals", usa: 5, uk: 4, eu: 5, canada: 3, formula: "Count of comparable M&A transactions", standard: "CFA transaction analysis", note: "US: SaaS M&A; UK: UK tech M&A; EU: European tech; CA: Canadian tech" },
    { lineItem: "EV/Revenue — Low", usa: 5.0, uk: 2.5, eu: 3.0, canada: 3.0, formula: "Min(EV/Revenue) across precedent deals", standard: "Precedent transaction analysis", note: "Lowest M&A multiple (usually smaller/distressed deals)" },
    { lineItem: "EV/Revenue — Median", usa: 11.4, uk: 5.0, eu: 6.0, canada: 4.5, formula: "Median(EV/Revenue) across deals", standard: "Median methodology (less affected by outliers)", note: "Median is preferred over mean for M&A (outlier-sensitive)" },
    { lineItem: "EV/Revenue — High", usa: 18.8, uk: 8.0, eu: 12.0, canada: 7.0, formula: "Max(EV/Revenue) across deals", standard: "Precedent transaction analysis", note: "Highest multiple (usually strategic premium)" },
    { lineItem: "Average Control Premium", usa: 35.2, uk: 28.0, eu: 30.0, canada: 25.0, formula: "Avg Premium = Avg((Offer Price − Unaffected Price) / Unaffected Price)", standard: "Control premium per CFA / Mergerstat", note: "US higher (competitive auctions); Canada lower (smaller market)" },
    { lineItem: "Implied EV (Median) ($M)", usa: 741, uk: 6.38, eu: 252, canada: 235, formula: "EV = Median Multiple × Target Revenue", standard: "Precedent application", note: "US: 11.4×65=$741M; EU: 6.0×42=€252M" },
    { lineItem: "Implied Equity (Median) ($M)", usa: 681, uk: 6.77, eu: 242, canada: 227, formula: "Equity = Implied EV − Net Debt", standard: "Equity bridge with control premium", note: "Includes control premium vs trading comps" },
    { lineItem: "Implied Price/Share (Median)", usa: 34.05, uk: 6770, eu: 48.40, canada: 28.38, formula: "Price = Implied Equity / Shares", standard: "Per share from precedents", note: "US: $681M/20M=$34.05; between trading comps low and high" },
  ],
};

// ============ 5. SENSITIVITY ANALYSIS ============
export const SENSITIVITY_SECTION: ValSection = {
  title: "Sensitivity Analysis — WACC × Terminal Growth Rate → Value per Share",
  standard: "CFA Level II sensitivity analysis · IAS 36 value-in-use sensitivity disclosure",
  rows: [
    { lineItem: "WACC = 7.5%, g = 2.0%", usa: 8.25, uk: 14.2, eu: 28.5, canada: 15.2, formula: "DCF per share at WACC=7.5%, g=2%", standard: "Two-way data table", note: "Lower WACC + lower g → moderate per share" },
    { lineItem: "WACC = 8.0%, g = 2.5%", usa: 6.50, uk: 11.8, eu: 24.0, canada: 12.8, formula: "DCF per share at WACC=8.0%, g=2.5%", standard: "Two-way data table", note: "Slightly higher WACC, slightly higher g" },
    { lineItem: "WACC = 8.65%, g = 3.0% (US Base)", usa: 4.61, uk: 9.5, eu: 19.84, canada: 8.85, formula: "DCF per share at base case WACC and g", standard: "Base case", note: "US base case WACC 8.65%, g 3%. Other jurisdictions use their own base WACC" },
    { lineItem: "WACC = 9.0%, g = 3.5%", usa: 3.80, uk: 7.8, eu: 16.2, canada: 7.2, formula: "DCF per share at WACC=9.0%, g=3.5%", standard: "Two-way data table", note: "Higher WACC, higher g → still lower per share due to WACC dominance" },
    { lineItem: "WACC = 9.5%, g = 4.0%", usa: 3.10, uk: 6.5, eu: 13.5, canada: 5.9, formula: "DCF per share at WACC=9.5%, g=4%", standard: "Two-way data table", note: "High WACC → low valuation. Tests downside" },
    { lineItem: "Sensitivity Range (High − Low)", usa: 5.15, uk: 7.7, eu: 15.0, canada: 9.3, formula: "Range = Max − Min across sensitivity grid", standard: "Sensitivity range disclosure per IAS 36", note: "US: $8.25−$3.10=$5.15 range; wider range = more uncertainty" },
  ],
};

// ============ 6. FOOTBALL FIELD SUMMARY ============
export const FOOTBALL_FIELD_SECTION: ValSection = {
  title: "Football Field — Multi-Method Valuation Range Summary",
  standard: "CFA Level II valuation synthesis · ASC 820 fair value measurement",
  rows: [
    { lineItem: "52-Week Trading Range", usa: 12.0, uk: 4000, eu: 8.0, canada: 10.0, formula: "52-week low / high market price", standard: "Market observable (Level 1 per ASC 820)", note: "Current market trading range" },
    { lineItem: "Trading Comps — EV/Rev Low", usa: 21.4, uk: 3630, eu: 31.6, canada: 21.88, formula: "(Low Multiple × Rev − Net Debt) / Shares", standard: "Level 2 (observable inputs)", note: "Lowest implied per share from trading comps" },
    { lineItem: "Trading Comps — EV/Rev High", usa: 84.1, uk: 9822, eu: 82.0, canada: 44.63, formula: "(High Multiple × Rev − Net Debt) / Shares", standard: "Level 2", note: "Highest implied per share from trading comps" },
    { lineItem: "Precedent Tx — Median", usa: 34.05, uk: 6770, eu: 48.40, canada: 28.38, formula: "(Median Mult × Rev − Net Debt) / Shares", standard: "Level 3 (unobservable, includes control premium)", note: "M&A multiples with control premium" },
    { lineItem: "DCF — Gordon Growth", usa: 4.61, uk: 7850, eu: 19.84, canada: 8.85, formula: "DCF base case per share", standard: "Level 3 (unobservable inputs)", note: "Base case DCF with WACC and terminal growth" },
    { lineItem: "DCF — Sensitivity Low", usa: 3.10, uk: 6500, eu: 13.50, canada: 5.90, formula: "Min DCF per share from sensitivity table", standard: "Level 3 sensitivity", note: "High WACC scenario" },
    { lineItem: "DCF — Sensitivity High", usa: 8.25, uk: 14200, eu: 28.50, canada: 15.20, formula: "Max DCF per share from sensitivity table", standard: "Level 3 sensitivity", note: "Low WACC scenario" },
    { lineItem: "OVERALL LOW", usa: 3.10, uk: 3630, eu: 8.0, canada: 5.90, formula: "Min across all methods", standard: "Conservative valuation", note: "Most conservative value across all methods" },
    { lineItem: "OVERALL MEAN", usa: 24.83, uk: 7280, eu: 33.14, canada: 20.15, formula: "Average across all methods", standard: "Central tendency", note: "Average of all methods — primary valuation indication" },
    { lineItem: "OVERALL HIGH", usa: 84.10, uk: 14200, eu: 82.0, canada: 44.63, formula: "Max across all methods", standard: "Optimistic valuation", note: "Most optimistic value across all methods" },
    { lineItem: "Current Market Price", usa: 20.00, uk: 4898, eu: 12.00, canada: 15.00, formula: "Current trading price", standard: "Level 1 observable", note: "Current share price for comparison" },
    { lineItem: "Implied Upside/(Downside)", usa: 24.2, uk: 48.6, eu: 176.2, canada: 34.3, formula: "(Overall Mean − Current Price) / Current Price × 100", standard: "Upside analysis", note: "US: (24.83−20)/20=24.2% upside; EU: (33.14−12)/12=176.2% upside" },
  ],
};

// ============ 7. LAWS & STANDARDS APPLIED ============
export const VALUATION_LAWS = [
  { law: "IAS 36 — Impairment of Assets", application: "DCF used for impairment testing of goodwill and intangibles. Recoverable amount = higher of FVLCD and Value-in-Use (VIU). Sensitivity disclosure required per IAS 36.134(f)." },
  { law: "ASC 350-20 — Goodwill Impairment (US GAAP)", application: "Goodwill tested at reporting unit level using fair value. DCF supports fair value measurement. Qualitative screen first (ASC 350-20-35-3)." },
  { law: "ASC 360 — Long-Lived Asset Impairment (US GAAP)", application: "DCF for testing long-lived assets for impairment. Step 1: trigger test; Step 2: fair value test." },
  { law: "ASC 820 — Fair Value Measurement (US GAAP)", application: "Valuation hierarchy: Level 1 (market price), Level 2 (observable inputs — comps), Level 3 (unobservable inputs — DCF). Required disclosure for Level 3." },
  { law: "IFRS 13 — Fair Value Measurement (IFRS)", application: "Same hierarchy as ASC 820. Exit price perspective. Level 3 disclosure requires sensitivity analysis." },
  { law: "FRS 102 s9 — Group Accounts (UK)", application: "Goodwill impairment testing per FRS 102 s9. DCF as VIU methodology." },
  { law: "ASPE 3462 — Future Income Taxes (Canada)", application: "Deferred tax on DCF step-ups recognized per ASPE 3462 (private) or IAS 12 (PAE)." },
  { law: "CFA Institute — Global Investment Performance Standards (GIPS)", application: "Valuation methodology per CFA curriculum: DCF (FCFF/FCFE), relative valuation (comps/precedents), asset-based. Football field synthesis." },
  { law: "FRM (GARP) — Risk Management", application: "Sensitivity analysis (WACC × g) for market risk. Stress testing per FRM curriculum: bear/stress scenarios." },
  { law: "ICAEW / CPA Canada — Professional Standards", application: "Valuation engagement per RICS Red Book (UK) / CICBV standards (Canada). Independence, competence, and disclosure requirements." },
];

export const VALUATION_META = {
  title: "Comprehensive Valuation Reports — Multi-Jurisdictional (USA / UK / EU / Canada)",
  subtitle: "Complex tabular reports for CFA, FRM, CA professionals",
  targets: VALUATION_TARGETS,
  sections: ["WACC", "DCF", "Trading Comps", "Precedent Tx", "Sensitivity", "Football Field"],
  lawsCount: 11,
  lastUpdated: "November 2026",
  standards: "IAS 36 · IFRS 13 · ASC 350-20 · ASC 360 · ASC 820 · FRS 102 s9 · ASPE 3462 · CFA GIPS · FRM GARP · RICS Red Book · CICBV",
};
