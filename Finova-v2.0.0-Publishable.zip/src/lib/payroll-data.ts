// Multi-country payroll data — USA, UK, EU (Germany/France/Ireland), Canada
// Per each country's tax laws, social security, pension, and statutory deductions.
//
// Source rates (FY 2025/26 enacted):
//   USA:   Federal income tax progressive (10/12/22/24/32/35/37%), SS 6.2% (wage base $168,600),
//          Medicare 1.45% + 0.9% additional >$200k, FUTA 0.6%, SUTA varies, 401(k) elective
//   UK:    PAYE income tax (20/40/45% — PA £12,570, basic £50,270, higher £125,140),
//          Employee NI 8% (>£12,570), Employer NI 13.8% (>£9,100), pension AE 5% min, SL Plan 1/2
//   Germany: Lohnsteuer progressive (14-45%), Soli 5.5%, Kirchensteuer 8/9%,
//          RV 9.3%, AV 1.65%, KV 7.3%, PV 1.7% (employee share)
//   France: IR progressive (0/11/30/41/45%), CSG/CRDS 9.2%, secu sociale 22% employer,
//          retraite 11.02% employee, complementaire sante
//   Ireland: PAYE 20/40% (standard band €42k single), USC 0.5-8%, PRSI 4% (>€352),
//          employer PRSI 8.25/11.05%
//   Canada: Federal tax progressive (15/20.5/26/29/33% — thresholds $55,867/$111,733/$173,205/$246,752),
//          CPP 5.95% (YMPE $68,500, YAMPE $73,200, basic exemption $3,500), EI 1.64% (max $63,200 insurable),
//          provincial tax (Ontario demo: 5.05/9.15/11.16/12.16/13.16%), RRSP elective

export type PayrollDeduction = {
  label: string;
  rate: number | null;          // null = fixed amount or non-rate-based
  rateStr: string;              // human-readable rate
  employeeShare: number;
  employerShare: number;
  statutory: boolean;
  capped: boolean;
  ytdCap?: number;
  standard: string;             // law reference
  note?: string;
};

export type PayslipEmployee = {
  employeeId: string;
  name: string;
  role: string;
  grossPay: number;             // monthly gross in local currency
  currency: string;
  deductions: PayrollDeduction[];
  netPay: number;
  totalDeductions: number;
  employerCost: number;         // gross + employer contributions
};

export type CountryPayroll = {
  countryCode: string;
  countryName: string;
  flag: string;
  currency: string;
  symbol: string;
  taxYear: string;
  minimumWage: string;
  taxAuthority: string;
  filingFrequency: string;
  payeLabel: string;            // PAYE / Lohnsteuer / IR / Federal income tax
  statutoryStandards: string;
  employees: PayslipEmployee[];
  totals: {
    grossPayroll: number;
    totalEmployeeTax: number;
    totalEmployerContributions: number;
    totalNetPay: number;
    totalEmployerCost: number;
  };
  journalEntry: {
    jeNo: string;
    description: string;
    debitAccount: string;
    creditAccount: string;
    debitAmount: number;
    creditAmount: number;
  };
  laws: {
    name: string;
    description: string;
    reference: string;
  }[];
};

// ============ USA PAYROLL ============
// 6 fictitious employees, CA-based, monthly gross
const usaEmployees: PayslipEmployee[] = [
  // Director — $15,000/mo
  (() => {
    const gross = 15000;
    const fedInc = Math.round(gross * 0.22 * 100) / 100; // 22% bracket effective demo
    const stateInc = Math.round(gross * 0.05 * 100) / 100; // CA 5% demo
    const ssEmp = Math.round(gross * 0.062 * 100) / 100; // 6.2% Social Security (wage base $168,600)
    const medicareEmp = Math.round(gross * 0.0145 * 100) / 100; // 1.45%
    const emp401k = Math.round(gross * 0.05 * 100) / 100; // 5% elective
    const healthIns = 250; // fixed
    const totalDeductions = fedInc + stateInc + ssEmp + medicareEmp + emp401k + healthIns;
    return {
      employeeId: "US-EMP-001",
      name: "Sarah Mitchell",
      role: "Director / CEO",
      grossPay: gross,
      currency: "USD",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.062 + gross * 0.0145 + gross * 0.006 + gross * 0.027 + gross * 0.03 + 250) * 100) / 100,
      deductions: [
        { label: "Federal Income Tax (withholding)", rate: 0.22, rateStr: "22% bracket", employeeShare: fedInc, employerShare: 0, statutory: true, capped: false, standard: "IRC §3402 — Federal Insurance Contributions Act" },
        { label: "California State Income Tax (demo 5%)", rate: 0.05, rateStr: "5.0% demo", employeeShare: stateInc, employerShare: 0, statutory: true, capped: false, standard: "Cal. Rev. & Tax. Code §17001" },
        { label: "Social Security (FICA-OASDI)", rate: 0.062, rateStr: "6.2% (wage base $168,600)", employeeShare: ssEmp, employerShare: ssEmp, statutory: true, capped: true, ytdCap: 168600, standard: "IRC §3101(a) / 3111(a)" },
        { label: "Medicare (FICA-HI)", rate: 0.0145, rateStr: "1.45% (no cap; +0.9% >$200k)", employeeShare: medicareEmp, employerShare: medicareEmp, statutory: true, capped: false, standard: "IRC §3101(b) / 3111(b)" },
        { label: "401(k) elective deferral", rate: 0.05, rateStr: "5% employee (3% employer match)", employeeShare: emp401k, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: false, capped: true, ytdCap: 23000, standard: "IRC §401(k) — ERISA" },
        { label: "Health insurance premium", rate: null, rateStr: "Fixed $250/mo employee + $750 employer", employeeShare: healthIns, employerShare: 750, statutory: false, capped: false, standard: "ACA / ERISA" },
      ],
    };
  })(),
  // Manager — $8,000/mo
  (() => {
    const gross = 8000;
    const fedInc = Math.round(gross * 0.22 * 100) / 100;
    const stateInc = Math.round(gross * 0.05 * 100) / 100;
    const ssEmp = Math.round(gross * 0.062 * 100) / 100;
    const medicareEmp = Math.round(gross * 0.0145 * 100) / 100;
    const emp401k = Math.round(gross * 0.05 * 100) / 100;
    const healthIns = 200;
    const totalDeductions = fedInc + stateInc + ssEmp + medicareEmp + emp401k + healthIns;
    return {
      employeeId: "US-EMP-002",
      name: "James Wilson",
      role: "Operations Manager",
      grossPay: gross,
      currency: "USD",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.062 + gross * 0.0145 + gross * 0.006 + gross * 0.027 + gross * 0.03 + 200) * 100) / 100,
      deductions: [
        { label: "Federal Income Tax (withholding)", rate: 0.22, rateStr: "22% bracket", employeeShare: fedInc, employerShare: 0, statutory: true, capped: false, standard: "IRC §3402" },
        { label: "California State Income Tax", rate: 0.05, rateStr: "5.0% demo", employeeShare: stateInc, employerShare: 0, statutory: true, capped: false, standard: "Cal. Rev. & Tax. Code §17001" },
        { label: "Social Security (FICA-OASDI)", rate: 0.062, rateStr: "6.2%", employeeShare: ssEmp, employerShare: ssEmp, statutory: true, capped: true, ytdCap: 168600, standard: "IRC §3101(a) / 3111(a)" },
        { label: "Medicare (FICA-HI)", rate: 0.0145, rateStr: "1.45%", employeeShare: medicareEmp, employerShare: medicareEmp, statutory: true, capped: false, standard: "IRC §3101(b) / 3111(b)" },
        { label: "401(k) elective deferral", rate: 0.05, rateStr: "5% (3% match)", employeeShare: emp401k, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: false, capped: true, ytdCap: 23000, standard: "IRC §401(k)" },
        { label: "Health insurance premium", rate: null, rateStr: "Fixed $200/mo + $600 employer", employeeShare: healthIns, employerShare: 600, statutory: false, capped: false, standard: "ACA" },
      ],
    };
  })(),
  // Analyst — $5,500/mo
  (() => {
    const gross = 5500;
    const fedInc = Math.round(gross * 0.12 * 100) / 100; // 12% bracket demo
    const stateInc = Math.round(gross * 0.04 * 100) / 100;
    const ssEmp = Math.round(gross * 0.062 * 100) / 100;
    const medicareEmp = Math.round(gross * 0.0145 * 100) / 100;
    const emp401k = Math.round(gross * 0.05 * 100) / 100;
    const healthIns = 150;
    const totalDeductions = fedInc + stateInc + ssEmp + medicareEmp + emp401k + healthIns;
    return {
      employeeId: "US-EMP-003",
      name: "Emily Chen",
      role: "Senior Analyst",
      grossPay: gross,
      currency: "USD",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.062 + gross * 0.0145 + gross * 0.006 + gross * 0.027 + gross * 0.03 + 150) * 100) / 100,
      deductions: [
        { label: "Federal Income Tax", rate: 0.12, rateStr: "12% bracket", employeeShare: fedInc, employerShare: 0, statutory: true, capped: false, standard: "IRC §3402" },
        { label: "California State Income Tax", rate: 0.04, rateStr: "4.0% demo", employeeShare: stateInc, employerShare: 0, statutory: true, capped: false, standard: "Cal. Rev. & Tax. Code §17001" },
        { label: "Social Security (FICA-OASDI)", rate: 0.062, rateStr: "6.2%", employeeShare: ssEmp, employerShare: ssEmp, statutory: true, capped: true, ytdCap: 168600, standard: "IRC §3101(a) / 3111(a)" },
        { label: "Medicare (FICA-HI)", rate: 0.0145, rateStr: "1.45%", employeeShare: medicareEmp, employerShare: medicareEmp, statutory: true, capped: false, standard: "IRC §3101(b)" },
        { label: "401(k) elective deferral", rate: 0.05, rateStr: "5%", employeeShare: emp401k, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: false, capped: true, ytdCap: 23000, standard: "IRC §401(k)" },
        { label: "Health insurance premium", rate: null, rateStr: "Fixed $150/mo + $450 employer", employeeShare: healthIns, employerShare: 450, statutory: false, capped: false, standard: "ACA" },
      ],
    };
  })(),
];

// ============ UK PAYROLL (TechFlow Solutions Ltd — December 2025) ============
const ukEmployees: PayslipEmployee[] = [
  // Director — £8,000/mo
  (() => {
    const gross = 8000;
    // Annual salary £96,000 → monthly £8,000. Above PA £12,570 annual = £1,047.50/mo PA
    const pa = 1047.50;
    const taxableMonthly = gross - pa; // £6,952.50
    // Basic rate 20% on first (£50,270-£12,570)/12 = £3,141.67
    const basic = Math.round(3141.67 * 0.20 * 100) / 100;
    // Higher rate 40% on remainder
    const higher = Math.round((taxableMonthly - 3141.67) * 0.40 * 100) / 100;
    const paye = Math.round((basic + higher) * 100) / 100;
    // Employee NI 8% on earnings >£12,570 annual = >£1,047.50/mo
    const niEmp = Math.round((gross - 1047.50) * 0.08 * 100) / 100;
    // Pension AE 5%
    const pensionEmp = Math.round(gross * 0.05 * 100) / 100;
    // Student loan Plan 1 — 9% on earnings >£24,990 annual = >£2,082.50/mo
    const studentLoan = Math.round((gross - 2082.50) * 0.09 * 100) / 100;
    const totalDeductions = paye + niEmp + pensionEmp + studentLoan;
    return {
      employeeId: "UK-EMP-001",
      name: "Director",
      role: "Director",
      grossPay: gross,
      currency: "GBP",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.138 + gross * 0.03) * 100) / 100, // 13.8% Er NI + 3% pension
      deductions: [
        { label: "PAYE Income Tax (basic 20% + higher 40%)", rate: null, rateStr: "20% / 40% bands", employeeShare: paye, employerShare: 0, statutory: true, capped: false, standard: "ITEPA 2003 s.1 — Income Tax (Earnings and Pensions) Act" },
        { label: "Employee National Insurance (Class 1)", rate: 0.08, rateStr: "8% on earnings >£12,570 PA", employeeShare: niEmp, employerShare: Math.round(gross * 0.138 * 100) / 100, statutory: true, capped: false, standard: "SSCBA 1992 s.8 — Social Security Contributions & Benefits Act" },
        { label: "Pension (auto-enrolment)", rate: 0.05, rateStr: "5% employee + 3% employer (min)", employeeShare: pensionEmp, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: true, capped: false, standard: "PA 2008 — Pensions Act 2008 (auto-enrolment)" },
        { label: "Student Loan (Plan 1)", rate: 0.09, rateStr: "9% on earnings >£24,990", employeeShare: studentLoan, employerShare: 0, statutory: true, capped: false, standard: "Education (Student Loans) Act 1998" },
      ],
    };
  })(),
  // Manager — £4,500/mo
  (() => {
    const gross = 4500;
    const pa = 1047.50;
    const taxableMonthly = gross - pa; // £3,452.50
    const basic = Math.round(3141.67 * 0.20 * 100) / 100;
    const higher = Math.round((taxableMonthly - 3141.67) * 0.40 * 100) / 100;
    const paye = Math.round((basic + higher) * 100) / 100;
    const niEmp = Math.round((gross - 1047.50) * 0.08 * 100) / 100;
    const pensionEmp = Math.round(gross * 0.05 * 100) / 100;
    const totalDeductions = paye + niEmp + pensionEmp;
    return {
      employeeId: "UK-EMP-002",
      name: "Manager",
      role: "Operations Manager",
      grossPay: gross,
      currency: "GBP",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.138 + gross * 0.03) * 100) / 100,
      deductions: [
        { label: "PAYE Income Tax", rate: null, rateStr: "20% / 40% bands", employeeShare: paye, employerShare: 0, statutory: true, capped: false, standard: "ITEPA 2003 s.1" },
        { label: "Employee NI (Class 1)", rate: 0.08, rateStr: "8% >£12,570", employeeShare: niEmp, employerShare: Math.round(gross * 0.138 * 100) / 100, statutory: true, capped: false, standard: "SSCBA 1992 s.8" },
        { label: "Pension (auto-enrolment)", rate: 0.05, rateStr: "5% + 3%", employeeShare: pensionEmp, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: true, capped: false, standard: "PA 2008" },
      ],
    };
  })(),
  // Senior Analyst — £3,500/mo
  (() => {
    const gross = 3500;
    const pa = 1047.50;
    const taxableMonthly = gross - pa; // £2,452.50
    const paye = Math.round(taxableMonthly * 0.20 * 100) / 100; // all in basic band
    const niEmp = Math.round((gross - 1047.50) * 0.08 * 100) / 100;
    const pensionEmp = Math.round(gross * 0.05 * 100) / 100;
    const totalDeductions = paye + niEmp + pensionEmp;
    return {
      employeeId: "UK-EMP-003",
      name: "Senior Analyst",
      role: "Senior Analyst",
      grossPay: gross,
      currency: "GBP",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.138 + gross * 0.03) * 100) / 100,
      deductions: [
        { label: "PAYE Income Tax (basic 20%)", rate: 0.20, rateStr: "20% basic band", employeeShare: paye, employerShare: 0, statutory: true, capped: false, standard: "ITEPA 2003 s.1" },
        { label: "Employee NI (Class 1)", rate: 0.08, rateStr: "8%", employeeShare: niEmp, employerShare: Math.round(gross * 0.138 * 100) / 100, statutory: true, capped: false, standard: "SSCBA 1992 s.8" },
        { label: "Pension (auto-enrolment)", rate: 0.05, rateStr: "5% + 3%", employeeShare: pensionEmp, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: true, capped: false, standard: "PA 2008" },
      ],
    };
  })(),
  // Analyst — £2,800/mo
  (() => {
    const gross = 2800;
    const pa = 1047.50;
    const taxableMonthly = gross - pa; // £1,752.50
    const paye = Math.round(taxableMonthly * 0.20 * 100) / 100;
    const niEmp = Math.round((gross - 1047.50) * 0.08 * 100) / 100;
    const pensionEmp = Math.round(gross * 0.05 * 100) / 100;
    const totalDeductions = paye + niEmp + pensionEmp;
    return {
      employeeId: "UK-EMP-004",
      name: "Analyst",
      role: "Analyst",
      grossPay: gross,
      currency: "GBP",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.138 + gross * 0.03) * 100) / 100,
      deductions: [
        { label: "PAYE Income Tax", rate: 0.20, rateStr: "20%", employeeShare: paye, employerShare: 0, statutory: true, capped: false, standard: "ITEPA 2003 s.1" },
        { label: "Employee NI", rate: 0.08, rateStr: "8%", employeeShare: niEmp, employerShare: Math.round(gross * 0.138 * 100) / 100, statutory: true, capped: false, standard: "SSCBA 1992 s.8" },
        { label: "Pension AE", rate: 0.05, rateStr: "5%", employeeShare: pensionEmp, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: true, capped: false, standard: "PA 2008" },
      ],
    };
  })(),
  // Junior — £2,200/mo
  (() => {
    const gross = 2200;
    const pa = 1047.50;
    const taxableMonthly = gross - pa; // £1,152.50
    const paye = Math.round(taxableMonthly * 0.20 * 100) / 100;
    const niEmp = Math.round((gross - 1047.50) * 0.08 * 100) / 100;
    const pensionEmp = Math.round(gross * 0.05 * 100) / 100;
    const totalDeductions = paye + niEmp + pensionEmp;
    return {
      employeeId: "UK-EMP-005",
      name: "Junior",
      role: "Junior Analyst",
      grossPay: gross,
      currency: "GBP",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.138 + gross * 0.03) * 100) / 100,
      deductions: [
        { label: "PAYE Income Tax", rate: 0.20, rateStr: "20%", employeeShare: paye, employerShare: 0, statutory: true, capped: false, standard: "ITEPA 2003 s.1" },
        { label: "Employee NI", rate: 0.08, rateStr: "8%", employeeShare: niEmp, employerShare: Math.round(gross * 0.138 * 100) / 100, statutory: true, capped: false, standard: "SSCBA 1992 s.8" },
        { label: "Pension AE", rate: 0.05, rateStr: "5%", employeeShare: pensionEmp, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: true, capped: false, standard: "PA 2008" },
      ],
    };
  })(),
  // Admin — £2,000/mo
  (() => {
    const gross = 2000;
    const pa = 1047.50;
    const taxableMonthly = gross - pa; // £952.50
    const paye = Math.round(taxableMonthly * 0.20 * 100) / 100;
    const niEmp = Math.round((gross - 1047.50) * 0.08 * 100) / 100;
    const pensionEmp = Math.round(gross * 0.05 * 100) / 100;
    const totalDeductions = paye + niEmp + pensionEmp;
    return {
      employeeId: "UK-EMP-006",
      name: "Admin",
      role: "Administrator",
      grossPay: gross,
      currency: "GBP",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + gross * 0.138 + gross * 0.03) * 100) / 100,
      deductions: [
        { label: "PAYE Income Tax", rate: 0.20, rateStr: "20%", employeeShare: paye, employerShare: 0, statutory: true, capped: false, standard: "ITEPA 2003 s.1" },
        { label: "Employee NI", rate: 0.08, rateStr: "8%", employeeShare: niEmp, employerShare: Math.round(gross * 0.138 * 100) / 100, statutory: true, capped: false, standard: "SSCBA 1992 s.8" },
        { label: "Pension AE", rate: 0.05, rateStr: "5%", employeeShare: pensionEmp, employerShare: Math.round(gross * 0.03 * 100) / 100, statutory: true, capped: false, standard: "PA 2008" },
      ],
    };
  })(),
];

// ============ GERMANY PAYROLL (EU — 3 employees, Munich) ============
const germanyEmployees: PayslipEmployee[] = [
  // Geschäftsführer — €10,000/mo
  (() => {
    const gross = 10000;
    const lohnsteuer = Math.round(gross * 0.30 * 100) / 100; // 30% demo effective
    const soli = Math.round(lohnsteuer * 0.055 * 100) / 100; // 5.5% Soli on Lohnsteuer
    const kirchensteuer = 0; // assumed not church tax payer
    const rv = Math.round(gross * 0.093 * 100) / 100; // 9.3% pension insurance
    const av = Math.round(gross * 0.0165 * 100) / 100; // 1.65% unemployment
    const kv = Math.round(gross * 0.073 * 100) / 100; // 7.3% health insurance
    const pv = Math.round(gross * 0.017 * 100) / 100; // 1.7% long-term care
    const totalDeductions = lohnsteuer + soli + rv + av + kv + pv;
    return {
      employeeId: "DE-EMP-001",
      name: "Herr Schmidt",
      role: "Geschäftsführer (Managing Director)",
      grossPay: gross,
      currency: "EUR",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + rv + av + kv + pv + gross * 0.0145) * 100) / 100, // employer pays matching social + U1/U2
      deductions: [
        { label: "Lohnsteuer (wage tax)", rate: 0.30, rateStr: "30% effective (progressive 14-45%)", employeeShare: lohnsteuer, employerShare: 0, statutory: true, capped: false, standard: "EStG §38 — Einkommensteuergesetz" },
        { label: "Solidaritätszuschlag", rate: 0.055, rateStr: "5.5% of Lohnsteuer", employeeShare: soli, employerShare: 0, statutory: true, capped: false, standard: "SolZG 1995" },
        { label: "Rentenversicherung (RV)", rate: 0.093, rateStr: "9.3% (capped at Beitragsbemessungsgrenze €7,650/mo West)", employeeShare: rv, employerShare: rv, statutory: true, capped: true, ytdCap: 7650 * 12, standard: "SGB VI §228 — Sozialgesetzbuch" },
        { label: "Arbeitslosenversicherung (AV)", rate: 0.0165, rateStr: "1.65% (capped €7,650/mo)", employeeShare: av, employerShare: av, statutory: true, capped: true, ytdCap: 7650 * 12, standard: "SGB III §341" },
        { label: "Krankenversicherung (KV)", rate: 0.073, rateStr: "7.3% (capped €5,175/mo West)", employeeShare: kv, employerShare: kv, statutory: true, capped: true, ytdCap: 5175 * 12, standard: "SGB V §241" },
        { label: "Pflegeversicherung (PV)", rate: 0.017, rateStr: "1.7% (no childless surcharge assumed)", employeeShare: pv, employerShare: pv, statutory: true, capped: false, standard: "SGB XI §55" },
      ],
    };
  })(),
  // Manager — €5,500/mo
  (() => {
    const gross = 5500;
    const lohnsteuer = Math.round(gross * 0.28 * 100) / 100;
    const soli = Math.round(lohnsteuer * 0.055 * 100) / 100;
    const rv = Math.round(gross * 0.093 * 100) / 100;
    const av = Math.round(gross * 0.0165 * 100) / 100;
    const kv = Math.round(gross * 0.073 * 100) / 100;
    const pv = Math.round(gross * 0.017 * 100) / 100;
    const totalDeductions = lohnsteuer + soli + rv + av + kv + pv;
    return {
      employeeId: "DE-EMP-002",
      name: "Frau Müller",
      role: "Betriebsleiter (Operations Manager)",
      grossPay: gross,
      currency: "EUR",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + rv + av + kv + pv + gross * 0.0145) * 100) / 100,
      deductions: [
        { label: "Lohnsteuer", rate: 0.28, rateStr: "28% effective", employeeShare: lohnsteuer, employerShare: 0, statutory: true, capped: false, standard: "EStG §38" },
        { label: "Solidaritätszuschlag", rate: 0.055, rateStr: "5.5% on Lohnsteuer", employeeShare: soli, employerShare: 0, statutory: true, capped: false, standard: "SolZG 1995" },
        { label: "Rentenversicherung (RV)", rate: 0.093, rateStr: "9.3%", employeeShare: rv, employerShare: rv, statutory: true, capped: true, ytdCap: 7650 * 12, standard: "SGB VI" },
        { label: "Arbeitslosenversicherung (AV)", rate: 0.0165, rateStr: "1.65%", employeeShare: av, employerShare: av, statutory: true, capped: true, ytdCap: 7650 * 12, standard: "SGB III" },
        { label: "Krankenversicherung (KV)", rate: 0.073, rateStr: "7.3%", employeeShare: kv, employerShare: kv, statutory: true, capped: true, ytdCap: 5175 * 12, standard: "SGB V" },
        { label: "Pflegeversicherung (PV)", rate: 0.017, rateStr: "1.7%", employeeShare: pv, employerShare: pv, statutory: true, capped: false, standard: "SGB XI" },
      ],
    };
  })(),
  // Sachbearbeiter — €3,200/mo
  (() => {
    const gross = 3200;
    const lohnsteuer = Math.round(gross * 0.18 * 100) / 100;
    const soli = Math.round(lohnsteuer * 0.055 * 100) / 100;
    const rv = Math.round(gross * 0.093 * 100) / 100;
    const av = Math.round(gross * 0.0165 * 100) / 100;
    const kv = Math.round(gross * 0.073 * 100) / 100;
    const pv = Math.round(gross * 0.017 * 100) / 100;
    const totalDeductions = lohnsteuer + soli + rv + av + kv + pv;
    return {
      employeeId: "DE-EMP-003",
      name: "Herr Weber",
      role: "Sachbearbeiter (Clerk)",
      grossPay: gross,
      currency: "EUR",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + rv + av + kv + pv + gross * 0.0145) * 100) / 100,
      deductions: [
        { label: "Lohnsteuer", rate: 0.18, rateStr: "18% effective", employeeShare: lohnsteuer, employerShare: 0, statutory: true, capped: false, standard: "EStG §38" },
        { label: "Solidaritätszuschlag", rate: 0.055, rateStr: "5.5%", employeeShare: soli, employerShare: 0, statutory: true, capped: false, standard: "SolZG 1995" },
        { label: "RV (pension)", rate: 0.093, rateStr: "9.3%", employeeShare: rv, employerShare: rv, statutory: true, capped: true, ytdCap: 7650 * 12, standard: "SGB VI" },
        { label: "AV (unemployment)", rate: 0.0165, rateStr: "1.65%", employeeShare: av, employerShare: av, statutory: true, capped: true, ytdCap: 7650 * 12, standard: "SGB III" },
        { label: "KV (health)", rate: 0.073, rateStr: "7.3%", employeeShare: kv, employerShare: kv, statutory: true, capped: true, ytdCap: 5175 * 12, standard: "SGB V" },
        { label: "PV (long-term care)", rate: 0.017, rateStr: "1.7%", employeeShare: pv, employerShare: pv, statutory: true, capped: false, standard: "SGB XI" },
      ],
    };
  })(),
];

// ============ CANADA PAYROLL (Ontario — 3 employees) ============
// Federal 2025 brackets: 15% ≤$55,867, 20.5% $55,867-$111,733, 26% $111,733-$173,205,
//    29% $173,205-$246,752, 33% >$246,752
// Ontario 2025 brackets: 5.05% ≤$51,446, 9.15% $51,446-$103,458, 11.16% $103,458-$150,000,
//    12.16% $150,000-$220,000, 13.16% >$220,000
// CPP 2025: 5.95% on earnings between $3,500 (basic exemption) and $68,500 (YMPE).
//   Second additional contribution (CPP2): 4% on earnings $68,500-$73,200 (YAMPE).
// EI 2025: 1.64% on insurable earnings up to $63,200 (max premium $1,036.48). Employer 1.4× employee.
const canadaEmployees: PayslipEmployee[] = [
  // Director — C$12,000/mo (annual $144,000)
  (() => {
    const gross = 12000;
    // Federal income tax monthly demo (effective ~24%)
    const fedTax = Math.round(gross * 0.24 * 100) / 100;
    // Ontario provincial tax (effective ~9.15%)
    const provTax = Math.round(gross * 0.0915 * 100) / 100;
    // CPP — monthly salary, but capped annually. Assume employee has hit YMPE in Sept, so partial month
    // For demo: full 5.95% × gross, but capped at YMPE
    const cpp = Math.round(gross * 0.0595 * 100) / 100; // demo (actual calc requires YTD tracking)
    // EI — 1.64% × gross, capped at $63,200 insurable
    const ei = Math.round(gross * 0.0164 * 100) / 100;
    // RRSP elective 5%
    const rrsp = Math.round(gross * 0.05 * 100) / 100;
    const totalDeductions = fedTax + provTax + cpp + ei + rrsp;
    return {
      employeeId: "CA-EMP-001",
      name: "Marie Tremblay",
      role: "Director / CEO",
      grossPay: gross,
      currency: "CAD",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + cpp + ei * 1.4 + gross * 0.04 + gross * 0.02 + gross * 0.0195) * 100) / 100, // CPP match + EI 1.4× + EHT 1.95% ON + WSIB
      deductions: [
        { label: "Federal Income Tax (T4)", rate: 0.24, rateStr: "24% effective (brackets 15/20.5/26/29/33%)", employeeShare: fedTax, employerShare: 0, statutory: true, capped: false, standard: "ITA s.108 — Income Tax Act (Canada)" },
        { label: "Ontario Provincial Income Tax", rate: 0.0915, rateStr: "9.15% effective (brackets 5.05/9.15/11.16/12.16/13.16%)", employeeShare: provTax, employerShare: 0, statutory: true, capped: false, standard: "Taxation Act 2007 (Ontario) s.21" },
        { label: "Canada Pension Plan (CPP) — base + first additional", rate: 0.0595, rateStr: "5.95% (basic exemption $3,500; YMPE $68,500)", employeeShare: cpp, employerShare: cpp, statutory: true, capped: true, ytdCap: 68500, standard: "CPP Act s.12 — Canada Pension Plan" },
        { label: "Employment Insurance (EI)", rate: 0.0164, rateStr: "1.64% (max insurable $63,200; employer 1.4×)", employeeShare: ei, employerShare: Math.round(ei * 1.4 * 100) / 100, statutory: true, capped: true, ytdCap: 63200, standard: "EI Act s.49 — Employment Insurance Act" },
        { label: "RRSP elective deferral", rate: 0.05, rateStr: "5% (annual contribution room demo)", employeeShare: rrsp, employerShare: 0, statutory: false, capped: true, ytdCap: 31210, standard: "ITA s.146 — RRSP contribution room" },
      ],
    };
  })(),
  // Manager — C$6,500/mo (annual $78,000)
  (() => {
    const gross = 6500;
    const fedTax = Math.round(gross * 0.20 * 100) / 100;
    const provTax = Math.round(gross * 0.075 * 100) / 100;
    const cpp = Math.round(gross * 0.0595 * 100) / 100;
    const ei = Math.round(gross * 0.0164 * 100) / 100;
    const rrsp = Math.round(gross * 0.05 * 100) / 100;
    const totalDeductions = fedTax + provTax + cpp + ei + rrsp;
    return {
      employeeId: "CA-EMP-002",
      name: "Daniel O'Brien",
      role: "Operations Manager",
      grossPay: gross,
      currency: "CAD",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + cpp + ei * 1.4 + gross * 0.04 + gross * 0.0195) * 100) / 100,
      deductions: [
        { label: "Federal Income Tax (T4)", rate: 0.20, rateStr: "20% effective", employeeShare: fedTax, employerShare: 0, statutory: true, capped: false, standard: "ITA s.108" },
        { label: "Ontario Provincial Tax", rate: 0.075, rateStr: "7.5% effective", employeeShare: provTax, employerShare: 0, statutory: true, capped: false, standard: "Taxation Act 2007 (Ontario)" },
        { label: "CPP", rate: 0.0595, rateStr: "5.95% (YMPE $68,500)", employeeShare: cpp, employerShare: cpp, statutory: true, capped: true, ytdCap: 68500, standard: "CPP Act s.12" },
        { label: "EI", rate: 0.0164, rateStr: "1.64% (max $63,200 insurable)", employeeShare: ei, employerShare: Math.round(ei * 1.4 * 100) / 100, statutory: true, capped: true, ytdCap: 63200, standard: "EI Act s.49" },
        { label: "RRSP", rate: 0.05, rateStr: "5%", employeeShare: rrsp, employerShare: 0, statutory: false, capped: true, ytdCap: 31210, standard: "ITA s.146" },
      ],
    };
  })(),
  // Analyst — C$4,500/mo (annual $54,000)
  (() => {
    const gross = 4500;
    const fedTax = Math.round(gross * 0.15 * 100) / 100; // 15% bracket
    const provTax = Math.round(gross * 0.0505 * 100) / 100; // 5.05% Ontario lowest
    const cpp = Math.round(gross * 0.0595 * 100) / 100;
    const ei = Math.round(gross * 0.0164 * 100) / 100;
    const rrsp = Math.round(gross * 0.05 * 100) / 100;
    const totalDeductions = fedTax + provTax + cpp + ei + rrsp;
    return {
      employeeId: "CA-EMP-003",
      name: "Sophia Patel",
      role: "Senior Analyst",
      grossPay: gross,
      currency: "CAD",
      netPay: Math.round((gross - totalDeductions) * 100) / 100,
      totalDeductions: Math.round(totalDeductions * 100) / 100,
      employerCost: Math.round((gross + cpp + ei * 1.4 + gross * 0.04 + gross * 0.0195) * 100) / 100,
      deductions: [
        { label: "Federal Income Tax (T4)", rate: 0.15, rateStr: "15% bracket", employeeShare: fedTax, employerShare: 0, statutory: true, capped: false, standard: "ITA s.108" },
        { label: "Ontario Provincial Tax", rate: 0.0505, rateStr: "5.05% lowest bracket", employeeShare: provTax, employerShare: 0, statutory: true, capped: false, standard: "Taxation Act 2007 (Ontario)" },
        { label: "CPP", rate: 0.0595, rateStr: "5.95% (YMPE $68,500)", employeeShare: cpp, employerShare: cpp, statutory: true, capped: true, ytdCap: 68500, standard: "CPP Act s.12" },
        { label: "EI", rate: 0.0164, rateStr: "1.64%", employeeShare: ei, employerShare: Math.round(ei * 1.4 * 100) / 100, statutory: true, capped: true, ytdCap: 63200, standard: "EI Act s.49" },
        { label: "RRSP", rate: 0.05, rateStr: "5%", employeeShare: rrsp, employerShare: 0, statutory: false, capped: true, ytdCap: 31210, standard: "ITA s.146" },
      ],
    };
  })(),
];

// ============ Helper: compute totals for a country's employee list ============
function computeTotals(emps: PayslipEmployee[]) {
  const grossPayroll = emps.reduce((s, e) => s + e.grossPay, 0);
  const totalEmployeeTax = emps.reduce((s, e) => s + e.totalDeductions, 0);
  const totalEmployerContributions = emps.reduce(
    (s, e) => s + (e.employerCost - e.grossPay), 0
  );
  const totalNetPay = emps.reduce((s, e) => s + e.netPay, 0);
  const totalEmployerCost = emps.reduce((s, e) => s + e.employerCost, 0);
  return {
    grossPayroll: Math.round(grossPayroll * 100) / 100,
    totalEmployeeTax: Math.round(totalEmployeeTax * 100) / 100,
    totalEmployerContributions: Math.round(totalEmployerContributions * 100) / 100,
    totalNetPay: Math.round(totalNetPay * 100) / 100,
    totalEmployerCost: Math.round(totalEmployerCost * 100) / 100,
  };
}

// ============ Country payroll wrappers ============
const USA_PAYROLL: CountryPayroll = {
  countryCode: "US",
  countryName: "United States",
  flag: "🇺🇸",
  currency: "USD",
  symbol: "$",
  taxYear: "2025",
  minimumWage: "$7.25/hr federal (varies by state — CA $16.00/hr)",
  taxAuthority: "IRS (federal) + state DOR",
  filingFrequency: "Monthly/Quarterly (Form 941) + Annual (Form 940 + W-2)",
  payeLabel: "Federal Income Tax withholding",
  statutoryStandards: "IRC §§3101, 3111, 3402 (FICA + withholding); ERISA (401k); ACA (healthcare)",
  employees: usaEmployees,
  totals: computeTotals(usaEmployees),
  journalEntry: {
    jeNo: "JE-PAY-US-001",
    description: "Monthly payroll — December 2025 (USA)",
    debitAccount: "6000 — Salaries and Wages (P&L expense, gross)",
    creditAccount: "2300 — PAYE/FICA Payable (BS liability) + 1010 — Cash at Bank (net pay)",
    debitAmount: usaEmployees.reduce((s, e) => s + e.employerCost, 0),
    creditAmount: usaEmployees.reduce((s, e) => s + e.employerCost, 0),
  },
  laws: [
    { name: "Federal Insurance Contributions Act (FICA)", description: "Mandatory payroll tax funding Social Security (6.2%) and Medicare (1.45%) — both employee and employer.", reference: "IRC §§3101, 3111" },
    { name: "Federal Unemployment Tax Act (FUTA)", description: "Employer-only tax 0.6% on first $7,000 wages per employee. Funds federal unemployment.", reference: "IRC §§3301, 3306" },
    { name: "State Unemployment Tax Act (SUTA)", description: "State-level employer-only unemployment tax. Varies by state and experience rating.", reference: "State unemployment codes (varies)" },
    { name: "Affordable Care Act (ACA)", description: "Employer mandate: companies ≥50 FTE must offer minimum essential healthcare coverage.", reference: "ACA §4980H (PPACA 2010)" },
    { name: "Employee Retirement Income Security Act (ERISA)", description: "Governs 401(k) and other employer-sponsored benefit plans. Fiduciary standards, reporting (Form 5500).", reference: "ERISA 1974 (29 USC §1001+)" },
    { name: "Fair Labor Standards Act (FLSA)", description: "Federal minimum wage ($7.25/hr), overtime (1.5× over 40 hrs/week), recordkeeping.", reference: "FLSA 1938 (29 USC §201+)" },
  ],
};

const UK_PAYROLL: CountryPayroll = {
  countryCode: "UK",
  countryName: "United Kingdom",
  flag: "🇬🇧",
  currency: "GBP",
  symbol: "£",
  taxYear: "2025/26",
  minimumWage: "NLW £12.21/hr (age 21+); £9.50/hr (18-20); £7.55/hr (16-17)",
  taxAuthority: "HMRC",
  filingFrequency: "Monthly FPS/EPS via RTI + Annual P60/P35",
  payeLabel: "PAYE Income Tax",
  statutoryStandards: "ITEPA 2003 (PAYE); SSCBA 1992 (NI); PA 2008 (auto-enrolment)",
  employees: ukEmployees,
  totals: computeTotals(ukEmployees),
  journalEntry: {
    jeNo: "JE-PAY-UK-001",
    description: "Monthly payroll — December 2025 (UK)",
    debitAccount: "6000 — Salaries and Wages + 6010 — Employer's NI + 6020 — Pension Contributions",
    creditAccount: "2300 — PAYE/NI Payable + 2400 — Pension Provider Payable + 1010 — Cash at Bank (net pay)",
    debitAmount: ukEmployees.reduce((s, e) => s + e.employerCost, 0),
    creditAmount: ukEmployees.reduce((s, e) => s + e.employerCost, 0),
  },
  laws: [
    { name: "Income Tax (Earnings and Pensions) Act 2003 (ITEPA)", description: "Governs PAYE income tax withholding. Three bands: basic 20% (£12,571-£50,270), higher 40% (£50,271-£125,140), additional 45% (>£125,140).", reference: "ITEPA 2003 c.1" },
    { name: "Social Security Contributions and Benefits Act 1992 (SSCBA)", description: "National Insurance — Class 1 employee 8% above £12,570 PA; employer 13.8% above £9,100 PT.", reference: "SSCBA 1992 c.4" },
    { name: "Pensions Act 2008 (auto-enrolment)", description: "Employer must auto-enrol eligible workers (age 22-SP, earnings >£10,000) into a qualifying pension. Minimum 8% total (5% employee + 3% employer).", reference: "PA 2008 c.30" },
    { name: "National Minimum Wage Act 1998", description: "Statutory minimum hourly pay. National Living Wage £12.21/hr for age 21+ (April 2025).", reference: "NMWA 1998 c.8" },
    { name: "Education (Student Loans) Act 1998", description: "Student loan repayment via PAYE. Plan 1: 9% on earnings >£24,990. Plan 2: 9% on earnings >£27,295.", reference: "ESLA 1998 c.12" },
  ],
};

const GERMANY_PAYROLL: CountryPayroll = {
  countryCode: "DE",
  countryName: "Germany (EU)",
  flag: "🇩🇪",
  currency: "EUR",
  symbol: "€",
  taxYear: "2025 (Kalenderjahr)",
  minimumWage: "€14.60/hr (Mindestlohn 2025)",
  taxAuthority: "Bundeszentralamt für Steuern (BZSt) + Krankenkasse",
  filingFrequency: "Monthly Lohnsteueranmeldung + Annual Lohnsteuerbescheinigung",
  payeLabel: "Lohnsteuer (wage tax)",
  statutoryStandards: "EStG (income tax); SGB III/V/VI/XI (social insurance); SolZG (solidarity)",
  employees: germanyEmployees,
  totals: computeTotals(germanyEmployees),
  journalEntry: {
    jeNo: "JE-PAY-DE-001",
    description: "Monthly payroll — December 2025 (Germany)",
    debitAccount: "6000 — Gehälter (Salaries) + 6010 — Arbeitgeberanteil Sozialversicherung (employer social)",
    creditAccount: "2400 — Lohnsteuer + Social insurance payable + 1010 — Bank (net pay)",
    debitAmount: germanyEmployees.reduce((s, e) => s + e.employerCost, 0),
    creditAmount: germanyEmployees.reduce((s, e) => s + e.employerCost, 0),
  },
  laws: [
    { name: "Einkommensteuergesetz (EStG)", description: "Lohnsteuer (wage tax) — progressive 14-45%. Withheld at source by employer. Bracket split for singles/married. Withholding tables (Lohnsteuertabelle).", reference: "EStG §38" },
    { name: "Solidaritätszuschlaggesetz (SolZG)", description: "Solidarity surcharge 5.5% on income tax. Effectively abolished for 90%+ taxpayers since 2021 (exemption limit €18,130 single).", reference: "SolZG 1995" },
    { name: "Sozialgesetzbuch (SGB) — Sozialversicherung", description: "Statutory social insurance: RV (pension 9.3%+9.3%), AV (unemployment 1.65%+1.65%), KV (health 7.3%+7.3% + Zusatzbeitrag), PV (long-term care 1.7%+1.7% + childless surcharge 0.6%). Capped at Beitragsbemessungsgrenze.", reference: "SGB III, V, VI, XI" },
    { name: "Mindestlohngesetz (MiLoG)", description: "Statutory minimum wage €14.60/hr (2025). Applies to most workers aged 18+.", reference: "MiLoG 2014" },
    { name: "Kirchensteuer", description: "Church tax 8% (Bavaria, Baden-Württemberg) or 9% (other Länder) of income tax. Only for members of recognised churches (Catholic, evangelical).", reference: "Kirchensteuergesetz der Länder" },
  ],
};

const CANADA_PAYROLL: CountryPayroll = {
  countryCode: "CA",
  countryName: "Canada",
  flag: "🇨🇦",
  currency: "CAD",
  symbol: "C$",
  taxYear: "2025",
  minimumWage: "C$17.20/hr Ontario general minimum wage (2025)",
  taxAuthority: "CRA (federal) + provincial Ministry of Finance",
  filingFrequency: "Monthly/semi-monthly remittance + Annual T4 (Feb 28)",
  payeLabel: "Federal Income Tax (T4)",
  statutoryStandards: "ITA (income tax); CPP Act; EI Act; provincial Taxation Acts; EHT (Ontario)",
  employees: canadaEmployees,
  totals: computeTotals(canadaEmployees),
  journalEntry: {
    jeNo: "JE-PAY-CA-001",
    description: "Monthly payroll — December 2025 (Canada — Ontario)",
    debitAccount: "6000 — Salaries and Wages + 6010 — CPP/EI Employer Contributions + 6020 — EHT",
    creditAccount: "2300 — Source Deductions Payable (income tax + CPP + EI) + 1010 — Cash at Bank (net pay)",
    debitAmount: canadaEmployees.reduce((s, e) => s + e.employerCost, 0),
    creditAmount: canadaEmployees.reduce((s, e) => s + e.employerCost, 0),
  },
  laws: [
    { name: "Income Tax Act (Canada) — ITA", description: "Federal income tax progressive: 15% ≤$55,867, 20.5% to $111,733, 26% to $173,205, 29% to $246,752, 33% >$246,752. Withheld at source via TD1 forms.", reference: "ITA s.108 (R.S.C. 1985, c.1, 5th Supp.)" },
    { name: "Canada Pension Plan Act (CPP Act)", description: "CPP contributions: 5.95% on earnings between basic exemption ($3,500) and YMPE ($68,500, 2025). Both employee and employer match. CPP2: 4% on $68,500-$73,200 (YAMPE) for enhanced benefits.", reference: "CPP Act R.S.C. 1985 — s.12" },
    { name: "Employment Insurance Act (EI Act)", description: "EI premiums: employee 1.64% on insurable earnings up to $63,200 (max premium $1,036.48). Employer 1.4× employee premium. Funds unemployment, maternity, sickness benefits.", reference: "EI Act s.49 (S.C. 1996, c.23)" },
    { name: "Provincial Taxation Act (Ontario)", description: "Ontario provincial income tax: 5.05% ≤$51,446, 9.15% to $103,458, 11.16% to $150,000, 12.16% to $220,000, 13.16% >$220,000. Other provinces have different brackets (QC, BC, AB).", reference: "Taxation Act 2007 (Ontario) s.21" },
    { name: "Employer Health Tax (EHT) — Ontario", description: "Employer payroll tax on remuneration: 1.95% on Ontario remuneration exceeding $1M exemption (small employers exempt).", reference: "EHT Act (Ontario) R.S.O. 1990" },
    { name: "Workplace Safety and Insurance Act (WSIB)", description: "Employer-only workplace injury insurance premium. Industry-classified rate; ~2-8% of insurable earnings depending on risk class.", reference: "WSIA 1997 (Ontario)" },
  ],
};

export const ALL_COUNTRY_PAYROLLS: CountryPayroll[] = [
  USA_PAYROLL,
  UK_PAYROLL,
  GERMANY_PAYROLL,
  CANADA_PAYROLL,
];

export const PAYROLL_STATS = {
  totalCountries: ALL_COUNTRY_PAYROLLS.length,
  totalEmployees: ALL_COUNTRY_PAYROLLS.reduce((s, c) => s + c.employees.length, 0),
  taxYearsCovered: ["2025", "2025/26"],
  statutoryFrameworks: "USA: IRC + ERISA + ACA | UK: ITEPA + SSCBA + PA 2008 | EU: EStG + SGB + SolZG | Canada: ITA + CPP Act + EI Act",
  lastUpdated: "November 2026",
};
