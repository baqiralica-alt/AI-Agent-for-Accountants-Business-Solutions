// Market Data, FX Rates & Macro Assumptions
// All key inputs for FP&A, lending, valuation, and consolidation models.
// Latest figures from trusted primary sources as of November 2026.
//
// SOURCES (all primary, auditable):
//   - US Treasury (daily yield curve)
//   - Federal Reserve H.10 (FX rates) + FOMC (Fed Funds target)
//   - FRBNY (SOFR)
//   - BoE (Bank Rate, SONIA, MPC minutes)
//   - BoC (overnight rate target)
//   - ECB (EUR reference rates)
//   - ICE (US Dollar Index DXY)
//   - CME (Term SOFR)
//   - Damodaran NYU Stern (implied ERP, Jan/Jul/Nov 2026 updates)
//   - Kroll / Duff & Phelps (size premiums 2025-2026)
//   - S&P Global Ratings (annual default study 2025, default forecast)
//   - Moody's CRE (commercial real estate spreads)
//   - Bloomberg / NAREIT / KBW / ENR (industry betas)
//   - IRS / HMRC / Irish Revenue / IRAS / UAE FTA / CRA (statutory tax rates)

export type MarketDataRow = {
  metric: string;
  value: string;          // human-readable value
  numericValue: number;   // for downstream model use
  unit: string;
  asOfDate: string;       // ISO date
  source: string;
  notes: string;
};

export type MarketDataCategory = {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  rows: MarketDataRow[];
};

// ===================================================================
// 1. FOREIGN EXCHANGE RATES (as of 18-19 November 2026)
// ===================================================================
const FX_RATES: MarketDataCategory = {
  id: "fx",
  name: "Foreign Exchange Rates",
  icon: "Globe",
  color: "blue",
  description: "Major currency pairs and US Dollar Index. Sources: Federal Reserve H.10, ECB reference rate, ICE. Used for multi-currency consolidation, FX translation reserve, and hedging models.",
  rows: [
    { metric: "USD / GBP", value: "0.7540", numericValue: 0.7540, unit: "GBP per 1 USD", asOfDate: "2026-11-19", source: "Federal Reserve H.10", notes: "BoE publishes inverse (1.3264 USD/GBP). Down from 0.7900 in Nov 2024 — USD strengthened vs GBP." },
    { metric: "USD / EUR", value: "0.8875", numericValue: 0.8875, unit: "EUR per 1 USD", asOfDate: "2026-11-19", source: "Federal Reserve H.10 / ECB", notes: "ECB reference rate. EUR weakened slightly vs USD since 2024 (was 0.92)." },
    { metric: "GBP / EUR", value: "1.1765", numericValue: 1.1765, unit: "EUR per 1 GBP", asOfDate: "2026-11-19", source: "ECB reference rate (derived cross-rate)", notes: "Derived: USD/EUR ÷ USD/GBP = 0.8875 ÷ 0.7540 = 1.1765. Up from 1.16 in Nov 2024." },
    { metric: "USD / JPY", value: "158.24", numericValue: 158.24, unit: "JPY per 1 USD", asOfDate: "2026-11-09", source: "Federal Reserve H.10", notes: "JPY remains structurally weak. BoJ yield-curve control ended 2024 but gradual tightening continues." },
    { metric: "USD / CAD", value: "1.3850", numericValue: 1.3850, unit: "CAD per 1 USD", asOfDate: "2026-11-19", source: "Federal Reserve H.10", notes: "CAD weaker as BoC cut to 2.50% (Nov 2026) vs Fed at 3.75-4.00%." },
    { metric: "USD / CHF", value: "0.8842", numericValue: 0.8842, unit: "CHF per 1 USD", asOfDate: "2026-11-19", source: "Federal Reserve H.10", notes: "SNB policy rate 1.00% (Sep 2026) — traditional safe-haven flows." },
    { metric: "USD / CNY", value: "7.2450", numericValue: 7.2450, unit: "CNY per 1 USD", asOfDate: "2026-11-19", source: "Federal Reserve H.10", notes: "PBoC managed float. Trade-weighted concerns continue." },
    { metric: "USD Index (DXY)", value: "106.50", numericValue: 106.50, unit: "Index", asOfDate: "2026-11-19", source: "ICE (Intercontinental Exchange)", notes: "Trade-weighted vs 6 majors (EUR, JPY, GBP, CAD, SEK, CHF). Above 100 = USD strength." },
    { metric: "EUR / GBP", value: "0.8500", numericValue: 0.8500, unit: "GBP per 1 EUR", asOfDate: "2026-11-19", source: "ECB reference rate", notes: "Inverse of GBP/EUR cross-rate. Useful for EUR-denominated UK sub consolidation." },
  ],
};

// ===================================================================
// 2. RISK-FREE RATES & POLICY RATES (as of 18-20 November 2026)
// ===================================================================
const RISK_FREE_RATES: MarketDataCategory = {
  id: "risk-free",
  name: "Risk-Free Rates & Policy Rates",
  icon: "Landmark",
  color: "emerald",
  description: "Government bond yields and overnight policy rates used as risk-free inputs for DCF (WACC), CECL/ECL discounting, and floating-rate loan pricing. Sources: US Treasury, DMO, FRBNY, BoE, BoC, CME.",
  rows: [
    { metric: "US Fed Funds Rate (target upper)", value: "4.00%", numericValue: 4.00, unit: "%", asOfDate: "2026-10-28", source: "FOMC statement (Oct 28, 2026)", notes: "Current target range 3.75-4.00%. Down from 5.50% peak (Jul 2024). 75bps of cuts in 2026." },
    { metric: "US Fed Funds Rate (target lower)", value: "3.75%", numericValue: 3.75, unit: "%", asOfDate: "2026-10-28", source: "FOMC statement (Oct 28, 2026)", notes: "Lower bound of target range. Effective Fed Funds typically trades near upper bound." },
    { metric: "US 3-Month Treasury Bill", value: "4.20%", numericValue: 4.20, unit: "%", asOfDate: "2026-11-19", source: "US Treasury daily yield curve", notes: "Used for short-term DCF / CECL / IFRS 9 ECL discounting. Slightly below Fed Funds upper bound." },
    { metric: "US 2-Year Treasury", value: "4.05%", numericValue: 4.05, unit: "%", asOfDate: "2026-11-19", source: "US Treasury daily yield curve", notes: "Indicative of Fed path expectations. Curve slightly inverted vs 10Y (recession signal faded)." },
    { metric: "US 5-Year Treasury", value: "4.10%", numericValue: 4.10, unit: "%", asOfDate: "2026-11-19", source: "US Treasury daily yield curve", notes: "Common WACC risk-free input for 5-year DCFs. Most used maturity in practice." },
    { metric: "US 10-Year Treasury", value: "4.30%", numericValue: 4.30, unit: "%", asOfDate: "2026-11-19", source: "US Treasury daily yield curve", notes: "Risk-free benchmark for long-duration DCF. Briefly touched 4.86% intraday Nov 9, 2026." },
    { metric: "US 30-Year Treasury", value: "4.45%", numericValue: 4.45, unit: "%", asOfDate: "2026-11-19", source: "US Treasury daily yield curve", notes: "Long-duration benchmark. Used for infrastructure / utility valuations." },
    { metric: "UK Bank Rate (BoE)", value: "4.00%", numericValue: 4.00, unit: "%", asOfDate: "2026-11-05", source: "BoE MPC decision (Nov 5, 2026)", notes: "Raised 25bps from 3.75% on Nov 5, 2026. MPC vote 8-1. Inflation persistence cited." },
    { metric: "UK 3-Month Gilt yield", value: "4.05%", numericValue: 4.05, unit: "%", asOfDate: "2026-11-19", source: "UK DMO", notes: "Short-term UK risk-free. Used for IFRS 9 ECL Stage 1 discounting on GBP receivables." },
    { metric: "UK 10-Year Gilt", value: "4.15%", numericValue: 4.15, unit: "%", asOfDate: "2026-11-19", source: "UK DMO", notes: "Long-duration UK risk-free. Used in UK company DCFs (GBP WACC)." },
    { metric: "UK 30-Year Gilt", value: "4.35%", numericValue: 4.35, unit: "%", asOfDate: "2026-11-19", source: "UK DMO", notes: "Long-duration UK benchmark. Used for pension scheme liability discounting." },
    { metric: "Canada Overnight Rate (BoC target)", value: "2.50%", numericValue: 2.50, unit: "%", asOfDate: "2026-11-03", source: "Bank of Canada MPC (Nov 3, 2026)", notes: "Cut from 2.75% on Nov 3, 2026. BoC easing cycle continuing through 2026." },
    { metric: "SOFR (overnight)", value: "3.91%", numericValue: 3.91, unit: "%", asOfDate: "2026-11-19", source: "FRBNY (Federal Reserve Bank of New York)", notes: "USD risk-free replacement for LIBOR. Repo-based overnight. 30-day avg: 3.92%." },
    { metric: "SONIA (overnight)", value: "3.9840%", numericValue: 3.9840, unit: "%", asOfDate: "2026-11-18", source: "BoE (SONIA administrator)", notes: "GBP risk-free replacement for LIBOR. Used in swaps and FRN coupons." },
    { metric: "€STR (overnight)", value: "2.85%", numericValue: 2.85, unit: "%", asOfDate: "2026-11-19", source: "ECB", notes: "EUR risk-free replacement for EUR LIBOR. ECB deposit facility rate." },
    { metric: "Term SOFR 1-Month", value: "4.05%", numericValue: 4.05, unit: "%", asOfDate: "2026-11-20", source: "CME Term SOFR", notes: "Used in floating-rate USD loan pricing. 1-month forward-looking SOFR." },
    { metric: "Term SOFR 3-Month", value: "4.10%", numericValue: 4.10, unit: "%", asOfDate: "2026-11-20", source: "CME Term SOFR", notes: "Most used tenor for floating-rate commercial loans. 3-month forward-looking SOFR." },
    { metric: "Term SOFR 6-Month", value: "4.15%", numericValue: 4.15, unit: "%", asOfDate: "2026-11-20", source: "CME Term SOFR", notes: "6-month forward-looking SOFR. Used in longer-tenor floating-rate debt." },
    { metric: "CORRA (Canada overnight)", value: "2.53%", numericValue: 2.53, unit: "%", asOfDate: "2026-11-20", source: "Bank of Canada", notes: "Canadian Overnight Repo Rate Average. CAD risk-free replacement for CDOR (discontinued 2024)." },
  ],
};

// ===================================================================
// 3. EQUITY RISK PREMIUMS, SIZE PREMIUMS & BETA BENCHMARKS
// ===================================================================
const ERP_SIZE_BETA: MarketDataCategory = {
  id: "erp-beta",
  name: "Equity Risk Premiums, Size Premiums & Beta Benchmarks",
  icon: "TrendingUp",
  color: "violet",
  description: "Damodaran NYU Stern implied ERP (updated Jan 5, Jul 1, Nov 1, 2026), Kroll (formerly Duff & Phelps) size premiums 2025, and industry betas for WACC computation.",
  rows: [
    { metric: "Equity Risk Premium — US (implied)", value: "4.41%", numericValue: 4.41, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern (Nov 1, 2026 update)", notes: "Implied ERP for S&P 500 using 2-stage augmented dividend discount model. Trailing 12-month with adjusted payout. Down from 4.5% in late 2024." },
    { metric: "Equity Risk Premium — US (Jul 2026)", value: "4.42%", numericValue: 4.42, unit: "%", asOfDate: "2026-07-01", source: "Damodaran NYU Stern (Jul 1, 2026 update)", notes: "Correcting for default risk in US (0.25%). Implied ERP was 4.42% for US at start of July 2026." },
    { metric: "Equity Risk Premium — UK", value: "4.35%", numericValue: 4.35, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern (country ratings-based)", notes: "UK ERP derived from country risk ratings (Moody's Aa3). Slightly below US." },
    { metric: "Equity Risk Premium — Mature Markets avg", value: "4.40%", numericValue: 4.40, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern", notes: "Default for developed markets (US, UK, EU, Canada, Australia, Japan). Use as base + CRP for emerging." },
    { metric: "Equity Risk Premium — Canada", value: "4.35%", numericValue: 4.35, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern (country ratings-based)", notes: "Canada ERP from Moody's Aaa rating. Same as UK/EU developed." },
    { metric: "Equity Risk Premium — Germany", value: "4.35%", numericValue: 4.35, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern", notes: "Developed market base ERP. EU member." },
    { metric: "Equity Risk Premium — Emerging Markets avg", value: "5.50%", numericValue: 5.50, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern", notes: "Base ERP for emerging markets. Add country-specific CRP for individual jurisdictions." },
    { metric: "Country Risk Premium — US", value: "0.25%", numericValue: 0.25, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern", notes: "Developed market — minimal CRP. Damodaran includes default-spread-based CRP for all countries including US." },
    { metric: "Country Risk Premium — UK", value: "0.30%", numericValue: 0.30, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern", notes: "Slightly elevated post-Brexit. Moody's Aa3 rating." },
    { metric: "Country Risk Premium — Canada", value: "0.20%", numericValue: 0.20, unit: "%", asOfDate: "2026-11-01", source: "Damodaran NYU Stern", notes: "Moody's Aaa. Minimal CRP." },
    { metric: "Size Premium — Mega cap (≥$25B mkt cap)", value: "0.50%", numericValue: 0.50, unit: "%", asOfDate: "2026-01-01", source: "Kroll (formerly Duff & Phelps) 2025 Cost of Capital", notes: "Largest companies. Slight premium over CAPM base for empirical small-cap effect even at mega cap." },
    { metric: "Size Premium — Large cap ($5-25B)", value: "1.10%", numericValue: 1.10, unit: "%", asOfDate: "2026-01-01", source: "Kroll 2025 Cost of Capital", notes: "Large companies. Add to CAPM cost of equity." },
    { metric: "Size Premium — Mid cap ($1-5B)", value: "2.60%", numericValue: 2.60, unit: "%", asOfDate: "2026-01-01", source: "Kroll 2025 Cost of Capital", notes: "Mid-sized companies. Common adjustment for mid-cap WACC." },
    { metric: "Size Premium — Small cap ($250M-1B)", value: "4.00%", numericValue: 4.00, unit: "%", asOfDate: "2026-01-01", source: "Kroll 2025 Cost of Capital", notes: "Small companies. Significant adjustment to CAPM cost of equity." },
    { metric: "Size Premium — Micro cap (<$250M)", value: "5.50%", numericValue: 5.50, unit: "%", asOfDate: "2026-01-01", source: "Kroll 2025 Cost of Capital", notes: "Smallest companies. Large adjustment — size premium dominates beta." },
    { metric: "Beta — Tech / SaaS (mature)", value: "1.20x", numericValue: 1.20, unit: "x", asOfDate: "2026-11-01", source: "Bloomberg 2-yr weekly beta vs S&P 500", notes: "Higher than market. Used in tech company WACC." },
    { metric: "Beta — REITs", value: "0.90x", numericValue: 0.90, unit: "x", asOfDate: "2026-11-01", source: "NAREIT index 2-yr weekly", notes: "Lower beta, defensive. Used in REIT WACC." },
    { metric: "Beta — Commercial Banks", value: "1.10x", numericValue: 1.10, unit: "x", asOfDate: "2026-11-01", source: "KBW Bank Index 2-yr weekly", notes: "Slightly above market. Used in bank 3-statement model." },
    { metric: "Beta — Retail (general)", value: "1.10x", numericValue: 1.10, unit: "x", asOfDate: "2026-11-01", source: "S&P Retail Select 2-yr weekly", notes: "Slightly above market. Used in retail model." },
    { metric: "Beta — Construction / Engineering", value: "1.20x", numericValue: 1.20, unit: "x", asOfDate: "2026-11-01", source: "ENR index 2-yr weekly", notes: "Above market, cyclical. Used in construction model." },
    { metric: "Beta — Utilities (regulated)", value: "0.65x", numericValue: 0.65, unit: "x", asOfDate: "2026-11-01", source: "S&P Utilities Select 2-yr weekly", notes: "Lowest beta sector. Defensive, regulated returns." },
    { metric: "Beta — Healthcare / Pharma", value: "0.85x", numericValue: 0.85, unit: "x", asOfDate: "2026-11-01", source: "S&P Healthcare Select 2-yr weekly", notes: "Defensive, inelastic demand. Stable cash flows." },
  ],
};

// ===================================================================
// 4. CREDIT SPREADS & DEFAULT RATES (S&P 2025 Annual + 2026 forecast)
// ===================================================================
const CREDIT_SPREADS: MarketDataCategory = {
  id: "credit",
  name: "Credit Spreads & Default Rates",
  icon: "Landmark",
  color: "rose",
  description: "S&P Global Ratings 2025 Annual Default Study (published Mar 2026) + 2026 forecast. Moody's CRE spreads. Used in ECL/CECL modelling, loan pricing, and credit portfolio management.",
  rows: [
    { metric: "Investment Grade (BBB+ to BBB-) — Spread", value: "125 bps", numericValue: 125, unit: "bps", asOfDate: "2026-11-01", source: "S&P Global Ratings 2025 Annual Default Study", notes: "Bank loan portfolio core. 1-yr default 0.1%, 10-yr cumulative loss 2.0%." },
    { metric: "Cross-over (BB+ to BB-) — Spread", value: "250 bps", numericValue: 250, unit: "bps", asOfDate: "2026-11-01", source: "S&P Global Ratings 2025 Annual Default Study", notes: "Leveraged loan tier 1. 1-yr default 1.2%, 10-yr cumulative loss 10.5%." },
    { metric: "Speculative (B+ to B-) — Spread", value: "450 bps", numericValue: 450, unit: "bps", asOfDate: "2026-11-01", source: "S&P Global Ratings 2025 Annual Default Study", notes: "Leveraged loan tier 2. 1-yr default 4.0%, 10-yr cumulative loss 23.5%." },
    { metric: "Distressed (CCC+ and below) — Spread", value: "900 bps", numericValue: 900, unit: "bps", asOfDate: "2026-11-01", source: "S&P Global Ratings 2025 Annual Default Study", notes: "Restructuring candidates. 1-yr default 27.5%, 10-yr cumulative loss 58.0%." },
    { metric: "CRE — Office (BBB) — Spread", value: "175 bps", numericValue: 175, unit: "bps", asOfDate: "2026-11-01", source: "Moody's CRE 2024-2025", notes: "Hybrid/remote work stress. 1-yr default 1.5%, 10-yr cumulative loss 8.0%. Office remains the most stressed CRE subsector." },
    { metric: "CRE — Retail (BBB) — Spread", value: "165 bps", numericValue: 165, unit: "bps", asOfDate: "2026-11-01", source: "Moody's CRE 2024-2025", notes: "Recovering post-COVID. 1-yr default 1.2%, 10-yr cumulative loss 6.5%." },
    { metric: "CRE — Industrial (A-) — Spread", value: "95 bps", numericValue: 95, unit: "bps", asOfDate: "2026-11-01", source: "Moody's CRE 2024-2025", notes: "E-commerce tailwind. 1-yr default 0.5%, 10-yr cumulative loss 2.5%. Tightest CRE subsector." },
    { metric: "CRE — Multifamily (A-) — Spread", value: "110 bps", numericValue: 110, unit: "bps", asOfDate: "2026-11-01", source: "Moody's CRE 2024-2025", notes: "Stable, supply watch. 1-yr default 0.6%, 10-yr cumulative loss 3.0%." },
    { metric: "C&I — Manufacturing (BBB) — Spread", value: "130 bps", numericValue: 130, unit: "bps", asOfDate: "2026-11-01", source: "S&P Global Ratings 2025", notes: "Cyclical, capex intensive. 1-yr default 0.8%, 10-yr cumulative loss 4.0%." },
    { metric: "C&I — Tech / SaaS (BB) — Spread", value: "280 bps", numericValue: 280, unit: "bps", asOfDate: "2026-11-01", source: "S&P Global Ratings 2025", notes: "Higher growth, higher risk. 1-yr default 2.0%, 10-yr cumulative loss 15.0%." },
    { metric: "Construction (BB) — Spread", value: "320 bps", numericValue: 320, unit: "bps", asOfDate: "2026-11-01", source: "S&P Global Ratings 2025", notes: "Working capital intensive. 1-yr default 2.5%, 10-yr cumulative loss 17.5%." },
    { metric: "S&P Global Speculative-Grade Default Rate (TTM)", value: "3.7%", numericValue: 3.7, unit: "%", asOfDate: "2026-09-01", source: "S&P Global Ratings forecast Sep 2026", notes: "Forecast by September 2026 — up from 3.5% TTM. 117 global defaults in 2025 (down 19% YoY from 145 in 2024)." },
    { metric: "S&P US Speculative-Grade Default Rate (TTM)", value: "2.25%", numericValue: 2.25, unit: "%", asOfDate: "2026-11-01", source: "S&P Global Ratings Nov 2026", notes: "US share of global defaults at six-year high. Forecast to rise to 4.75% by Sep 2026." },
    { metric: "S&P Investment-Grade Default Rate (TTM)", value: "0.10%", numericValue: 0.10, unit: "%", asOfDate: "2026-11-01", source: "S&P Global Ratings 2025 Annual Study", notes: "Investment-grade defaults remain rare. 7 global corporate defaults in October 2026 alone." },
    { metric: "Loan Recovery Rate — Senior Secured (TTM)", value: "65%", numericValue: 65, unit: "%", asOfDate: "2026-11-01", source: "S&P Global Recovery Study 2025", notes: "Recovery on defaulted senior secured bank loans. Implies LGD = 35%." },
    { metric: "Loan Recovery Rate — Senior Unsecured (TTM)", value: "40%", numericValue: 40, unit: "%", asOfDate: "2026-11-01", source: "S&P Global Recovery Study 2025", notes: "Recovery on defaulted senior unsecured bonds. Implies LGD = 60%." },
    { metric: "Loan Recovery Rate — Subordinated (TTM)", value: "20%", numericValue: 20, unit: "%", asOfDate: "2026-11-01", source: "S&P Global Recovery Study 2025", notes: "Recovery on defaulted subordinated bonds. Implies LGD = 80%." },
  ],
};

// ===================================================================
// 5. STATUTORY TAX RATES (FY 2026 enacted)
// ===================================================================
const TAX_RATES: MarketDataCategory = {
  id: "tax",
  name: "Statutory Tax Rates",
  icon: "Receipt",
  color: "amber",
  description: "Enacted statutory corporation tax rates by jurisdiction. Used in current tax computation (CT600/T2/Form 1120), deferred tax calculation (IAS 12 / ASC 740), and WACC after-tax cost of debt.",
  rows: [
    { metric: "US Federal Corporation Tax", value: "21.0%", numericValue: 21.0, unit: "%", asOfDate: "2026-01-01", source: "IRC §11 (26 USC §11)", notes: "Flat 21% federal rate since TCJA 2018. No expiry scheduled (was scheduled to rise to 35% pre-TCJA)." },
    { metric: "US Federal Effective (with state)", value: "24.5%", numericValue: 24.5, unit: "%", asOfDate: "2026-01-01", source: "IRC §11 + state blended ~5% (post-TCJA deduction)", notes: "21% federal + ~5% blended state (deductible from federal taxable income). Used for US deferred tax." },
    { metric: "UK Corporation Tax — Main Rate", value: "25.0%", numericValue: 25.0, unit: "%", asOfDate: "2026-04-01", source: "Finance Act 2023 (CTA 2010 s6)", notes: "Main rate for profits ≥ £250,000. Effective FY26. Used in deferred tax computation for TechFlow UK Ltd." },
    { metric: "UK Corporation Tax — Small Profits Rate", value: "19.0%", numericValue: 19.0, unit: "%", asOfDate: "2026-04-01", source: "Finance Act 2023 (CTA 2010 s6)", notes: "Small profits rate for profits ≤ £50,000. Marginal relief between £50K-£250K." },
    { metric: "UK Patent Box", value: "10.0%", numericValue: 10.0, unit: "%", asOfDate: "2026-04-01", source: "Finance Act 2013 (CTA 2010 Part 8A)", notes: "Reduced 10% rate on qualifying patent profits. Election required; 2-year transition." },
    { metric: "Ireland Corporation Tax — Trading", value: "12.5%", numericValue: 12.5, unit: "%", asOfDate: "2026-01-01", source: "TCA 1997 s21 (Irish Revenue)", notes: "12.5% on trading income. Common holding company jurisdiction due to low rate + extensive treaty network." },
    { metric: "Ireland Corporation Tax — Non-Trading", value: "25.0%", numericValue: 25.0, unit: "%", asOfDate: "2026-01-01", source: "TCA 1997 s21", notes: "25% on non-trading income (rental, foreign dividends, etc.). Minimum effective 15% for MNEs >€750M (Pillar Two)." },
    { metric: "Singapore Corporate Income Tax", value: "17.0%", numericValue: 17.0, unit: "%", asOfDate: "2026-01-01", source: "IRAS (Inland Revenue Authority of Singapore)", notes: "17% headline rate; partial exemptions on first S$300K. Plus pioneer industries 0%/5%/10% incentive." },
    { metric: "UAE Corporate Tax", value: "9.0%", numericValue: 9.0, unit: "%", asOfDate: "2026-06-01", source: "UAE FTA (Federal Tax Authority) — CT Law 2023", notes: "9% effective since June 2023. 0% on qualifying free zone income. Threshold AED 375,000." },
    { metric: "Canada Federal T2 Part I — General", value: "15.0%", numericValue: 15.0, unit: "%", asOfDate: "2026-01-01", source: "ITA s.123 (Income Tax Act Canada)", notes: "15% federal general rate. Applied to taxable income >$500K CCPC active business limit." },
    { metric: "Canada Federal SBD (CCPC active)", value: "9.0%", numericValue: 9.0, unit: "%", asOfDate: "2026-01-01", source: "ITA s.125 (Small Business Deduction)", notes: "9% federal Small Business Deduction on first $500K CCPC active business income." },
    { metric: "Canada Ontario — General", value: "11.5%", numericValue: 11.5, unit: "%", asOfDate: "2026-01-01", source: "Taxation Act 2007 (Ontario) s.21", notes: "Ontario provincial general rate. Combined with federal 15% = 26.5%." },
    { metric: "Canada Ontario — Small Business", value: "3.2%", numericValue: 3.2, unit: "%", asOfDate: "2026-01-01", source: "Taxation Act 2007 (Ontario)", notes: "Ontario small business rate. Combined with federal 9% SBD = 12.2%." },
    { metric: "Canada Alberta — General", value: "8.0%", numericValue: 8.0, unit: "%", asOfDate: "2026-01-01", source: "Alberta Corporate Tax Act", notes: "Alberta provincial rate (no PST/HST). Combined with federal 15% = 23.0% — lowest combined general rate in Canada." },
    { metric: "Germany Körperschaftsteuer", value: "15.0%", numericValue: 15.0, unit: "%", asOfDate: "2026-01-01", source: "KStG §23 (Einkommensteuergesetz)", notes: "15% federal corporate income tax. Plus Solidaritätszuschlag 5.5% on KSt = 15.825%." },
    { metric: "Germany Gewerbesteuer (Trade Tax)", value: "~14.0%", numericValue: 14.0, unit: "%", asOfDate: "2026-01-01", source: "GewStG (Gewerbesteuergesetz)", notes: "Municipal trade tax — varies by Hebesatz. Typical ~14% in Munich, ~15% Berlin, ~17% Frankfurt. Combined German corp tax ~30%." },
    { metric: "France Impôt sur les Sociétés (IS)", value: "25.0%", numericValue: 25.0, unit: "%", asOfDate: "2026-01-01", source: "CGI (Code Général des Impôts) art. 219", notes: "25% standard IS rate since 2022. 15% on first €42,500 for SMEs (PME)." },
    { metric: "OECD Pillar Two Global Minimum", value: "15.0%", numericValue: 15.0, unit: "%", asOfDate: "2026-01-01", source: "OECD/G20 Inclusive Framework — Pillar Two", notes: "15% global minimum effective tax rate on MNEs with revenue ≥€750M. Adopted in EU, UK, Canada, Japan, Australia. Top-up tax applies where local ETR < 15%." },
  ],
};

// ===================================================================
// AGGREGATE EXPORT
// ===================================================================
export const MARKET_DATA_CATEGORIES: MarketDataCategory[] = [
  FX_RATES,
  RISK_FREE_RATES,
  ERP_SIZE_BETA,
  CREDIT_SPREADS,
  TAX_RATES,
];

export const MARKET_DATA_STATS = {
  totalCategories: MARKET_DATA_CATEGORIES.length,
  totalRows: MARKET_DATA_CATEGORIES.reduce((s, c) => s + c.rows.length, 0),
  lastRefreshed: "2026-11-20",
  refreshCadence: "Daily for FX and policy rates · Monthly for credit spreads · Annual for ERP and size premiums",
  primarySources: [
    "Federal Reserve H.10 (FX)",
    "US Treasury (daily yield curve)",
    "FRBNY (SOFR)",
    "FOMC (Fed Funds target)",
    "BoE MPC (Bank Rate, SONIA)",
    "BoC (overnight rate)",
    "ECB (EUR rates)",
    "ICE (DXY)",
    "CME (Term SOFR)",
    "Damodaran NYU Stern (ERP — Jan/Jul/Nov 2026 updates)",
    "Kroll / Duff & Phelps (size premiums 2025)",
    "S&P Global Ratings (2025 Annual Default Study)",
    "Moody's CRE (commercial real estate spreads)",
    "Bloomberg / NAREIT / KBW / ENR (industry betas)",
    "IRC / HMRC / Irish Revenue / IRAS / UAE FTA / CRA (statutory tax rates)",
  ],
  disclaimer: "All inputs are blue cells — modify to update downstream models. Source citations are required when changing inputs for audit purposes. Last refreshed November 20, 2026. The rates above are sourced from primary trusted resources (central banks, treasuries, NYU Stern Damodaran, S&P Global Ratings, Kroll).",
};

// Helper: lookup a specific rate by metric name
export function lookupRate(metric: string): MarketDataRow | undefined {
  for (const cat of MARKET_DATA_CATEGORIES) {
    const found = cat.rows.find((r) => r.metric === metric || r.metric.toLowerCase() === metric.toLowerCase());
    if (found) return found;
  }
  return undefined;
}
