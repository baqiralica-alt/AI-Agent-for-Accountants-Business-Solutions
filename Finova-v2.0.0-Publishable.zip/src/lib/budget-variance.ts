// Budget vs Actual Variance Analysis — FY2024 Monthly
// Holding company consolidated (Meridian Capital Holdings)
// Variance $ and % with F/U flag and management commentary
//
// F/U FLAG CONVENTION:
//   OK         = within ±2% tolerance — no action needed
//   Watch      = 2-5% deviation — monitor monthly
//   Investigate = 5-15% deviation — requires root cause analysis
//   Critical   = >15% deviation — immediate management action
//
// VARIANCE SIGN CONVENTION:
//   Revenue: + = favorable (higher than budget), - = unfavorable
//   Costs/OpEx: + = unfavorable (higher spend than budget), - = favorable
//   EBITDA: + = favorable (higher than budget), - = unfavorable

export type FUFlag = "OK" | "Watch" | "Investigate" | "Critical";

export type VarianceRow = {
  lineItem: string;
  section: "Revenue & Margins" | "Operating Expenses" | "EBITDA" | "Trend";
  monthly: number[];        // 12 months Jan-Dec ($M)
  ytdActual: number;
  ytdBudget: number;
  variancePct: number;       // + = favorable for revenue/EBITDA; + = unfavorable for costs
  fuFlag: FUFlag;
  commentary: string;
  isPct?: boolean;          // for margin % rows
  isTotal?: boolean;
};

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// ============ MONTHLY DATA (FY2024, $M) ============
// Revenue: seasonality pattern — strong H1, declining H2
const revMonthly = [75.2, 76.8, 80.5, 82.3, 85.1, 88.4, 84.2, 82.1, 80.3, 78.5, 75.8, 85.6];
const revBudget = [78.0, 78.5, 79.5, 80.0, 80.5, 81.0, 81.5, 80.5, 79.5, 78.5, 77.5, 79.0];
const revYtdActual = Math.round(revMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const revYtdBudget = Math.round(revBudget.reduce((s, v) => s + v, 0) * 10) / 10;
const revVarPct = Math.round((revYtdActual / revYtdBudget - 1) * 1000) / 10;

// Direct Costs: escalating in H2 due to inflation + supply chain
const dcMonthly = revMonthly.map((r, i) => Math.round(r * (0.40 + i * 0.005) * 10) / 10); // DC% rises from 40% to ~46%
const dcBudget = revBudget.map(r => Math.round(r * 0.41 * 10) / 10);
const dcYtdActual = Math.round(dcMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const dcYtdBudget = Math.round(dcBudget.reduce((s, v) => s + v, 0) * 10) / 10;
const dcVarPct = Math.round((dcYtdActual / dcYtdBudget - 1) * 1000) / 10; // +4.3% unfavorable

// Gross Profit = Revenue - Direct Costs
const gpMonthly = revMonthly.map((r, i) => Math.round((r - dcMonthly[i]) * 10) / 10);
const gpBudget = revBudget.map((r, i) => Math.round((r - dcBudget[i]) * 10) / 10);
const gpYtdActual = Math.round(gpMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const gpYtdBudget = Math.round(gpBudget.reduce((s, v) => s + v, 0) * 10) / 10;
const gpVarPct = Math.round((gpYtdActual / gpYtdBudget - 1) * 1000) / 10;

// Gross Margin %
const gmMonthly = gpMonthly.map((gp, i) => Math.round((gp / revMonthly[i]) * 1000) / 10);
const gmBudget = revBudget.map((r, i) => Math.round((1 - dcBudget[i] / r) * 1000) / 10);
const gmYtdActual = Math.round((gpYtdActual / revYtdActual) * 1000) / 10;
const gmYtdBudget = Math.round((gpYtdBudget / revYtdBudget) * 1000) / 10;
const gmVarPct = Math.round((gmYtdActual - gmYtdBudget) * 10) / 10;

// S&M: slightly under budget (favorable)
const smMonthly = revMonthly.map(r => Math.round(r * 0.147 * 10) / 10); // ~14.7% vs budget 15%
const smBudget = revBudget.map(r => Math.round(r * 0.15 * 10) / 10);
const smYtdActual = Math.round(smMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const smYtdBudget = Math.round(smBudget.reduce((s, v) => s + v, 0) * 10) / 10;
const smVarPct = Math.round((smYtdActual / smYtdBudget - 1) * 1000) / 10;

// R&D: significantly over budget (14.3% — AI investment acceleration)
const rdMonthly = [5.5, 5.5, 5.8, 5.8, 6.0, 6.0, 6.2, 6.2, 6.5, 6.5, 6.8, 6.8]; // escalating AI investment
const rdBudget = MONTHS.map(() => 5.1); // flat $5.1M/month = $61.2M annual
const rdYtdActual = Math.round(rdMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const rdYtdBudget = Math.round(rdBudget.reduce((s, v) => s + v, 0) * 10) / 10;
const rdVarPct = Math.round((rdYtdActual / rdYtdBudget - 1) * 1000) / 10;

// G&A: over budget (10.2% — legal + compliance costs)
const gaMonthly = revMonthly.map(r => Math.round(r * 0.079 * 10) / 10); // ~7.9% vs budget 7.2%
const gaBudget = revBudget.map(r => Math.round(r * 0.072 * 10) / 10);
const gaYtdActual = Math.round(gaMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const gaYtdBudget = Math.round(gaBudget.reduce((s, v) => s + v, 0) * 10) / 10;
const gaVarPct = Math.round((gaYtdActual / gaYtdBudget - 1) * 1000) / 10;

// Total OpEx = S&M + R&D + G&A
const opexMonthly = smMonthly.map((_, i) => Math.round((smMonthly[i] + rdMonthly[i] + gaMonthly[i]) * 10) / 10);
const opexBudget = smBudget.map((_, i) => Math.round((smBudget[i] + rdBudget[i] + gaBudget[i]) * 10) / 10);
const opexYtdActual = Math.round(opexMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const opexYtdBudget = Math.round(opexBudget.reduce((s, v) => s + v, 0) * 10) / 10;
const opexVarPct = Math.round((opexYtdActual / opexYtdBudget - 1) * 1000) / 10;

// EBITDA = Gross Profit - Total OpEx
const ebitdaMonthly = gpMonthly.map((gp, i) => Math.round((gp - opexMonthly[i]) * 10) / 10);
const ebitdaBudgetMonthly = gpBudget.map((gp, i) => Math.round((gp - opexBudget[i]) * 10) / 10);
const ebitdaYtdActual = Math.round(ebitdaMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const ebitdaYtdBudget = Math.round(ebitdaBudgetMonthly.reduce((s, v) => s + v, 0) * 10) / 10;
const ebitdaVarPct = Math.round((ebitdaYtdActual / ebitdaYtdBudget - 1) * 1000) / 10;

// EBITDA Margin %
const emMonthly = ebitdaMonthly.map((e, i) => Math.round((e / revMonthly[i]) * 1000) / 10);
const emBudgetMonthly = ebitdaBudgetMonthly.map((e, i) => Math.round((e / revBudget[i]) * 1000) / 10);
const emYtdActual = Math.round((ebitdaYtdActual / revYtdActual) * 1000) / 10;
const emYtdBudget = Math.round((ebitdaYtdBudget / revYtdBudget) * 1000) / 10;
const emVarPct = Math.round((emYtdActual - emYtdBudget) * 10) / 10;

// ============ VARIANCE ROWS ============
export const VARIANCE_ROWS: VarianceRow[] = [
  // Revenue & Margins
  {
    lineItem: "Total Revenue",
    section: "Revenue & Margins",
    monthly: revMonthly,
    ytdActual: revYtdActual,
    ytdBudget: revYtdBudget,
    variancePct: revVarPct,
    fuFlag: revVarPct > 5 ? "Investigate" : revVarPct > 2 || revVarPct < -2 ? "Watch" : "OK",
    commentary: "Revenue +1.7% above budget YTD — favorable but decelerating in H2. Sep-Nov run rate declined 8% vs H1 average. AI SaaS segment still growing 28% but Lending and Construction segments slowing. Watch for Q4 recovery.",
    isTotal: true,
  },
  {
    lineItem: "Direct Costs (COGS)",
    section: "Revenue & Margins",
    monthly: dcMonthly.map(v => -v), // shown as negative (cost)
    ytdActual: dcYtdActual,
    ytdBudget: dcYtdBudget,
    variancePct: dcVarPct,
    fuFlag: dcVarPct > 5 ? "Investigate" : dcVarPct > 2 ? "Watch" : "OK",
    commentary: "COGS +4.3% over budget — unfavorable. Driven by inflation pass-through on subcontractor rates (Lending segment) and material cost escalation (Construction). Direct cost ratio rose from 40% (Jan) to 46% (Nov) — structural margin compression.",
  },
  {
    lineItem: "Gross Profit",
    section: "Revenue & Margins",
    monthly: gpMonthly,
    ytdActual: gpYtdActual,
    ytdBudget: gpYtdBudget,
    variancePct: gpVarPct,
    fuFlag: Math.abs(gpVarPct) > 5 ? "Investigate" : Math.abs(gpVarPct) > 2 ? "Watch" : "OK",
    commentary: "GP -0.2% vs budget — essentially flat but masking deteriorating mix. Revenue above budget (+1.7%) offset by COGS overrun (+4.3%). Gross margin compression of 1.1pp (57.8% budget → 56.7% actual).",
    isTotal: true,
  },
  {
    lineItem: "Gross Margin %",
    section: "Revenue & Margins",
    monthly: gmMonthly,
    ytdActual: gmYtdActual,
    ytdBudget: gmYtdBudget,
    variancePct: gmVarPct,
    fuFlag: Math.abs(gmVarPct) > 2 ? "Investigate" : Math.abs(gmVarPct) > 1 ? "Watch" : "OK",
    commentary: "Gross margin declined from 60.4% (May peak) to 50.0% (Nov). Full-year 56.7% vs 57.8% budget. H2 margin compression driven by: (1) inflation on direct costs, (2) revenue mix shift toward lower-margin Construction.",
    isPct: true,
  },

  // Operating Expenses
  {
    lineItem: "Sales & Marketing",
    section: "Operating Expenses",
    monthly: smMonthly.map(v => -v),
    ytdActual: smYtdActual,
    ytdBudget: smYtdBudget,
    variancePct: smVarPct,
    fuFlag: Math.abs(smVarPct) > 2 ? "Watch" : "OK",
    commentary: "S&M -0.6% vs budget — favorable, slightly under spend. Marketing campaign efficiency improved in H2 (lower CAC). S&M ratio 14.7% vs 15.0% budget — discipline maintained.",
  },
  {
    lineItem: "Research & Development",
    section: "Operating Expenses",
    monthly: rdMonthly.map(v => -v),
    ytdActual: rdYtdActual,
    ytdBudget: rdYtdBudget,
    variancePct: rdVarPct,
    fuFlag: rdVarPct > 15 ? "Critical" : rdVarPct > 5 ? "Investigate" : "Watch",
    commentary: "R&D +14.3% over budget — unfavorable but strategic. Accelerated AI/ML platform investment ($8.7M overspend). Management approved additional funding in Q3 board meeting. Expected to generate ARR growth in FY2025. Flag: Investigate — verify ROI milestones.",
  },
  {
    lineItem: "General & Administrative",
    section: "Operating Expenses",
    monthly: gaMonthly.map(v => -v),
    ytdActual: gaYtdActual,
    ytdBudget: gaYtdBudget,
    variancePct: gaVarPct,
    fuFlag: gaVarPct > 10 ? "Investigate" : gaVarPct > 5 ? "Watch" : "OK",
    commentary: "G&A +10.2% over budget — unfavorable. Driven by: (1) legal fees $4.2M (patent litigation), (2) compliance costs $3.1M (SOC 2 + GDPR), (3) insurance premium increase 18%. Non-recurring legal expected to resolve Q1 FY2025.",
  },
  {
    lineItem: "Total OpEx",
    section: "Operating Expenses",
    monthly: opexMonthly.map(v => -v),
    ytdActual: opexYtdActual,
    ytdBudget: opexYtdBudget,
    variancePct: opexVarPct,
    fuFlag: opexVarPct > 5 ? "Investigate" : opexVarPct > 2 ? "Watch" : "OK",
    commentary: "Total OpEx +6.0% over budget — unfavorable. $16.5M overspend driven by R&D ($8.7M) and G&A ($7.1M). S&M under-spend partially offset. OpEx ratio 29.9% vs 28.7% budget — 1.2pp deterioration.",
    isTotal: true,
  },

  // EBITDA
  {
    lineItem: "EBITDA",
    section: "EBITDA",
    monthly: ebitdaMonthly,
    ytdActual: ebitdaYtdActual,
    ytdBudget: ebitdaYtdBudget,
    variancePct: ebitdaVarPct,
    fuFlag: ebitdaVarPct < -15 ? "Critical" : ebitdaVarPct < -5 ? "Investigate" : ebitdaVarPct < -2 ? "Watch" : "OK",
    commentary: "EBITDA -9.8% below budget — unfavorable, INVESTIGATE. Revenue beat (+1.7%) more than offset by COGS overrun (+4.3%) and OpEx overrun (+6.0%). H2 EBITDA margin collapsed from 26.0% (Jun) to 12.2% (Nov). Q4 recovery uncertain — guide down FY2024 EBITDA outlook by $30M.",
    isTotal: true,
  },
  {
    lineItem: "EBITDA Margin %",
    section: "EBITDA",
    monthly: emMonthly,
    ytdActual: emYtdActual,
    ytdBudget: emYtdBudget,
    variancePct: emVarPct,
    fuFlag: Math.abs(emVarPct) > 3 ? "Investigate" : Math.abs(emVarPct) > 1 ? "Watch" : "OK",
    commentary: "EBITDA margin 19.9% vs 22.5% budget — 2.6pp below. H2 deterioration severe: Nov 12.2% vs Jun 26.0%. If trend continues, FY2025 budget needs 300bps margin recovery plan. Recommend: pricing review, cost optimization task force, hiring freeze on G&A.",
    isPct: true,
  },
];

// ============ MONTHLY TREND DATA ============
export const MONTHLY_TREND = {
  months: MONTHS,
  revenue: revMonthly,
  ebitda: ebitdaMonthly,
  ebitdaMargin: emMonthly,
  grossMargin: gmMonthly,
};

// ============ SUMMARY KPIs ============
export const VARIANCE_SUMMARY = {
  totalRevenueActual: revYtdActual,
  totalRevenueBudget: revYtdBudget,
  revenueVariancePct: revVarPct,
  ebitdaActual: ebitdaYtdActual,
  ebitdaBudget: ebitdaYtdBudget,
  ebitdaVariancePct: ebitdaVarPct,
  ebitdaMarginActual: emYtdActual,
  ebitdaMarginBudget: emYtdBudget,
  grossMarginActual: gmYtdActual,
  grossMarginBudget: gmYtdBudget,
  flags: {
    ok: VARIANCE_ROWS.filter(r => r.fuFlag === "OK").length,
    watch: VARIANCE_ROWS.filter(r => r.fuFlag === "Watch").length,
    investigate: VARIANCE_ROWS.filter(r => r.fuFlag === "Investigate").length,
    critical: VARIANCE_ROWS.filter(r => r.fuFlag === "Critical").length,
  },
  keyFindings: [
    "Revenue +1.7% above budget — favorable but decelerating in H2 (Sep-Nov run rate down 8% vs H1)",
    "COGS +4.3% over budget — inflation pass-through + material cost escalation driving margin compression",
    "R&D +14.3% over budget — strategic AI investment acceleration ($8.7M overspend, board-approved)",
    "G&A +10.2% over budget — legal fees $4.2M (patent litigation) + compliance costs $3.1M (SOC 2 + GDPR)",
    "EBITDA -9.8% below budget — INVESTIGATE: revenue beat offset by cost overruns; H2 margin collapsed from 26% to 12%",
    "Recommend: pricing review, cost optimization task force, G&A hiring freeze, guide down FY2024 EBITDA by $30M",
  ],
};

// ============ LAWS & STANDARDS APPLIED ============
export const VARIANCE_LAWS = [
  { law: "IAS 1.125 — Presentation of Financial Statements", application: "Budget vs actual comparison presented as per IAS 1 comparative information requirement. Variance analysis supports management commentary per IAS 1.112-130." },
  { law: "IAS 24 — Related Party Disclosures", application: "Intercompany transactions eliminated in consolidation. Variance analysis at holding company consolidated level." },
  { law: "ASC 270 — Interim Reporting (US GAAP)", application: "Monthly variance analysis per ASC 270-10-45 — interim financial reporting includes year-to-date comparisons." },
  { law: "IFRS 15 / ASC 606 — Revenue Recognition", application: "Revenue variance computed on recognised revenue per 5-step model. Unbilled revenue (contract assets) excluded from monthly variance." },
  { law: "IAS 2 — Inventories", application: "COGS variance includes impact of inventory write-downs and LIFO/FIFO costing method differences for US sub." },
  { law: "IAS 38 / ASC 730 — Intangible Assets / R&D", application: "R&D expense variance: $8.7M overspend on AI platform development. Under IFRS, development costs capitalised when PIRRATE criteria met (IAS 38.57); under US GAAP, expensed until technological feasibility (ASC 985-20)." },
  { law: "FRS 102 s28 — Employee Benefits (UK)", application: "G&A variance includes pension contribution increase + salary inflation adjustments per FRS 102 s28." },
  { law: "IAS 12 — Income Tax (Deferred)", application: "Variance analysis pre-tax. Tax variance computed separately in Tax Center → Normal Tax tab." },
  { law: "Management Reporting Cadence (FP&A Best Practice)", application: "Monthly close (5-10 BD) → flash report (10-15 BD) → board pack (20-25 BD). This variance analysis is the flash report content." },
];

export const VARIANCE_META = {
  title: "Budget vs Actual Variance Analysis — FY2024 Monthly",
  entity: "Meridian Capital Holdings (Holding company consolidated)",
  fiscalYear: "FY2024",
  description: "Monthly budget vs actual with variance $ and %, F/U flag (OK/Watch/Investigate/Critical), and management commentary per line item.",
  methodology: "Variance % = (Actual − Budget) / Budget × 100. Positive = favorable for Revenue/EBITDA; Positive = unfavorable for Costs/OpEx. F/U flag: OK (±2%), Watch (2-5%), Investigate (5-15%), Critical (>15%).",
  lastUpdated: "November 2026",
  standards: "IAS 1.125 · ASC 270 · IFRS 15 · IAS 2 · IAS 38 · FRS 102 s28 · IAS 12 · FP&A Best Practice",
};
