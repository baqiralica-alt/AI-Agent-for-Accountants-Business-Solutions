"use client";

import { create } from "zustand";

export type ModuleKey =
  | "dashboard"
  | "agents"
  | "clients"
  | "transactions"
  | "journal"
  | "invoices"
  | "import"
  | "automations"
  | "integrations"
  | "api"
  | "tax"
  | "payroll"
  | "market-data"
  | "llm-hub"
  | "reports"
  | "consolidation"
  | "corporate-finance"
  | "disclosures"
  | "bank-accounts"
  | "help";

export type Company = {
  id: string;
  name: string;
  industry: string;
  country: string;
  currency: string;
  taxId?: string | null;
  paymentStatus?: string; // paid | overdue | blocked
  paymentDueDate?: string | null;
  lastPaymentDate?: string | null;
};

type AppState = {
  // The currently active tenant company
  activeCompanyId: string;
  activeCompany: Company | null;
  companies: Company[];
  setCompanies: (c: Company[]) => void;
  setActiveCompanyId: (id: string) => void;
  addCompany: (c: Company) => void;
  companiesLoaded: boolean;
  setCompaniesLoaded: (b: boolean) => void;
  reloadCompaniesFlag: number;
  bumpReloadCompanies: () => void;

  // Active module / sidebar selection
  activeModule: ModuleKey;
  setActiveModule: (m: ModuleKey) => void;

  // Sidebar collapse (desktop)
  sidebarOpen: boolean;
  setSidebarOpen: (b: boolean) => void;

  // Command palette (Cmd+K)
  commandOpen: boolean;
  setCommandOpen: (b: boolean) => void;
};

export const useAppStore = create<AppState>((set) => ({
  activeCompanyId: "co_usa_mfg",
  activeCompany: null,
  companies: [],
  companiesLoaded: false,
  setCompaniesLoaded: (b) => set({ companiesLoaded: b }),
  setCompanies: (c) =>
    set((s) => ({
      companies: c,
      activeCompany: c.find((x) => x.id === s.activeCompanyId) ?? c[0] ?? null,
      activeCompanyId: c.find((x) => x.id === s.activeCompanyId)?.id ?? c[0]?.id ?? s.activeCompanyId,
    })),
  setActiveCompanyId: (id) =>
    set((s) => ({ activeCompanyId: id, activeCompany: s.companies.find((x) => x.id === id) ?? null })),
  addCompany: (c) =>
    set((s) => ({ companies: [...s.companies, c], activeCompanyId: c.id, activeCompany: c, activeModule: "dashboard" })),
  reloadCompaniesFlag: 0,
  bumpReloadCompanies: () => set((s) => ({ reloadCompaniesFlag: s.reloadCompaniesFlag + 1 })),

  activeModule: "dashboard",
  setActiveModule: (m) => set({ activeModule: m }),

  sidebarOpen: true,
  setSidebarOpen: (b) => set({ sidebarOpen: b }),

  commandOpen: false,
  setCommandOpen: (b) => set({ commandOpen: b }),
}));
