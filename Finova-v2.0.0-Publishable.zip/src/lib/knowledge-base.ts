// Finova — Knowledge Base from uploaded workbooks
// Encodes the formats, laws, parameters, and report structures from:
// 1. FP&A Interview Prep Workbook (35 sheets — 3-statement, DCF, LBO, CECL, IFRS 9, REIT, construction, retail, SaaS, bank)
// 2. Head of FP&A Study Workbook (13 sheets — loan portfolio, liquidity, covenants, scenarios, DCF, 13-week cash, variance, capital)
// 3. TechFlow Solutions UK Practice Set (FRS 102 Section 1A — chart of accounts, 726 journal entries, trial balance, P&L, BS, CF, VAT100, CT600, SA302, payroll, audit working papers)

// ===================== IAS 1 / FRS 102 REPORT FORMAT =====================
// Every financial statement must include these sections per IAS 1.32-1.54:
export const IAS1_REPORT_STRUCTURE = {
  header: [
    "Name of the reporting entity",
    "Whether the financial statements cover the single entity or a group",
    "The reporting date or period covered",
    "The presentation currency",
    "The level of rounding used",
  ],
  primary_statements: [
    "Statement of financial position (Balance Sheet)",
    "Statement(s) of profit or loss and other comprehensive income",
    "Statement of changes in equity",
    "Statement of cash flows",
  ],
  notes_order: [
    "Note 1: Statement of compliance and basis of preparation",
    "Note 2: Significant accounting policies",
    "Note 3: Revenue recognition (IFRS 15 / ASC 606)",
    "Note 4: Leases (IFRS 16 / ASC 842)",
    "Note 5: Income taxes (IAS 12 / ASC 740)",
    "Note 6: Business combinations & goodwill (IFRS 3 / ASC 805)",
    "Note 7: Financial instruments (IFRS 9 / ASC 825)",
    "Note 8: Provisions & contingencies (IAS 37 / ASC 450)",
    "Note 9: Related party disclosures (IAS 24 / ASC 850)",
    "Note 10: Subsequent events (IAS 10 / ASC 855)",
    "Note 11: Operating segments (IFRS 8 / ASC 280)",
    "Note 12: Critical judgments & estimation uncertainty (IAS 1.122-133)",
  ],
  disclosure_must_be_inline: true, // Disclosures are part of the financial statements, not separate
};

// ===================== UK FRS 102 SECTION 1A CHECKLIST =====================
// From TechFlow Solutions practice set — 40-point FRS 102 Section 1A disclosure checklist
export const FRS102_SECTION_1A_CHECKLIST = [
  "Balance sheet (statement of financial position)",
  "Income statement (profit and loss account)",
  "Notes to the financial statements",
  "Accounting policies (FRS 102 Section 1A)",
  "Revenue recognition policy",
  "Depreciation policy",
  "Amortisation policy",
  "Trade receivables disclosure",
  "Trade payables disclosure",
  "Corporation tax computation",
  "Share capital disclosure",
  "Directors' remuneration disclosure",
  "Going concern basis",
  "Subsequent events review",
  "Audit exemption statement (Section 477A)",
  "Cash flow statement (indirect method)",
  "Bank reconciliation",
  "VAT returns (VAT100 quarterly)",
  "Payroll schedule (PAYE/NI)",
  "Self assessment (SA302 director)",
  "Trial balance (unadjusted, adjustments, final)",
  "Journal entries (general ledger)",
  "Chart of accounts",
  "Comparative figures (prior year)",
  "Note numbers cross-referenced to IS/BS",
  "Employee numbers disclosure",
  "Deferred tax disclosure",
  "Financial instruments disclosure",
  "Related party transactions",
  "Dividends disclosure",
  "Capital commitments",
  "Contingent liabilities",
  "Post-balance sheet events",
  "Audit working papers",
  "Marginal relief computation (if applicable)",
  "Dividend tax computation",
  "Cash flow indirect method",
  "Bank reconciliation evidence",
  "P60/PAYE filing references",
  "AIA (Annual Investment Allowance) computation",
];

// ===================== SAP FICO CHART OF ACCOUNTS (from TechFlow workbook) =====================
export const UK_CHART_OF_ACCOUNTS = [
  { code: "1010", name: "Cash at Bank", type: "Asset", statement: "BS" },
  { code: "1100", name: "Trade Receivables", type: "Asset", statement: "BS" },
  { code: "1150", name: "Prepayments", type: "Asset", statement: "BS" },
  { code: "1300", name: "PPE", type: "Asset", statement: "BS" },
  { code: "1310", name: "Accumulated Depreciation", type: "Contra-Asset", statement: "BS" },
  { code: "1400", name: "Intangible Assets", type: "Asset", statement: "BS" },
  { code: "1410", name: "Accumulated Amortisation", type: "Contra-Asset", statement: "BS" },
  { code: "2010", name: "Trade Payables", type: "Liability", statement: "BS" },
  { code: "2100", name: "Accruals", type: "Liability", statement: "BS" },
  { code: "2200", name: "VAT Output Tax", type: "Liability", statement: "BS" },
  { code: "2210", name: "VAT Input Tax", type: "Asset", statement: "BS" },
  { code: "2300", name: "PAYE Payable", type: "Liability", statement: "BS" },
  { code: "2400", name: "Corporation Tax Payable", type: "Liability", statement: "BS" },
  { code: "3000", name: "Share Capital", type: "Equity", statement: "BS" },
  { code: "3200", name: "Retained Earnings", type: "Equity", statement: "BS" },
  { code: "4000", name: "Consulting Revenue", type: "Income", statement: "IS" },
  { code: "4010", name: "Software Sub Revenue", type: "Income", statement: "IS" },
  { code: "4020", name: "Training Revenue", type: "Income", statement: "IS" },
  { code: "4030", name: "Interest Income", type: "Income", statement: "IS" },
  { code: "5000", name: "COGS - Subcontractors", type: "COGS", statement: "IS" },
  { code: "5010", name: "COGS - Materials", type: "COGS", statement: "IS" },
  { code: "6000", name: "Salaries and Wages", type: "Expense", statement: "IS" },
  { code: "6010", name: "Employers NI", type: "Expense", statement: "IS" },
  { code: "6020", name: "Pension Contributions", type: "Expense", statement: "IS" },
  { code: "6100", name: "Rent and Rates", type: "Expense", statement: "IS" },
  { code: "6200", name: "Utilities", type: "Expense", statement: "IS" },
  { code: "6300", name: "Professional Fees", type: "Expense", statement: "IS" },
  { code: "6400", name: "Software Subscriptions", type: "Expense", statement: "IS" },
  { code: "6500", name: "Insurance", type: "Expense", statement: "IS" },
  { code: "6600", name: "Travel and Subsistence", type: "Expense", statement: "IS" },
  { code: "6700", name: "Marketing", type: "Expense", statement: "IS" },
  { code: "6800", name: "Bank Charges", type: "Expense", statement: "IS" },
  { code: "6900", name: "Depreciation", type: "Expense", statement: "IS" },
  { code: "6910", name: "Amortisation", type: "Expense", statement: "IS" },
  { code: "7000", name: "Bad Debts", type: "Expense", statement: "IS" },
  { code: "8000", name: "Corporation Tax", type: "Expense", statement: "IS" },
];

// ===================== CONCEPTS GLOSSARY (97 terms from the workbooks) =====================
export const CONCEPTS_GLOSSARY = [
  { term: "3-Statement Model", category: "FP&A", definition: "Integrated income statement, balance sheet, and cash flow statement linked by formulas. Changes in one statement automatically update the others." },
  { term: "Driver Tree", category: "FP&A", definition: "Hierarchical decomposition of a KPI (e.g., Revenue = Price × Volume × Mix) used to build forecasts and run sensitivities." },
  { term: "CECL", category: "Lending", definition: "Current Expected Credit Losses — US GAAP ASC 326; requires lifetime ECL at origination for all financial assets carried at amortized cost." },
  { term: "IFRS 9 ECL", category: "Lending", definition: "3-stage approach: Stage 1 (12-month ECL), Stage 2 (lifetime ECL upon SICR), Stage 3 (lifetime ECL, credit-impaired)." },
  { term: "SICR", category: "Lending", definition: "Significant Increase in Credit Risk — trigger moving IFRS 9 loan from Stage 1 to Stage 2. Triggers: 30+ DPD, watchlist, rating downgrade." },
  { term: "DSCR", category: "Lending", definition: "NOI / (Principal + Interest). Min 1.25x typical covenant; 1.40x for new origination." },
  { term: "LTV", category: "Lending", definition: "Loan principal / appraised collateral value. Max 75% typical CRE; 65% office; 80% multifamily." },
  { term: "Debt Yield", category: "Lending", definition: "NOI / Loan principal. Lender's cap rate if foreclosed today. Min 8-10% typical." },
  { term: "REO", category: "Lending", definition: "Real Estate Owned — property acquired by lender through foreclosure. Recovery = sale proceeds - carrying costs - liens." },
  { term: "NPL", category: "Lending", definition: "Non-Performing Loan — past due >90 days or unlikely to pay. Triggers ECL stage transfer." },
  { term: "WACC", category: "Equity", definition: "(E/V × Re) + (D/V × Rd × (1-T)). Discount rate for FCFF; weights at market values." },
  { term: "CAPM", category: "Equity", definition: "Re = Rf + β × ERP. Required return on equity." },
  { term: "FCFF", category: "Equity", definition: "EBIT × (1-T) + D&A - ΔNWC - Capex. Discounted at WACC to get EV." },
  { term: "Terminal Value", category: "Equity", definition: "Gordon: TV = FCF × (1+g) / (WACC - g); Exit multiple: TV = EBITDA × EV/EBITDA_exit." },
  { term: "NOI", category: "REIT", definition: "Rental Revenue - Property Operating Expenses. Pre-leverage cash flow at property level." },
  { term: "FFO", category: "REIT", definition: "Net Income + D&A - gains on sales. NAREIT standard REIT cash earnings." },
  { term: "AFFO", category: "REIT", definition: "FFO - recurring capex - leasing commissions - straight-line rent. Distributable cash." },
  { term: "Cap Rate", category: "REIT", definition: "NOI / Property Value. 4-6% prime US; 5-7% secondary; UK 4.5-6.5%." },
  { term: "NAV", category: "REIT", definition: "(Property NOI / Cap rate) + other assets - debt. Asset-based valuation per share." },
  { term: "% Completion", category: "Construction", definition: "Costs Incurred / Total Estimated Cost × Contract Value. ASC 606 / IFRS 15." },
  { term: "WIP", category: "Construction", definition: "Costs incurred + profit recognized - billings. Asset if positive, liability if negative." },
  { term: "Backlog", category: "Construction", definition: "Contracted work not yet recognized. >12 months of revenue = healthy." },
  { term: "EMR", category: "Construction", definition: "Experience Modification Rate — worker's comp multiplier. 1.0 = avg; <0.9 excellent." },
  { term: "SSS", category: "Retail", definition: "Same-Store Sales — stores open ≥13 months. Traffic × Conversion × AOV." },
  { term: "GMROI", category: "Retail", definition: "Gross Margin $ / Average Inventory Cost. >200 healthy apparel." },
  { term: "ARR", category: "SaaS", definition: "MRR × 12. Primary SaaS valuation driver (EV/ARR multiple)." },
  { term: "NRR", category: "SaaS", definition: "(Starting + Expansion - Contraction - Churn) / Starting. >120% top quartile." },
  { term: "Magic Number", category: "SaaS", definition: "Q ARR Growth × 4 / Prior Q S&M. >0.75 excellent GTM efficiency." },
  { term: "Rule of 40", category: "SaaS", definition: "Rev Growth % + FCF Margin % ≥ 40%. Balances growth vs profitability." },
  { term: "Burn Multiple", category: "SaaS", definition: "Net Cash Burn / Net New ARR. <1.0 excellent capital efficiency." },
  { term: "LBO", category: "Equity", definition: "Leveraged Buyout — 60-70% debt. Returns from EBITDA growth, debt paydown, multiple expansion." },
  { term: "IRR", category: "Equity", definition: "Discount rate making NPV zero. LBO target: 20-25% base, 15% stress." },
  { term: "MOIC", category: "Equity", definition: "Exit Equity / Initial Equity. Cash-on-cash. 2.0-3.0x target for LBO." },
  { term: "CET1 Ratio", category: "Banking", definition: "Common Equity Tier 1 / RWA. Min 4.5% + 2.5% buffer = 7.0%. Target 12-14%." },
  { term: "NIM", category: "Banking", definition: "(Interest Income - Interest Expense) / Avg Earning Assets. 3-4% US commercial." },
  { term: "Efficiency Ratio", category: "Banking", definition: "Non-Interest Expense / Revenue. <55% excellent; 55-65% typical; >65% concern." },
];

// ===================== KEY FORMULAS (from cheat sheet) =====================
export const KEY_FORMULAS = [
  { formula: "WACC = (E/V × Re) + (D/V × Rd × (1-T))", use: "DCF discount rate" },
  { formula: "Re = Rf + β × ERP + Size Premium + CRP", use: "CAPM cost of equity" },
  { formula: "FCFF = EBIT × (1-T) + D&A - ΔNWC - Capex", use: "DCF enterprise value" },
  { formula: "TV (Gordon) = FCF × (1+g) / (WACC - g)", use: "DCF terminal value" },
  { formula: "DSCR = NOI / (Principal + Interest)", use: "Loan covenant" },
  { formula: "LTV = Loan / Collateral Value", use: "Loan underwriting" },
  { formula: "Debt Yield = NOI / Loan Principal", use: "Loan underwriting" },
  { formula: "CECL = PD × LGD × EAD × (1 + Q-factors)", use: "US GAAP ASC 326" },
  { formula: "NOI = Rental Rev - Property OpEx", use: "REIT valuation" },
  { formula: "NAV = (NOI/Cap Rate) + Other Assets - Debt", use: "REIT per-share value" },
  { formula: "ARR = MRR × 12", use: "SaaS valuation" },
  { formula: "NRR = (Beg + Expansion - Contraction - Churn) / Beg", use: "SaaS health" },
  { formula: "Magic Number = Q ARR Growth × 4 / Prior Q S&M", use: "SaaS GTM efficiency" },
  { formula: "Rule of 40 = Rev Growth % + FCF Margin %", use: "SaaS benchmark" },
  { formula: "Burn Multiple = Net Burn / Net New ARR", use: "SaaS capital efficiency" },
  { formula: "IRR = MOIC^(1/years) - 1", use: "LBO/private equity returns" },
  { formula: "Justified P/E = Payout / (k - g)", use: "Valuation cross-check" },
  { formula: "% Complete = Costs Incurred / Total Est Cost", use: "Construction revenue ASC 606" },
  { formula: "GMROI = Gross Margin $ / Avg Inventory Cost", use: "Retail inventory productivity" },
  { formula: "Efficiency Ratio = Non-Int Expense / Revenue", use: "Banking cost efficiency" },
];

// ===================== RATIO THRESHOLDS (healthy / watch / danger) =====================
export const RATIO_THRESHOLDS = [
  { ratio: "DSCR", healthy: ">1.40x", watch: "1.20-1.40x", danger: "<1.20x", sector: "CRE Lending" },
  { ratio: "LTV", healthy: "<65%", watch: "65-75%", danger: ">75%", sector: "CRE Lending" },
  { ratio: "Debt Yield", healthy: ">10%", watch: "8-10%", danger: "<8%", sector: "CRE Lending" },
  { ratio: "Debt/EBITDA", healthy: "<3.0x", watch: "3.0-4.5x", danger: ">4.5x", sector: "Corporate" },
  { ratio: "Interest Coverage", healthy: ">4.0x", watch: "3.0-4.0x", danger: "<3.0x", sector: "Corporate" },
  { ratio: "Current Ratio", healthy: ">1.5x", watch: "1.0-1.5x", danger: "<1.0x", sector: "Corporate" },
  { ratio: "NIM", healthy: ">3.5%", watch: "3.0-3.5%", danger: "<3.0%", sector: "Banking" },
  { ratio: "CET1 Ratio", healthy: ">13%", watch: "11-13%", danger: "<11%", sector: "Banking" },
  { ratio: "NRR (SaaS)", healthy: ">120%", watch: "100-120%", danger: "<100%", sector: "SaaS" },
  { ratio: "Rule of 40", healthy: ">40%", watch: "30-40%", danger: "<30%", sector: "SaaS" },
  { ratio: "Burn Multiple", healthy: "<1.0", watch: "1.0-2.0", danger: ">2.0", sector: "SaaS" },
  { ratio: "EMR (Construction)", healthy: "<0.90", watch: "0.90-1.10", danger: ">1.10", sector: "Construction" },
  { ratio: "Inventory Turn", healthy: ">5.0x", watch: "3.5-5.0x", danger: "<3.5x", sector: "Retail" },
  { ratio: "ROE", healthy: ">15%", watch: "10-15%", danger: "<10%", sector: "All" },
  { ratio: "ROIC vs WACC", healthy: ">WACC+500bps", watch: "WACC to WACC+500bps", danger: "<WACC", sector: "All" },
];

// ===================== US GAAP vs IFRS KEY DIFFERENCES =====================
export const GAAP_VS_IFRS = [
  { topic: "Credit Losses", us_gaap: "ASC 326 CECL — lifetime from Day 1", ifrs: "IFRS 9 ECL — 3-stage (12-mo / lifetime SICR / lifetime impaired)", difference: "MAJOR: CECL no staging; IFRS 9 stages via SICR" },
  { topic: "Revenue", us_gaap: "ASC 606 — 5-step model", ifrs: "IFRS 15 — 5-step model", difference: "Mostly converged; collection threshold differs" },
  { topic: "Leases (Lessee)", us_gaap: "ASC 842 — dual model (operating/finance)", ifrs: "IFRS 16 — single model (all finance-like)", difference: "MAJOR: IFRS 16 front-loads expense; EBITDA higher" },
  { topic: "Income Taxes", us_gaap: "ASC 740 — DTA valuation allowance", ifrs: "IAS 12 — DTA recognition threshold", difference: "Similar; UK 25% vs US 21% federal + state" },
  { topic: "Hedge Accounting", us_gaap: "ASC 815 — rules-based, 80-125% effectiveness", ifrs: "IFRS 9 — principles-based, broader eligibility", difference: "IFRS 9 easier to qualify; less P&L volatility" },
  { topic: "Business Combinations", us_gaap: "ASC 805", ifrs: "IFRS 3", difference: "Largely converged; goodwill = purchase price - FV net assets" },
  { topic: "Consolidation", us_gaap: "ASC 810 / VIE model", ifrs: "IFRS 10 — control = power + variable returns + ability to use power", difference: "US: VIE analysis; IFRS: control assessment" },
];

// ===================== UK-SPECIFIC TAX PARAMETERS =====================
export const UK_TAX_PARAMS = {
  corporation_tax: {
    main_rate: "25% (profits >£250k)",
    small_rate: "19% (profits ≤£50k)",
    marginal_relief: "Between £50k-£250k, marginal relief applies",
    patent_box: "10% effective rate on qualifying patent profits",
    ct600_filing: "12 months after FY-end",
    ct_payment: "9 months + 1 day after FY-end",
    quarterly_instalments: "Required if profits >£1.5M (large company)",
  },
  vat: {
    standard_rate: "20%",
    reduced_rate: "5%",
    zero_rate: "0% (food, books, children's clothing)",
    registration_threshold: "£90,000 (2024/25)",
    filing: "Quarterly VAT100 via Making Tax Digital",
    boxes: {
      box1: "VAT Output Tax (sales)",
      box4: "VAT Input Tax (purchases)",
      box5: "Net VAT Payable (Box 1 - Box 4)",
      box6: "Total Sales (excl VAT)",
      box7: "Total Purchases (excl VAT)",
    },
  },
  paye_ni: {
    paye_threshold: "£12,570 personal allowance (2025/26)",
    basic_rate: "20% (£12,571-£50,270)",
    higher_rate: "40% (£50,271-£125,140)",
    additional_rate: "45% (>£125,140)",
    employee_ni: "8% (£12,570-£50,270)",
    employer_ni: "13.8% (above £9,100/yr per employee)",
    pension_auto_enrol: "5% employee + 3% employer (minimum)",
    filing: "Monthly FPS/EPS via HMRC RTI",
    p60_deadline: "19 April following tax year",
  },
  self_assessment: {
    filing_deadline: "31 January (online) following tax year end",
    payment_deadline: "31 January (balancing payment) + 31 July (payment on account)",
    dividend_allowance: "£500 (2025/26)",
    dividend_tax_basic: "8.75%",
    dividend_tax_higher: "33.75%",
    dividend_tax_additional: "39.35%",
  },
  capital_allowances: {
    aia_limit: "£1,000,000 (2025)",
    writing_down_allowance: "18% main pool, 6% special pool",
    full_expensing: "100% for qualifying plant & machinery (permanent)",
    structures_allowances: "3% for qualifying buildings",
  },
};

// ===================== US-SPECIFIC TAX PARAMETERS =====================
export const US_TAX_PARAMS = {
  federal_corp_tax: "21% flat",
  state_corp_tax: "~5% blended (varies by state; TX 0%, CA 8.84%)",
  effective_rate: "~24.5% (federal + state)",
  sales_tax: "State + local; CA 7.25%, NY 8.875%, TX 6.25%",
  payroll_tax: {
    futa: "0.6% (first $7k per employee)",
    suta: "~2.7% (varies by state experience rating)",
    social_security_employer: "6.2% (first $168,600 in 2024)",
    medicare_employer: "1.45% (no cap)",
    social_security_employee: "6.2%",
    medicare_employee: "1.45% (+0.9% additional >$200k)",
  },
  r_and_d_credit: "Form 6765 — 20% qualified spending (alternative simplified 14%)",
  section_174: "R&D costs MUST be amortized 5yr (US) / 15yr (foreign) since 2022",
  form_941: "Quarterly payroll tax return",
  form_1120: "Federal corporation income tax return",
};

// ===================== COMMERCIAL LENDING MODELS (from Head of FP&A workbook) =====================
export const LENDING_MODELS = {
  cecl: {
    standard: "ASC 326",
    formula: "CECL = PD × LGD × EAD × (1 + Q-factors)",
    stages: "Single stage — lifetime ECL from Day 1",
    q_factors: [
      "Economic conditions (national)",
      "Economic conditions (regional)",
      "Industry/sector trends",
      "Lending volume growth",
      "Loan concentration",
      "Credit quality trends",
      "Collateral values",
      "Borrower financial condition",
      "Other factors (regulatory)",
    ],
    typical_reserve: "~$30-35M for $1B portfolio",
  },
  ifrs9_ecl: {
    standard: "IFRS 9",
    formula: "ECL = PD × LGD × EAD (stage-dependent)",
    stages: {
      stage1: "Performing — 12-month ECL",
      stage2: "SICR — Lifetime ECL",
      stage3: "Credit-impaired — Lifetime ECL on drawn balance",
    },
    sicr_triggers: [
      "30+ days past due",
      "Watchlist addition (rating 6+)",
      "Risk rating downgrade (2+ notches)",
      "Borrower payment default",
      "Collateral value decline >20%",
      "Covenant breach",
      "Forbearance / modification",
      "Borrower bankruptcy filing",
    ],
    cure_period: "12 months sustained performance before transfer back",
  },
  covenant_compliance: {
    types: ["DSCR (min 1.25x)", "LTV (max 75%)", "Debt Yield (min 8-10%)", "Interest Coverage (min 3.0x)", "Max Leverage (4.5x)", "Min Liquidity", "Min Tangible Net Worth"],
    breach_process: "Notice → 30-90 day cure → waiver/amendment/acceleration → cross-default risk",
  },
  reo_lifecycle: {
    steps: ["Foreclosure (judicial ~12mo / non-judicial ~4mo)", "Eviction", "Stabilization", "Marketing (6-18mo)", "Sale"],
    carrying_costs: "Property taxes, insurance, maintenance, security, utilities",
    recovery_formula: "Sale Proceeds - Carrying Costs - Brokerage (3%) - Senior Liens",
    loss_severity: "(Original Loan - Recovery) / Original Loan",
    recovery_by_type: { industrial: "80-85%", multifamily: "80-85%", office: "50-55%", retail: "50-55%" },
  },
};

// ===================== MARKET DATA (from workbook Sheet 04) =====================
export const MARKET_DATA = {
  fx: { usd_gbp: 0.79, usd_eur: 0.92, gbp_eur: 1.16 },
  risk_free_rates: {
    us_10y: "4.3%",
    us_3m: "4.4%",
    uk_10y: "4.1%",
    uk_3m: "4.2%",
    sofr: "4.4%",
    sonia: "4.6%",
  },
  equity_risk_premium: { us: "4.5%", uk: "4.4%", mature_markets: "4.5%" },
  size_premiums: {
    mega_cap: "0.5%",
    large_cap: "1.1%",
    mid_cap: "2.6%",
    small_cap: "4.0%",
    micro_cap: "5.5%",
  },
  betas: {
    tech_saas: "1.2x",
    reits: "0.9x",
    banks: "1.1x",
    retail: "1.1x",
    construction: "1.2x",
  },
  credit_spreads: {
    investment_grade: "125 bps, 0.1% 1yr PD",
    cross_over: "250 bps, 1.2% 1yr PD",
    speculative: "450 bps, 4.0% 1yr PD",
    distressed: "900 bps, 27.5% 1yr PD",
  },
  statutory_tax_rates: {
    us_federal: "21% (effective ~24.5%)",
    uk: "25% (main), 19% (small)",
    ireland: "12.5%",
    singapore: "17%",
    uae: "9%",
  },
};

// ===================== SECTOR-SPECIFIC KPIs (from workbooks) =====================
export const SECTOR_KPIS = {
  REIT: ["NOI", "FFO", "AFFO", "Cap Rate", "NAV", "WALT", "Releasing Spread", "Occupancy", "P/FFO", "P/AFFO", "Dividend Coverage"],
  Construction: ["% Complete", "WIP", "Over/Under Billings", "Backlog (months of revenue)", "EMR", "TRIR", "DART", "Surety Utilization", "Project Margin vs Bid"],
  Retail: ["Same-Store Sales", "Traffic × Conversion × AOV", "GMROI", "Inventory Turn", "Shrinkage %", "Four-Wall Contribution", "Markdown %", "Comp Store Count"],
  SaaS: ["ARR", "MRR", "NRR", "GRR", "CAC", "LTV", "LTV:CAC", "Magic Number", "Rule of 40", "Burn Multiple", "CAC Payback", "Cohort Retention"],
  Banking: ["NIM", "Efficiency Ratio", "ROA", "ROE", "LDR", "ACL/Gross Loans", "CET1 Ratio", "PLL/Avg Loans"],
  Lending: ["Origination Volume", "NPL Ratio", "Default Rate", "Recovery Rate", "LGD", "DSCR", "LTV", "Debt Yield", "Facility Utilization"],
};
