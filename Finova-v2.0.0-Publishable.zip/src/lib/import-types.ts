// Shared types for the import flow
export type ParsedTxn = {
  date?: string;
  description?: string;
  amount?: number;
  type?: "income" | "expense";
  category?: string;
  account?: string;
};
