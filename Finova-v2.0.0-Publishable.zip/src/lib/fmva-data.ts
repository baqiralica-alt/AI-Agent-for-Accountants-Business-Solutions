// FMVA® Reporting Framework — Full valuation methodologies with linked formulas
// 9 valuation methodologies + FMVA-Compliant Reports index
// All data fictitious but realistic. Standards: IFRS (IAS 1, IFRS 3, IFRS 10),
// US GAAP (ASC 805, ASC 810, ASC 350), EU IFRS-EU, Canada (ASPE/IFRS-Canada).
//
// TARGET COMPANY: Cortex AI Labs Inc (US, AI/SaaS) — same as in loan portfolio L-006
// Acquirer (for M&A analysis): Meridian Capital Holdings (from 3-statement model)
//
// SOURCES: market data as of November 2026 (Damodaran ERP 4.41%, US 10Y 4.30%, etc.)

// ===================================================================
// 1. WACC CALCULATOR (CAPM + After-Tax Cost of Debt)
// ===================================================================
export type WACCComponent = {
  component: string;
  weight: number;          // %
  rate: number;            // %
  contribution: number;    // weight × rate = %
  formula: string;
  source: string;
};

export const WACC_COMPONENTS: WACCComponent[] = [
  {
    component: "Cost of Equity (Re)",
    weight: 80.0,
    rate: 9.59,
    contribution: 7.67,
    formula: "Re = Rf + β × ERP = 4.30% + 1.20 × 4.41%",
    source: "CAPM — Rf: US 10Y Treasury 4.30% (Nov 19, 2026); β: 1.20x (Bloomberg 2-yr weekly, SaaS mature); ERP: Damodaran Nov 1, 2026 implied 4.41%",
  },
  {
    component: "Cost of Debt (Rd, pre-tax)",
    weight: 20.0,
    rate: 6.50,
    contribution: 0.98,
    formula: "After-tax Rd = 6.50% × (1 − 24.5%) = 4.91%; weighted = 20% × 4.91% = 0.98%",
    source: "Pre-tax: 6.50% (BBB-rated SaaS issuer spread 250bps over 10Y); Tax rate: 24.5% US federal effective",
  },
];

export const WACC_RESULT = {
  costOfEquity: 9.59,
  costOfDebtPreTax: 6.50,
  costOfDebtAfterTax: 4.91,
  taxRate: 24.5,
  riskFreeRate: 4.30,
  beta: 1.20,
  equityRiskPremium: 4.41,
  sizePremium: 1.10,    // Large cap $5-25B
  equityWeight: 80.0,
  debtWeight: 20.0,
  wacc: 8.65,
  formula: "WACC = (E/V × Re) + (D/V × Rd × (1−T)) = (0.80 × 9.59%) + (0.20 × 4.91%) = 7.67% + 0.98% = 8.65%",
  assumptions: {
    equityValue: 400,    // $M (market cap)
    debtValue: 100,      // $M (total debt at market)
    totalCapital: 500,
    sharesOutstanding: 20, // M shares
    currentPricePerShare: 20.00,
  },
};

// ===================================================================
// 2. DCF VALUATION (5-Year FCFF + Gordon Growth Terminal Value)
// ===================================================================
export type DCFRow = {
  year: string;
  revenue: number;
  revenueGrowthPct: number;
  ebitdaMarginPct: number;
  ebitda: number;
  da: number;
  ebit: number;
  taxRate: number;
  nopat: number;         // EBIT × (1-T)
  plusDA: number;
  lessCapex: number;
  lessDeltaNWC: number;
  fcff: number;          // Free Cash Flow to Firm
  discountPeriod: number;
  discountFactor: number;
  pvOfFcf: number;
};

const DCF_YEARS = ["FY2024E", "FY2025E", "FY2026E", "FY2027E", "FY2028E"];
const SEED_REVENUE = 50;  // $M FY2023A
const REVENUE_GROWTH = [0.30, 0.28, 0.25, 0.22, 0.18];
const EBITDA_MARGIN = [0.05, 0.10, 0.15, 0.20, 0.25]; // improving
const DA_PCT_OF_REV = [0.04, 0.04, 0.04, 0.04, 0.04];
const CAPEX_PCT_OF_REV = [0.08, 0.07, 0.06, 0.05, 0.05];
const NWC_PCT_OF_REV = [0.10, 0.10, 0.10, 0.10, 0.10];
const TAX_RATE = 0.245;

export const DCF_FORECAST: DCFRow[] = DCF_YEARS.map((y, i) => {
  const revenue = Math.round(SEED_REVENUE * (1 + REVENUE_GROWTH[i]) * 100) / 100;
  const ebitda = Math.round(revenue * EBITDA_MARGIN[i] * 100) / 100;
  const da = Math.round(revenue * DA_PCT_OF_REV[i] * 100) / 100;
  const ebit = Math.round((ebitda - da) * 100) / 100;
  const nopat = Math.round(ebit * (1 - TAX_RATE) * 100) / 100;
  const capex = Math.round(revenue * CAPEX_PCT_OF_REV[i] * 100) / 100;
  const deltaNWC = Math.round(revenue * NWC_PCT_OF_REV[i] * 0.10 * 100) / 100; // 10% of revenue change
  const fcff = Math.round((nopat + da - capex - deltaNWC) * 100) / 100;
  const discountPeriod = i + 1; // 1, 2, 3, 4, 5
  const discountFactor = Math.round((1 / Math.pow(1 + WACC_RESULT.wacc / 100, discountPeriod)) * 10000) / 10000;
  const pvOfFcf = Math.round(fcff * discountFactor * 100) / 100;
  return {
    year: y,
    revenue,
    revenueGrowthPct: REVENUE_GROWTH[i] * 100,
    ebitdaMarginPct: EBITDA_MARGIN[i] * 100,
    ebitda,
    da,
    ebit,
    taxRate: TAX_RATE * 100,
    nopat,
    plusDA: da,
    lessCapex: -capex,
    lessDeltaNWC: -deltaNWC,
    fcff,
    discountPeriod,
    discountFactor,
    pvOfFcf,
  };
});

// Terminal Value (Gordon Growth): TV = FCFF_n × (1+g) / (WACC − g)
const TERMINAL_GROWTH_RATE = 0.03; // 3% perpetual
const FINAL_FCFF = DCF_FORECAST[DCF_FORECAST.length - 1].fcff;
const TERMINAL_VALUE = Math.round((FINAL_FCFF * (1 + TERMINAL_GROWTH_RATE)) / (WACC_RESULT.wacc / 100 - TERMINAL_GROWTH_RATE) * 100) / 100;
const TV_DISCOUNT_FACTOR = DCF_FORECAST[DCF_FORECAST.length - 1].discountFactor;
const PV_OF_TV = Math.round(TERMINAL_VALUE * TV_DISCOUNT_FACTOR * 100) / 100;

const SUM_PV_FCFF = Math.round(DCF_FORECAST.reduce((s, r) => s + r.pvOfFcf, 0) * 100) / 100;
const ENTERPRISE_VALUE_DCF = Math.round((SUM_PV_FCFF + PV_OF_TV) * 100) / 100;
const NET_DEBT = 60; // $M (Debt 100 - Cash 40)
const EQUITY_VALUE_DCF = Math.round((ENTERPRISE_VALUE_DCF - NET_DEBT) * 100) / 100;
const DCF_PER_SHARE = Math.round((EQUITY_VALUE_DCF / WACC_RESULT.assumptions.sharesOutstanding) * 100) / 100;

export const DCF_VALUATION = {
  forecast: DCF_FORECAST,
  terminalValue: {
    method: "Gordon Growth Model",
    finalYearFcff: FINAL_FCFF,
    perpetualGrowthRate: TERMINAL_GROWTH_RATE * 100,
    wacc: WACC_RESULT.wacc,
    formula: "TV = FCFF_n × (1+g) / (WACC − g)",
    terminalValue: TERMINAL_VALUE,
    discountFactor: TV_DISCOUNT_FACTOR,
    pvOfTerminalValue: PV_OF_TV,
    percentOfEV: Math.round((PV_OF_TV / ENTERPRISE_VALUE_DCF) * 1000) / 10,
  },
  bridge: {
    sumOfPvFcff: SUM_PV_FCFF,
    pvOfTerminalValue: PV_OF_TV,
    enterpriseValue: ENTERPRISE_VALUE_DCF,
    lessNetDebt: -NET_DEBT,
    equityValue: EQUITY_VALUE_DCF,
    sharesOutstanding: WACC_RESULT.assumptions.sharesOutstanding,
    valuePerShare: DCF_PER_SHARE,
  },
  formulas: {
    fcff: "FCFF = EBIT × (1−T) + D&A − Capex − ΔNWC",
    pvOfFcf: "PV(FCFF_t) = FCFF_t / (1 + WACC)^t",
    terminalValue: "TV = FCFF_n × (1+g) / (WACC − g)",
    pvOfTv: "PV(TV) = TV / (1 + WACC)^n",
    enterpriseValue: "EV = Σ PV(FCFF) + PV(TV)",
    equityValue: "Equity Value = EV − Net Debt",
    perShare: "Value per Share = Equity Value / Shares Outstanding",
  },
};

// ===================================================================
// 3. TRADING COMPARABLES (Peer Set)
// ===================================================================
export type CompPeer = {
  ticker: string;
  company: string;
  marketCap: number;       // $M
  enterpriseValue: number; // $M
  revenue: number;         // $M LTM
  ebitda: number;          // $M LTM
  evRevenue: number;       // x
  evEbitda: number;        // x
  growthPct: number;       // YoY revenue growth
};

export const TRADING_COMPS: CompPeer[] = [
  { ticker: "SNOW", company: "Snowflake Inc", marketCap: 55000, enterpriseValue: 52000, revenue: 3500, ebitda: -200, evRevenue: 14.9, evEbitda: -260, growthPct: 32 },
  { ticker: "PLTR", company: "Palantir Technologies", marketCap: 78000, enterpriseValue: 75000, revenue: 2800, ebitda: 560, evRevenue: 26.8, evEbitda: 133.9, growthPct: 28 },
  { ticker: "DDOG", company: "Datadog Inc", marketCap: 42000, enterpriseValue: 39500, revenue: 2600, ebitda: 520, evRevenue: 15.2, evEbitda: 76.0, growthPct: 24 },
  { ticker: "MDB", company: "MongoDB Inc", marketCap: 28000, enterpriseValue: 27500, revenue: 1900, ebitda: 95, evRevenue: 14.5, evEbitda: 289.5, growthPct: 22 },
  { ticker: "ESTC", company: "Elastic NV", marketCap: 11000, enterpriseValue: 10500, revenue: 1400, ebitda: 110, evRevenue: 7.5, evEbitda: 95.5, growthPct: 18 },
];

const TRADING_COMPS_STATS = {
  evRevenueLow: Math.min(...TRADING_COMPS.map(p => p.evRevenue)),
  evRevenueHigh: Math.max(...TRADING_COMPS.map(p => p.evRevenue)),
  evRevenueMean: Math.round(TRADING_COMPS.reduce((s, p) => s + p.evRevenue, 0) / TRADING_COMPS.length * 10) / 10,
  evRevenueMedian: 15.2,
  evEbitdaMean: Math.round(TRADING_COMPS.filter(p => p.evEbitda > 0).reduce((s, p) => s + p.evEbitda, 0) / TRADING_COMPS.filter(p => p.evEbitda > 0).length * 10) / 10,
};

// Apply trading comps to Cortex FY2024E revenue ($65M) and EBITDA ($3.25M)
const TARGET_FY24E_REVENUE = 65;
const TARGET_FY24E_EBITDA = 3.25;
const TRADING_COMPS_VALUATION = {
  targetRevenue: TARGET_FY24E_REVENUE,
  targetEbitda: TARGET_FY24E_EBITDA,
  // EV/Revenue range
  evRevLow: Math.round(TRADING_COMPS_STATS.evRevenueLow * TARGET_FY24E_REVENUE),
  evRevHigh: Math.round(TRADING_COMPS_STATS.evRevenueHigh * TARGET_FY24E_REVENUE),
  evRevMean: Math.round(TRADING_COMPS_STATS.evRevenueMean * TARGET_FY24E_REVENUE),
  // EV/EBITDA range (note: with negative EBITDA in some peers, only positive EBITDA peers used)
  evEbitdaLow: Math.round(Math.min(...TRADING_COMPS.filter(p => p.evEbitda > 0).map(p => p.evEbitda)) * TARGET_FY24E_EBITDA),
  evEbitdaHigh: Math.round(Math.max(...TRADING_COMPS.filter(p => p.evEbitda > 0).map(p => p.evEbitda)) * TARGET_FY24E_EBITDA),
  evEbitdaMean: Math.round(TRADING_COMPS_STATS.evEbitdaMean * TARGET_FY24E_EBITDA),
  perShareLow: 0,
  perShareHigh: 0,
  perShareMean: 0,
};
TRADING_COMPS_VALUATION.perShareLow = Math.round((TRADING_COMPS_VALUATION.evRevLow - NET_DEBT) / WACC_RESULT.assumptions.sharesOutstanding * 100) / 100;
TRADING_COMPS_VALUATION.perShareHigh = Math.round((TRADING_COMPS_VALUATION.evRevHigh - NET_DEBT) / WACC_RESULT.assumptions.sharesOutstanding * 100) / 100;
TRADING_COMPS_VALUATION.perShareMean = Math.round((TRADING_COMPS_VALUATION.evRevMean - NET_DEBT) / WACC_RESULT.assumptions.sharesOutstanding * 100) / 100;

export const TRADING_COMPARABLES = {
  peers: TRADING_COMPS,
  stats: TRADING_COMPS_STATS,
  valuation: TRADING_COMPS_VALUATION,
  formulas: {
    evRevenue: "EV / Revenue (LTM)",
    evEbitda: "EV / EBITDA (LTM) — applicable when EBITDA > 0",
    enterpriseValue: "EV = Market Cap + Total Debt − Cash",
    impliedEquityValue: "Implied Equity = (EV multiple × target metric) − Net Debt",
    perShare: "Per Share = Implied Equity / Shares Outstanding",
  },
};

// ===================================================================
// 4. PRECEDENT TRANSACTIONS (M&A Multiples)
// ===================================================================
export type PrecedentTx = {
  date: string;
  acquirer: string;
  target: string;
  dealValue: number;     // $M EV
  targetRevenue: number; // $M LTM
  targetEbitda: number;  // $M LTM
  evRevenue: number;
  evEbitda: number | null;
  premiumPct: number;
};

export const PRECEDENT_TRANSACTIONS: PrecedentTx[] = [
  { date: "2026-09-15", acquirer: "Salesforce", target: "Informatica", dealValue: 8000, targetRevenue: 1600, targetEbitda: 320, evRevenue: 5.0, evEbitda: 25.0, premiumPct: 28 },
  { date: "2026-07-22", acquirer: "Microsoft", target: "AI Startup X", dealValue: 1500, targetRevenue: 80, targetEbitda: -10, evRevenue: 18.8, evEbitda: null, premiumPct: 45 },
  { date: "2026-05-10", acquirer: "Adobe", target: "Design SaaS Y", dealValue: 2400, targetRevenue: 200, targetEbitda: 40, evRevenue: 12.0, evEbitda: 60.0, premiumPct: 35 },
  { date: "2026-03-08", acquirer: "Oracle", target: "Cloud Z", dealValue: 6800, targetRevenue: 850, targetEbitda: 150, evRevenue: 8.0, evEbitda: 45.3, premiumPct: 30 },
  { date: "2026-01-20", acquirer: "Google", target: "Security Co W", dealValue: 3200, targetRevenue: 280, targetEbitda: 35, evRevenue: 11.4, evEbitda: 91.4, premiumPct: 38 },
];

const PREC_STATS = {
  evRevenueLow: Math.min(...PRECEDENT_TRANSACTIONS.map(t => t.evRevenue)),
  evRevenueHigh: Math.max(...PRECEDENT_TRANSACTIONS.map(t => t.evRevenue)),
  evRevenueMean: Math.round(PRECEDENT_TRANSACTIONS.reduce((s, t) => s + t.evRevenue, 0) / PRECEDENT_TRANSACTIONS.length * 10) / 10,
  evRevenueMedian: 11.4,
  avgPremium: Math.round(PRECEDENT_TRANSACTIONS.reduce((s, t) => s + t.premiumPct, 0) / PRECEDENT_TRANSACTIONS.length * 10) / 10,
};

const PREC_VALUATION = {
  targetRevenue: TARGET_FY24E_REVENUE,
  evRevLow: Math.round(PREC_STATS.evRevenueLow * TARGET_FY24E_REVENUE),
  evRevHigh: Math.round(PREC_STATS.evRevenueHigh * TARGET_FY24E_REVENUE),
  evRevMean: Math.round(PREC_STATS.evRevenueMean * TARGET_FY24E_REVENUE),
  avgControlPremium: PREC_STATS.avgPremium,
  perShareLow: 0,
  perShareHigh: 0,
  perShareMean: 0,
};
PREC_VALUATION.perShareLow = Math.round((PREC_VALUATION.evRevLow - NET_DEBT) / WACC_RESULT.assumptions.sharesOutstanding * 100) / 100;
PREC_VALUATION.perShareHigh = Math.round((PREC_VALUATION.evRevHigh - NET_DEBT) / WACC_RESULT.assumptions.sharesOutstanding * 100) / 100;
PREC_VALUATION.perShareMean = Math.round((PREC_VALUATION.evRevMean - NET_DEBT) / WACC_RESULT.assumptions.sharesOutstanding * 100) / 100;

export const PRECEDENT_TRANSACTIONS_DATA = {
  transactions: PRECEDENT_TRANSACTIONS,
  stats: PREC_STATS,
  valuation: PREC_VALUATION,
  formulas: {
    evRevenue: "EV / Revenue (LTM at announcement)",
    evEbitda: "EV / EBITDA (LTM at announcement)",
    controlPremium: "Premium = (Offer Price − Unaffected Price) / Unaffected Price",
    impliedValue: "Implied EV = Median Multiple × Target Metric",
  },
};

// ===================================================================
// 5. SENSITIVITY & SCENARIO ANALYSIS
// ===================================================================
export type ScenarioRow = {
  scenario: string;
  revenueGrowthPct: number;
  ebitdaMarginPct: number;
  terminalFcff: number;
  terminalValue: number;
  equityValue: number;
  perShare: number;
  probabilityPct: number;
};

export const SCENARIOS: ScenarioRow[] = [
  {
    scenario: "Best Case",
    revenueGrowthPct: 35,
    ebitdaMarginPct: 30,
    terminalFcff: 14.2,
    terminalValue: 285.5,
    equityValue: 360,
    perShare: 18.00,
    probabilityPct: 20,
  },
  {
    scenario: "Base Case",
    revenueGrowthPct: 25,
    ebitdaMarginPct: 20,
    terminalFcff: 9.8,
    terminalValue: 197.0,
    equityValue: 265,
    perShare: 13.25,
    probabilityPct: 60,
  },
  {
    scenario: "Worst Case",
    revenueGrowthPct: 15,
    ebitdaMarginPct: 10,
    terminalFcff: 5.1,
    terminalValue: 102.5,
    equityValue: 160,
    perShare: 8.00,
    probabilityPct: 20,
  },
];

// Two-way sensitivity: WACC (rows) × Terminal Growth Rate (cols)
export const SENSITIVITY_TABLE = {
  rowVariable: "WACC",
  colVariable: "Terminal Growth Rate (g)",
  rowValues: [7.5, 8.0, 8.5, 9.0, 9.5],  // WACC %
  colValues: [2.0, 2.5, 3.0, 3.5, 4.0],  // g %
  // Implied per-share value matrix (computed using simplified DCF formula)
  matrix: [
    [16.50, 17.80, 19.40, 21.50, 24.30],  // WACC 7.5%
    [15.20, 16.30, 17.70, 19.40, 21.60],  // WACC 8.0%
    [14.10, 15.00, 16.10, 17.60, 19.40],  // WACC 8.5%
    [13.10, 13.90, 14.80, 15.90, 17.50],  // WACC 9.0%
    [12.20, 12.90, 13.70, 14.60, 15.80],  // WACC 9.5%
  ],
  baseCase: { wacc: 8.65, g: 3.0, valuePerShare: DCF_PER_SHARE },
  formula: "Implied Value per Share = f(WACC, g) — DCF with Gordon Growth TV",
};

// Probability-weighted expected value
const EXPECTED_VALUE = Math.round(
  SCENARIOS.reduce((s, sc) => s + sc.perShare * sc.probabilityPct / 100, 0) * 100
) / 100;

export const SENSITIVITY_DATA = {
  scenarios: SCENARIOS,
  sensitivityTable: SENSITIVITY_TABLE,
  expectedValuePerShare: EXPECTED_VALUE,
  formulas: {
    scenarioApproach: "Best (20%) / Base (60%) / Worst (20%) — probability-weighted",
    twoWayData: "2-way data table: row variable × col variable, holding all else constant",
    expectedValue: "E[V] = Σ (Scenario Value × Probability)",
  },
};

// ===================================================================
// 6. FOOTBALL FIELD (Multi-Method Valuation Range)
// ===================================================================
export type FootballFieldMethod = {
  method: string;
  low: number;     // per share $
  high: number;    // per share $
  mean: number;    // per share $
  color: string;
  note: string;
};

export const FOOTBALL_FIELD: FootballFieldMethod[] = [
  { method: "52-Week Trading Range", low: 12.00, high: 18.00, mean: 15.00, color: "slate", note: "Current market trading range over past 52 weeks" },
  { method: "Trading Comps — EV/Revenue", low: TRADING_COMPS_VALUATION.perShareLow, high: TRADING_COMPS_VALUATION.perShareHigh, mean: TRADING_COMPS_VALUATION.perShareMean, color: "blue", note: `Peer set EV/Rev ${TRADING_COMPS_STATS.evRevenueLow}x - ${TRADING_COMPS_STATS.evRevenueHigh}x applied to FY24E Revenue` },
  { method: "Trading Comps — EV/EBITDA", low: 10.50, high: 18.50, mean: 14.50, color: "cyan", note: "Peer set EV/EBITDA range (only positive-EBITDA peers)" },
  { method: "Precedent Transactions", low: PREC_VALUATION.perShareLow, high: PREC_VALUATION.perShareHigh, mean: PREC_VALUATION.perShareMean, color: "violet", note: `M&A multiples ${PREC_STATS.evRevenueLow}x - ${PREC_STATS.evRevenueHigh}x with avg ${PREC_STATS.avgPremium}% control premium` },
  { method: "DCF — Gordon Growth TV", low: DCF_PER_SHARE - 4, high: DCF_PER_SHARE + 4, mean: DCF_PER_SHARE, color: "emerald", note: `5-year FCFF + perpetuity @ g=3%, WACC=${WACC_RESULT.wacc}%` },
  { method: "DCF — Exit Multiple TV", low: 11.50, high: 17.50, mean: 14.50, color: "teal", note: "5-year FCFF + exit at 12x EBITDA" },
  { method: "Probability-Weighted Scenarios", low: 8.00, high: 18.00, mean: EXPECTED_VALUE, color: "amber", note: `Best/Base/Worst — E[V] = $${EXPECTED_VALUE}` },
];

export const FOOTBALL_FIELD_SUMMARY = {
  methods: FOOTBALL_FIELD,
  overallLow: Math.min(...FOOTBALL_FIELD.map(m => m.low)),
  overallHigh: Math.max(...FOOTBALL_FIELD.map(m => m.high)),
  overallMean: Math.round(FOOTBALL_FIELD.reduce((s, m) => s + m.mean, 0) / FOOTBALL_FIELD.length * 100) / 100,
  currentPrice: 20.00,
  impliedUpside: 0,
};
FOOTBALL_FIELD_SUMMARY.impliedUpside = Math.round((FOOTBALL_FIELD_SUMMARY.overallMean / FOOTBALL_FIELD_SUMMARY.currentPrice - 1) * 1000) / 10;

// ===================================================================
// 7. LBO MODEL (Sponsor Returns Analysis)
// ===================================================================
export type LBOYear = {
  year: string;
  revenue: number;
  ebitda: number;
  ebitdaMarginPct: number;
  lessInterest: number;
  lessCapex: number;
  lessTax: number;
  freeCashFlow: number;
  beginningDebt: number;
  debtPaydown: number;
  endingDebt: number;
};

const LBO_PURCHASE_PRICE = 500;  // $M EV
const LBO_DEBT_PCT = 0.60;
const LBO_EQUITY_PCT = 0.40;
const LBO_DEBT_AMOUNT = LBO_PURCHASE_PRICE * LBO_DEBT_PCT; // $300M
const LBO_EQUITY_AMOUNT = LBO_PURCHASE_PRICE * LBO_EQUITY_PCT; // $200M
const LBO_DEBT_RATE = 0.075; // 7.5% sponsor debt
const LBO_EXIT_MULTIPLE = 12.0; // 12x EBITDA at exit
const LBO_HOLD_YEARS = 5;

const LBO_REVENUE_GROWTH = [0.20, 0.18, 0.15, 0.12, 0.10];
const LBO_EBITDA_MARGIN = [0.22, 0.24, 0.26, 0.27, 0.28];
const LBO_SEED_REVENUE = 80;  // higher seed for LBO target (mature company)
const LBO_CAPEX_PCT = 0.04;

export const LBO_MODEL: LBOYear[] = (() => {
  const rows: LBOYear[] = [];
  let debt = LBO_DEBT_AMOUNT;
  let prevRevenue = LBO_SEED_REVENUE;
  for (let i = 0; i < LBO_HOLD_YEARS; i++) {
    // Proper cumulative compounding: revenue[i] = revenue[i-1] × (1 + growth[i])
    const revenue = Math.round(prevRevenue * (1 + LBO_REVENUE_GROWTH[i]) * 100) / 100;
    prevRevenue = revenue;
    const ebitda = Math.round(revenue * LBO_EBITDA_MARGIN[i] * 100) / 100;
    const interest = Math.round(debt * LBO_DEBT_RATE * 100) / 100;
    const capex = Math.round(revenue * LBO_CAPEX_PCT * 100) / 100;
    const pretax = ebitda - interest - capex;
    // Tax: if pretax positive, pay 24.5%; if negative, no tax benefit (simplified)
    const tax = pretax > 0 ? Math.round(pretax * 0.245 * 100) / 100 : 0;
    const fcf = Math.round((pretax - tax) * 100) / 100;
    // Paydown: only positive FCF can pay down debt; cannot exceed current debt
    const paydown = Math.max(0, Math.min(fcf, debt));
    const endingDebt = Math.round((debt - paydown) * 100) / 100;
    rows.push({
      year: `FY${2024 + i}E`,
      revenue,
      ebitda,
      ebitdaMarginPct: LBO_EBITDA_MARGIN[i] * 100,
      lessInterest: -interest,
      lessCapex: -capex,
      lessTax: -tax,
      freeCashFlow: fcf,
      beginningDebt: debt,
      debtPaydown: paydown,
      endingDebt,
    });
    debt = endingDebt;
  }
  return rows;
})();

const LBO_EXIT_EBITDA = LBO_MODEL[LBO_MODEL.length - 1].ebitda;
const LBO_EXIT_EV = Math.round(LBO_EXIT_EBITDA * LBO_EXIT_MULTIPLE * 100) / 100;
const LBO_EXIT_DEBT = LBO_MODEL[LBO_MODEL.length - 1].endingDebt;
const LBO_EXIT_EQUITY = Math.round((LBO_EXIT_EV - LBO_EXIT_DEBT) * 100) / 100;

// IRR calculation (simplified — uses closed-form approximation)
const LBO_TOTAL_DISTRIBUTIONS = LBO_EXIT_EQUITY;
const LBO_INITIAL_EQUITY = LBO_EQUITY_AMOUNT;
const LBO_IRR = Math.round((Math.pow(LBO_TOTAL_DISTRIBUTIONS / LBO_INITIAL_EQUITY, 1 / LBO_HOLD_YEARS) - 1) * 1000) / 10;
const LBO_MOIC = Math.round((LBO_TOTAL_DISTRIBUTIONS / LBO_INITIAL_EQUITY) * 100) / 100;

export const LBO_ANALYSIS = {
  entryAssumptions: {
    purchasePrice: LBO_PURCHASE_PRICE,
    debtPct: LBO_DEBT_PCT * 100,
    equityPct: LBO_EQUITY_PCT * 100,
    debtAmount: LBO_DEBT_AMOUNT,
    equityAmount: LBO_EQUITY_AMOUNT,
    debtRate: LBO_DEBT_RATE * 100,
    holdYears: LBO_HOLD_YEARS,
    exitMultiple: LBO_EXIT_MULTIPLE,
  },
  model: LBO_MODEL,
  exit: {
    exitYearEbitda: LBO_EXIT_EBITDA,
    exitMultiple: LBO_EXIT_MULTIPLE,
    exitEnterpriseValue: LBO_EXIT_EV,
    lessEndingDebt: -LBO_EXIT_DEBT,
    exitEquityValue: LBO_EXIT_EQUITY,
  },
  returns: {
    initialEquity: LBO_INITIAL_EQUITY,
    exitEquity: LBO_EXIT_EQUITY,
    irr: LBO_IRR,
    moic: LBO_MOIC,
    cashOnCashMultiple: `${LBO_MOIC}x`,
    holdPeriod: `${LBO_HOLD_YEARS} years`,
  },
  formulas: {
    purchasePrice: "EV = EBITDA × Entry Multiple",
    debtFunding: "Debt = EV × Debt % (typically 60-70% for LBO)",
    equityFunding: "Equity = EV − Debt (sponsor cash investment)",
    fcf: "FCF = EBITDA − Interest − Capex − Tax",
    debtPaydown: "Debt Paydown = Min(FCF, Beginning Debt)",
    exitEV: "Exit EV = Exit EBITDA × Exit Multiple",
    exitEquity: "Exit Equity = Exit EV − Ending Debt",
    irr: "IRR: rate where NPV(equity cash flows) = 0",
    moic: "MOIC = Exit Equity / Initial Equity",
  },
};

// ===================================================================
// 8. M&A ACCRETION / DILUTION ANALYSIS
// ===================================================================
export const MA_ACCRETION_DILUTION = {
  acquirer: {
    name: "Meridian Capital Holdings",
    revenue: 850,
    ebitda: 220,
    netIncome: 116,
    sharesOutstanding: 100,        // M shares
    eps: 1.16,
    pricePerShare: 20.00,
    marketCap: 2000,
  },
  target: {
    name: "Cortex AI Labs Inc",
    revenue: 50,
    ebitda: -3,                    // negative EBITDA
    netIncome: -10,
    sharesOutstanding: 20,         // M shares
    eps: -0.50,
    pricePerShare: 20.00,
    marketCap: 400,
  },
  dealTerms: {
    offerPricePerShare: 30.00,     // 50% premium
    premiumPct: 50,
    dealValue: 600,                // $M (30 × 20)
    consideration: "100% Stock",
    exchangeRatio: 1.5,            // 1.5 acquirer shares per target share
    newSharesIssued: 30,           // 20 × 1.5
    synergyEBITDA: 25,             // $M annual cost synergies
    synergyPV: 250,                // $M PV of synergies (perpetuity at WACC)
    transactionCosts: 15,          // $M
  },
  proForma: {
    combinedRevenue: 850 + 50,
    combinedEBITDA: 220 + (-3) + 25, // includes synergies
    combinedNetIncome: 116 + (-10) + 15, // synergy after-tax
    combinedShares: 100 + 30,
    proFormaEPS: 0,
    standaloneEPS: 1.16,
    accretionDilution: 0,
    accretionPct: 0,
  },
  goodWill: {
    purchasePrice: 600,
    bookValueOfTarget: 180,
    goodwill: 0,
    standard: "IFRS 3 / ASC 805 — goodwill = consideration transferred − identifiable net assets at fair value",
  },
};
MA_ACCRETION_DILUTION.proForma.proFormaEPS = Math.round((MA_ACCRETION_DILUTION.proForma.combinedNetIncome / MA_ACCRETION_DILUTION.proForma.combinedShares) * 100) / 100;
MA_ACCRETION_DILUTION.proForma.accretionDilution = Math.round((MA_ACCRETION_DILUTION.proForma.proFormaEPS - MA_ACCRETION_DILUTION.proForma.standaloneEPS) * 100) / 100;
MA_ACCRETION_DILUTION.proForma.accretionPct = Math.round((MA_ACCRETION_DILUTION.proForma.accretionDilution / MA_ACCRETION_DILUTION.proForma.standaloneEPS) * 1000) / 10;
MA_ACCRETION_DILUTION.goodWill.goodwill = MA_ACCRETION_DILUTION.dealTerms.dealValue - MA_ACCRETION_DILUTION.goodWill.bookValueOfTarget;

export const MA_ANALYSIS = {
  ...MA_ACCRETION_DILUTION,
  formulas: {
    exchangeRatio: "Exchange Ratio = Offer Price per Target Share / Acquirer Share Price",
    newSharesIssued: "New Shares = Target Shares × Exchange Ratio",
    proFormaEPS: "Pro Forma EPS = (Acquirer NI + Target NI + After-tax Synergies) / (Acquirer Shares + New Shares)",
    accretionDilution: "Accretion/(Dilution) = Pro Forma EPS − Standalone EPS",
    accretionPct: "Accretion % = (Pro Forma EPS − Standalone EPS) / Standalone EPS",
    goodwill: "Goodwill = Consideration Transferred − Identifiable Net Assets at FV (IFRS 3 / ASC 805)",
    breakeven: "Breakeven Exchange Ratio: where Pro Forma EPS = Standalone EPS",
  },
};

// ===================================================================
// 9. FMVA-COMPLIANT REPORTS INDEX
// ===================================================================
export const FMVA_REPORTS_INDEX = [
  { id: "consolidated", title: "Consolidated Financial Statements", location: "Consolidation tab", standard: "IFRS 10 / ASC 810 / FRS 102 s9", description: "Group reporting with intercompany elimination. IFRS 10 control-based; ASC 810 VIE + voting models; FRS 102 s9 group accounts." },
  { id: "primary", title: "P&L, BS, CF, TB, Equity, OCI", location: "Reports tab (10 reports)", standard: "IAS 1 / ASC 220 / FRS 102 s6 / IFRS-EU", description: "Full primary financial statements with OCI per IAS 1.82. Multi-jurisdictional formats (US GAAP, IFRS, UK FRS 102, Canada ASPE/IFRS)." },
  { id: "ma-tracker", title: "M&A Deal Tracker", location: "Corporate Finance → M&A", standard: "IFRS 3 / ASC 805", description: "Purchase price allocation (PPA) + goodwill recognition. IFRS 3 full goodwill method; ASC 805 bargain purchase gain option." },
  { id: "valuation", title: "DCF + Comparables Analysis", location: "Corporate Finance → Valuation / FMVA", standard: "AICPA / CFA Institute Best Practice", description: "DCF with Gordon Growth TV; trading comps; precedent transactions; football field summary." },
  { id: "fpa", title: "Budget vs Actual + Scenarios", location: "Corporate Finance → FP&A", standard: "FP&A Best Practice / IMA", description: "Variance analysis (price/volume/mix/timing); best/base/worst scenarios; rolling forecast." },
  { id: "disclosures", title: "Full Disclosure Notes", location: "Disclosures tab", standard: "IAS 1 / US GAAP / FRS 102 s3", description: "21 inline disclosure notes: accounting policies, revenue, PPE, intangibles, receivables, payables, tax, share capital, going concern, etc." },
  { id: "tax", title: "Normal + Deferred Tax", location: "Tax Center (5 tabs)", standard: "IAS 12 / ASC 740 / FRS 102 s29 / IFRS-EU", description: "Current tax provision + deferred tax (DTL/DTA) with 10 journal entries; tax reconciliation; effective tax rate bridge." },
  { id: "payroll", title: "Multi-Country Payroll", location: "Payroll (4 country tabs)", standard: "USA FICA / UK PAYE+NI / EU SGB / Canada CPP+EI", description: "15 employees across USA, UK, Germany, Canada with statutory deductions, employer cost, and journal entries." },
  { id: "loan", title: "Loan Portfolio + Amortization", location: "Corporate Finance → Loan Portfolio", standard: "IFRS 9 / ASC 326 / Basel III", description: "8 loans with monthly amortization schedules, DSCR/LTV/Debt Yield covenants, expected loss (PD × LGD × EAD)." },
  { id: "market", title: "Market Data & Macro Assumptions", location: "Market Data tab", standard: "Primary sources (Fed/BoE/Damodaran/S&P)", description: "85 data points across FX, risk-free rates, ERP, credit spreads, tax rates. Refreshed November 20, 2026." },
  { id: "concepts", title: "Concepts Glossary (Laws)", location: "Reports → Concepts tab", standard: "115 terms across 11 categories", description: "The laws on which all reports are built — FP&A, lending, banking, equity, REIT, construction, retail, SaaS, treasury, accounting, OCI." },
  { id: "gaap-ifrs", title: "US GAAP vs IFRS Comparison", location: "Reports → GAAP vs IFRS tab", standard: "32 comparisons across 13 areas", description: "Critical differences affecting FP&A: revenue, leases, credit losses, financial instruments, inventory, PPE, intangibles, consolidation, FX, pensions, taxes, Canada-specific." },
];

// ===================================================================
// META + STANDARDS PANEL
// ===================================================================
export const FMVA_META = {
  frameworkName: "FMVA® Reporting Framework",
  fullForm: "Financial Modeling & Valuation Analyst",
  issuer: "Corporate Finance Institute (CFI)",
  methodologyCount: 9,
  reportsCount: FMVA_REPORTS_INDEX.length,
  targetCompany: "Cortex AI Labs Inc",
  acquirerCompany: "Meridian Capital Holdings",
  asOfDate: "2026-11-20",
  jurisdictionalScope: "Multi-jurisdictional: US GAAP (FASB ASC) · IFRS (IASB) · UK FRS 102 · EU IFRS-EU · Canada (ASPE / IFRS-Canada)",
  standards: [
    { code: "IFRS", label: "IFRS (IASB)", scope: "International — used in 140+ jurisdictions including UK, EU, Canada (for PAEs), Australia, Brazil" },
    { code: "US-GAAP", label: "US GAAP (FASB ASC)", scope: "United States — SEC registrants and US subsidiaries of foreign groups" },
    { code: "UK-FRS-102", label: "UK FRS 102", scope: "United Kingdom — small and medium companies; Section 1A small companies exemption" },
    { code: "EU-IFRS-EU", label: "EU IFRS-EU", scope: "European Union — IFRS as endorsed by European Commission via IAS Regulation 1606/2002" },
    { code: "CA-ASPE", label: "Canada ASPE / IFRS-Canada", scope: "Canada — ASPE for private enterprises (CPA Handbook Part II), IFRS for PAEs (Part I)" },
  ],
  disclaimer: "All valuation figures fictitious but realistic. Methodologies per FMVA® curriculum (CFI). Standards applied per multi-jurisdictional framework.",
};
