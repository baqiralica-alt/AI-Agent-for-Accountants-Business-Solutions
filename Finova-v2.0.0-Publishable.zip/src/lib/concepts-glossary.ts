// Concepts Glossary — Laws & Standards on which FP&A Reports are built
// Source: FP&A Interview Prep Workbook + Head of FP&A Study Workbook
// 97 terms across 10 categories: FP&A, Lending, Banking, Equity, REIT,
// Construction, Retail, SaaS, Treasury, Accounting.
// These are the conceptual "laws" every report in this app is built upon.

export type GlossaryTerm = {
  no: number;
  term: string;
  category: string;
  definition: string;
  usaUkNote: string;
  sheetRef: string;
};

export type GlossaryCategory = {
  name: string;
  icon: string;
  color: string;
  terms: GlossaryTerm[];
};

export const GLOSSARY_CATEGORIES: GlossaryCategory[] = [
  {
    name: "FP&A",
    icon: "TrendingUp",
    color: "emerald",
    terms: [
      { no: 1, term: "3-Statement Model", category: "FP&A", definition: "Integrated income statement, balance sheet, and cash flow statement linked by formulas. Changes in one statement automatically update the others.", usaUkNote: "Same in US & UK", sheetRef: "05_3Stmt_Holding_Co" },
      { no: 2, term: "Driver Tree", category: "FP&A", definition: "Hierarchical decomposition of a KPI (e.g., Revenue = Price × Volume × Mix) used to build forecasts and run sensitivities.", usaUkNote: "Same in US & UK", sheetRef: "06_Driver_Tree_Scenarios" },
      { no: 3, term: "Scenario Analysis", category: "FP&A", definition: "Pre-defined sets of driver assumptions (Base, Bull, Bear, Stress) used to bound outcomes and stress-test plans.", usaUkNote: "Same in US & UK", sheetRef: "06_Driver_Tree_Scenarios" },
      { no: 4, term: "Sensitivity Analysis", category: "FP&A", definition: "One-variable or two-variable data table showing how an output (e.g., FCF) responds to changes in inputs (e.g., growth rate, WACC).", usaUkNote: "Same in US & UK", sheetRef: "06_Driver_Tree_Scenarios" },
      { no: 5, term: "Variance Analysis", category: "FP&A", definition: "Comparison of actuals to budget or prior period, decomposed into price, volume, mix, and timing effects.", usaUkNote: "Same in US & UK", sheetRef: "07_Variance_Budget_Actual" },
      { no: 6, term: "Long-Range Plan (LRP)", category: "FP&A", definition: "5-10 year strategic forecast covering revenue, capex, financing, and capital allocation; feeds annual budget.", usaUkNote: "Same in US & UK", sheetRef: "09_LRP_10yr" },
      { no: 7, term: "Driver-Based Forecasting", category: "FP&A", definition: "Forecasting revenue and costs from operational drivers (units, headcount, capacity) rather than flat growth rates.", usaUkNote: "Same in US & UK", sheetRef: "06_Driver_Tree_Scenarios" },
      { no: 8, term: "Rolling Forecast", category: "FP&A", definition: "Continuous forecast updated monthly or quarterly with a fixed forward horizon (e.g., 12-18 months); replaces static annual budget in agile orgs.", usaUkNote: "Same in US & UK", sheetRef: "—" },
      { no: 9, term: "Zero-Based Budgeting (ZBB)", category: "FP&A", definition: "Budgeting approach that re-evaluates every expense from scratch each period, rather than incrementally adjusting prior budget.", usaUkNote: "Same in US & UK", sheetRef: "—" },
      { no: 10, term: "Activity-Based Budgeting", category: "FP&A", definition: "Budget built from cost drivers of activities rather than departmental spend; aligns spend to strategic activities.", usaUkNote: "Same in US & UK", sheetRef: "—" },
      { no: 11, term: "Budget Calendar", category: "FP&A", definition: "Annual cycle: strategic plan (Q1) → LRP refresh (Q2) → bottom-up budget (Q3) → board approval (Q4) → monthly close & variance.", usaUkNote: "Same in US & UK", sheetRef: "07_Variance_Budget_Actual" },
      { no: 12, term: "Management Reporting Cadence", category: "FP&A", definition: "Monthly close (5-10 BD) → flash report (10-15 BD) → board pack (20-25 BD) → investor report (quarterly).", usaUkNote: "Same in US & UK", sheetRef: "08_Board_Pack_Dashboard" },
    ],
  },
  {
    name: "Lending",
    icon: "Landmark",
    color: "rose",
    terms: [
      { no: 13, term: "Non-Performing Loan (NPL)", category: "Lending", definition: "Loan past due >90 days or where borrower is unlikely to pay in full without collateral realization. Triggers ECL stage transfer and watchlist.", usaUkNote: "Same in US & UK", sheetRef: "10_Loan_Portfolio_Master" },
      { no: 14, term: "REO (Real Estate Owned)", category: "Lending", definition: "Property acquired by lender through foreclosure or deed-in-lieu; carried on balance sheet until sold. Recovery = sale proceeds - carrying costs - liens.", usaUkNote: "Same in US & UK", sheetRef: "14_REO_Workouts" },
      { no: 15, term: "Recovery Rate", category: "Lending", definition: "% of defaulted exposure recovered through collateral sale, guarantees, or workout; 1 - Loss Given Default.", usaUkNote: "Same in US & UK", sheetRef: "14_REO_Workouts" },
      { no: 16, term: "Loss Given Default (LGD)", category: "Lending", definition: "% of exposure expected lost if borrower defaults, after recoveries and workout costs. LGD = 1 - Recovery Rate.", usaUkNote: "Same in US & UK", sheetRef: "11_CECL_Model" },
      { no: 17, term: "Probability of Default (PD)", category: "Lending", definition: "Likelihood borrower defaults over a given horizon (12-month for short-term, lifetime for CECL/Stage 2/3).", usaUkNote: "Same in US & UK", sheetRef: "11_CECL_Model" },
      { no: 18, term: "Exposure at Default (EAD)", category: "Lending", definition: "Expected outstanding exposure at time of default, including drawn balances + CCF × undrawn commitments.", usaUkNote: "Same in US & UK", sheetRef: "11_CECL_Model" },
      { no: 19, term: "CECL", category: "Lending", definition: "Current Expected Credit Losses — US GAAP ASC 326; requires lifetime ECL at origination for all financial assets carried at amortized cost.", usaUkNote: "US GAAP ASC 326", sheetRef: "11_CECL_Model" },
      { no: 20, term: "ECL (Expected Credit Loss)", category: "Lending", definition: "Forward-looking expected loss provision; CECL (US) is lifetime from Day 1, IFRS 9 (UK/EU) uses 3-stage approach.", usaUkNote: "US: CECL · UK/EU: IFRS 9", sheetRef: "11_CECL_Model, 12_IFRS9_ECL_Model" },
      { no: 21, term: "SICR (Significant Increase in Credit Risk)", category: "Lending", definition: "Trigger that moves IFRS 9 loan from Stage 1 (12-month ECL) to Stage 2 (lifetime ECL). Triggers: 30+ DPD, watchlist, rating downgrade.", usaUkNote: "IFRS 9 (UK/EU only)", sheetRef: "12_IFRS9_ECL_Model" },
      { no: 22, term: "Stage 1 / 2 / 3", category: "Lending", definition: "IFRS 9 staging: Stage 1 = performing, 12-month ECL; Stage 2 = SICR, lifetime ECL; Stage 3 = credit-impaired, lifetime ECL on drawn balance.", usaUkNote: "IFRS 9 (UK/EU only)", sheetRef: "12_IFRS9_ECL_Model" },
      { no: 23, term: "DSCR (Debt Service Coverage Ratio)", category: "Lending", definition: "NOI / (Principal + Interest). Measures ability to service debt from operating cash flow. Min 1.25x typical covenant; 1.40x for new origination.", usaUkNote: "Same in US & UK", sheetRef: "13_Covenant_Compliance" },
      { no: 24, term: "LTV (Loan-to-Value)", category: "Lending", definition: "Loan principal / appraised collateral value. Measures cushion before lender loss. Max 75% typical CRE; 65% for office; 80% multifamily.", usaUkNote: "Same in US & UK", sheetRef: "13_Covenant_Compliance" },
      { no: 25, term: "Debt Yield", category: "Lending", definition: "NOI / Loan principal. Lender's cap rate if foreclosed today. Min 8-10% typical; lower = riskier loan.", usaUkNote: "Same in US & UK", sheetRef: "13_Covenant_Compliance" },
      { no: 26, term: "Interest Coverage Ratio", category: "Lending", definition: "EBITDA / Interest Expense. Min 3.0x typical covenant; 2.5x for stressed credits; 4.0x for investment-grade.", usaUkNote: "Same in US & UK", sheetRef: "13_Covenant_Compliance" },
      { no: 27, term: "Covenant Breach", category: "Lending", definition: "Failure to meet a financial covenant; triggers default, acceleration risk, waiver negotiation, amendment fees, cross-default to other facilities.", usaUkNote: "Same in US & UK", sheetRef: "13_Covenant_Compliance" },
      { no: 28, term: "Q-Factors (Qualitative Adjustments)", category: "Lending", definition: "Management adjustments to modeled CECL/ECL for forward-looking conditions not captured in historical data: economic, regulatory, environmental, competitive.", usaUkNote: "Same in US & UK", sheetRef: "11_CECL_Model" },
      { no: 29, term: "ACL (Allowance for Credit Losses)", category: "Lending", definition: "Balance sheet reserve for expected credit losses on loans and commitments. Contra-asset; reduces gross loans to net carrying value.", usaUkNote: "US: ACL · UK: ECL allowance", sheetRef: "15_Bank_3Stmt_Model" },
      { no: 30, term: "Provision for Credit Losses (PCL/PLL)", category: "Lending", definition: "Income statement charge that increases ACL by required amount each period. Formula: End ACL - Begin ACL + Charge-offs - Recoveries.", usaUkNote: "Same in US & UK", sheetRef: "15_Bank_3Stmt_Model" },
      { no: 31, term: "Net Charge-offs (NCO)", category: "Lending", definition: "Gross charge-offs - recoveries. Actual losses recognized in period, distinct from provisions which are forward-looking.", usaUkNote: "Same in US & UK", sheetRef: "15_Bank_3Stmt_Model" },
    ],
  },
  {
    name: "Banking",
    icon: "Building2",
    color: "blue",
    terms: [
      { no: 32, term: "Net Interest Margin (NIM)", category: "Banking", definition: "(Interest Income - Interest Expense) / Average Earning Assets. Bank's core profitability metric; typically 3-4% for US commercial banks.", usaUkNote: "Same in US & UK", sheetRef: "15_Bank_3Stmt_Model" },
      { no: 33, term: "Loan-to-Deposit Ratio (LDR)", category: "Banking", definition: "Total Loans / Total Deposits. Liquidity indicator; 80-90% healthy; >100% indicates wholesale funding reliance.", usaUkNote: "Same in US & UK", sheetRef: "15_Bank_3Stmt_Model" },
      { no: 34, term: "CET1 Ratio", category: "Banking", definition: "Common Equity Tier 1 Capital / Risk-Weighted Assets. Min 4.5% (Basel III) + capital conservation buffer 2.5% = 7.0% effective minimum; most US/UK banks target 12-14%.", usaUkNote: "Basel III — US & UK", sheetRef: "15_Bank_3Stmt_Model" },
      { no: 35, term: "Efficiency Ratio", category: "Banking", definition: "Non-Interest Expense / (Net Interest Income + Non-Interest Income). Lower is better; <55% excellent, 55-65% typical US, >65% concern.", usaUkNote: "Same in US & UK", sheetRef: "15_Bank_3Stmt_Model" },
      { no: 36, term: "Deposit Beta", category: "Banking", definition: "% change in deposit rates for a 1% change in market rates. Higher beta = faster repricing = margin compression in rising-rate environment.", usaUkNote: "Same in US & UK", sheetRef: "15_Bank_3Stmt_Model" },
    ],
  },
  {
    name: "Equity",
    icon: "LineChart",
    color: "violet",
    terms: [
      { no: 37, term: "WACC", category: "Equity", definition: "Weighted Average Cost of Capital = (E/V × Re) + (D/V × Rd × (1-T)). Discount rate for FCFF; weights at market values not book.", usaUkNote: "Same in US & UK", sheetRef: "28_DCF_WACC" },
      { no: 38, term: "CAPM", category: "Equity", definition: "Capital Asset Pricing Model: Re = Rf + β × (Rm - Rf). Required return on equity; beta measured vs local market index.", usaUkNote: "Same in US & UK", sheetRef: "28_DCF_WACC" },
      { no: 39, term: "Equity Risk Premium (ERP)", category: "Equity", definition: "Rm - Rf in CAPM; historical excess return of equities over risk-free. US: ~5.0-5.5%; UK: ~5.0-5.5% (Damodaran 2024).", usaUkNote: "US ~5.0-5.5% · UK ~5.0-5.5%", sheetRef: "04_Market_Data_FX" },
      { no: 40, term: "Size Premium", category: "Equity", definition: "Additional return demanded for smaller companies; Duff & Phelps 2024: ~0-1% large cap, ~3-5% micro-cap. Added to CAPM cost of equity.", usaUkNote: "Same in US & UK", sheetRef: "28_DCF_WACC" },
      { no: 41, term: "Country Risk Premium (CRP)", category: "Equity", definition: "Additional return for emerging markets or non-domestic listings; Damodaran: 0% developed, 3-7% emerging, 8%+ frontier.", usaUkNote: "Same in US & UK", sheetRef: "28_DCF_WACC" },
      { no: 42, term: "Unlevered Free Cash Flow (FCFF)", category: "Equity", definition: "FCFF = EBIT × (1-T) + D&A - ΔNWC - Capex. Cash available to all providers of capital (debt + equity). Discounted at WACC to get EV.", usaUkNote: "Same in US & UK", sheetRef: "28_DCF_WACC" },
      { no: 43, term: "Levered Free Cash Flow (FCFE)", category: "Equity", definition: "FCFE = FCFF - Interest × (1-T) + Net Borrowing. Cash available to equity holders only. Discounted at Re to get equity value directly.", usaUkNote: "Same in US & UK", sheetRef: "28_DCF_WACC" },
      { no: 44, term: "Terminal Value", category: "Equity", definition: "Value of cash flows beyond explicit forecast period. Two methods: (1) Gordon growth TV = FCF_n × (1+g) / (WACC - g); (2) Exit multiple TV = EBITDA_n × EV/EBITDA_exit.", usaUkNote: "Same in US & UK", sheetRef: "28_DCF_WACC" },
      { no: 45, term: "Gordon Growth Model", category: "Equity", definition: "TV = CF_1 / (r - g). Assumes perpetual growth at constant rate g < r. Used in DCF terminal value and DDM for mature dividend payers.", usaUkNote: "Same in US & UK", sheetRef: "28_DCF_WACC" },
      { no: 46, term: "H-Model", category: "Equity", definition: "Variation of DDM: assumes dividend growth starts high and declines linearly to perpetual rate. V0 = (D0 × (1+gL)) / (r-gL) + (D0 × (gS-gL) × H) / (r-gL), where H = half-life.", usaUkNote: "Same in US & UK", sheetRef: "30_DDM_REIT_Val" },
      { no: 47, term: "Justified P/E", category: "Equity", definition: "P0/E1 = (D1/E1) / (k - g) = payout ratio / (required return - growth). The P/E 'justified' by fundamentals; compare to market P/E.", usaUkNote: "Same in US & UK", sheetRef: "30_DDM_REIT_Val" },
      { no: 48, term: "Justified P/B", category: "Equity", definition: "P0/B0 = (ROE - g) / (Re - g). Implies P/B > 1 only if ROE > Re; high-ROE banks command P/B premium.", usaUkNote: "Same in US & UK", sheetRef: "29_Relative_Val" },
      { no: 49, term: "Residual Income", category: "Equity", definition: "RI_t = EP_t = (ROE_t - Re) × B_{t-1}. Value = Book value + PV of future residual income. Useful when cash flows are negative or hard to project.", usaUkNote: "Same; Edwards-Bell-Ohlson model", sheetRef: "—" },
      { no: 50, term: "EV/EBITDA", category: "Equity", definition: "Enterprise Value / EBITDA. Capital-structure-neutral multiple; 8-12x typical mature, 15-25x high-growth, 6-8x cyclical.", usaUkNote: "Same in US & UK", sheetRef: "29_Relative_Val" },
      { no: 51, term: "EV/Sales", category: "Equity", definition: "Enterprise Value / Revenue. Used for early-stage or low-margin companies where EBITDA is negative or volatile. 1-3x typical SaaS at scale.", usaUkNote: "Same in US & UK", sheetRef: "29_Relative_Val" },
      { no: 52, term: "P/E (Price-to-Earnings)", category: "Equity", definition: "Price per share / EPS. Trailing (TTM) or Forward (FY+1). 15-20x typical S&P 500; 25-40x growth; <15x cyclical/value.", usaUkNote: "Same in US & UK", sheetRef: "29_Relative_Val" },
      { no: 53, term: "P/B (Price-to-Book)", category: "Equity", definition: "Price per share / Book value per share. Primary multiple for banks & insurance; 1.0-2.0x typical; <1x signals distress.", usaUkNote: "Same in US & UK", sheetRef: "29_Relative_Val" },
      { no: 54, term: "LBO (Leveraged Buyout)", category: "Equity", definition: "Acquisition using significant debt (60-70% of purchase price) secured by target's cash flows. Sponsor returns driven by debt paydown, EBITDA growth, and multiple expansion.", usaUkNote: "Same in US & UK", sheetRef: "31_LBO_Model" },
      { no: 55, term: "IRR (Internal Rate of Return)", category: "Equity", definition: "Discount rate making NPV of cash flows zero. Primary sponsor return metric; LBO target: 20-25% base case, 15% stress case.", usaUkNote: "Same in US & UK", sheetRef: "31_LBO_Model" },
      { no: 56, term: "MOIC (Multiple on Invested Capital)", category: "Equity", definition: "Total distributions / total invested capital. Cash-on-cash return; 2.0-3.0x target for LBO; 5.0x+ exceptional.", usaUkNote: "Same in US & UK", sheetRef: "31_LBO_Model" },
    ],
  },
  {
    name: "REIT",
    icon: "Home",
    color: "amber",
    terms: [
      { no: 57, term: "FFO (Funds From Operations)", category: "REIT", definition: "Net Income + D&A + gains/losses on property sales - non-recurring items. NAREIT definition; standard REIT cash flow metric.", usaUkNote: "US: NAREIT FFO · UK: EPRA earnings", sheetRef: "16_REIT_Model" },
      { no: 58, term: "AFFO (Adjusted FFO)", category: "REIT", definition: "FFO - recurring capex (maintenance) - lease commissions - straight-line rent adjustment. Better measure of distributable cash.", usaUkNote: "Same in US & UK", sheetRef: "16_REIT_Model" },
      { no: 59, term: "NOI (Net Operating Income)", category: "REIT", definition: "Rental income + recoveries - property operating expenses (excl. depreciation, interest, corporate G&A). Pre-leverage cash flow at property level.", usaUkNote: "Same in US & UK", sheetRef: "16_REIT_Model" },
      { no: 60, term: "Cap Rate", category: "REIT", definition: "NOI / Property Value. Direct yield on real estate; 4-6% prime US, 5-7% secondary; UK 4.5-6.5% prime London.", usaUkNote: "US 4-6% prime · UK 4.5-6.5%", sheetRef: "16_REIT_Model" },
      { no: 61, term: "NAV (Net Asset Value)", category: "REIT", definition: "(Property NOI / Cap rate) + other assets - debt. Asset-based valuation per share; compare to market price for premium/discount.", usaUkNote: "Same in US & UK", sheetRef: "30_DDM_REIT_Val" },
      { no: 62, term: "WALT (Weighted Avg Lease Term)", category: "REIT", definition: "Remaining lease term weighted by rental income. Longer WALT = more stable cash flow. Office: 4-7 yrs; Industrial: 5-9 yrs; Multifamily: <1 yr.", usaUkNote: "Same in US & UK", sheetRef: "17_REIT_Var_KPI" },
      { no: 63, term: "Releasing Spread", category: "REIT", definition: "New lease rent vs prior lease rent on renewal. Positive = releasing gains; negative = releasing loss. Key CRE health indicator.", usaUkNote: "Same in US & UK", sheetRef: "17_REIT_Var_KPI" },
    ],
  },
  {
    name: "Construction",
    icon: "HardHat",
    color: "orange",
    terms: [
      { no: 64, term: "% Completion Method", category: "Construction", definition: "Revenue recognition based on progress toward completion (cost-to-cost or units-delivered). ASC 606 / IFRS 15 require input/output method.", usaUkNote: "US: ASC 606 · UK: IFRS 15", sheetRef: "19_Construction_Model" },
      { no: 65, term: "WIP (Work-in-Progress)", category: "Construction", definition: "Inventory asset for in-process construction; = costs incurred + profit recognized - billings to date. Positive = asset, negative = liability (overbilling).", usaUkNote: "Same in US & UK", sheetRef: "19_Construction_Model" },
      { no: 66, term: "Over/Under Billings", category: "Construction", definition: "Difference between revenue recognized and amounts billed. Overbilling = liability (cash collected ahead of work); underbilling = asset (work done but not yet billed).", usaUkNote: "Same in US & UK", sheetRef: "19_Construction_Model" },
      { no: 67, term: "Backlog", category: "Construction", definition: "Value of contracted work not yet started or completed. Key leading indicator; >12 months of revenue is healthy.", usaUkNote: "Same in US & UK", sheetRef: "20_Construction_Var_KPI" },
      { no: 68, term: "Surety Bond", category: "Construction", definition: "Guarantee from surety company that contractor will perform per contract; required on most public and large private projects. Capacity = max aggregate bonds.", usaUkNote: "Same in US & UK", sheetRef: "20_Construction_Var_KPI" },
      { no: 69, term: "EMR (Experience Modification Rate)", category: "Construction", definition: "Worker's comp premium multiplier based on safety record vs industry. 1.0 = average; <0.9 excellent; >1.1 poor; affects bid competitiveness.", usaUkNote: "US-specific (EMR)", sheetRef: "20_Construction_Var_KPI" },
    ],
  },
  {
    name: "Retail",
    icon: "ShoppingBag",
    color: "pink",
    terms: [
      { no: 70, term: "Same-Store Sales (SSS)", category: "Retail", definition: "Revenue growth from stores open ≥13 months, excluding new/closed stores. Purest measure of comparable growth; reported monthly by US retailers.", usaUkNote: "Same in US & UK", sheetRef: "22_Retail_Model" },
      { no: 71, term: "GMROI", category: "Retail", definition: "Gross Margin $ / Average Inventory Cost. Inventory productivity measure; >200 healthy apparel, >350 grocery, >150 specialty.", usaUkNote: "Same in US & UK", sheetRef: "23_Retail_Var_KPI" },
      { no: 72, term: "Inventory Turn", category: "Retail", definition: "COGS / Average Inventory. Higher = leaner inventory; 4-8x specialty retail, 12x+ grocery, 2-3x luxury.", usaUkNote: "Same in US & UK", sheetRef: "23_Retail_Var_KPI" },
      { no: 73, term: "Shrinkage", category: "Retail", definition: "Inventory loss from theft, damage, error. Reported as % of sales; 1.0-1.5% typical; >2.0% concern.", usaUkNote: "Same in US & UK", sheetRef: "23_Retail_Var_KPI" },
      { no: 74, term: "Four-Wall Contribution", category: "Retail", definition: "Store revenue - direct store costs (COGS, labor, occupancy). Pre-corporate-overhead store profitability; <0 = candidate for closure.", usaUkNote: "Same in US & UK", sheetRef: "22_Retail_Model" },
      { no: 75, term: "Markdown", category: "Retail", definition: "Reduction from initial retail price to clear inventory; tracked as markdown %. Plan vs actual markdowns key margin driver.", usaUkNote: "Same in US & UK", sheetRef: "23_Retail_Var_KPI" },
    ],
  },
  {
    name: "SaaS",
    icon: "Cloud",
    color: "cyan",
    terms: [
      { no: 76, term: "ARR (Annual Recurring Revenue)", category: "SaaS", definition: "MRR × 12. Contracted subscription revenue normalized to annual; excludes one-time fees. Primary SaaS valuation driver (EV/ARR multiple).", usaUkNote: "Same in US & UK", sheetRef: "25_AI_SaaS_Model" },
      { no: 77, term: "MRR (Monthly Recurring Revenue)", category: "SaaS", definition: "Sum of monthly subscription fees across active customers. Decomposition: starting + new + expansion - contraction - churn = ending.", usaUkNote: "Same in US & UK", sheetRef: "25_AI_SaaS_Model" },
      { no: 78, term: "NRR (Net Revenue Retention)", category: "SaaS", definition: "(Starting MRR + Expansion - Contraction - Churn) / Starting MRR. >100% = expansion exceeds churn; <100% = net erosion. Top quartile SaaS: >120%.", usaUkNote: "Same in US & UK", sheetRef: "26_AI_SaaS_Var_KPI" },
      { no: 79, term: "GRR (Gross Revenue Retention)", category: "SaaS", definition: "(Starting MRR - Churn - Contraction) / Starting MRR. Pure churn measure excluding expansion. Top quartile: >90%.", usaUkNote: "Same in US & UK", sheetRef: "26_AI_SaaS_Var_KPI" },
      { no: 80, term: "CAC (Customer Acquisition Cost)", category: "SaaS", definition: "S&M spend / new customers acquired. Lower = efficient GTM. Varies widely: SMB $100s, mid-market $1K-10K, enterprise $50K+.", usaUkNote: "Same in US & UK", sheetRef: "26_AI_SaaS_Var_KPI" },
      { no: 81, term: "LTV (Lifetime Value)", category: "SaaS", definition: "ARPU × Gross Margin / Monthly Churn. Total profit per customer; should exceed CAC by 3x+ (LTV:CAC ≥ 3).", usaUkNote: "Same in US & UK", sheetRef: "26_AI_SaaS_Var_KPI" },
      { no: 82, term: "Magic Number", category: "SaaS", definition: "Quarterly ARR growth / Q-1 S&M spend. >0.75 excellent (efficient GTM), 0.5-0.75 good, <0.5 inefficient. Also: 4 × quarterly growth / prior-quarter S&M.", usaUkNote: "Same in US & UK", sheetRef: "26_AI_SaaS_Var_KPI" },
      { no: 83, term: "Rule of 40", category: "SaaS", definition: "Revenue growth % + FCF margin % ≥ 40%. Framework for balancing growth vs profitability. Top decile: >50%.", usaUkNote: "Same in US & UK", sheetRef: "26_AI_SaaS_Var_KPI" },
      { no: 84, term: "Burn Multiple", category: "SaaS", definition: "Net Cash Burn / Net New ARR. Lower is better; <1.0 excellent, 1-2 good, >2 concern, >3 critical. Coined by Craft Ventures.", usaUkNote: "Same in US & UK", sheetRef: "26_AI_SaaS_Var_KPI" },
      { no: 85, term: "Cohort Analysis", category: "SaaS", definition: "Track retention and revenue behavior of customers grouped by acquisition period. Reveals true churn/upsell patterns vs aggregate.", usaUkNote: "Same in US & UK", sheetRef: "26_AI_SaaS_Var_KPI" },
    ],
  },
  {
    name: "Treasury",
    icon: "Coins",
    color: "yellow",
    terms: [
      { no: 86, term: "SOFR", category: "Treasury", definition: "Secured Overnight Financing Rate — US risk-free replacement for USD LIBOR. Repo-based, overnight. Term SOFR: 1M/3M/6M/12M published.", usaUkNote: "US only (replaced USD LIBOR)", sheetRef: "04_Market_Data_FX" },
      { no: 87, term: "SONIA", category: "Treasury", definition: "Sterling Overnight Index Average — UK risk-free replacement for GBP LIBOR. BoE-published, overnight. Used in swaps and FRN coupons.", usaUkNote: "UK only (replaced GBP LIBOR)", sheetRef: "04_Market_Data_FX" },
      { no: 88, term: "Fed Funds Rate", category: "Treasury", definition: "US overnight interbank lending rate; set by FOMC within target range. Primary US policy rate; influences prime rate and bank deposit betas.", usaUkNote: "US only", sheetRef: "04_Market_Data_FX" },
      { no: 89, term: "Bank Rate", category: "Treasury", definition: "BoE's official policy rate; rate BoE charges (or pays) on reserves. UK equivalent of Fed Funds; influences SONIA directly.", usaUkNote: "UK only", sheetRef: "04_Market_Data_FX" },
      { no: 90, term: "Credit Spread", category: "Treasury", definition: "Yield difference between corporate bond and risk-free of same maturity. Compensates for default risk; widens in stress, tightens in expansion.", usaUkNote: "Same in US & UK", sheetRef: "04_Market_Data_FX" },
      { no: 91, term: "Basis Swap", category: "Treasury", definition: "Swap of floating rates in different currencies (e.g., 3M SOFR vs 3M SONIA). Used to hedge cross-currency funding exposure.", usaUkNote: "Same in US & UK", sheetRef: "04_Market_Data_FX" },
      { no: 92, term: "Liquidity Coverage Ratio (LCR)", category: "Treasury", definition: "HQLA / Net Cash Outflows over 30-day stress. Basel III liquidity metric; min 100%. Banks hold HQLA (Treasuries, Gilts, cash) for stress.", usaUkNote: "Basel III — US & UK", sheetRef: "15_Bank_3Stmt_Model" },
    ],
  },
  {
    name: "Accounting",
    icon: "BookOpen",
    color: "slate",
    terms: [
      { no: 93, term: "ASC 606", category: "Accounting", definition: "US GAAP revenue recognition standard: 5-step model (identify contract, performance obligations, transaction price, allocate, recognize as satisfied).", usaUkNote: "US GAAP only", sheetRef: "03_GAAP_IFRS_Framework" },
      { no: 94, term: "IFRS 15", category: "Accounting", definition: "International revenue recognition standard; 5-step model. Substantively converged with ASC 606 with minor differences (e.g., collection threshold).", usaUkNote: "UK/EU/IFRS only", sheetRef: "03_GAAP_IFRS_Framework" },
      { no: 95, term: "ASC 842", category: "Accounting", definition: "US GAAP lease accounting; lessees recognize ROU asset and lease liability for all leases >12 months. Operating leases on balance sheet since 2019.", usaUkNote: "US GAAP only", sheetRef: "03_GAAP_IFRS_Framework" },
      { no: 96, term: "IFRS 16", category: "Accounting", definition: "International lease accounting; single lessee model — all leases on balance sheet as ROU asset and liability, depreciation + interest. No operating/finance distinction for lessees.", usaUkNote: "UK/EU/IFRS only", sheetRef: "03_GAAP_IFRS_Framework" },
      { no: 97, term: "ASC 740", category: "Accounting", definition: "US GAAP income tax accounting; deferred tax assets/liabilities for temporary differences; valuation allowance if >50% likely DTA not realized.", usaUkNote: "US GAAP only (UK uses IAS 12)", sheetRef: "03_GAAP_IFRS_Framework" },
      { no: 107, term: "ASPE (Accounting Standards for Private Enterprises)", category: "Accounting", definition: "Canadian GAAP for private enterprises — simplified standards separate from IFRS. Used by privately-held Canadian companies. Includes Section 3855 financial instruments, Section 3061 leases, Section 3462 income taxes.", usaUkNote: "Canada only — private enterprises", sheetRef: "03_GAAP_IFRS_Framework" },
      { no: 108, term: "IFRS-Canada (CPA Canada Handbook)", category: "Accounting", definition: "IFRS as adopted in Canada for publicly accountable enterprises (PAEs) since 2011. CPA Canada Handbook Part I = IFRS. Substantively identical to IASB-issued IFRS. Listed Canadian companies must apply IFRS.", usaUkNote: "Canada — PAEs use IFRS; private cos use ASPE", sheetRef: "03_GAAP_IFRS_Framework" },
      { no: 109, term: "CPP (Canada Pension Plan)", category: "Accounting", definition: "Canadian statutory pension plan funded by payroll contributions: 5.95% employee + 5.95% employer on earnings between $3,500 basic exemption and YMPE ($68,500 in 2025). CPP2: additional 4% on $68,500-$73,200 (YAMPE) for enhanced benefits.", usaUkNote: "Canada only — equivalent to US Social Security / UK State Pension", sheetRef: "—" },
      { no: 110, term: "EI (Employment Insurance)", category: "Accounting", definition: "Canadian federal unemployment insurance. Employee premium 1.64% on insurable earnings up to $63,200 (max $1,036.48 in 2025). Employer 1.4× employee premium. Funds unemployment, maternity, parental, sickness, compassionate care benefits.", usaUkNote: "Canada only — equivalent to US FUTA/SUTA / UK JSA", sheetRef: "—" },
      { no: 111, term: "SOFR (Secured Overnight Financing Rate)", category: "Treasury", definition: "USD risk-free replacement for LIBOR (discontinued June 2023). Repo-based overnight rate published by FRBNY. As of Nov 19, 2026: 3.91%. Term SOFR (1M/3M/6M) published by CME: 4.05% / 4.10% / 4.15%.", usaUkNote: "US only (replaced USD LIBOR)", sheetRef: "Market Data — Risk-Free Rates" },
      { no: 112, term: "SONIA (Sterling Overnight Index Average)", category: "Treasury", definition: "GBP risk-free replacement for LIBOR. BoE-published overnight rate based on actual sterling overnight transactions. As of Nov 18, 2026: 3.9840%. Used in GBP swaps and floating-rate note coupons.", usaUkNote: "UK only (replaced GBP LIBOR)", sheetRef: "Market Data — Risk-Free Rates" },
      { no: 113, term: "Damodaran Implied ERP", category: "Equity", definition: "Aswath Damodaran (NYU Stern) publishes implied Equity Risk Premium monthly using a 2-stage augmented dividend discount model. As of Nov 1, 2026: US implied ERP = 4.41% (trailing 12-month with adjusted payout). Use as CAPM ERP input.", usaUkNote: "Same methodology across markets — country-specific via Moody's ratings", sheetRef: "Market Data — ERP / Beta" },
      { no: 114, term: "Fed Funds Target Range", category: "Treasury", definition: "FOMC-set target range for overnight interbank lending. As of Oct 28, 2026 FOMC: 3.75% - 4.00% (upper bound 4.00%). Down from 5.50% peak in Jul 2024. Primary US policy rate influencing SOFR and prime rate.", usaUkNote: "US only", sheetRef: "Market Data — Risk-Free Rates" },
      { no: 115, term: "OECD Pillar Two Global Minimum Tax", category: "Accounting", definition: "15% global minimum effective tax rate on multinational enterprises with consolidated revenue ≥€750M. Adopted in EU, UK, Canada, Japan, Australia. Top-up tax applies where local ETR < 15%. Effective FY 2024-2025 depending on jurisdiction.", usaUkNote: "Global — adopted in 50+ jurisdictions", sheetRef: "Market Data — Tax Rates" },
    ],
  },
  {
    name: "Comprehensive Income",
    icon: "Layers",
    color: "teal",
    terms: [
      { no: 98, term: "Comprehensive Income", category: "Comprehensive Income", definition: "Total of Net Profit/(Loss) for the period + Other Comprehensive Income (OCI). Represents all changes in equity during a period except those arising from transactions with owners (share subscriptions, dividends).", usaUkNote: "IFRS IAS 1 · US GAAP ASC 220 · EU IFRS-EU", sheetRef: "OCI_Statement" },
      { no: 99, term: "Other Comprehensive Income (OCI)", category: "Comprehensive Income", definition: "Income and expenses not recognised in profit or loss as required or permitted by IFRS. Includes FX translation, cash flow hedges, revaluation surplus, pension remeasurements, FVOCI instruments. Bypasses P&L and goes directly to equity.", usaUkNote: "IFRS IAS 1 · US GAAP ASC 220 · EU IFRS-EU", sheetRef: "OCI_Statement" },
      { no: 100, term: "Recycling (Reclassification)", category: "Comprehensive Income", definition: "When an OCI item is realised (e.g., AFS security sold, hedged forecast transaction occurs), the cumulative OCI amount is reclassified ('recycled') from OCI reserve to profit or loss. Non-recyclable items (pension remeasurements, FVOCI equity) never reclassify.", usaUkNote: "IFRS IAS 1 · US GAAP ASC 220", sheetRef: "OCI_Statement" },
      { no: 101, term: "Revaluation Surplus (IAS 16)", category: "Comprehensive Income", definition: "Surplus arising from revaluing PPE under the revaluation model. Recognised in OCI (non-recyclable); on disposal, may transfer directly to retained earnings (not recycled through P&L).", usaUkNote: "IFRS IAS 16 (allowed) · US GAAP (not allowed — historical cost only)", sheetRef: "OCI_Statement" },
      { no: 102, term: "FVOCI (Fair Value through OCI)", category: "Comprehensive Income", definition: "Measurement category for financial assets under IFRS 9. Equity instruments can be irrevocably elected to FVOCI — gains/losses in OCI never recycle to P&L (non-recyclable). Debt instruments at FVOCI: gains/losses in OCI but recycled on derecognition.", usaUkNote: "IFRS 9 (UK/EU) · US GAAP uses AFS (ASC 320)", sheetRef: "OCI_Statement" },
      { no: 103, term: "Cash Flow Hedge Reserve", category: "Comprehensive Income", definition: "Effective portion of changes in fair value of a hedging instrument designated as a cash flow hedge. Recognised in OCI (recyclable); reclassified to P&L when the hedged forecast transaction affects earnings.", usaUkNote: "IFRS 9 (UK/EU) · US GAAP ASC 815", sheetRef: "OCI_Statement" },
      { no: 104, term: "Foreign Currency Translation Reserve", category: "Comprehensive Income", definition: "Exchange differences arising from translating the financial statements of a foreign operation (functional currency ≠ presentation currency). Recognised in OCI (recyclable); reclassified to P&L on disposal of the foreign operation.", usaUkNote: "IFRS IAS 21 · US GAAP ASC 830 · EU IFRS-EU", sheetRef: "OCI_Statement" },
      { no: 105, term: "Defined Benefit Plan Remeasurements", category: "Comprehensive Income", definition: "Actuarial gains/losses, plus changes in the effect of the asset ceiling, on defined benefit pension plans. Recognised in OCI (non-recyclable) under IAS 19 (post-2013). US GAAP also routes to OCI under ASC 715.", usaUkNote: "IFRS IAS 19 · US GAAP ASC 715", sheetRef: "OCI_Statement" },
      { no: 106, term: "Accumulated OCI Reserve", category: "Comprehensive Income", definition: "Equity reserve that accumulates all OCI items period-over-period until recycled (for recyclable items) or derecognised (for non-recyclable items). Disclosed separately in the Statement of Changes in Equity.", usaUkNote: "IFRS IAS 1 · US GAAP ASC 220 · EU IFRS-EU", sheetRef: "OCI_Statement" },
    ],
  },
];

// Flat list of all terms (for search / export)
export const ALL_GLOSSARY_TERMS: GlossaryTerm[] = GLOSSARY_CATEGORIES.flatMap((c) => c.terms);

export const GLOSSARY_STATS = {
  totalTerms: ALL_GLOSSARY_TERMS.length,
  totalCategories: GLOSSARY_CATEGORIES.length,
  sourceWorkbooks: ["FP&A Interview Prep Workbook", "Head of FP&A Study Workbook"],
};
