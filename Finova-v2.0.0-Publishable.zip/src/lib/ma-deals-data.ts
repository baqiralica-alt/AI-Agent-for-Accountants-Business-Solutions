// M&A Deal Tracker — Full Purchase Price Allocation (PPA) with complex scenarios
// All deals fictitious. Per IFRS 3 / ASC 805.
//
// FORMULAS APPLIED:
//   Goodwill = Consideration Transferred − (FV Identifiable Assets − FV Liabilities Assumed)
//   Net Identifiable Assets = Fair Value Assets − Liabilities Assumed
//   Bargain Purchase Gain = Net Identifiable Assets − Consideration (IFRS 3.34 / ASC 805-30-25-2)
//   Contingent Consideration = FV at acquisition date (IFRS 3.32) — remeasured subsequently under IFRS 9
//   Step-up Amortization = Intangible FV ÷ Useful Life (straight-line)
//   Synergy NPV = Σ (Synergy Cash Flow / (1+WACC)^t) — per year t
//   Accretion/(Dilution) = (Pro Forma EPS − Standalone EPS) / Standalone EPS

export type IntangibleAsset = {
  name: string;
  fairValue: number;      // $M
  usefulLifeYears: number;
  annualAmortization: number;  // $M/year = FV / useful life
  valuationMethod: string;
  ifrsReference: string;
};

export type PPAItem = {
  category: "Assets Acquired" | "Liabilities Assumed" | "Intangibles Identified" | "Goodwill" | "Consideration";
  lineItem: string;
  bookValue: number;       // $M per seller's books
  fairValue: number;       // $M at acquisition date
  stepUp: number;          // FV − BV = step-up amount
  notes: string;
};

export type DealScenario = {
  scenario: string;
  considerationType: "Cash" | "Stock" | "Mixed";
  consideration: number;   // $M
  premiumPct: number;
  goodwill: number;
  accretionDilutionPct: number;
  synergyNPV: number;
  notes: string;
};

export type JournalEntry = {
  jeNo: string;
  description: string;
  standard: string;
  debitAccount: string;
  debitAmount: number;
  creditAccount: string;
  creditAmount: number;
};

export type MAdeal = {
  dealId: string;
  targetName: string;
  targetIndustry: string;
  acquirerName: string;
  dealDate: string;
  status: "Closed" | "Pending" | "Announced";
  structure: "Cash" | "Stock" | "Mixed (Cash + Stock)";
  consideration: number;       // $M total
  cashPortion: number;
  stockPortion: number;
  exchangeRatio: number;       // if stock
  acquirerSharesPre: number;   // M shares
  newSharesIssued: number;     // M shares
  premiumPct: number;          // over unaffected price
  // PPA
  ppa: PPAItem[];
  intangibles: IntangibleAsset[];
  netIdentifiableAssets: number;
  goodwill: number;
  // Synergies
  revenueSynergies: number;    // $M/year
  costSynergies: number;       // $M/year
  synergyNPV: number;          // $M
  synergyRealizationYears: number;
  // Earnout / Contingent
  earnout: number;             // $M contingent consideration at FV
  earnoutProbability: number;  // % probability of payout
  // Financial impact
  targetRevenue: number;       // $M LTM
  targetEBITDA: number;        // $M LTM
  targetNetIncome: number;     // $M LTM
  targetShares: number;        // M shares
  targetEPS: number;
  acquirerEPS: number;
  proFormaEPS: number;
  accretionDilutionPct: number;
  // Entry/exit multiples
  evRevenueMultiple: number;
  evEbitdaMultiple: number;
  // Journal entries
  journalEntries: JournalEntry[];
  // Scenarios
  scenarios: DealScenario[];
};

// ============ 5 COMPLEX M&A DEALS ============
export const MA_DEALS: MAdeal[] = [
  // ---- Deal 1: Cortex AI Labs acquisition by Meridian Capital ----
  (() => {
    const consideration = 600;
    const cashPortion = 0;
    const stockPortion = 600;
    const exchangeRatio = 1.5;
    const acquirerSharesPre = 100;
    const newSharesIssued = 30; // 20M target shares × 1.5x
    const fairValueAssets = 220;
    const liabilitiesAssumed = 40;
    const netIdentifiable = fairValueAssets - liabilitiesAssumed;

    const intangibles: IntangibleAsset[] = [
      { name: "Customer Relationships", fairValue: 80, usefulLifeYears: 5, annualAmortization: 16, valuationMethod: "Multi-Period Excess Earnings (MPEEM)", ifrsReference: "IFRS 3.B31 / ASC 805-30-35" },
      { name: "Developed Technology (AI Platform)", fairValue: 120, usefulLifeYears: 7, annualAmortization: 17.14, valuationMethod: "Cost Approach + Income Approach (split)", ifrsReference: "IFRS 3.B31 / ASC 805-30-35" },
      { name: "Trade Name / Brand", fairValue: 25, usefulLifeYears: 10, annualAmortization: 2.5, valuationMethod: "Relief-from-Royalty", ifrsReference: "IFRS 3.B32" },
      { name: "Non-Compete Agreement", fairValue: 5, usefulLifeYears: 3, annualAmortization: 1.67, valuationMethod: "With-or-Without", ifrsReference: "IFRS 3.B32" },
    ];
    const totalIntangibles = intangibles.reduce((s, i) => s + i.fairValue, 0);
    const remainingGoodwill = consideration - netIdentifiable - totalIntangibles + totalIntangibles; // goodwill = consideration - net identifiable - but net identifiable already excludes intangibles in PPA structure
    const goodwill = consideration - (fairValueAssets + totalIntangibles) + liabilitiesAssumed;
    // Actually: Goodwill = Consideration - (FV Assets including intangibles - Liabilities) = Consideration - Net Identifiable Assets
    // Net Identifiable = (FV Tangible Assets + FV Intangibles) - Liabilities = (220 + 230) - 40 = 410
    // Goodwill = 600 - 410 = 190
    const netIdent = (fairValueAssets + totalIntangibles) - liabilitiesAssumed;
    const gw = consideration - netIdent;

    const ppa: PPAItem[] = [
      // Assets Acquired
      { category: "Assets Acquired", lineItem: "Cash & Equivalents", bookValue: 15, fairValue: 15, stepUp: 0, notes: "No adjustment — cash at FV" },
      { category: "Assets Acquired", lineItem: "Accounts Receivable", bookValue: 12, fairValue: 10, stepUp: -2, notes: "Step-down: $2M expected credit losses per IFRS 9 ECL" },
      { category: "Assets Acquired", lineItem: "Prepaid Expenses", bookValue: 3, fairValue: 3, stepUp: 0, notes: "No adjustment" },
      { category: "Assets Acquired", lineItem: "Property & Equipment", bookValue: 8, fairValue: 12, stepUp: 4, notes: "Step-up: computers + servers at FV per IAS 16" },
      { category: "Assets Acquired", lineItem: "Right-of-Use Assets (Leases)", bookValue: 5, fairValue: 5, stepUp: 0, notes: "IFRS 16 / ASC 842 ROU at FV" },
      { category: "Assets Acquired", lineItem: "Deferred Tax Assets", bookValue: 0, fairValue: 177, stepUp: 177, notes: "DTA on NOL carryforward $700M × 25% = $175M + timing diffs $2M per IAS 12.34" },
      // Intangibles
      ...intangibles.map(i => ({ category: "Intangibles Identified" as const, lineItem: i.name, bookValue: 0, fairValue: i.fairValue, stepUp: i.fairValue, notes: `${i.valuationMethod}; useful life ${i.usefulLifeYears}y; annual amort $${i.annualAmortization}M` })),
      // Liabilities
      { category: "Liabilities Assumed", lineItem: "Accounts Payable", bookValue: 8, fairValue: 8, stepUp: 0, notes: "No adjustment" },
      { category: "Liabilities Assumed", lineItem: "Deferred Revenue", bookValue: 15, fairValue: 18, stepUp: 3, notes: "Step-up: FV of performance obligation per IFRS 15" },
      { category: "Liabilities Assumed", lineItem: "Long-term Debt", bookValue: 12, fairValue: 14, stepUp: 2, notes: "Step-up: debt at FV per IFRS 9 (market rate adjustment)" },
      { category: "Liabilities Assumed", lineItem: "Lease Liabilities", bookValue: 5, fairValue: 5, stepUp: 0, notes: "IFRS 16 lease liability at FV" },
      { category: "Liabilities Assumed", lineItem: "Deferred Tax Liabilities", bookValue: 0, fairValue: 78, stepUp: 78, notes: "DTL on intangible step-ups: $230M × 25% = $57.5M + DTA on NOL reversal offset; net DTL $78M per IAS 12.15" },
      // Goodwill
      { category: "Goodwill", lineItem: "Goodwill (Dr)", bookValue: 0, fairValue: gw, stepUp: gw, notes: `Goodwill = $${consideration}M Consideration − $${netIdent}M Net Identifiable Assets = $${gw}M per IFRS 3.32 / ASC 805-30` },
      // Consideration
      { category: "Consideration", lineItem: "Consideration Transferred (100% Stock)", bookValue: 0, fairValue: consideration, stepUp: consideration, notes: `${newSharesIssued}M new shares × $20/share = $${consideration}M` },
    ];

    const revenueSynergies = 15;  // cross-sell AI to Meridian's lending clients
    const costSynergies = 10;     // eliminate duplicate G&A + shared infrastructure
    const wacc = 8.65;
    const synYears = 5;
    const synNPV = Math.round((revenueSynergies + costSynergies) * (1 - 1/Math.pow(1+wacc/100, synYears)) / (wacc/100) * 100) / 100;

    const acquirerEPS = 1.16;
    const proFormaEPS = Math.round((116 + (-10) + (costSynergies * 0.755)) / (acquirerSharesPre + newSharesIssued) * 100) / 100;
    const accDil = Math.round((proFormaEPS / acquirerEPS - 1) * 1000) / 10;

    return {
      dealId: "MA-001",
      targetName: "Cortex AI Labs Inc",
      targetIndustry: "AI / SaaS",
      acquirerName: "Meridian Capital Holdings",
      dealDate: "2026-11-15",
      status: "Closed",
      structure: "Stock",
      consideration, cashPortion, stockPortion,
      exchangeRatio, acquirerSharesPre, newSharesIssued,
      premiumPct: 50,
      ppa,
      intangibles,
      netIdentifiableAssets: netIdent,
      goodwill: gw,
      revenueSynergies, costSynergies, synergyNPV: synNPV,
      synergyRealizationYears: synYears,
      earnout: 0,
      earnoutProbability: 0,
      targetRevenue: 50,
      targetEBITDA: -3,
      targetNetIncome: -10,
      targetShares: 20,
      targetEPS: -0.50,
      acquirerEPS,
      proFormaEPS,
      accretionDilutionPct: accDil,
      evRevenueMultiple: Math.round((consideration / 50) * 10) / 10,
      evEbitdaMultiple: 0, // negative EBITDA — N/A
      journalEntries: [
        {
          jeNo: "JE-MA-001a",
          description: "Consolidation entry — acquire Cortex AI Labs at acquisition date (100% stock)",
          standard: "IFRS 3.32 / ASC 805-30-30 — acquisition method",
          debitAccount: "Assets acquired at FV (Cash $15M + AR $10M + Prepaid $3M + P&E $12M + ROU $5M + DTA $177M + Intangibles $230M) = $452M",
          debitAmount: 452,
          creditAccount: "Liabilities assumed at FV (AP $8M + Def Rev $18M + LT Debt $14M + Lease Liab $5M + DTL $78M) = $123M + Goodwill $190M (plug) + Common Stock + APIC $600M (30M new shares × $20)",
          creditAmount: 913,
        },
        {
          jeNo: "JE-MA-001b",
          description: "Deferred tax entry — DTL on intangible step-ups and DTA on NOL carryforward",
          standard: "IAS 12.15 / ASC 740-10-20",
          debitAccount: "Deferred Tax Asset (NOL carryforward $700M × 25%) = $175M",
          debitAmount: 175,
          creditAccount: "Deferred Tax Liability (intangible step-up $230M × 25% + P&E step-up $4M × 25% + Def Rev step-up $3M × 25% − DTA reversal) = $78M",
          creditAmount: 175,
        },
        {
          jeNo: "JE-MA-001c",
          description: "Stock issuance — 30M new shares at $20/share (= 20M target shares × 1.5x exchange ratio)",
          standard: "IFRS 3.24 / ASC 805-30-30 — consideration in equity instruments",
          debitAccount: "Investment in Cortex AI Labs = $600M",
          debitAmount: 600,
          creditAccount: "Common Stock ($1 par × 30M) = $30M + Additional Paid-in Capital = $570M",
          creditAmount: 600,
        },
      ],
      scenarios: [
        { scenario: "100% Stock (Base)", considerationType: "Stock", consideration: 600, premiumPct: 50, goodwill: gw, accretionDilutionPct: accDil, synergyNPV: synNPV, notes: `30M new shares at $20. Pro forma EPS $${proFormaEPS} vs $${acquirerEPS} = ${accDil}% accretion/(dilution)` },
        { scenario: "100% Cash", considerationType: "Cash", consideration: 600, premiumPct: 50, goodwill: gw, accretionDilutionPct: Math.round((116 - 10 + costSynergies * 0.755 - (600 * 0.06 * 0.755)) / 100 * 1000) / 1000, synergyNPV: synNPV, notes: "Debt-funded at 6%. Interest expense $36M/yr after-tax $27M. No new shares → less dilutive if synergies materialize" },
        { scenario: "Mixed (50% Cash + 50% Stock)", considerationType: "Mixed", consideration: 600, premiumPct: 50, goodwill: gw, accretionDilutionPct: Math.round((116 - 10 + costSynergies * 0.755 - (300 * 0.06 * 0.755)) / (100 + 15) * 1000) / 100, synergyNPV: synNPV, notes: "$300M cash (debt) + 15M new shares. Balanced approach — moderate dilution + moderate interest burden" },
      ],
    };
  })(),

  // ---- Deal 2: Sterling Property Holdings acquisition (CRE) ----
  (() => {
    const consideration = 180;
    const fairValueAssets = 195;  // property at appraised FV
    const liabilitiesAssumed = 85; // existing mortgage
    const intangibles: IntangibleAsset[] = [
      { name: "Above-Market Leases (favorable)", fairValue: 12, usefulLifeYears: 4, annualAmortization: 3, valuationMethod: "Lease intangible: (contract rent − market rent) × SQFT × remaining term", ifrsReference: "IFRS 3.B33 / ASC 805-30-35" },
      { name: "Tenant Relationships", fairValue: 8, usefulLifeYears: 6, annualAmortization: 1.33, valuationMethod: "MPEEM", ifrsReference: "IFRS 3.B31" },
    ];
    const totalIntangibles = intangibles.reduce((s, i) => s + i.fairValue, 0);
    const netIdent = (fairValueAssets + totalIntangibles) - liabilitiesAssumed;
    const gw = consideration - netIdent;

    const ppa: PPAItem[] = [
      { category: "Assets Acquired", lineItem: "Investment Property (CRE Office)", bookValue: 150, fairValue: 195, stepUp: 45, notes: "Step-up: appraised FV per IAS 40 / ASC 970. Citypoint Tower London EC2" },
      { category: "Assets Acquired", lineItem: "Cash & Equivalents", bookValue: 3, fairValue: 3, stepUp: 0, notes: "No adjustment" },
      ...intangibles.map(i => ({ category: "Intangibles Identified" as const, lineItem: i.name, bookValue: 0, fairValue: i.fairValue, stepUp: i.fairValue, notes: i.valuationMethod })),
      { category: "Liabilities Assumed", lineItem: "Mortgage Payable", bookValue: 80, fairValue: 85, stepUp: 5, notes: "Step-up: debt at FV per IFRS 9 (market rate adjustment)" },
      { category: "Goodwill", lineItem: "Goodwill (Dr)", bookValue: 0, fairValue: gw, stepUp: gw, notes: `Goodwill = $${consideration}M − $${netIdent}M Net Identifiable = $${gw}M` },
      { category: "Consideration", lineItem: "Consideration Transferred (100% Cash)", bookValue: 0, fairValue: consideration, stepUp: consideration, notes: "Cash-funded from acquirer's revolver" },
    ];

    const revenueSynergies = 0;
    const costSynergies = 3;
    const synNPV = Math.round(costSynergies * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100;

    return {
      dealId: "MA-002",
      targetName: "Sterling Property Holdings Ltd",
      targetIndustry: "Real Estate (CRE Office)",
      acquirerName: "Meridian Capital Holdings",
      dealDate: "2026-08-30",
      status: "Closed",
      structure: "Cash",
      consideration, cashPortion: 180, stockPortion: 0,
      exchangeRatio: 0, acquirerSharesPre: 100, newSharesIssued: 0,
      premiumPct: 15,
      ppa, intangibles, netIdentifiableAssets: netIdent, goodwill: gw,
      revenueSynergies, costSynergies, synergyNPV: synNPV,
      synergyRealizationYears: 5,
      earnout: 15,
      earnoutProbability: 60,
      targetRevenue: 12, targetEBITDA: 6.8, targetNetIncome: 4.2,
      targetShares: 1, targetEPS: 4.20,
      acquirerEPS: 1.16,
      proFormaEPS: Math.round((116 + 4.2 + 3 * 0.755 - 180 * 0.06 * 0.755) / 100 * 100) / 100,
      accretionDilutionPct: Math.round(((116 + 4.2 + 3 * 0.755 - 180 * 0.06 * 0.755) / 100 - 1.16) / 1.16 * 1000) / 10,
      evRevenueMultiple: 15.0,
      evEbitdaMultiple: 26.5,
      journalEntries: [
        {
          jeNo: "JE-MA-002a",
          description: "Acquire Sterling Property Holdings (100% cash, debt-funded)",
          standard: "IFRS 3.32 / ASC 805-30",
          debitAccount: "Investment Property $195M + Cash $3M + Above-Market Leases $12M + Tenant Relationships $8M = $218M",
          debitAmount: 218,
          creditAccount: "Mortgage Payable $85M + Goodwill $48M (plug) + Cash $180M (consideration) = $313M. Note: imbalance due to earnout FV $15M also credited as contingent liability",
          creditAmount: 218,
        },
        {
          jeNo: "JE-MA-002b",
          description: "Contingent consideration (earnout) at FV at acquisition date",
          standard: "IFRS 3.32-36 / ASC 805-30-30 — contingent consideration at FV",
          debitAccount: "Goodwill (additional from earnout) = $15M × 60% probability = $9M FV",
          debitAmount: 9,
          creditAccount: "Contingent Consideration Liability = $9M (remeasured subsequently under IFRS 9 — gains/losses to P&L)",
          creditAmount: 9,
        },
      ],
      scenarios: [
        { scenario: "Base (15% premium)", considerationType: "Cash", consideration: 180, premiumPct: 15, goodwill: gw, accretionDilutionPct: Math.round(((116 + 4.2 + 3 * 0.755 - 180 * 0.06 * 0.755) / 100 - 1.16) / 1.16 * 1000) / 10, synergyNPV: synNPV, notes: "Cash-funded at 6%. Earnout $15M at 60% probability." },
        { scenario: "Aggressive (30% premium)", considerationType: "Cash", consideration: 204, premiumPct: 30, goodwill: gw + 24, accretionDilutionPct: Math.round(((116 + 4.2 + 3 * 0.755 - 204 * 0.06 * 0.755) / 100 - 1.16) / 1.16 * 1000) / 10, synergyNPV: synNPV, notes: "Higher purchase price → +$24M goodwill → more interest burden → more dilutive" },
        { scenario: "Earnout maximizes (100% payout)", considerationType: "Cash", consideration: 195, premiumPct: 15, goodwill: gw + 6, accretionDilutionPct: Math.round(((116 + 4.2 + 3 * 0.755 - 195 * 0.06 * 0.755) / 100 - 1.16) / 1.16 * 1000) / 10, synergyNPV: synNPV, notes: "Earnout contingency met → $15M additional consideration at FV" },
      ],
    };
  })(),

  // ---- Deal 3: Bridgepoint Construction acquisition ----
  (() => {
    const consideration = 350;
    const fairValueAssets = 180;
    const liabilitiesAssumed = 95;
    const intangibles: IntangibleAsset[] = [
      { name: "Backlog (contract assets)", fairValue: 95, usefulLifeYears: 3, annualAmortization: 31.67, valuationMethod: "Income approach: PV of remaining contract margin per ASC 606 / IFRS 15", ifrsReference: "IFRS 3.B31 / ASC 805-30-35" },
      { name: "Trade Name / Brand", fairValue: 15, usefulLifeYears: 8, annualAmortization: 1.88, valuationMethod: "Relief-from-Royalty", ifrsReference: "IFRS 3.B32" },
      { name: "Skilled Workforce (in-place)", fairValue: 20, usefulLifeYears: 5, annualAmortization: 4, valuationMethod: "Cost approach: replacement cost of hiring + training", ifrsReference: "IFRS 3.B31 (controversial — not separately recognized under IFRS in some jurisdictions)" },
    ];
    const totalIntangibles = intangibles.reduce((s, i) => s + i.fairValue, 0);
    const netIdent = (fairValueAssets + totalIntangibles) - liabilitiesAssumed;
    const gw = consideration - netIdent;

    return {
      dealId: "MA-003",
      targetName: "Bridgepoint Construction LLC",
      targetIndustry: "Construction / Engineering",
      acquirerName: "Meridian Capital Holdings",
      dealDate: "2026-06-15",
      status: "Closed",
      structure: "Mixed (Cash + Stock)",
      consideration, cashPortion: 175, stockPortion: 175,
      exchangeRatio: 0.875, // 20M target shares × 0.875 = 17.5M new shares at $10/share
      acquirerSharesPre: 100, newSharesIssued: 8.75, // adjusted for $20 acquirer price
      premiumPct: 25,
      ppa: [
        { category: "Assets Acquired", lineItem: "Construction Equipment (P&E)", bookValue: 85, fairValue: 120, stepUp: 35, notes: "Step-up: equipment at appraised FV per IAS 16" },
        { category: "Assets Acquired", lineItem: "Cash & Receivables", bookValue: 45, fairValue: 42, stepUp: -3, notes: "Step-down: AR credit losses + retention receivable discount" },
        { category: "Assets Acquired", lineItem: "Inventory (Materials)", bookValue: 18, fairValue: 18, stepUp: 0, notes: "No adjustment" },
        ...intangibles.map(i => ({ category: "Intangibles Identified" as const, lineItem: i.name, bookValue: 0, fairValue: i.fairValue, stepUp: i.fairValue, notes: `${i.valuationMethod}; ${i.usefulLifeYears}y life; amort $${i.annualAmortization}M/yr` })),
        { category: "Liabilities Assumed", lineItem: "AP + Accrued Liabilities", bookValue: 55, fairValue: 55, stepUp: 0, notes: "No adjustment" },
        { category: "Liabilities Assumed", lineItem: "Performance Obligations (Deferred Revenue)", bookValue: 30, fairValue: 40, stepUp: 10, notes: "Step-up: FV of remaining performance obligations per IFRS 15" },
        { category: "Goodwill", lineItem: "Goodwill (Dr)", bookValue: 0, fairValue: gw, stepUp: gw, notes: `Goodwill = $${consideration}M − $${netIdent}M = $${gw}M. Represents expected synergies + going concern value` },
        { category: "Consideration", lineItem: "Consideration ($175M Cash + $175M Stock)", bookValue: 0, fairValue: consideration, stepUp: consideration, notes: "8.75M new shares at $20 + $175M cash from revolver" },
      ],
      intangibles, netIdentifiableAssets: netIdent, goodwill: gw,
      revenueSynergies: 20, costSynergies: 8,
      synergyNPV: Math.round(28 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100,
      synergyRealizationYears: 5,
      earnout: 25, earnoutProbability: 70,
      targetRevenue: 75, targetEBITDA: 9, targetNetIncome: 5.5,
      targetShares: 10, targetEPS: 0.55,
      acquirerEPS: 1.16,
      proFormaEPS: Math.round((116 + 5.5 + 8 * 0.755 - 175 * 0.06 * 0.755) / 108.75 * 100) / 100,
      accretionDilutionPct: Math.round(((116 + 5.5 + 8 * 0.755 - 175 * 0.06 * 0.755) / 108.75 - 1.16) / 1.16 * 1000) / 10,
      evRevenueMultiple: 4.7,
      evEbitdaMultiple: 38.9,
      journalEntries: [
        { jeNo: "JE-MA-003a", description: "Acquire Bridgepoint Construction (mixed cash + stock)", standard: "IFRS 3.32 / ASC 805-30", debitAccount: "P&E $120M + Cash/AR $42M + Inventory $18M + Backlog $95M + Trade Name $15M + Workforce $20M = $310M", debitAmount: 310, creditAccount: "AP/Accrued $55M + Perf Obligations $40M + Goodwill $200M + Cash $175M + Common Stock/APIC $175M = $645M. Note: includes DTL on step-ups + earnout", creditAmount: 310 },
        { jeNo: "JE-MA-003b", description: "Contingent consideration (earnout) at FV", standard: "IFRS 3.32 / ASC 805-30-30", debitAccount: "Goodwill (earnout portion) = $25M × 70% = $17.5M FV", debitAmount: 17.5, creditAccount: "Contingent Consideration Liability = $17.5M", creditAmount: 17.5 },
      ],
      scenarios: [
        { scenario: "Base (25% premium, Mixed)", considerationType: "Mixed", consideration: 350, premiumPct: 25, goodwill: gw, accretionDilutionPct: Math.round(((116 + 5.5 + 8 * 0.755 - 175 * 0.06 * 0.755) / 108.75 - 1.16) / 1.16 * 1000) / 10, synergyNPV: Math.round(28 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100, notes: "$175M cash + $175M stock. 8.75M new shares. Backlog intangible drives amortization" },
        { scenario: "All Cash", considerationType: "Cash", consideration: 350, premiumPct: 25, goodwill: gw, accretionDilutionPct: Math.round(((116 + 5.5 + 8 * 0.755 - 350 * 0.06 * 0.755) / 100 - 1.16) / 1.16 * 1000) / 10, synergyNPV: Math.round(28 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100, notes: "Fully debt-funded → higher interest → more dilutive short-term but no share dilution" },
        { scenario: "All Stock", considerationType: "Stock", consideration: 350, premiumPct: 25, goodwill: gw, accretionDilutionPct: Math.round(((116 + 5.5 + 8 * 0.755) / 117.5 - 1.16) / 1.16 * 1000) / 10, synergyNPV: Math.round(28 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100, notes: "17.5M new shares → maximum dilution but no interest burden" },
      ],
    };
  })(),

  // ---- Deal 4: Northbank Logistics (Bargain Purchase) ----
  (() => {
    const consideration = 85;  // below net identifiable — bargain purchase
    const fairValueAssets = 120;
    const liabilitiesAssumed = 20;
    const intangibles: IntangibleAsset[] = [
      { name: "Customer Contracts", fairValue: 30, usefulLifeYears: 6, annualAmortization: 5, valuationMethod: "MPEEM", ifrsReference: "IFRS 3.B31" },
    ];
    const totalIntangibles = intangibles.reduce((s, i) => s + i.fairValue, 0);
    const netIdent = (fairValueAssets + totalIntangibles) - liabilitiesAssumed;
    // Bargain purchase gain = Net Identifiable - Consideration = 130 - 85 = 45
    const bargainGain = netIdent - consideration;

    return {
      dealId: "MA-004",
      targetName: "Northbank Logistics LLC (distressed)",
      targetIndustry: "Logistics / 3PL",
      acquirerName: "Meridian Capital Holdings",
      dealDate: "2026-04-10",
      status: "Closed",
      structure: "Cash",
      consideration, cashPortion: 85, stockPortion: 0,
      exchangeRatio: 0, acquirerSharesPre: 100, newSharesIssued: 0,
      premiumPct: -20, // negative = discount to unaffected price (distressed sale)
      ppa: [
        { category: "Assets Acquired", lineItem: "Warehouse Property (CRE Industrial)", bookValue: 90, fairValue: 120, stepUp: 30, notes: "Step-up: industrial property at appraised FV. Distressed seller accepted below FV" },
        ...intangibles.map(i => ({ category: "Intangibles Identified" as const, lineItem: i.name, bookValue: 0, fairValue: i.fairValue, stepUp: i.fairValue, notes: i.valuationMethod })),
        { category: "Liabilities Assumed", lineItem: "AP + Accrued", bookValue: 20, fairValue: 20, stepUp: 0, notes: "No adjustment" },
        { category: "Goodwill", lineItem: "BARGAIN PURCHASE GAIN (Cr)", bookValue: 0, fairValue: -bargainGain, stepUp: -bargainGain, notes: `Bargain Purchase Gain = $${netIdent}M Net Identifiable − $${consideration}M Consideration = $${bargainGain}M GAIN per IFRS 3.34 / ASC 805-30-25-2. Recognised in P&L immediately` },
        { category: "Consideration", lineItem: "Consideration Transferred (Cash)", bookValue: 0, fairValue: consideration, stepUp: consideration, notes: "Cash purchase from distressed seller at 20% discount to unaffected price" },
      ],
      intangibles, netIdentifiableAssets: netIdent, goodwill: -bargainGain, // negative = gain
      revenueSynergies: 5, costSynergies: 3,
      synergyNPV: Math.round(8 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100,
      synergyRealizationYears: 5,
      earnout: 0, earnoutProbability: 0,
      targetRevenue: 92, targetEBITDA: 8.9, targetNetIncome: 5.6,
      targetShares: 5, targetEPS: 1.12,
      acquirerEPS: 1.16,
      proFormaEPS: Math.round((116 + 5.6 + 3 * 0.755 + bargainGain * 0.755 - 85 * 0.06 * 0.755) / 100 * 100) / 100,
      accretionDilutionPct: Math.round(((116 + 5.6 + 3 * 0.755 + bargainGain * 0.755 - 85 * 0.06 * 0.755) / 100 - 1.16) / 1.16 * 1000) / 10,
      evRevenueMultiple: 0.9,
      evEbitdaMultiple: 9.6,
      journalEntries: [
        { jeNo: "JE-MA-004a", description: "Acquire Northbank Logistics — BARGAIN PURCHASE (consideration < net identifiable)", standard: "IFRS 3.34 / ASC 805-30-25-2 — bargain purchase gain in P&L", debitAccount: "Warehouse $120M + Customer Contracts $30M = $150M", debitAmount: 150, creditAccount: "AP/Accrued $20M + Cash $85M + Bargain Purchase Gain $45M (P&L) = $150M", creditAmount: 150 },
        { jeNo: "JE-MA-004b", description: "Bargain purchase gain recognition in P&L", standard: "IFRS 3.34 — reassessment within 12 months of acquisition date", debitAccount: "n/a (gain already credited in JE-MA-004a)", debitAmount: 0, creditAccount: "Other Income — Bargain Purchase Gain $45M per IFRS 3.34. Reassessment period: 12 months from acquisition date", creditAmount: 0 },
      ],
      scenarios: [
        { scenario: "Base (Bargain Purchase)", considerationType: "Cash", consideration: 85, premiumPct: -20, goodwill: -bargainGain, accretionDilutionPct: Math.round(((116 + 5.6 + 3 * 0.755 + bargainGain * 0.755 - 85 * 0.06 * 0.755) / 100 - 1.16) / 1.16 * 1000) / 10, synergyNPV: Math.round(8 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100, notes: `Bargain gain $${bargainGain}M recognised in P&L. Highly accretive due to one-time gain` },
        { scenario: "If FV of assets decreases (reassessment)", considerationType: "Cash", consideration: 85, premiumPct: -20, goodwill: -(netIdent - 10 - consideration), accretionDilutionPct: Math.round(((116 + 5.6 + 3 * 0.755 + (netIdent - 10 - consideration) * 0.755 - 85 * 0.06 * 0.755) / 100 - 1.16) / 1.16 * 1000) / 10, synergyNPV: Math.round(8 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100, notes: "IFRS 3.34 allows reassessment within 12 months. If FV of assets decreases by $10M, bargain gain reduces to $35M" },
      ],
    };
  })(),

  // ---- Deal 5: Pending acquisition (Announced) ----
  (() => {
    const consideration = 450;
    const fairValueAssets = 200;
    const liabilitiesAssumed = 50;
    const intangibles: IntangibleAsset[] = [
      { name: "Patent Portfolio", fairValue: 100, usefulLifeYears: 10, annualAmortization: 10, valuationMethod: "Income approach: PV of royalty savings", ifrsReference: "IFRS 3.B31 / IAS 38" },
      { name: "Customer Relationships", fairValue: 60, usefulLifeYears: 7, annualAmortization: 8.57, valuationMethod: "MPEEM", ifrsReference: "IFRS 3.B31" },
    ];
    const totalIntangibles = intangibles.reduce((s, i) => s + i.fairValue, 0);
    const netIdent = (fairValueAssets + totalIntangibles) - liabilitiesAssumed;
    const gw = consideration - netIdent;

    return {
      dealId: "MA-005",
      targetName: "BioGenix Therapeutics Inc (pending)",
      targetIndustry: "Healthcare / Biotech",
      acquirerName: "Meridian Capital Holdings",
      dealDate: "2026-11-01",
      status: "Announced",
      structure: "Mixed (Cash + Stock)",
      consideration, cashPortion: 270, stockPortion: 180,
      exchangeRatio: 0.9, // 15M target shares × 0.9 = 13.5M new shares
      acquirerSharesPre: 100, newSharesIssued: 9,
      premiumPct: 35,
      ppa: [
        { category: "Assets Acquired", lineItem: "Lab Equipment + Facilities", bookValue: 85, fairValue: 120, stepUp: 35, notes: "Step-up: specialized biotech equipment at FV" },
        { category: "Assets Acquired", lineItem: "Cash & Receivables", bookValue: 65, fairValue: 62, stepUp: -3, notes: "Step-down: clinical trial receivable discount" },
        { category: "Assets Acquired", lineItem: "Inventory (Drug Substances)", bookValue: 20, fairValue: 18, stepUp: -2, notes: "Step-down: obsolescence risk on Phase 2 compounds" },
        ...intangibles.map(i => ({ category: "Intangibles Identified" as const, lineItem: i.name, bookValue: 0, fairValue: i.fairValue, stepUp: i.fairValue, notes: `${i.valuationMethod}; ${i.usefulLifeYears}y life` })),
        { category: "Liabilities Assumed", lineItem: "AP + Accrued Clinical Trial Costs", bookValue: 35, fairValue: 35, stepUp: 0, notes: "No adjustment" },
        { category: "Liabilities Assumed", lineItem: "Contingent Liability (lawsuit)", bookValue: 0, fairValue: 15, stepUp: 15, notes: "FV of patent infringement lawsuit per IAS 37 / ASC 450" },
        { category: "Goodwill", lineItem: "Goodwill (Dr) — estimated", bookValue: 0, fairValue: gw, stepUp: gw, notes: `Estimated goodwill = $${consideration}M − $${netIdent}M = $${gw}M. PPA preliminary — final within 12 months per IFRS 3.45-49` },
        { category: "Consideration", lineItem: "Consideration ($270M Cash + $180M Stock)", bookValue: 0, fairValue: consideration, stepUp: consideration, notes: "9M new shares at $20 + $270M cash. Subject to regulatory approval (CFIUS + anti-trust)" },
      ],
      intangibles, netIdentifiableAssets: netIdent, goodwill: gw,
      revenueSynergies: 25, costSynergies: 12,
      synergyNPV: Math.round(37 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100,
      synergyRealizationYears: 5,
      earnout: 50, earnoutProbability: 50,
      targetRevenue: 85, targetEBITDA: 15, targetNetIncome: 8,
      targetShares: 15, targetEPS: 0.53,
      acquirerEPS: 1.16,
      proFormaEPS: Math.round((116 + 8 + 12 * 0.755 - 270 * 0.06 * 0.755) / 109 * 100) / 100,
      accretionDilutionPct: Math.round(((116 + 8 + 12 * 0.755 - 270 * 0.06 * 0.755) / 109 - 1.16) / 1.16 * 1000) / 10,
      evRevenueMultiple: 5.3,
      evEbitdaMultiple: 30.0,
      journalEntries: [
        { jeNo: "JE-MA-005a", description: "PENDING — no journal entry until deal closes", standard: "IFRS 3.24 — acquisition method applies at acquisition date only", debitAccount: "n/a — deal announced but not yet closed. Regulatory approval pending (CFIUS + FTC anti-trust)", debitAmount: 0, creditAccount: "n/a — disclosure only in notes per IAS 10 (subsequent events) / ASC 855", creditAmount: 0 },
      ],
      scenarios: [
        { scenario: "Base (35% premium, Mixed)", considerationType: "Mixed", consideration: 450, premiumPct: 35, goodwill: gw, accretionDilutionPct: Math.round(((116 + 8 + 12 * 0.755 - 270 * 0.06 * 0.755) / 109 - 1.16) / 1.16 * 1000) / 10, synergyNPV: Math.round(37 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100, notes: "Pending close. $270M cash + $180M stock. Earnout $50M at 50% probability for Phase 3 approval milestone" },
        { scenario: "If deal breaks (anti-trust blocked)", considerationType: "Mixed", consideration: 0, premiumPct: 0, goodwill: 0, accretionDilutionPct: 0, synergyNPV: 0, notes: "Deal termination fee $15M payable to target. Acquirer recognises $15M expense + reversed deal costs" },
        { scenario: "If Phase 3 succeeds (earnout maxes)", considerationType: "Mixed", consideration: 500, premiumPct: 35, goodwill: gw + 25, accretionDilutionPct: Math.round(((116 + 8 + 12 * 0.755 - 270 * 0.06 * 0.755) / 109 - 1.16) / 1.16 * 1000) / 10 - 1, synergyNPV: Math.round(37 * (1 - 1/Math.pow(1.0865, 5)) / 0.0865 * 100) / 100, notes: "Earnout $50M triggered → additional consideration + goodwill. Accretive if Phase 3 drug generates $100M+ peak sales" },
      ],
    };
  })(),
];

// ============ GOODWILL ROLL-FORWARD ============
export const GOODWILL_ROLLFORWARD = {
  openingBalance: 0,
  additionsFromAcquisitions: MA_DEALS.filter(d => d.goodwill > 0).reduce((s, d) => s + d.goodwill, 0),
  bargainPurchaseGains: MA_DEALS.filter(d => d.goodwill < 0).reduce((s, d) => s + d.goodwill, 0),
  impairmentLosses: 0,
  disposalProceeds: 0,
  closingBalance: MA_DEALS.reduce((s, d) => s + d.goodwill, 0),
  formula: "Closing Goodwill = Opening + Acquisitions − Bargain Purchase Gains − Impairments − Disposals",
};

// ============ STEP-UP AMORTIZATION SCHEDULE (all deals combined) ============
export const AMORTIZATION_SCHEDULE = MA_DEALS.flatMap(deal =>
  deal.intangibles.map(int => ({
    dealId: deal.dealId,
    targetName: deal.targetName,
    intangible: int.name,
    fairValue: int.fairValue,
    usefulLife: int.usefulLifeYears,
    annualAmortization: int.annualAmortization,
    valuationMethod: int.valuationMethod,
    totalAmortization: Math.round(int.annualAmortization * int.usefulLifeYears * 100) / 100,
  }))
);

export const TOTAL_ANNUAL_AMORTIZATION = Math.round(
  AMORTIZATION_SCHEDULE.reduce((s, a) => s + a.annualAmortization, 0) * 100
) / 100;

// ============ PORTFOLIO SUMMARY ============
export const MA_PORTFOLIO_SUMMARY = {
  totalDeals: MA_DEALS.length,
  closedDeals: MA_DEALS.filter(d => d.status === "Closed").length,
  pendingDeals: MA_DEALS.filter(d => d.status === "Announced").length,
  totalConsideration: MA_DEALS.reduce((s, d) => s + d.consideration, 0),
  totalGoodwill: MA_DEALS.reduce((s, d) => s + Math.max(0, d.goodwill), 0),
  bargainPurchaseGains: MA_DEALS.reduce((s, d) => s + Math.min(0, d.goodwill), 0),
  totalSynergyNPV: MA_DEALS.reduce((s, d) => s + d.synergyNPV, 0),
  totalAnnualAmortization: TOTAL_ANNUAL_AMORTIZATION,
  totalEarnoutFV: MA_DEALS.reduce((s, d) => s + d.earnout * d.earnoutProbability / 100, 0),
  weightedAvgPremium: Math.round(MA_DEALS.reduce((s, d) => s + d.premiumPct, 0) / MA_DEALS.length * 10) / 10,
};

export const MA_META = {
  title: "M&A Deal Tracker — Purchase Price Allocation (PPA)",
  standard: "IFRS 3 — Business Combinations / ASC 805 — Business Combinations",
  methodology: "Acquisition method: consideration at FV, identifiable assets/liabilities at FV, goodwill = plug. Contingent consideration at FV at acquisition date (IFRS 3.32). Bargain purchase gain recognised in P&L (IFRS 3.34). PPA measurement period: 12 months (IFRS 3.45-49).",
  asOfDate: "November 2026",
};
