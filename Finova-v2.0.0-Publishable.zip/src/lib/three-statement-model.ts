// 3-Statement Model — Meridian Capital Holdings
// Multi-entity holding company (US Inc + UK Ltd + Partners LP) | $850M FY23 Revenue
// Driver-based: all line items derived from blue-cell assumptions via linked formulas.
//
// FORMULA LINKAGES:
//   Revenue[t] = Revenue[t-1] × (1 + Growth[t])                          [per segment]
//   Total Revenue[t] = Σ segment revenues[t]
//   Direct Costs[t] = Direct Cost %[t] × Total Revenue[t]
//   Gross Profit[t] = Total Revenue[t] - Direct Costs[t]
//   S&M[t] = S&M %[t] × Total Revenue[t]
//   R&D[t] = R&D %[t] × Total Revenue[t]
//   G&A[t] = G&A %[t] × Total Revenue[t]
//   Total OpEx[t] = S&M[t] + R&D[t] + G&A[t]
//   EBITDA[t] = Gross Profit[t] - Total OpEx[t]
//   D&A[t] = D&A %[t] × Beginning PP&E (gross)[t]
//   EBIT[t] = EBITDA[t] - D&A[t]
//   Interest Expense[t] = Avg Interest Rate[t] × Avg Debt[t]
//   Interest Income[t] = Cash Rate[t] × Avg Cash[t]
//   EBT[t] = EBIT[t] - Interest Expense[t] + Interest Income[t]
//   Tax[t] = Effective Tax Rate[t] × EBT[t]
//   Net Income[t] = EBT[t] - Tax[t]
//
// Balance Sheet linkages:
//   Cash[t] = Beginning Cash[t] + Net Change in Cash[t]                [from CF]
//   AR[t] = AR Days[t] × Revenue[t] / 365 (or simplified % × Revenue)
//   Inventory[t] = Inventory Days × COGS[t] / 365
//   PP&E Gross[t] = PP&E Gross[t-1] + Capex[t]
//   Accumulated Depreciation[t] = AccDep[t-1] + D&A[t]
//   PP&E Net[t] = PP&E Gross[t] - Accumulated Depreciation[t]
//   Retained Earnings[t] = RE[t-1] + Net Income[t] - Dividends[t]
//   Dividends[t] = Dividend Payout %[t] × Net Income[t]
//   TOTAL ASSETS = TOTAL LIABILITIES + EQUITY  [balance check = 0]
//
// Cash Flow linkages:
//   CFO = NI + D&A + Intangibles Amort + ΔWC (AR, Inv, AP, Accrued, Deferred Rev)
//   CFI = -Capex[t]  (Capex = Capex %[t] × Revenue[t])
//   CFF = -Dividends[t]  (+ ΔDebt if modelled)
//   Net Change in Cash = CFO + CFI + CFF
//   Ending Cash = Beginning Cash + Net Change in Cash

export type YearColumn = "FY2020A" | "FY2021A" | "FY2022A" | "FY2023A" | "FY2024E" | "FY2025E" | "FY2026E" | "FY2027E";
export const YEARS: YearColumn[] = ["FY2020A", "FY2021A", "FY2022A", "FY2023A", "FY2024E", "FY2025E", "FY2026E", "FY2027E"];

// ============ ASSUMPTIONS (blue cells — user-modifiable) ============
export type Assumption = {
  driver: string;
  values: number[];           // 8 values for FY2020-FY2027
  formula: string;            // human-readable formula
  unit: string;
};

export const ASSUMPTIONS: Assumption[] = [
  { driver: "Revenue Growth — Lending Segment", values: [0.06, 0.07, 0.05, 0.06, 0.07, 0.08, 0.09, 0.08], formula: "Rev[t] = Rev[t-1] × (1 + Growth[t])", unit: "%" },
  { driver: "Revenue Growth — Construction Segment", values: [0.09, 0.11, 0.08, 0.09, 0.10, 0.10, 0.11, 0.10], formula: "Rev[t] = Rev[t-1] × (1 + Growth[t])", unit: "%" },
  { driver: "Revenue Growth — Real Estate (NOI)", values: [0.04, 0.05, 0.03, 0.04, 0.04, 0.05, 0.05, 0.06], formula: "Rev[t] = Rev[t-1] × (1 + Growth[t])", unit: "%" },
  { driver: "Revenue Growth — AI SaaS Segment", values: [0.25, 0.32, 0.28, 0.30, 0.30, 0.28, 0.25, 0.22], formula: "Rev[t] = Rev[t-1] × (1 + Growth[t])", unit: "%" },
  { driver: "Direct Cost % of Revenue", values: [0.45, 0.44, 0.44, 0.43, 0.43, 0.42, 0.42, 0.41], formula: "Direct Costs[t] = Direct Cost %[t] × Total Revenue[t]", unit: "%" },
  { driver: "S&M % of Revenue", values: [0.18, 0.17, 0.16, 0.15, 0.15, 0.15, 0.14, 0.14], formula: "S&M[t] = S&M %[t] × Total Revenue[t]", unit: "%" },
  { driver: "R&D % of Revenue", values: [0.06, 0.06, 0.07, 0.07, 0.07, 0.07, 0.08, 0.08], formula: "R&D[t] = R&D %[t] × Total Revenue[t]", unit: "%" },
  { driver: "G&A % of Revenue", values: [0.10, 0.10, 0.09, 0.09, 0.09, 0.08, 0.08, 0.08], formula: "G&A[t] = G&A %[t] × Total Revenue[t]", unit: "%" },
  { driver: "D&A % of Beginning PP&E (gross)", values: [0.08, 0.08, 0.08, 0.09, 0.09, 0.09, 0.09, 0.09], formula: "D&A[t] = D&A %[t] × Beginning PP&E Gross[t]", unit: "%" },
  { driver: "Interest Rate on Debt (avg)", values: [0.055, 0.055, 0.060, 0.065, 0.060, 0.055, 0.055, 0.050], formula: "Int Exp[t] = Avg Debt Rate[t] × Avg Debt[t]", unit: "%" },
  { driver: "Interest Rate on Cash", values: [0.020, 0.015, 0.020, 0.040, 0.045, 0.040, 0.035, 0.030], formula: "Int Inc[t] = Cash Rate[t] × Avg Cash[t]", unit: "%" },
  { driver: "Effective Tax Rate", values: [0.245, 0.240, 0.245, 0.250, 0.245, 0.240, 0.235, 0.235], formula: "Tax[t] = ETR[t] × EBT[t]", unit: "%" },
  { driver: "Capex % of Revenue", values: [0.05, 0.06, 0.06, 0.05, 0.06, 0.07, 0.07, 0.06], formula: "Capex[t] = Capex %[t] × Revenue[t]", unit: "%" },
  { driver: "Dividend Payout Ratio", values: [0.10, 0.12, 0.15, 0.20, 0.22, 0.25, 0.28, 0.30], formula: "Dividends[t] = Payout %[t] × Net Income[t]", unit: "%" },
];

// ============ SEED VALUES (FY2020 actuals — blue cells) ============
export const SEED_REVENUE = {
  lending: 230,         // $M FY2020
  construction: 175,
  realEstate: 105,
  aiSaaS: 72,
};

// Beginning Balance Sheet FY2019 (opening for FY2020 computation)
export const SEED_BALANCE_SHEET = {
  cash: 45,
  ar: 65,
  inventory: 30,
  prepaid: 12,
  ppEGross: 280,
  accDepreciation: -85,
  intangibles: 40,
  goodwill: 120,
  otherAssets: 25,
  ap: 38,
  accruedLiab: 28,
  deferredRevenue: 15,
  shortTermDebt: 80,
  longTermDebt: 320,
  leaseLiability: 35,
  commonStock: 10,
  apic: 180,
  retainedEarnings: 26,
  accumulatedOci: 0,
};

// Working capital day assumptions (simplified)
const AR_DAYS = 45;
const INVENTORY_DAYS = 60;
const AP_DAYS = 50;
const ACCRUED_DAYS = 35;
const DEFREV_DAYS = 25;

// ============ HELPER: compute revenue per segment per year ============
function computeRevenue(seed: number, growthRates: number[]): number[] {
  const out: number[] = [];
  let prev = seed;
  for (let i = 0; i < growthRates.length; i++) {
    const rev = i === 0 ? seed : prev * (1 + growthRates[i]);
    out.push(Math.round(rev * 100) / 100);
    prev = rev;
  }
  return out;
}

// ============ COMPUTE THE 3-STATEMENT MODEL ============
function computeModel() {
  const lendingRev = computeRevenue(SEED_REVENUE.lending, ASSUMPTIONS[0].values);
  const constructionRev = computeRevenue(SEED_REVENUE.construction, ASSUMPTIONS[1].values);
  const realEstateRev = computeRevenue(SEED_REVENUE.realEstate, ASSUMPTIONS[2].values);
  const aiSaaSRev = computeRevenue(SEED_REVENUE.aiSaaS, ASSUMPTIONS[3].values);

  const totalRevenue = lendingRev.map((_, i) =>
    Math.round((lendingRev[i] + constructionRev[i] + realEstateRev[i] + aiSaaSRev[i]) * 100) / 100
  );

  // Assumption accessors
  const directCostPct = ASSUMPTIONS[4].values;
  const smPct = ASSUMPTIONS[5].values;
  const rdPct = ASSUMPTIONS[6].values;
  const gaPct = ASSUMPTIONS[7].values;
  const daPct = ASSUMPTIONS[8].values;
  const debtRate = ASSUMPTIONS[9].values;
  const cashRate = ASSUMPTIONS[10].values;
  const etr = ASSUMPTIONS[11].values;
  const capexPct = ASSUMPTIONS[12].values;
  const payoutPct = ASSUMPTIONS[13].values;

  // INCOME STATEMENT
  const directCosts = totalRevenue.map((r, i) => Math.round(r * directCostPct[i] * 100) / 100);
  const grossProfit = totalRevenue.map((r, i) => Math.round((r - directCosts[i]) * 100) / 100);
  const grossMarginPct = grossProfit.map((gp, i) => Math.round((gp / totalRevenue[i]) * 1000) / 10);

  const sm = totalRevenue.map((r, i) => Math.round(r * smPct[i] * 100) / 100);
  const rd = totalRevenue.map((r, i) => Math.round(r * rdPct[i] * 100) / 100);
  const ga = totalRevenue.map((r, i) => Math.round(r * gaPct[i] * 100) / 100);
  const totalOpEx = sm.map((_, i) => Math.round((sm[i] + rd[i] + ga[i]) * 100) / 100);

  const ebitda = grossProfit.map((gp, i) => Math.round((gp - totalOpEx[i]) * 100) / 100);
  const ebitdaMarginPct = ebitda.map((e, i) => Math.round((e / totalRevenue[i]) * 1000) / 10);

  // PP&E roll-forward (gross): PP&E[t] = PP&E[t-1] + Capex[t]
  // D&A[t] = D&A %[t] × Beginning PP&E Gross[t]
  const ppEGross: number[] = [];
  const accumulatedDepreciation: number[] = [];
  const da: number[] = [];
  let curPpE = SEED_BALANCE_SHEET.ppEGross;
  let curAccDep = -SEED_BALANCE_SHEET.accDepreciation; // store as positive
  for (let i = 0; i < YEARS.length; i++) {
    const begPpE = curPpE;
    const daThisYear = Math.round(begPpE * daPct[i] * 100) / 100;
    da.push(daThisYear);
    const capex = Math.round(totalRevenue[i] * capexPct[i] * 100) / 100;
    curPpE = Math.round((begPpE + capex) * 100) / 100;
    ppEGross.push(curPpE);
    curAccDep = Math.round((curAccDep + daThisYear) * 100) / 100;
    accumulatedDepreciation.push(curAccDep);
  }

  const ebit = ebitda.map((e, i) => Math.round((e - da[i]) * 100) / 100);

  // Debt schedule (simplified — debt stays roughly flat, draws down via FCF)
  const totalDebt: number[] = [];
  let curDebt = SEED_BALANCE_SHEET.shortTermDebt + SEED_BALANCE_SHEET.longTermDebt;
  for (let i = 0; i < YEARS.length; i++) {
    // Simplified: debt reduces proportionally to FCF generation
    const reduction = i === 0 ? 0 : Math.round(ebitda[i] * 0.20 * 100) / 100; // 20% of EBITDA used to pay down debt
    curDebt = Math.round((curDebt - reduction) * 100) / 100;
    totalDebt.push(curDebt);
  }

  // Cash schedule — iterate because interest income depends on avg cash
  // Use simplified: build cash from CF, then interest income from avg cash
  // First pass: estimate cash growth from FCF
  const cashEstimate: number[] = [];
  let curCash = SEED_BALANCE_SHEET.cash;
  const interestExpense: number[] = [];
  const interestIncome: number[] = [];
  const ebt: number[] = [];
  const tax: number[] = [];
  const netIncome: number[] = [];

  for (let i = 0; i < YEARS.length; i++) {
    // Interest expense on avg debt
    const begDebt = i === 0 ? (SEED_BALANCE_SHEET.shortTermDebt + SEED_BALANCE_SHEET.longTermDebt) : totalDebt[i - 1];
    const endDebt = totalDebt[i];
    const avgDebt = (begDebt + endDebt) / 2;
    const intExp = Math.round(avgDebt * debtRate[i] * 100) / 100;
    interestExpense.push(intExp);

    // Interest income on avg cash
    const begCash = curCash;
    const intInc = Math.round(begCash * cashRate[i] * 100) / 100;
    interestIncome.push(intInc);

    const ebtThisYear = Math.round((ebit[i] - intExp + intInc) * 100) / 100;
    ebt.push(ebtThisYear);
    const taxThisYear = Math.round(ebtThisYear * etr[i] * 100) / 100;
    tax.push(taxThisYear);
    const ni = Math.round((ebtThisYear - taxThisYear) * 100) / 100;
    netIncome.push(ni);

    // Cash flow: simplified
    // Working capital changes
    const arBeg = i === 0 ? SEED_BALANCE_SHEET.ar : Math.round(totalRevenue[i - 1] * AR_DAYS / 365 * 100) / 100;
    const arEnd = Math.round(totalRevenue[i] * AR_DAYS / 365 * 100) / 100;
    const deltaAR = arEnd - arBeg;

    const invBeg = i === 0 ? SEED_BALANCE_SHEET.inventory : Math.round(directCosts[i - 1] * INVENTORY_DAYS / 365 * 100) / 100;
    const invEnd = Math.round(directCosts[i] * INVENTORY_DAYS / 365 * 100) / 100;
    const deltaInv = invEnd - invBeg;

    const apBeg = i === 0 ? SEED_BALANCE_SHEET.ap : Math.round(directCosts[i - 1] * AP_DAYS / 365 * 100) / 100;
    const apEnd = Math.round(directCosts[i] * AP_DAYS / 365 * 100) / 100;
    const deltaAP = apEnd - apBeg;

    const accruedBeg = i === 0 ? SEED_BALANCE_SHEET.accruedLiab : Math.round(totalOpEx[i - 1] * ACCRUED_DAYS / 365 * 100) / 100;
    const accruedEnd = Math.round(totalOpEx[i] * ACCRUED_DAYS / 365 * 100) / 100;
    const deltaAccrued = accruedEnd - accruedBeg;

    const defRevBeg = i === 0 ? SEED_BALANCE_SHEET.deferredRevenue : Math.round(totalRevenue[i - 1] * DEFREV_DAYS / 365 * 100) / 100;
    const defRevEnd = Math.round(totalRevenue[i] * DEFREV_DAYS / 365 * 100) / 100;
    const deltaDefRev = defRevEnd - defRevBeg;

    const cfo = Math.round((ni + da[i] - deltaAR - deltaInv + deltaAP + deltaAccrued + deltaDefRev) * 100) / 100;
    const capex = Math.round(totalRevenue[i] * capexPct[i] * 100) / 100;
    const cfi = -capex;
    const dividends = Math.round(ni * payoutPct[i] * 100) / 100;
    const cff = -dividends;
    const netChangeInCash = Math.round((cfo + cfi + cff) * 100) / 100;
    curCash = Math.round((curCash + netChangeInCash) * 100) / 100;
    cashEstimate.push(curCash);
  }

  // ============ INCOME STATEMENT (output) ============
  const incomeStatement = {
    segmentRevenue: {
      lending: lendingRev,
      construction: constructionRev,
      realEstate: realEstateRev,
      aiSaaS: aiSaaSRev,
    },
    totalRevenue,
    directCosts,
    grossProfit,
    grossMarginPct,
    sm, rd, ga, totalOpEx,
    ebitda, ebitdaMarginPct,
    da,
    ebit,
    interestExpense,
    interestIncome,
    ebt,
    tax,
    netIncome,
    netMarginPct: netIncome.map((ni, i) => Math.round((ni / totalRevenue[i]) * 1000) / 10),
  };

  // ============ BALANCE SHEET (output) ============
  const cash = cashEstimate;
  const ar = totalRevenue.map(r => Math.round(r * AR_DAYS / 365 * 100) / 100);
  const inventory = directCosts.map(c => Math.round(c * INVENTORY_DAYS / 365 * 100) / 100);
  const prepaid = YEARS.map((_, i) => Math.round((SEED_BALANCE_SHEET.prepaid + totalRevenue[i] * 0.015) * 100) / 100);
  const totalCurrentAssets = cash.map((c, i) =>
    Math.round((c + ar[i] + inventory[i] + prepaid[i]) * 100) / 100
  );

  const ppENet = ppEGross.map((g, i) => Math.round((g - accumulatedDepreciation[i]) * 100) / 100);
  const intangibles = YEARS.map(() => SEED_BALANCE_SHEET.intangibles);
  const goodwill = YEARS.map(() => SEED_BALANCE_SHEET.goodwill);
  const otherAssets = YEARS.map(() => SEED_BALANCE_SHEET.otherAssets);

  const totalAssets = totalCurrentAssets.map((ca, i) =>
    Math.round((ca + ppENet[i] + intangibles[i] + goodwill[i] + otherAssets[i]) * 100) / 100
  );

  const ap = directCosts.map(c => Math.round(c * AP_DAYS / 365 * 100) / 100);
  const accruedLiab = totalOpEx.map(o => Math.round(o * ACCRUED_DAYS / 365 * 100) / 100);
  const deferredRevenue = totalRevenue.map(r => Math.round(r * DEFREV_DAYS / 365 * 100) / 100);

  // Split debt into short-term (assume 20% of total) and long-term (80%)
  const shortTermDebt = totalDebt.map(d => Math.round(d * 0.20 * 100) / 100);
  const longTermDebt = totalDebt.map(d => Math.round(d * 0.80 * 100) / 100);
  const leaseLiability = YEARS.map(() => SEED_BALANCE_SHEET.leaseLiability);

  const totalLiabilities = shortTermDebt.map((std, i) =>
    Math.round((ap[i] + accruedLiab[i] + deferredRevenue[i] + std + longTermDebt[i] + leaseLiability[i]) * 100) / 100
  );

  const commonStock = YEARS.map(() => SEED_BALANCE_SHEET.commonStock);
  const apic = YEARS.map(() => SEED_BALANCE_SHEET.apic);

  // Retained Earnings roll-forward: RE[t] = RE[t-1] + NI[t] - Dividends[t]
  const retainedEarnings: number[] = [];
  let curRE = SEED_BALANCE_SHEET.retainedEarnings;
  for (let i = 0; i < YEARS.length; i++) {
    const dividends = Math.round(netIncome[i] * payoutPct[i] * 100) / 100;
    curRE = Math.round((curRE + netIncome[i] - dividends) * 100) / 100;
    retainedEarnings.push(curRE);
  }

  const accumulatedOci = YEARS.map(() => SEED_BALANCE_SHEET.accumulatedOci);

  const totalEquity = retainedEarnings.map((re, i) =>
    Math.round((commonStock[i] + apic[i] + re + accumulatedOci[i]) * 100) / 100
  );

  const totalLiabAndEquity = totalLiabilities.map((tl, i) =>
    Math.round((tl + totalEquity[i]) * 100) / 100
  );

  const balanceCheck = totalAssets.map((ta, i) =>
    Math.round((ta - totalLiabAndEquity[i]) * 100) / 100
  );

  const balanceSheet = {
    cash, ar, inventory, prepaid, totalCurrentAssets,
    ppEGross, accumulatedDepreciation, ppENet, intangibles, goodwill, otherAssets,
    totalAssets,
    ap, accruedLiab, deferredRevenue, shortTermDebt, longTermDebt, leaseLiability,
    totalLiabilities,
    commonStock, apic, retainedEarnings, accumulatedOci,
    totalEquity, totalLiabAndEquity, balanceCheck,
  };

  // ============ CASH FLOW STATEMENT (output) ============
  const cfNetIncome = netIncome;
  const cfDA = da;
  const cfIntangibleAmort = YEARS.map(() => 0); // simplified

  const cfDeltaAR = ar.map((a, i) => i === 0
    ? Math.round((a - SEED_BALANCE_SHEET.ar) * 100) / 100
    : Math.round((a - ar[i - 1]) * 100) / 100
  );
  const cfDeltaInv = inventory.map((inv, i) => i === 0
    ? Math.round((inv - SEED_BALANCE_SHEET.inventory) * 100) / 100
    : Math.round((inv - inventory[i - 1]) * 100) / 100
  );
  const cfDeltaAP = ap.map((a, i) => i === 0
    ? Math.round((a - SEED_BALANCE_SHEET.ap) * 100) / 100
    : Math.round((a - ap[i - 1]) * 100) / 100
  );
  const cfDeltaAccrued = accruedLiab.map((a, i) => i === 0
    ? Math.round((a - SEED_BALANCE_SHEET.accruedLiab) * 100) / 100
    : Math.round((a - accruedLiab[i - 1]) * 100) / 100
  );
  const cfDeltaDefRev = deferredRevenue.map((d, i) => i === 0
    ? Math.round((d - SEED_BALANCE_SHEET.deferredRevenue) * 100) / 100
    : Math.round((d - deferredRevenue[i - 1]) * 100) / 100
  );

  const cashFromOps = cfNetIncome.map((ni, i) =>
    Math.round((ni + cfDA[i] + cfIntangibleAmort[i] - cfDeltaAR[i] - cfDeltaInv[i] + cfDeltaAP[i] + cfDeltaAccrued[i] + cfDeltaDefRev[i]) * 100) / 100
  );

  const capex = totalRevenue.map((r, i) => Math.round(r * capexPct[i] * 100) / 100);
  const cashFromInvesting = capex.map(c => -c);

  const dividendsPaid = netIncome.map((ni, i) => Math.round(ni * payoutPct[i] * 100) / 100);
  const cashFromFinancing = dividendsPaid.map(d => -d);

  const netChangeInCash = cashFromOps.map((cfo, i) =>
    Math.round((cfo + cashFromInvesting[i] + cashFromFinancing[i]) * 100) / 100
  );

  const beginningCash = cash.map((c, i) => i === 0 ? SEED_BALANCE_SHEET.cash : cash[i - 1]);
  const endingCash = cash;

  const cashFlow = {
    netIncome: cfNetIncome,
    da: cfDA,
    intangibleAmort: cfIntangibleAmort,
    deltaAR: cfDeltaAR,
    deltaInv: cfDeltaInv,
    deltaAP: cfDeltaAP,
    deltaAccrued: cfDeltaAccrued,
    deltaDefRev: cfDeltaDefRev,
    cashFromOps,
    capex,
    cashFromInvesting,
    dividendsPaid,
    cashFromFinancing,
    netChangeInCash,
    beginningCash,
    endingCash,
  };

  // ============ SUMMARY KPIs ============
  const revenueGrowthPct = totalRevenue.map((r, i) =>
    i === 0 ? 0 : Math.round(((r / totalRevenue[i - 1]) - 1) * 1000) / 10
  );
  const roe = netIncome.map((ni, i) =>
    Math.round((ni / totalEquity[i]) * 1000) / 10
  );
  const roa = netIncome.map((ni, i) =>
    Math.round((ni / totalAssets[i]) * 1000) / 10
  );
  const debtToEbitda = totalDebt.map((d, i) =>
    Math.round((d / ebitda[i]) * 100) / 100
  );
  const interestCoverage = ebitda.map((e, i) =>
    Math.round((e / interestExpense[i]) * 100) / 100
  );
  const currentRatio = totalCurrentAssets.map((ca, i) =>
    Math.round((ca / (ap[i] + accruedLiab[i] + deferredRevenue[i] + shortTermDebt[i])) * 100) / 100
  );
  const workingCapital = totalCurrentAssets.map((ca, i) =>
    Math.round((ca - (ap[i] + accruedLiab[i] + deferredRevenue[i] + shortTermDebt[i])) * 100) / 100
  );
  const freeCashFlow = cashFromOps.map((cfo, i) =>
    Math.round((cfo - capex[i]) * 100) / 100
  );

  const kpis = {
    revenueGrowthPct,
    ebitdaMarginPct,
    netMarginPct: incomeStatement.netMarginPct,
    roe,
    roa,
    debtToEbitda,
    interestCoverage,
    currentRatio,
    workingCapital,
    freeCashFlow,
  };

  return {
    incomeStatement,
    balanceSheet,
    cashFlow,
    kpis,
    assumptions: ASSUMPTIONS,
    seedRevenue: SEED_REVENUE,
    seedBalanceSheet: SEED_BALANCE_SHEET,
    years: YEARS,
    formulas: {
      revenueLinkage: "Revenue[t] = Revenue[t-1] × (1 + Growth[t])",
      directCosts: "Direct Costs[t] = Direct Cost %[t] × Total Revenue[t]",
      grossProfit: "Gross Profit[t] = Total Revenue[t] − Direct Costs[t]",
      smRdGa: "S&M/R&D/G&A[t] = respective % × Total Revenue[t]",
      ebitda: "EBITDA[t] = Gross Profit[t] − Total OpEx[t]",
      da: "D&A[t] = D&A %[t] × Beginning PP&E Gross[t]",
      ebit: "EBIT[t] = EBITDA[t] − D&A[t]",
      interestExpense: "Interest Expense[t] = Avg Debt Rate[t] × Avg Debt[t]",
      interestIncome: "Interest Income[t] = Cash Rate[t] × Avg Cash[t]",
      ebt: "EBT[t] = EBIT[t] − Interest Expense[t] + Interest Income[t]",
      tax: "Tax[t] = Effective Tax Rate[t] × EBT[t]",
      netIncome: "Net Income[t] = EBT[t] − Tax[t]",
      ppEGross: "PP&E Gross[t] = PP&E Gross[t-1] + Capex[t]",
      accDep: "Accumulated Depreciation[t] = AccDep[t-1] + D&A[t]",
      ppENet: "PP&E Net[t] = PP&E Gross[t] − Accumulated Depreciation[t]",
      retainedEarnings: "Retained Earnings[t] = RE[t-1] + Net Income[t] − Dividends[t]",
      dividends: "Dividends[t] = Dividend Payout %[t] × Net Income[t]",
      balanceCheck: "Balance Check = Total Assets − (Total Liabilities + Total Equity) = 0",
      cashFlowOps: "CFO = NI + D&A + Intangible Amort − ΔAR − ΔInv + ΔAP + ΔAccrued + ΔDeferred Rev",
      cashFlowInvesting: "CFI = −Capex[t]",
      cashFlowFinancing: "CFF = −Dividends[t]",
      netChangeCash: "Net Change in Cash = CFO + CFI + CFF",
      endingCash: "Ending Cash = Beginning Cash + Net Change in Cash",
      debtToEbitda: "Debt / EBITDA = Total Debt[t] ÷ EBITDA[t]",
      interestCoverage: "Interest Coverage = EBITDA[t] ÷ Interest Expense[t]",
      currentRatio: "Current Ratio = Current Assets ÷ Current Liabilities",
      freeCashFlow: "FCF = CFO − Capex",
      roe: "ROE = Net Income ÷ Total Equity",
      roa: "ROA = Net Income ÷ Total Assets",
    },
  };
}

export const THREE_STATEMENT_MODEL = computeModel();

export const MODEL_META = {
  entity: "Meridian Capital Holdings",
  structure: "Multi-entity holding company (US Inc + UK Ltd + Partners LP)",
  fy23Revenue: "$850M (FY23A)",
  methodology: "Driver-based — all projections driven by blue input cells in Assumptions block",
  disclaimer: "Balance Check row should always read zero — formula: Assets − Liabilities − Equity. Modify any growth/margin/rate input to see downstream impact.",
  lastRefreshed: "November 2026",
};
