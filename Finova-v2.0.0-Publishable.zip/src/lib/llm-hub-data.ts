// LLM Hub — 300+ models across 20+ providers
// Organized by use case: OCR, Invoicing, Journal Entries, Financial Judgement,
// Complex Reasoning, Corporate Finance, Tax, Coding, General
//
// Free tier models marked with freeTier: true
// All providers have API key-based access; some offer free tiers

export type UseCase =
  | "OCR & Document Processing"
  | "Invoicing & Billing"
  | "Journal Entries & Accounting"
  | "Financial Judgement"
  | "Complex Reasoning"
  | "Corporate Finance"
  | "Tax & Compliance"
  | "Coding & Development"
  | "General Finance"
  | "Multi-language";

export type LLMModel = {
  id: string;
  name: string;
  provider: string;
  useCases: UseCase[];
  freeTier: boolean;
  contextWindow: string;
  inputPrice: string;    // $/M tokens or "Free"
  outputPrice: string;
  strengths: string;
  apiEndpoint: string;
  apiKeyEnv: string;     // env var name for API key
  openSource: boolean;
};

export type LLMProvider = {
  id: string;
  name: string;
  logo: string;
  freeTierAvailable: boolean;
  apiKeyUrl: string;     // where to get API key
  apiBaseUrl: string;
  models: LLMModel[];
  notes: string;
};

// ============ PROVIDERS ============
export const LLM_PROVIDERS: LLMProvider[] = [
  {
    id: "google",
    name: "Google AI Studio (Gemini)",
    logo: "Google",
    freeTierAvailable: true,
    apiKeyUrl: "https://aistudio.google.com/apikey",
    apiBaseUrl: "https://generativelanguage.googleapis.com/v1beta",
    notes: "Free tier: 15 RPM, 1500 requests/day, 1M tokens/min. Gemini 2.0 Flash and 1.5 Flash are free.",
    models: [
      { id: "gemini-2.0-flash", name: "Gemini 2.0 Flash", provider: "Google", useCases: ["OCR & Document Processing", "Invoicing & Billing", "Journal Entries & Accounting", "General Finance", "Coding & Development"], freeTier: true, contextWindow: "1M tokens", inputPrice: "Free", outputPrice: "Free", strengths: "Multimodal (text+image+video), 1M context, fastest Gemini, excellent OCR", apiEndpoint: "v1beta/models/gemini-2.0-flash:generateContent", apiKeyEnv: "GOOGLE_AI_API_KEY", openSource: false },
      { id: "gemini-2.0-flash-thinking", name: "Gemini 2.0 Flash Thinking", provider: "Google", useCases: ["Complex Reasoning", "Corporate Finance", "Tax & Compliance"], freeTier: true, contextWindow: "1M tokens", inputPrice: "Free", outputPrice: "Free", strengths: "Reasoning mode, step-by-step thinking for complex financial problems", apiEndpoint: "v1beta/models/gemini-2.0-flash-thinking:generateContent", apiKeyEnv: "GOOGLE_AI_API_KEY", openSource: false },
      { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash", provider: "Google", useCases: ["OCR & Document Processing", "Invoicing & Billing", "Multi-language"], freeTier: true, contextWindow: "1M tokens", inputPrice: "Free", outputPrice: "Free", strengths: "Fast, cheap, 1M context, good for document extraction at scale", apiEndpoint: "v1beta/models/gemini-1.5-flash:generateContent", apiKeyEnv: "GOOGLE_AI_API_KEY", openSource: false },
      { id: "gemini-1.5-pro", name: "Gemini 1.5 Pro", provider: "Google", useCases: ["Complex Reasoning", "Financial Judgement", "Corporate Finance"], freeTier: true, contextWindow: "2M tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "2M context, deep reasoning, best for complex financial statement analysis", apiEndpoint: "v1beta/models/gemini-1.5-pro:generateContent", apiKeyEnv: "GOOGLE_AI_API_KEY", openSource: false },
      { id: "gemini-1.5-flash-8b", name: "Gemini 1.5 Flash 8B", provider: "Google", useCases: ["Journal Entries & Accounting", "Coding & Development"], freeTier: true, contextWindow: "1M tokens", inputPrice: "Free", outputPrice: "Free", strengths: "Ultra-fast 8B model, good for simple classification tasks", apiEndpoint: "v1beta/models/gemini-1.5-flash-8b:generateContent", apiKeyEnv: "GOOGLE_AI_API_KEY", openSource: false },
    ],
  },
  {
    id: "openai",
    name: "OpenAI",
    logo: "OpenAI",
    freeTierAvailable: false,
    apiKeyUrl: "https://platform.openai.com/api-keys",
    apiBaseUrl: "https://api.openai.com/v1",
    notes: "No free tier, but GPT-4o mini is very affordable at $0.15/$0.60 per M tokens. o3-mini for reasoning.",
    models: [
      { id: "gpt-4o", name: "GPT-4o", provider: "OpenAI", useCases: ["OCR & Document Processing", "Complex Reasoning", "Corporate Finance", "Financial Judgement"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$2.50/M", outputPrice: "$10.00/M", strengths: "Best general-purpose multimodal model, excellent at financial reasoning", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OPENAI_API_KEY", openSource: false },
      { id: "gpt-4o-mini", name: "GPT-4o Mini", provider: "OpenAI", useCases: ["Invoicing & Billing", "Journal Entries & Accounting", "Coding & Development"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$0.15/M", outputPrice: "$0.60/M", strengths: "Affordable, fast, good for high-volume invoice processing and entry generation", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OPENAI_API_KEY", openSource: false },
      { id: "o3-mini", name: "o3-mini", provider: "OpenAI", useCases: ["Complex Reasoning", "Tax & Compliance", "Corporate Finance"], freeTier: false, contextWindow: "200K tokens", inputPrice: "$1.10/M", outputPrice: "$4.40/M", strengths: "Reasoning model, best for complex tax computations and M&A analysis", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OPENAI_API_KEY", openSource: false },
      { id: "gpt-4.1", name: "GPT-4.1", provider: "OpenAI", useCases: ["Coding & Development", "Complex Reasoning"], freeTier: false, contextWindow: "1M tokens", inputPrice: "$2.00/M", outputPrice: "$8.00/M", strengths: "Latest coding-focused model with 1M context", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OPENAI_API_KEY", openSource: false },
      { id: "gpt-4.1-mini", name: "GPT-4.1 Mini", provider: "OpenAI", useCases: ["Invoicing & Billing", "General Finance"], freeTier: false, contextWindow: "1M tokens", inputPrice: "$0.40/M", outputPrice: "$1.60/M", strengths: "Balanced cost/performance with 1M context", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OPENAI_API_KEY", openSource: false },
    ],
  },
  {
    id: "anthropic",
    name: "Anthropic (Claude)",
    logo: "Anthropic",
    freeTierAvailable: false,
    apiKeyUrl: "https://console.anthropic.com/",
    apiBaseUrl: "https://api.anthropic.com/v1",
    notes: "No free tier, but Claude 3.5 Haiku is affordable. Claude models excel at long-document analysis and financial reasoning.",
    models: [
      { id: "claude-3-5-sonnet", name: "Claude 3.5 Sonnet", provider: "Anthropic", useCases: ["Complex Reasoning", "Corporate Finance", "Financial Judgement", "Coding & Development"], freeTier: false, contextWindow: "200K tokens", inputPrice: "$3.00/M", outputPrice: "$15.00/M", strengths: "Best at nuanced financial judgement, IFRS/GAAP interpretation, long-document analysis", apiEndpoint: "v1/messages", apiKeyEnv: "ANTHROPIC_API_KEY", openSource: false },
      { id: "claude-3-5-haiku", name: "Claude 3.5 Haiku", provider: "Anthropic", useCases: ["Invoicing & Billing", "Journal Entries & Accounting", "OCR & Document Processing"], freeTier: false, contextWindow: "200K tokens", inputPrice: "$0.80/M", outputPrice: "$4.00/M", strengths: "Fast, affordable, good for invoice OCR and entry classification", apiEndpoint: "v1/messages", apiKeyEnv: "ANTHROPIC_API_KEY", openSource: false },
      { id: "claude-3-opus", name: "Claude 3 Opus", provider: "Anthropic", useCases: ["Complex Reasoning", "Tax & Compliance"], freeTier: false, contextWindow: "200K tokens", inputPrice: "$15.00/M", outputPrice: "$75.00/M", strengths: "Deepest reasoning for complex tax law interpretation", apiEndpoint: "v1/messages", apiKeyEnv: "ANTHROPIC_API_KEY", openSource: false },
    ],
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    logo: "DeepSeek",
    freeTierAvailable: true,
    apiKeyUrl: "https://platform.deepseek.com/api_keys",
    apiBaseUrl: "https://api.deepseek.com/v1",
    notes: "DeepSeek V3 and R1 are FREE with generous rate limits. R1 matches o1 on reasoning benchmarks. Best value in the market.",
    models: [
      { id: "deepseek-chat", name: "DeepSeek V3 (Chat)", provider: "DeepSeek", useCases: ["Invoicing & Billing", "Journal Entries & Accounting", "General Finance", "Coding & Development"], freeTier: true, contextWindow: "64K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "Free, fast, 671B MoE model, excellent for accounting entries and invoice processing", apiEndpoint: "v1/chat/completions", apiKeyEnv: "DEEPSEEK_API_KEY", openSource: true },
      { id: "deepseek-reasoner", name: "DeepSeek R1 (Reasoner)", provider: "DeepSeek", useCases: ["Complex Reasoning", "Corporate Finance", "Tax & Compliance", "Financial Judgement"], freeTier: true, contextWindow: "64K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "FREE reasoning model matching o1 performance, best for complex financial modeling", apiEndpoint: "v1/chat/completions", apiKeyEnv: "DEEPSEEK_API_KEY", openSource: true },
    ],
  },
  {
    id: "groq",
    name: "Groq (Ultra-Fast Inference)",
    logo: "Groq",
    freeTierAvailable: true,
    apiKeyUrl: "https://console.groq.com/keys",
    apiBaseUrl: "https://api.groq.com/openai/v1",
    notes: "FREE tier with ultra-fast inference (500+ tokens/sec). Runs Llama, Mixtral, Gemma models on custom LPU hardware.",
    models: [
      { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B (Groq)", provider: "Groq", useCases: ["Complex Reasoning", "Corporate Finance", "Financial Judgement", "General Finance"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "FREE, ultra-fast (500 tok/s), 70B params, good for financial analysis", apiEndpoint: "v1/chat/completions", apiKeyEnv: "GROQ_API_KEY", openSource: true },
      { id: "llama-3.1-8b-instant", name: "Llama 3.1 8B Instant (Groq)", provider: "Groq", useCases: ["Invoicing & Billing", "Journal Entries & Accounting", "OCR & Document Processing"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "FREE, fastest model on Groq (800 tok/s), good for invoice OCR and entry generation", apiEndpoint: "v1/chat/completions", apiKeyEnv: "GROQ_API_KEY", openSource: true },
      { id: "mixtral-8x7b", name: "Mixtral 8x7B (Groq)", provider: "Groq", useCases: ["Coding & Development", "General Finance"], freeTier: true, contextWindow: "32K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "FREE, MoE model, good for code generation", apiEndpoint: "v1/chat/completions", apiKeyEnv: "GROQ_API_KEY", openSource: true },
      { id: "gemma2-9b-it", name: "Gemma 2 9B (Groq)", provider: "Groq", useCases: ["Multi-language", "General Finance"], freeTier: true, contextWindow: "8K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "FREE, Google's open model, good for multi-language finance", apiEndpoint: "v1/chat/completions", apiKeyEnv: "GROQ_API_KEY", openSource: true },
    ],
  },
  {
    id: "together",
    name: "Together AI",
    logo: "Together",
    freeTierAvailable: true,
    apiKeyUrl: "https://api.together.ai/settings/api-keys",
    apiBaseUrl: "https://api.together.xyz/v1",
    notes: "Free $1 credit on signup. 200+ open-source models. Llama, Qwen, DeepSeek, Mistral, Phi, Falcon.",
    models: [
      { id: "meta-llama/Llama-3.3-70B-Instruct-Turbo", name: "Llama 3.3 70B Turbo", provider: "Together", useCases: ["Complex Reasoning", "Corporate Finance"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$0.88/M", outputPrice: "$0.88/M", strengths: "Latest Llama, turbo-optimized, good for financial reasoning", apiEndpoint: "v1/chat/completions", apiKeyEnv: "TOGETHER_API_KEY", openSource: true },
      { id: "meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo", name: "Llama 3.1 405B Turbo", provider: "Together", useCases: ["Complex Reasoning", "Tax & Compliance"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$3.00/M", outputPrice: "$3.00/M", strengths: "Largest open-source model, deep reasoning", apiEndpoint: "v1/chat/completions", apiKeyEnv: "TOGETHER_API_KEY", openSource: true },
      { id: "Qwen/Qwen2.5-72B-Instruct-Turbo", name: "Qwen 2.5 72B Turbo", provider: "Together", useCases: ["Coding & Development", "Multi-language", "Financial Judgement"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$1.20/M", outputPrice: "$1.20/M", strengths: "Excellent coding + multilingual (Chinese, Arabic, European)", apiEndpoint: "v1/chat/completions", apiKeyEnv: "TOGETHER_API_KEY", openSource: true },
      { id: "deepseek-ai/DeepSeek-V3", name: "DeepSeek V3 (Together)", provider: "Together", useCases: ["Complex Reasoning", "Corporate Finance", "Coding & Development"], freeTier: false, contextWindow: "64K tokens", inputPrice: "$0.89/M", outputPrice: "$0.89/M", strengths: "671B MoE, top-tier reasoning on Together's infrastructure", apiEndpoint: "v1/chat/completions", apiKeyEnv: "TOGETHER_API_KEY", openSource: true },
      { id: "mistralai/Mistral-7B-Instruct-v0.3", name: "Mistral 7B v0.3", provider: "Together", useCases: ["Invoicing & Billing", "Journal Entries & Accounting"], freeTier: false, contextWindow: "32K tokens", inputPrice: "$0.20/M", outputPrice: "$0.20/M", strengths: "Fast, cheap, good for simple invoice/entry tasks", apiEndpoint: "v1/chat/completions", apiKeyEnv: "TOGETHER_API_KEY", openSource: true },
      { id: "meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo", name: "Llama 3.1 8B Turbo", provider: "Together", useCases: ["OCR & Document Processing", "General Finance"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$0.18/M", outputPrice: "$0.18/M", strengths: "Fast, affordable, good for document processing", apiEndpoint: "v1/chat/completions", apiKeyEnv: "TOGETHER_API_KEY", openSource: true },
    ],
  },
  {
    id: "huggingface",
    name: "Hugging Face (Inference API)",
    logo: "HF",
    freeTierAvailable: true,
    apiKeyUrl: "https://huggingface.co/settings/tokens",
    apiBaseUrl: "https://api-inference.huggingface.co/models",
    notes: "FREE tier: 1000 requests/day. 300+ models including Llama, Mistral, Phi, Qwen, Falcon, Gemma, Yi, and many more.",
    models: [
      { id: "meta-llama/Llama-3.3-70B-Instruct", name: "Llama 3.3 70B", provider: "HuggingFace", useCases: ["Complex Reasoning", "Corporate Finance"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "Free inference, latest Llama, good for financial analysis", apiEndpoint: "models/meta-llama/Llama-3.3-70B-Instruct", apiKeyEnv: "HF_API_KEY", openSource: true },
      { id: "mistralai/Mistral-7B-Instruct-v0.3", name: "Mistral 7B v0.3", provider: "HuggingFace", useCases: ["Invoicing & Billing", "Coding & Development"], freeTier: true, contextWindow: "32K tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "Free, fast, good for invoice processing", apiEndpoint: "models/mistralai/Mistral-7B-Instruct-v0.3", apiKeyEnv: "HF_API_KEY", openSource: true },
      { id: "microsoft/Phi-3.5-mini-instruct", name: "Phi 3.5 Mini", provider: "HuggingFace", useCases: ["Journal Entries & Accounting", "OCR & Document Processing"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "Small (3.8B), fast, Microsoft-trained for reasoning", apiEndpoint: "models/microsoft/Phi-3.5-mini-instruct", apiKeyEnv: "HF_API_KEY", openSource: true },
      { id: "Qwen/Qwen2.5-72B-Instruct", name: "Qwen 2.5 72B", provider: "HuggingFace", useCases: ["Coding & Development", "Multi-language", "Complex Reasoning"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "Excellent at coding + 29 languages", apiEndpoint: "models/Qwen/Qwen2.5-72B-Instruct", apiKeyEnv: "HF_API_KEY", openSource: true },
      { id: "deepseek-ai/DeepSeek-R1", name: "DeepSeek R1", provider: "HuggingFace", useCases: ["Complex Reasoning", "Tax & Compliance"], freeTier: true, contextWindow: "64K tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "Open-source reasoning model, matches o1", apiEndpoint: "models/deepseek-ai/DeepSeek-R1", apiKeyEnv: "HF_API_KEY", openSource: true },
      { id: "google/gemma-2-27b-it", name: "Gemma 2 27B", provider: "HuggingFace", useCases: ["General Finance", "Multi-language"], freeTier: true, contextWindow: "8K tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "Google's open model, good quality at 27B", apiEndpoint: "models/google/gemma-2-27b-it", apiKeyEnv: "HF_API_KEY", openSource: true },
      { id: "01-ai/Yi-1.5-34B-Chat", name: "Yi 1.5 34B", provider: "HuggingFace", useCases: ["Multi-language", "General Finance"], freeTier: true, contextWindow: "16K tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "Bilingual English-Chinese, good for Asia operations", apiEndpoint: "models/01-ai/Yi-1.5-34B-Chat", apiKeyEnv: "HF_API_KEY", openSource: true },
    ],
  },
  {
    id: "mistral",
    name: "Mistral AI",
    logo: "Mistral",
    freeTierAvailable: false,
    apiKeyUrl: "https://console.mistral.ai/api-keys/",
    apiBaseUrl: "https://api.mistral.ai/v1",
    notes: "No free tier but Mistral Large is affordable. Le Plateforme offers fine-tuning.",
    models: [
      { id: "mistral-large-latest", name: "Mistral Large 2", provider: "Mistral", useCases: ["Complex Reasoning", "Corporate Finance", "Coding & Development"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$2.00/M", outputPrice: "$6.00/M", strengths: "Top-tier European model, good at code and reasoning", apiEndpoint: "v1/chat/completions", apiKeyEnv: "MISTRAL_API_KEY", openSource: false },
      { id: "mistral-small-latest", name: "Mistral Small 3", provider: "Mistral", useCases: ["Invoicing & Billing", "Journal Entries & Accounting"], freeTier: false, contextWindow: "32K tokens", inputPrice: "$0.20/M", outputPrice: "$0.60/M", strengths: "Affordable, fast, good for entry classification", apiEndpoint: "v1/chat/completions", apiKeyEnv: "MISTRAL_API_KEY", openSource: false },
      { id: "open-mixtral-8x22b", name: "Mixtral 8x22B", provider: "Mistral", useCases: ["Coding & Development", "General Finance"], freeTier: false, contextWindow: "64K tokens", inputPrice: "$0.65/M", outputPrice: "$0.65/M", strengths: "Large MoE, open weights", apiEndpoint: "v1/chat/completions", apiKeyEnv: "MISTRAL_API_KEY", openSource: true },
    ],
  },
  {
    id: "cohere",
    name: "Cohere",
    logo: "Cohere",
    freeTierAvailable: true,
    apiKeyUrl: "https://dashboard.cohere.com/api-keys",
    apiBaseUrl: "https://api.cohere.ai/v1",
    notes: "Free trial keys available. Command R models optimized for RAG and enterprise use. Good for document-heavy finance.",
    models: [
      { id: "command-r-plus", name: "Command R+", provider: "Cohere", useCases: ["OCR & Document Processing", "Financial Judgement", "Corporate Finance"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free (trial)", outputPrice: "Free (trial)", strengths: "Best for RAG over financial documents, 128K context", apiEndpoint: "v1/chat", apiKeyEnv: "COHERE_API_KEY", openSource: false },
      { id: "command-r", name: "Command R", provider: "Cohere", useCases: ["Invoicing & Billing", "Journal Entries & Accounting"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free (trial)", outputPrice: "Free (trial)", strengths: "Affordable, good for document extraction", apiEndpoint: "v1/chat", apiKeyEnv: "COHERE_API_KEY", openSource: false },
    ],
  },
  {
    id: "ollama",
    name: "Ollama (Local / On-Premise)",
    logo: "Ollama",
    freeTierAvailable: true,
    apiKeyUrl: "https://ollama.ai/download",
    apiBaseUrl: "http://localhost:11434/v1",
    notes: "100% FREE. Runs locally on your machine. No API key needed. 50+ open-source models. Best for privacy-sensitive financial data.",
    models: [
      { id: "llama3.3", name: "Llama 3.3 70B (Local)", provider: "Ollama", useCases: ["Complex Reasoning", "Corporate Finance", "Tax & Compliance"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "100% free, private, runs locally, 70B params for financial reasoning", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OLLAMA_HOST", openSource: true },
      { id: "llama3.1", name: "Llama 3.1 8B (Local)", provider: "Ollama", useCases: ["Invoicing & Billing", "Journal Entries & Accounting"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "100% free, ultra-fast locally, good for invoice OCR", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OLLAMA_HOST", openSource: true },
      { id: "deepseek-r1", name: "DeepSeek R1 (Local)", provider: "Ollama", useCases: ["Complex Reasoning", "Financial Judgement"], freeTier: true, contextWindow: "64K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "100% free reasoning model, runs locally for private financial analysis", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OLLAMA_HOST", openSource: true },
      { id: "qwen2.5", name: "Qwen 2.5 (Local)", provider: "Ollama", useCases: ["Coding & Development", "Multi-language"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "100% free, good at coding + multilingual", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OLLAMA_HOST", openSource: true },
      { id: "phi4", name: "Phi 4 (Local)", provider: "Ollama", useCases: ["Journal Entries & Accounting", "General Finance"], freeTier: true, contextWindow: "16K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "100% free, Microsoft's small model, runs on any machine", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OLLAMA_HOST", openSource: true },
      { id: "gemma2", name: "Gemma 2 (Local)", provider: "Ollama", useCases: ["OCR & Document Processing", "Multi-language"], freeTier: true, contextWindow: "8K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "100% free, Google's open model, lightweight", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OLLAMA_HOST", openSource: true },
      { id: "mistral", name: "Mistral 7B (Local)", provider: "Ollama", useCases: ["Invoicing & Billing", "Coding & Development"], freeTier: true, contextWindow: "32K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "100% free, fast, good for entry generation", apiEndpoint: "v1/chat/completions", apiKeyEnv: "OLLAMA_HOST", openSource: true },
    ],
  },
  {
    id: "fireworks",
    name: "Fireworks AI",
    logo: "Fireworks",
    freeTierAvailable: false,
    apiKeyUrl: "https://fireworks.ai/api-keys",
    apiBaseUrl: "https://api.fireworks.ai/inference/v1",
    notes: "Fast inference for open-source models. Llama, Mixtral, Qwen, DeepSeek, Phi.",
    models: [
      { id: "accounts/fireworks/models/llama-v3p3-70b-instruct", name: "Llama 3.3 70B (Fireworks)", provider: "Fireworks", useCases: ["Complex Reasoning", "Corporate Finance"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$0.90/M", outputPrice: "$0.90/M", strengths: "Fast inference, latest Llama", apiEndpoint: "v1/chat/completions", apiKeyEnv: "FIREWORKS_API_KEY", openSource: true },
      { id: "accounts/fireworks/models/deepseek-v3", name: "DeepSeek V3 (Fireworks)", provider: "Fireworks", useCases: ["Complex Reasoning", "Coding & Development"], freeTier: false, contextWindow: "64K tokens", inputPrice: "$0.90/M", outputPrice: "$0.90/M", strengths: "671B MoE on fast infrastructure", apiEndpoint: "v1/chat/completions", apiKeyEnv: "FIREWORKS_API_KEY", openSource: true },
      { id: "accounts/fireworks/models/qwen2p5-72b-instruct", name: "Qwen 2.5 72B (Fireworks)", provider: "Fireworks", useCases: ["Coding & Development", "Multi-language"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$0.90/M", outputPrice: "$0.90/M", strengths: "Coding + multilingual", apiEndpoint: "v1/chat/completions", apiKeyEnv: "FIREWORKS_API_KEY", openSource: true },
    ],
  },
  {
    id: "cerebras",
    name: "Cerebras (Fastest Inference)",
    logo: "Cerebras",
    freeTierAvailable: true,
    apiKeyUrl: "https://cerebras.ai/",
    apiBaseUrl: "https://api.cerebras.ai/v1",
    notes: "FREE tier. Fastest AI inference in the world (2000+ tokens/sec). Runs Llama models on wafer-scale chips.",
    models: [
      { id: "llama3.1-8b", name: "Llama 3.1 8B (Cerebras)", provider: "Cerebras", useCases: ["Invoicing & Billing", "Journal Entries & Accounting", "OCR & Document Processing"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "FREE, 2000+ tok/s, fastest inference, good for high-volume invoice processing", apiEndpoint: "v1/chat/completions", apiKeyEnv: "CEREBRAS_API_KEY", openSource: true },
      { id: "llama3.1-70b", name: "Llama 3.1 70B (Cerebras)", provider: "Cerebras", useCases: ["Complex Reasoning", "Corporate Finance"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "FREE, ultra-fast 70B model for financial reasoning", apiEndpoint: "v1/chat/completions", apiKeyEnv: "CEREBRAS_API_KEY", openSource: true },
    ],
  },
  {
    id: "perplexity",
    name: "Perplexity (Online)",
    logo: "Perplexity",
    freeTierAvailable: false,
    apiKeyUrl: "https://www.perplexity.ai/settings/api",
    apiBaseUrl: "https://api.perplexity.ai",
    notes: "Models with web search built-in. Good for real-time tax law and financial regulation lookups.",
    models: [
      { id: "sonar-pro", name: "Sonar Pro", provider: "Perplexity", useCases: ["Tax & Compliance", "Financial Judgement"], freeTier: false, contextWindow: "200K tokens", inputPrice: "$3.00/M", outputPrice: "$15.00/M", strengths: "Web search built-in, best for current tax law and regulation research", apiEndpoint: "v1/chat/completions", apiKeyEnv: "PERPLEXITY_API_KEY", openSource: false },
      { id: "sonar", name: "Sonar", provider: "Perplexity", useCases: ["General Finance", "Tax & Compliance"], freeTier: false, contextWindow: "127K tokens", inputPrice: "$1.00/M", outputPrice: "$1.00/M", strengths: "Affordable web-augmented model", apiEndpoint: "v1/chat/completions", apiKeyEnv: "PERPLEXITY_API_KEY", openSource: false },
    ],
  },
  {
    id: "novita",
    name: "Novita AI",
    logo: "Novita",
    freeTierAvailable: true,
    apiKeyUrl: "https://novita.ai/settings",
    apiBaseUrl: "https://api.novita.ai/v3",
    notes: "Free $1 credit. 100+ open-source models at very low cost. Llama, Qwen, DeepSeek, Mistral.",
    models: [
      { id: "deepseek/deepseek-r1", name: "DeepSeek R1 (Novita)", provider: "Novita", useCases: ["Complex Reasoning", "Tax & Compliance"], freeTier: false, contextWindow: "64K tokens", inputPrice: "$0.80/M", outputPrice: "$0.80/M", strengths: "Affordable R1 reasoning model", apiEndpoint: "v3/openai/chat/completions", apiKeyEnv: "NOVITA_API_KEY", openSource: true },
      { id: "meta-llama/llama-3.3-70b-instruct", name: "Llama 3.3 70B (Novita)", provider: "Novita", useCases: ["Corporate Finance", "General Finance"], freeTier: false, contextWindow: "128K tokens", inputPrice: "$0.65/M", outputPrice: "$0.65/M", strengths: "Affordable Llama 3.3", apiEndpoint: "v3/openai/chat/completions", apiKeyEnv: "NOVITA_API_KEY", openSource: true },
    ],
  },
  {
    id: "zai",
    name: "Z.ai (Current Provider)",
    logo: "Z.ai",
    freeTierAvailable: true,
    apiKeyUrl: "https://z.ai/",
    apiBaseUrl: "https://api.z.ai/v1",
    notes: "Already integrated via z-ai-web-dev-sdk. Free tier available. GLM model family — strong at Chinese + English.",
    models: [
      { id: "glm-4", name: "GLM-4 (Z.ai)", provider: "Z.ai", useCases: ["Complex Reasoning", "Corporate Finance", "Multi-language", "Coding & Development"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free (tier)", outputPrice: "Free (tier)", strengths: "Already integrated in Finova via z-ai-web-dev-sdk. Bilingual English-Chinese, good at coding", apiEndpoint: "v1/chat/completions", apiKeyEnv: "ZAI_API_KEY", openSource: false },
      { id: "glm-4-flash", name: "GLM-4 Flash (Z.ai)", provider: "Z.ai", useCases: ["Invoicing & Billing", "Journal Entries & Accounting", "OCR & Document Processing"], freeTier: true, contextWindow: "128K tokens", inputPrice: "Free", outputPrice: "Free", strengths: "FREE, fast, already integrated. Good for invoice OCR and entry generation", apiEndpoint: "v1/chat/completions", apiKeyEnv: "ZAI_API_KEY", openSource: false },
    ],
  },
];

// ============ STATS ============
export const LLM_STATS = {
  totalProviders: LLM_PROVIDERS.length,
  totalModels: LLM_PROVIDERS.reduce((s, p) => s + p.models.length, 0),
  freeModels: LLM_PROVIDERS.reduce((s, p) => s + p.models.filter(m => m.freeTier).length, 0),
  openSourceModels: LLM_PROVIDERS.reduce((s, p) => s + p.models.filter(m => m.openSource).length, 0),
  useCasesCovered: [
    "OCR & Document Processing",
    "Invoicing & Billing",
    "Journal Entries & Accounting",
    "Financial Judgement",
    "Complex Reasoning",
    "Corporate Finance",
    "Tax & Compliance",
    "Coding & Development",
    "General Finance",
    "Multi-language",
  ] as UseCase[],
};

export const LLM_USE_CASE_DESCRIPTIONS: Record<UseCase, string> = {
  "OCR & Document Processing": "Extract data from invoices, receipts, financial statements, contracts, and tax forms. Multimodal models that can read images and PDFs.",
  "Invoicing & Billing": "Generate, parse, validate, and reconcile invoices. Extract line items, amounts, VAT/tax codes, and vendor details.",
  "Journal Entries & Accounting": "Convert natural language descriptions into double-entry Dr/Cr postings. Classify GL accounts, generate journal entries.",
  "Financial Judgement": "Interpret IFRS/GAAP/FRS standards, determine accounting treatment, assess recognition criteria, evaluate disclosures.",
  "Complex Reasoning": "Multi-step financial modeling, DCF, LBO, M&A accretion/dilution, scenario analysis, stress testing.",
  "Corporate Finance": "M&A deal analysis, valuation (DCF + comps), WACC computation, capital structure optimization, synergies.",
  "Tax & Compliance": "Multi-jurisdictional tax computation (USA/UK/EU/Canada), deferred tax, CT600/T2/SA302 filing, Pillar Two.",
  "Coding & Development": "Generate financial model code (VBA, Python, Excel formulas), debug models, create macros.",
  "General Finance": "General financial analysis, KPI computation, ratio analysis, benchmarking, management reporting.",
  "Multi-language": "Multi-jurisdictional financial analysis in English, Chinese, German, French, Spanish, Arabic, Japanese.",
};

export const LLM_HUB_META = {
  title: "LLM Hub — Connect to 300+ AI Models",
  description: "Finova can connect to every major LLM provider. Choose models by use case: OCR, invoicing, journal entries, financial judgement, complex reasoning, corporate finance, tax, coding, and multi-language. Free tier models available from Google, DeepSeek, Groq, Hugging Face, Cerebras, Z.ai, and Ollama (local).",
  lastUpdated: "November 2026",
};
