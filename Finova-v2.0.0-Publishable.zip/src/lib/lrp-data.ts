// 10-Year Long-Range Plan — Meridian Capital Holdings
// FY2025E – FY2034E strategic plan | Segment growth, capex, financing, leverage, ROIC
// Seed from 3-Statement Model FY2024E segment revenues

export const LRP_YEARS = [
  "FY2025E", "FY2026E", "FY2027E", "FY2028E", "FY2029E",
  "FY2030E", "FY2031E", "FY2032E", "FY2033E", "FY2034E",
];

// Seed from 3-statement model FY2024E (year index 4)
const SEED = {
  lending: 252.47,      // FY2024E from 3-stmt model (230 × 1.06 × 1.07 × 1.05 × 1.06)
  construction: 256.57,  // 175 × compounding
  realEstate: 140.37,    // 105 × compounding
  aiSaaS: 197.68,        // 72 × compounding
  totalDebt: 350,        // approximate from 3-stmt
  totalEquity: 510,      // approximate from 3-stmt
};

const ASSUMPTIONS = {
  lendingGrowth:      [0.08, 0.09, 0.08, 0.07, 0.06, 0.05, 0.05, 0.04, 0.04, 0.03],
  constructionGrowth: [0.10, 0.11, 0.10, 0.08, 0.07, 0.06, 0.05, 0.05, 0.04, 0.04],
  realEstateGrowth:   [0.05, 0.05, 0.06, 0.05, 0.05, 0.04, 0.04, 0.04, 0.03, 0.03],
  aiSaaSGrowth:       [0.28, 0.25, 0.22, 0.20, 0.18, 0.15, 0.12, 0.10, 0.08, 0.07],
  directCostPct:      [0.42, 0.42, 0.41, 0.41, 0.40, 0.40, 0.40, 0.39, 0.39, 0.39],
  smPct:              [0.15, 0.14, 0.14, 0.13, 0.13, 0.13, 0.12, 0.12, 0.12, 0.11],
  gaPct:              [0.08, 0.08, 0.08, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07],
  rdPct:              [0.08, 0.08, 0.08, 0.07, 0.07, 0.07, 0.07, 0.06, 0.06, 0.06],
  daPct:              [0.04, 0.04, 0.04, 0.04, 0.04, 0.04, 0.04, 0.04, 0.04, 0.04],
  taxRate:            [0.245, 0.24, 0.235, 0.235, 0.23, 0.23, 0.225, 0.225, 0.22, 0.22],
  capexPct:           [0.06, 0.06, 0.07, 0.07, 0.06, 0.06, 0.05, 0.05, 0.05, 0.04],
  dividendPayout:     [0.22, 0.25, 0.28, 0.30, 0.32, 0.35, 0.38, 0.40, 0.42, 0.45],
};

// Compute projections
function compute() {
  const lendingRev: number[] = [];
  const constructionRev: number[] = [];
  const realEstateRev: number[] = [];
  const aiSaaSRev: number[] = [];
  const totalRevenue: number[] = [];
  const directCosts: number[] = [];
  const grossProfit: number[] = [];
  const sm: number[] = [];
  const rd: number[] = [];
  const ga: number[] = [];
  const totalOpEx: number[] = [];
  const ebitda: number[] = [];
  const da: number[] = [];
  const ebit: number[] = [];
  const interestExpense: number[] = [];
  const totalDebt: number[] = [];
  const ebt: number[] = [];
  const tax: number[] = [];
  const netIncome: number[] = [];
  const fcf: number[] = [];
  const endingEquity: number[] = [];
  const debtToEbitda: number[] = [];
  const roic: number[] = [];
  const cumulativeFCF: number[] = [];
  const capex: number[] = [];
  const nopat: number[] = [];
  const investedCapital: number[] = [];
  const dividends: number[] = [];

  let prevLending = SEED.lending;
  let prevConstruction = SEED.construction;
  let prevRealEstate = SEED.realEstate;
  let prevAiSaaS = SEED.aiSaaS;
  let curDebt = SEED.totalDebt;
  let curEquity = SEED.totalEquity;
  let cumFCF = 0;

  for (let i = 0; i < 10; i++) {
    // Revenue
    const lRev = Math.round(prevLending * (1 + ASSUMPTIONS.lendingGrowth[i]) * 10) / 10;
    const cRev = Math.round(prevConstruction * (1 + ASSUMPTIONS.constructionGrowth[i]) * 10) / 10;
    const rRev = Math.round(prevRealEstate * (1 + ASSUMPTIONS.realEstateGrowth[i]) * 10) / 10;
    const aRev = Math.round(prevAiSaaS * (1 + ASSUMPTIONS.aiSaaSGrowth[i]) * 10) / 10;
    const totRev = Math.round((lRev + cRev + rRev + aRev) * 10) / 10;

    // Costs
    const dc = Math.round(totRev * ASSUMPTIONS.directCostPct[i] * 10) / 10;
    const gp = Math.round((totRev - dc) * 10) / 10;
    const smVal = Math.round(totRev * ASSUMPTIONS.smPct[i] * 10) / 10;
    const rdVal = Math.round(totRev * ASSUMPTIONS.rdPct[i] * 10) / 10;
    const gaVal = Math.round(totRev * ASSUMPTIONS.gaPct[i] * 10) / 10;
    const opEx = Math.round((smVal + rdVal + gaVal) * 10) / 10;

    // EBITDA
    const ebitdaVal = Math.round((gp - opEx) * 10) / 10;
    const daVal = Math.round(totRev * ASSUMPTIONS.daPct[i] * 10) / 10;
    const ebitVal = Math.round((ebitdaVal - daVal) * 10) / 10;

    // Interest & Debt
    const intExp = Math.round(curDebt * 0.055 * 10) / 10; // 5.5% avg rate declining
    const debtPaydown = Math.round(ebitdaVal * 0.15 * 10) / 10; // 15% of EBITDA for debt repayment
    curDebt = Math.round((curDebt - debtPaydown) * 10) / 10;

    // Tax & NI
    const ebtVal = Math.round((ebitVal - intExp) * 10) / 10;
    const taxVal = ebtVal > 0 ? Math.round(ebtVal * ASSUMPTIONS.taxRate[i] * 10) / 10 : 0;
    const niVal = Math.round((ebtVal - taxVal) * 10) / 10;

    // FCF = EBITDA - Tax - Capex
    const capexVal = Math.round(totRev * ASSUMPTIONS.capexPct[i] * 10) / 10;
    const fcfVal = Math.round((ebitdaVal - taxVal - capexVal) * 10) / 10;
    cumFCF = Math.round((cumFCF + fcfVal) * 10) / 10;

    // Equity roll-forward
    const divVal = Math.round(niVal * ASSUMPTIONS.dividendPayout[i] * 10) / 10;
    curEquity = Math.round((curEquity + niVal - divVal) * 10) / 10;

    // ROIC
    const nopatVal = Math.round(ebitVal * (1 - ASSUMPTIONS.taxRate[i]) * 10) / 10;
    const invCap = Math.round((curDebt + curEquity) * 10) / 10;
    const roicVal = invCap > 0 ? Math.round((nopatVal / invCap) * 1000) / 10 : 0;

    // Debt/EBITDA
    const dToE = ebitdaVal > 0 ? Math.round((curDebt / ebitdaVal) * 100) / 100 : 0;

    // Push
    lendingRev.push(lRev); constructionRev.push(cRev); realEstateRev.push(rRev); aiSaaSRev.push(aRev);
    totalRevenue.push(totRev); directCosts.push(dc); grossProfit.push(gp);
    sm.push(smVal); rd.push(rdVal); ga.push(gaVal); totalOpEx.push(opEx);
    ebitda.push(ebitdaVal); da.push(daVal); ebit.push(ebitVal);
    interestExpense.push(intExp); totalDebt.push(curDebt);
    ebt.push(ebtVal); tax.push(taxVal); netIncome.push(niVal);
    fcf.push(fcfVal); endingEquity.push(curEquity);
    debtToEbitda.push(dToE); roic.push(roicVal);
    cumulativeFCF.push(cumFCF); capex.push(capexVal);
    nopat.push(nopatVal); investedCapital.push(invCap); dividends.push(divVal);

    prevLending = lRev; prevConstruction = cRev; prevRealEstate = rRev; prevAiSaaS = aRev;
  }

  return {
    lendingRev, constructionRev, realEstateRev, aiSaaSRev, totalRevenue,
    directCosts, grossProfit, sm, rd, ga, totalOpEx, ebitda,
    da, ebit, interestExpense, totalDebt, ebt, tax, netIncome,
    fcf, endingEquity, debtToEbitda, roic, cumulativeFCF, capex, nopat, investedCapital, dividends,
  };
}

export const LRP_PROJECTIONS = compute();

export const LRP_ASSUMPTIONS_TABLE = [
  { driver: "Lending Segment Growth %", values: ASSUMPTIONS.lendingGrowth.map(v => v * 100) },
  { driver: "Construction Segment Growth %", values: ASSUMPTIONS.constructionGrowth.map(v => v * 100) },
  { driver: "Real Estate NOI Growth %", values: ASSUMPTIONS.realEstateGrowth.map(v => v * 100) },
  { driver: "AI SaaS Segment Growth %", values: ASSUMPTIONS.aiSaaSGrowth.map(v => v * 100) },
  { driver: "Direct Cost % of Revenue", values: ASSUMPTIONS.directCostPct.map(v => v * 100) },
  { driver: "S&M % of Revenue", values: ASSUMPTIONS.smPct.map(v => v * 100) },
  { driver: "G&A % of Revenue", values: ASSUMPTIONS.gaPct.map(v => v * 100) },
  { driver: "R&D % of Revenue", values: ASSUMPTIONS.rdPct.map(v => v * 100) },
  { driver: "D&A % of Revenue", values: ASSUMPTIONS.daPct.map(v => v * 100) },
  { driver: "Tax Rate", values: ASSUMPTIONS.taxRate.map(v => v * 100) },
  { driver: "Capex % of Revenue", values: ASSUMPTIONS.capexPct.map(v => v * 100) },
  { driver: "Dividend Payout %", values: ASSUMPTIONS.dividendPayout.map(v => v * 100) },
];

export const LRP_SEED = SEED;

export const LRP_PROJECTION_ROWS = [
  { label: "Lending Segment Revenue", values: LRP_PROJECTIONS.lendingRev, isSegment: true },
  { label: "Construction Segment Revenue", values: LRP_PROJECTIONS.constructionRev, isSegment: true },
  { label: "Real Estate Segment Revenue (NOI)", values: LRP_PROJECTIONS.realEstateRev, isSegment: true },
  { label: "AI SaaS Segment Revenue", values: LRP_PROJECTIONS.aiSaaSRev, isSegment: true },
  { label: "Total Revenue", values: LRP_PROJECTIONS.totalRevenue, isTotal: true },
  { label: "Direct Costs", values: LRP_PROJECTIONS.directCosts },
  { label: "Gross Profit", values: LRP_PROJECTIONS.grossProfit, isTotal: true },
  { label: "S&M", values: LRP_PROJECTIONS.sm },
  { label: "R&D", values: LRP_PROJECTIONS.rd },
  { label: "G&A", values: LRP_PROJECTIONS.ga },
  { label: "Total OpEx", values: LRP_PROJECTIONS.totalOpEx, isTotal: true },
  { label: "EBITDA", values: LRP_PROJECTIONS.ebitda, isTotal: true },
  { label: "D&A", values: LRP_PROJECTIONS.da },
  { label: "EBIT", values: LRP_PROJECTIONS.ebit, isTotal: true },
  { label: "Interest Expense", values: LRP_PROJECTIONS.interestExpense },
  { label: "Total Debt (end of year)", values: LRP_PROJECTIONS.totalDebt },
  { label: "Pre-Tax Income (EBT)", values: LRP_PROJECTIONS.ebt, isTotal: true },
  { label: "Tax Expense", values: LRP_PROJECTIONS.tax },
  { label: "Net Income", values: LRP_PROJECTIONS.netIncome, isTotal: true },
  { label: "Free Cash Flow (EBITDA - Tax - Capex)", values: LRP_PROJECTIONS.fcf, isTotal: true },
  { label: "Ending Total Equity", values: LRP_PROJECTIONS.endingEquity },
  { label: "Debt / EBITDA (x)", values: LRP_PROJECTIONS.debtToEbitda, isRatio: true },
  { label: "ROIC (NOPAT / Invested Capital)", values: LRP_PROJECTIONS.roic, isPct: true },
  { label: "Cumulative FCF ($M)", values: LRP_PROJECTIONS.cumulativeFCF, isTotal: true },
];

export const LRP_STRATEGIC_DECISIONS = [
  { decision: "Debt Repayment Acceleration", triggerYear: "FY2027E", threshold: "Debt/EBITDA < 2.5x", currentTrajectory: "Trajectory: 3.2x → 1.8x by FY2032", action: "If Debt/EBITDA < 2.5x in FY27, evaluate accelerated repayment vs opportunistic M&A" },
  { decision: "Dividend Increase", triggerYear: "FY2028E", threshold: "Payout > 30% & FCF > $80M", currentTrajectory: "Trajectory: payout 22% → 45% by FY34", action: "Board to consider dividend growth policy when payout exceeds 30% with stable FCF" },
  { decision: "M&A Capacity", triggerYear: "FY2029E", threshold: "Cumulative FCF > $250M", currentTrajectory: "Trajectory: $80M → $400M+ by FY34", action: "From FY29, evaluate sizeable acquisitions in adjacent verticals ($50-150M range)" },
  { decision: "Share Buyback", triggerYear: "FY2031E", threshold: "ROIC > WACC + 500bps & no near-term M&A", currentTrajectory: "Trajectory: ROIC ~13% by FY31", action: "Implement buyback program if M&A pipeline thin and ROIC sustains above 15%" },
  { decision: "Capex Reset", triggerYear: "FY2032E", threshold: "Growth capex < 4% of revenue", currentTrajectory: "Trajectory: 6% → 4% by FY34", action: "As growth matures, shift capex mix toward maintenance; redeploy savings to shareholders" },
];

export const LRP_META = {
  title: "10-Year Long-Range Plan — Meridian Capital Holdings",
  subtitle: "FY2025E – FY2034E strategic plan | Segment growth, capex, financing, leverage, ROIC",
  description: "LRP illustrates 10-year strategic trajectory: revenue growth decelerating as segments mature, leverage declining from debt repayment, ROIC stabilizing. Cumulative FCF indicates M&A capacity or capital return headroom.",
  seedNote: "Seed Revenue FY2024E from 3-Statement Model (Corporate Finance → 3-Statement tab)",
  lastUpdated: "November 2026",
  standard: "FP&A Best Practice (IMA) · IAS 1 presentation · ASC 270 interim reporting",
};
