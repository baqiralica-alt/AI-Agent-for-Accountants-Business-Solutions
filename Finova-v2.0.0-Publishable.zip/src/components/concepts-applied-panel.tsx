"use client";

import * as React from "react";
import { BookOpen } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type ConceptApp = {
  id: string;
  report: string;
  location: string;
  conceptNos: number[];
  concepts: string[];
  formula: string;
  standards: string[];
  fictionalData: string;
  verificationStatus: "Applied" | "Computed" | "Disclosed" | "Forecast";
};

type Props = {
  reportName: string;
  /** Optional: also match subreports (e.g., "Corporate Finance" matches "Corporate Finance → 3-Statement") */
  matchSubreports?: boolean;
};

const STATUS_COLORS: Record<string, string> = {
  Applied: "border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10",
  Computed: "border-blue-500/40 text-blue-700 dark:text-blue-300 bg-blue-500/10",
  Disclosed: "border-amber-500/40 text-amber-700 dark:text-amber-300 bg-amber-500/10",
  Forecast: "border-violet-500/40 text-violet-700 dark:text-violet-300 bg-violet-500/10",
};

/**
 * Concepts Applied Panel — shows which glossary concepts, formulas, and standards
 * are applied in a specific report. Renders at the bottom of each major report module.
 */
export function ConceptsAppliedPanel({ reportName, matchSubreports = true }: Props) {
  const [data, setData] = React.useState<{ applications: ConceptApp[] } | null>(null);
  const [filter, setFilter] = React.useState<string>("All");

  React.useEffect(() => {
    fetch("/api/concepts-applied")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch(() => {});
  }, []);

  if (!data) return null;

  const apps = data.applications.filter((a) => {
    if (a.report === reportName) return true;
    if (matchSubreports && a.report.startsWith(reportName)) return true;
    // Also match if reportName is a substring (e.g., "Payroll" matches "Payroll" exactly)
    if (a.report === reportName) return true;
    return false;
  });
  if (apps.length === 0) return null;

  const statuses = ["All", "Applied", "Computed", "Disclosed", "Forecast"];
  const filtered = filter === "All" ? apps : apps.filter((a) => a.verificationStatus === filter);

  return (
    <Card className="border-l-4 border-l-slate-500">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <BookOpen className="size-4 text-slate-600" />
          Concepts Applied — Cross-Reference Matrix
        </CardTitle>
        <CardDescription>
          {apps.length} concept applications in {reportName} · Each computation cites its governing standard (IFRS / US GAAP / UK FRS / EU / Canada) and formula from the Concepts Glossary (115 terms)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Status filter chips */}
        <div className="flex flex-wrap gap-1.5">
          {statuses.map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={cn(
                "rounded-md border px-2 py-0.5 text-[10px] font-medium transition",
                filter === s ? "border-slate-700 bg-slate-700 text-white" : "bg-muted/30 hover:bg-muted/50"
              )}
            >
              {s} ({s === "All" ? apps.length : apps.filter((a) => a.verificationStatus === s).length})
            </button>
          ))}
        </div>

        {/* Applications grid */}
        <div className="grid gap-2 md:grid-cols-2">
          {filtered.map((app) => (
            <div key={app.id} className="rounded-md border p-3 space-y-1.5">
              <div className="flex items-start justify-between gap-2">
                <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">{app.location}</div>
                <Badge variant="outline" className={cn("text-[9px] shrink-0", STATUS_COLORS[app.verificationStatus])}>
                  {app.verificationStatus}
                </Badge>
              </div>
              {app.concepts.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {app.concepts.map((c, i) => (
                    <Badge key={i} variant="outline" className="text-[9px] border-emerald-500/30 text-emerald-700 dark:text-emerald-300">
                      {c}
                    </Badge>
                  ))}
                </div>
              )}
              <div className="text-[10px] text-muted-foreground italic">
                <strong className="text-slate-600 dark:text-slate-400 not-italic">Formula:</strong> {app.formula}
              </div>
              <div className="text-[10px] text-muted-foreground">
                <strong className="text-slate-600 dark:text-slate-400">Standards:</strong> {app.standards.join(" · ")}
              </div>
              <div className="text-[10px] text-muted-foreground bg-slate-500/5 rounded p-1.5">
                <strong className="text-slate-600 dark:text-slate-400">Data:</strong> {app.fictionalData}
              </div>
            </div>
          ))}
        </div>

        {/* Summary footer */}
        <div className="text-[10px] text-muted-foreground italic border-t pt-2">
          Showing {filtered.length} of {apps.length} applications. All {apps.length} computations in {reportName} apply concepts from the Concepts Glossary with cited standards (IFRS · US GAAP · UK FRS 102 · EU IFRS-EU · Canada ASPE/IFRS-Canada) and verified formulas.
        </div>
      </CardContent>
    </Card>
  );
}
