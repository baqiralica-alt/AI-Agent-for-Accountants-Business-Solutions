"use client";

import * as React from "react";
import { BookOpen, RefreshCw, Download, FileSpreadsheet, FileText, Save } from "lucide-react";
import ReactMarkdown from "react-markdown";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";

type Note = {
  id?: string;
  noteNumber: number;
  title: string;
  body: string;
};

export function DisclosuresModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [standard, setStandard] = React.useState("IFRS");
  const [notes, setNotes] = React.useState<Note[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [seeded, setSeeded] = React.useState(false);
  const [editingNote, setEditingNote] = React.useState<Note | null>(null);

  function load() {
    setLoading(true);
    fetch(`/api/disclosures?companyId=${activeCompanyId}&standard=${standard}`)
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setNotes(d.notes); setSeeded(d.seeded); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }
  React.useEffect(() => { load(); }, [activeCompanyId, standard]);

  async function saveNote(note: Note) {
    try {
      const res = await fetch("/api/disclosures", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyId: activeCompanyId, standard, noteNumber: note.noteNumber, title: note.title, body: note.body }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`Note ${note.noteNumber} saved`);
      setEditingNote(null);
      load();
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  async function downloadExcel() {
    const XLSX = await import("xlsx");
    const ws = XLSX.utils.json_to_sheet(notes.map((n) => ({ Note: n.noteNumber, Title: n.title, Body: n.body })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Disclosure Notes");
    XLSX.writeFile(wb, `disclosures_${activeCompanyId}_${standard}.xlsx`);
    toast.success("Excel downloaded");
  }

  function downloadPdf() {
    toast.info("Use the browser print dialog (Ctrl+P) to save this page as PDF");
    window.print();
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Disclosures</h1>
          <p className="text-sm text-muted-foreground">
            Full disclosure notes per <strong>IAS 1</strong> (IFRS) and <strong>FASB ASC</strong> (US GAAP). Includes statement of compliance, accounting policies, revenue, leases, taxes, business combinations, financial instruments, provisions, related parties, subsequent events and segments.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={standard} onValueChange={setStandard}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="IFRS">IFRS — IAS 1</SelectItem>
              <SelectItem value="US-GAAP">US GAAP — FASB ASC</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="size-3.5" /> Refresh</Button>
          <Button variant="outline" size="sm" onClick={downloadExcel}><FileSpreadsheet className="size-3.5" /> Excel</Button>
          <Button size="sm" onClick={downloadPdf}><FileText className="size-3.5" /> PDF</Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base">Disclosure Notes — {standard === "IFRS" ? "IAS 1 Presentation of Financial Statements" : "FASB ASC 235 — Notes to Financial Statements"}</CardTitle>
              <CardDescription>
                {activeCompany?.name} · {notes.length} notes · {seeded ? "saved" : "default templates — click any note to edit and save"}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-96 w-full" />
          ) : (
            <Accordion type="single" collapsible>
              {notes.map((n) => (
                <AccordionItem key={n.noteNumber} value={`note-${n.noteNumber}`}>
                  <AccordionTrigger>
                    <div className="flex items-center gap-3 text-left">
                      <Badge variant="outline" className="text-[10px]">Note {n.noteNumber}</Badge>
                      <span className="text-sm font-medium">{n.title}</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="prose prose-sm dark:prose-invert max-w-none text-sm text-muted-foreground">
                      <ReactMarkdown>{n.body}</ReactMarkdown>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => setEditingNote(n)}><Save className="size-3.5" /> Edit note</Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}
        </CardContent>
      </Card>

      {/* Compliance overview */}
      <Card>
        <CardHeader><CardTitle className="text-base">Compliance Overview</CardTitle><CardDescription>What IAS 1 / US GAAP requires and where Finova covers it</CardDescription></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          {[
            { req: "Statement of compliance", ref: "IAS 1.16", loc: "Reports tab — every report header shows standard" },
            { req: "Basis of preparation", ref: "IAS 1.10-12", loc: "Note 1 (this tab)" },
            { req: "Significant accounting policies", ref: "IAS 1.117-124", loc: "Note 2 (this tab)" },
            { req: "Revenue recognition", ref: "IFRS 15 / ASC 606", loc: "Note 3 (this tab)" },
            { req: "Leases", ref: "IFRS 16 / ASC 842", loc: "Note 4 (this tab)" },
            { req: "Income taxes", ref: "IAS 12 / ASC 740", loc: "Note 5 (this tab) + Tax Center" },
            { req: "Fair value measurements", ref: "IFRS 13 / ASC 820", loc: "Note 5 (US GAAP) / Note 7 (IFRS)" },
            { req: "Business combinations & goodwill", ref: "IFRS 3 / ASC 805 + IAS 36 / ASC 350", loc: "Note 6 (this tab) + Corporate Finance → M&A" },
            { req: "Financial instruments", ref: "IFRS 9 / ASC 825", loc: "Note 7 (this tab)" },
            { req: "Provisions & contingencies", ref: "IAS 37 / ASC 450", loc: "Note 8 (this tab)" },
            { req: "Related party disclosures", ref: "IAS 24 / ASC 850", loc: "Note 9 (this tab)" },
            { req: "Subsequent events", ref: "IAS 10 / ASC 855", loc: "Note 10 (this tab)" },
            { req: "Operating segments", ref: "IFRS 8 / ASC 280", loc: "Note 11 (this tab)" },
            { req: "Critical judgments & estimates", ref: "IAS 1.122-133", loc: "Note 12 (this tab)" },
            { req: "Consolidated statements", ref: "IFRS 10 / ASC 810", loc: "Consolidation tab" },
            { req: "Equity method investments", ref: "IAS 28 / ASC 323", loc: "Disclosure Note (editable)" },
          ].map((c) => (
            <div key={c.req} className="rounded-md border p-3">
              <div className="flex items-center justify-between gap-2">
                <div className="text-sm font-medium">{c.req}</div>
                <Badge variant="outline" className="text-[10px]">{c.ref}</Badge>
              </div>
              <div className="mt-1 text-xs text-muted-foreground">{c.loc}</div>
            </div>
          ))}
        </CardContent>
      </Card>

      <EditNoteDialog note={editingNote} onClose={() => setEditingNote(null)} onSave={saveNote} />
    </div>
  );
}

function EditNoteDialog({ note, onClose, onSave }: { note: Note | null; onClose: () => void; onSave: (n: Note) => void }) {
  const [title, setTitle] = React.useState("");
  const [body, setBody] = React.useState("");
  React.useEffect(() => {
    if (note) { setTitle(note.title); setBody(note.body); }
  }, [note]);
  if (!note) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div className="max-w-2xl w-full rounded-lg bg-background border p-6 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="text-lg font-semibold mb-2">Edit Note {note.noteNumber}</div>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium">Title</label>
            <input className="mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-medium">Body (Markdown supported)</label>
            <Textarea className="mt-1 min-h-[300px] font-mono text-xs" value={body} onChange={(e) => setBody(e.target.value)} />
          </div>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => onSave({ ...note, title, body })}><Save className="size-3.5" /> Save note</Button>
        </div>
      </div>
    </div>
  );
}
