"use client";

import * as React from "react";
import { HelpCircle, Sparkles, Upload, Bot, ReceiptText, Plug, Landmark, FileText, CheckCircle2, AlertTriangle, BookOpen, Zap, Users, ShieldCheck } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/lib/store";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";

export function HelpModule() {
  const setActiveModule = useAppStore((s) => s.setActiveModule);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">How to Use Finova</h1>
        <p className="text-sm text-muted-foreground">
          Plain-English guide — no technical knowledge needed. Finova is your AI accountant, CFO, tax specialist and auditor, all in one.
        </p>
      </div>

      {/* Hero — what is this */}
      <Card className="border-l-4 border-l-emerald-500 bg-emerald-500/5">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Sparkles className="size-6 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <h2 className="text-base font-semibold">Finova is an AI that does accounting work for you</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                You don't need to be an accountant, IT person, or developer. Just talk to it like a colleague. It posts journal entries, prepares invoices, files taxes, generates financial statements, and connects to your bank, Gmail, and accounting software (QuickBooks, Xero, SAP FICO, Oracle) automatically.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage / pricing — limited vs unlimited */}
      <Card>
        <CardHeader>
          <CardTitle>Is it free or paid? What are the limits?</CardTitle>
          <CardDescription>Honest breakdown so you know exactly what you're getting</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-3">
            <div className="rounded-md border p-4">
              <Badge className="mb-2">Free tier</Badge>
              <div className="text-2xl font-bold">$0</div>
              <div className="mt-1 text-xs text-muted-foreground">Forever, no credit card</div>
              <ul className="mt-3 space-y-1 text-xs">
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Up to 3 clients</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> 100 AI agent chats / month</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Unlimited transactions & journal entries</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> All reports (P&L, BS, CF, TB, Equity, VAT) — PDF/Excel/CSV</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> All 6 industry templates</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> 1 connected integration (e.g. Gmail OR QuickBooks)</li>
                <li className="flex gap-1.5"><AlertTriangle className="size-3 text-amber-500 mt-0.5" /> File import: 10 files / month</li>
              </ul>
            </div>
            <div className="rounded-md border border-emerald-500/30 p-4">
              <Badge className="mb-2 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">Pro (recommended)</Badge>
              <div className="text-2xl font-bold">$49<span className="text-sm font-normal text-muted-foreground">/mo</span></div>
              <div className="mt-1 text-xs text-muted-foreground">Per CPA / practice</div>
              <ul className="mt-3 space-y-1 text-xs">
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Unlimited clients</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Unlimited AI agent chats</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Unlimited transactions & entries</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> All integrations (Gmail + QuickBooks + Xero + bank feeds + …)</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Unlimited file imports</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Webhooks & REST API</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Priority support</li>
              </ul>
            </div>
            <div className="rounded-md border p-4">
              <Badge variant="outline" className="mb-2">Enterprise</Badge>
              <div className="text-2xl font-bold">Custom</div>
              <div className="mt-1 text-xs text-muted-foreground">For multi-partner firms</div>
              <ul className="mt-3 space-y-1 text-xs">
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> SSO (Okta / Azure AD)</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> On-prem / private cloud</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> SAP FICO / Oracle NetSuite connectors</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Custom AI agent personas</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> SOC 2 / audit log</li>
                <li className="flex gap-1.5"><CheckCircle2 className="size-3 text-emerald-500 mt-0.5" /> Dedicated CSM</li>
              </ul>
            </div>
          </div>
          <div className="mt-4 rounded-md bg-muted/40 p-3 text-xs text-muted-foreground">
            <strong className="text-foreground">Bottom line:</strong> the Free tier is genuinely usable for a solo accountant or one small business. You only upgrade when you need more clients, more AI chats, or to connect multiple integrations at once. No hidden limits, no surprise charges.
          </div>
        </CardContent>
      </Card>

      {/* Step-by-step getting started */}
      <Card>
        <CardHeader>
          <CardTitle>Getting started — 5 steps</CardTitle>
          <CardDescription>From zero to your first AI-posted journal entry in under 10 minutes</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible defaultValue="step1">
            <AccordionItem value="step1">
              <AccordionTrigger><span className="flex items-center gap-2"><Users className="size-4 text-emerald-500" /> 1. Pick or add your client</span></AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-2">
                  Use the company switcher in the sidebar to pick one of the demo clients (Atlas Manufacturing, Bridgepoint Construction, etc.), or go to the <Button variant="link" className="h-auto p-0" onClick={() => setActiveModule("clients")}>Clients</Button> tab and click <strong>Add Client</strong> to onboard a real one.
                </p>
                <p className="text-xs text-muted-foreground">Choose the industry (Construction / Real Estate / Retail / SaaS / AI / Manufacturing) and country (USA / UK / Germany / France / Ireland). The AI agents load the right tax regime and accounting rules automatically.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="step2">
              <AccordionTrigger><span className="flex items-center gap-2"><Plug className="size-4 text-emerald-500" /> 2. Connect your Gmail, bank and accounting software</span></AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-2">
                  Go to <Button variant="link" className="h-auto p-0" onClick={() => setActiveModule("integrations")}>Integrations</Button> and click <strong>Connect</strong> on Gmail, QuickBooks, Xero, Stripe, Plaid (banks), Shopify, etc.
                </p>
                <p className="text-xs text-muted-foreground">Each integration shows step-by-step setup instructions and the exact redirect URI to register. For SAP FICO and Oracle NetSuite, use the <Button variant="link" className="h-auto p-0" onClick={() => setActiveModule("api")}>API & Webhooks</Button> tab.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="step3">
              <AccordionTrigger><span className="flex items-center gap-2"><Upload className="size-4 text-emerald-500" /> 3. Import your transactions (PDF / Excel / CSV)</span></AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-2">
                  Download a bank statement PDF or export transactions as Excel/CSV from your bank. Go to <Button variant="link" className="h-auto p-0" onClick={() => setActiveModule("import")}>Import Files</Button>, drop the file in.
                </p>
                <p className="text-xs text-muted-foreground">Finova extracts every transaction and posts them to the General Ledger. The Trial Balance, P&L, Balance Sheet, Cash Flow, and Equity Statement all update instantly. Compliance-ready for IFRS / US GAAP / UK GAAP / German HGB / French PCG.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="step4">
              <AccordionTrigger><span className="flex items-center gap-2"><Bot className="size-4 text-emerald-500" /> 4. Chat with the AI agents</span></AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-2">
                  Go to <Button variant="link" className="h-auto p-0" onClick={() => setActiveModule("agents")}>AI Agents</Button>. Pick the right specialist:
                </p>
                <ul className="text-xs text-muted-foreground space-y-1 ml-4">
                  <li><strong>CFO Agent</strong> — cash flow, runway, P&L, FP&A, board reporting</li>
                  <li><strong>Accountant Agent</strong> — post journal entries, reconcile bank feeds, categorize transactions</li>
                  <li><strong>Tax Agent</strong> — calculate US/UK/EU taxes, track deadlines, prepare VAT/corp-tax filings</li>
                  <li><strong>CEO Agent</strong> — strategic decisions, pricing, expansion, fundraising</li>
                </ul>
                <p className="text-xs text-muted-foreground mt-2">Try: <em>"Post a $25k progress billing journal entry for Project 2148 at 35% complete"</em> — the Accountant agent will draft the Dr/Cr entry for you.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="step5">
              <AccordionTrigger><span className="flex items-center gap-2"><FileText className="size-4 text-emerald-500" /> 5. Generate reports & invoices</span></AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-2">
                  Go to <Button variant="link" className="h-auto p-0" onClick={() => setActiveModule("reports")}>Reports</Button> for P&L, Balance Sheet, Cash Flow, Trial Balance, Equity Statement, VAT — each with a one-click PDF download.
                </p>
                <p className="text-xs text-muted-foreground">For invoices, go to <Button variant="link" className="h-auto p-0" onClick={() => setActiveModule("invoices")}>Invoices</Button>, pick an industry template (AIA construction, retail POS, SaaS subscription, real estate rent, manufacturing PO, AI services), fill in the party, click <strong>Create</strong>, then <strong>Download PDF</strong>.</p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* FAQ */}
      <Card>
        <CardHeader>
          <CardTitle>Frequently asked questions</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible>
            <AccordionItem value="faq1">
              <AccordionTrigger>Do I need to know accounting or programming?</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">No. Finova is designed for non-accountants. The AI agents speak plain English — you just describe what you want (e.g. "post a $5,000 invoice to Acme Corp") and it does the double-entry bookkeeping for you. For technical users, there's also a REST API and webhooks.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq2">
              <AccordionTrigger>How do I connect Gmail, QuickBooks, my bank?</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">Each integration uses the standard OAuth flow that every major SaaS uses. Go to Integrations → Configure, follow the step-by-step instructions (we show you exactly which developer console to visit, which scopes to request, and which redirect URI to register). Once connected, the AI agents can read your Gmail for invoices, sync transactions from QuickBooks/Xero, and pull live bank balances via Plaid — all automatically.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq3">
              <AccordionTrigger>What if I have a PDF bank statement?</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">Upload it in the Import Files tab. Finova extracts text from the PDF and parses each transaction line (date, description, amount). Each transaction gets auto-categorized and posted to the General Ledger. For unstructured PDFs (receipts, handwritten invoices), the AI Accountant agent can read the extracted text and create transactions from it.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq4">
              <AccordionTrigger>Does it really follow IFRS / US GAAP / EU local laws?</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">Yes — the reports are generated in the format required by each framework (selectable in the Reports tab): IFRS, US GAAP, UK FRS 102, German HGB, French PCG, Irish FRS 102. The Tax Agent applies the correct regime for the client's country: US federal/state/payroll/sales tax + R&D credit + Section 174; UK Corporation Tax + VAT (MTD) + PAYE; German KSt/Soli/Gewerbe/USt; French IS/TVA; Irish CT/VAT/PAYE.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq5">
              <AccordionTrigger>Can I really use it free forever?</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">Yes. The Free tier ($0) supports up to 3 clients, 100 AI agent chats per month, and unlimited transactions and reports. You only pay ($49/mo Pro) when you need more than 3 clients, unlimited AI chats, or multiple simultaneous integrations. No credit card required to start.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq6">
              <AccordionTrigger>How do I deploy this for my own firm?</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">Download the <a className="text-emerald-600 dark:text-emerald-400 underline" href="/download/DEPLOYMENT.md" target="_blank" rel="noopener noreferrer">DEPLOYMENT.md guide</a>. It covers Vercel (1-click), Docker, and VPS options, plus the exact OAuth credentials you need from each provider (Gmail, QuickBooks, Xero, Stripe, Plaid, etc.). If you want us to host it for you, the Pro plan includes managed hosting.</p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq7">
              <AccordionTrigger>Are the AI outputs reliable enough to file taxes with?</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">No — and we're upfront about it. Every tax and report screen shows: <em>"Outputs are advisory — verify with a licensed CPA before filing."</em> Finova does 90% of the heavy lifting (data extraction, categorization, calculation, drafting) but a licensed local CPA must review and sign off on the actual filing. Finova is the AI copilot, not the licensed signer.</p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Quick links */}
      <Card>
        <CardHeader>
          <CardTitle>Jump to a task</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {[
            { icon: Bot, label: "Ask the CFO a question", module: "agents" },
            { icon: Upload, label: "Import a bank statement", module: "import" },
            { icon: ReceiptText, label: "Create a customer invoice", module: "invoices" },
            { icon: Plug, label: "Connect Gmail / QuickBooks", module: "integrations" },
            { icon: Landmark, label: "Run a tax calculation", module: "tax" },
            { icon: FileText, label: "Download P&L as PDF", module: "reports" },
            { icon: Users, label: "Add a new client", module: "clients" },
            { icon: Zap, label: "Set up an automation", module: "automations" },
            { icon: Code2Icon, label: "Set up a webhook", module: "api" },
          ].map((q) => (
            <button
              key={q.label}
              onClick={() => setActiveModule(q.module as any)}
              className="group flex items-center gap-3 rounded-md border p-3 text-left transition-all hover:border-emerald-500/30 hover:bg-muted/40"
            >
              <div className="flex size-8 items-center justify-center rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                <q.icon className="size-4" />
              </div>
              <div className="text-sm font-medium">{q.label}</div>
            </button>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-muted/30">
        <CardContent className="p-4 flex items-start gap-3">
          <ShieldCheck className="size-5 text-emerald-500 shrink-0 mt-0.5" />
          <div className="text-xs text-muted-foreground">
            <strong className="text-foreground">Privacy & data:</strong> your data is stored in your own database (SQLite for dev, Postgres for production). OAuth tokens are encrypted at rest. The AI agents only see the data needed to answer your question — nothing is sent to third parties for training. See the deployment guide for the full security checklist.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function Code2Icon(props: any) {
  // Re-export Code2 from lucide so the quick-link grid compiles with the same icon set
  return <BookOpen {...props} />;
}
