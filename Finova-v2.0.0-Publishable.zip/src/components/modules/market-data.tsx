"use client";

import * as React from "react";
import { ChartLine, Search, FileSpreadsheet, Download, Globe, Landmark, TrendingUp, Receipt, RefreshCw, BookOpen } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { ConceptsAppliedPanel } from "@/components/concepts-applied-panel";

type Row = {
  metric: string;
  value: string;
  numericValue: number;
  unit: string;
  asOfDate: string;
  source: string;
  notes: string;
};

type Category = {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  rows: Row[];
};

type MarketData = {
  categories: Category[];
  stats: any;
  intro: string;
};

const ICONS: Record<string, React.ElementType> = {
  Globe,
  Landmark,
  TrendingUp,
  Receipt,
};

const COLORS: Record<string, string> = {
  blue: "border-l-blue-500",
  emerald: "border-l-emerald-500",
  violet: "border-l-violet-500",
  rose: "border-l-rose-500",
  amber: "border-l-amber-500",
};

const COLOR_BADGE: Record<string, string> = {
  blue: "border-blue-500/30 text-blue-700 dark:text-blue-300 bg-blue-500/10",
  emerald: "border-emerald-500/30 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10",
  violet: "border-violet-500/30 text-violet-700 dark:text-violet-300 bg-violet-500/10",
  rose: "border-rose-500/30 text-rose-700 dark:text-rose-300 bg-rose-500/10",
  amber: "border-amber-500/30 text-amber-700 dark:text-amber-300 bg-amber-500/10",
};

const COLOR_HEADER: Record<string, string> = {
  blue: "bg-blue-700",
  emerald: "bg-emerald-700",
  violet: "bg-violet-700",
  rose: "bg-rose-700",
  amber: "bg-amber-700",
};

export function MarketDataModule() {
  const [data, setData] = React.useState<MarketData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");

  React.useEffect(() => {
    setLoading(true);
    fetch("/api/market-data")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  async function downloadExcel() {
    if (!data) return;
    const XLSX = await import("xlsx");
    const rows: any[] = [];
    for (const cat of data.categories) {
      for (const r of cat.rows) {
        rows.push({
          Category: cat.name,
          Metric: r.metric,
          Value: r.value,
          NumericValue: r.numericValue,
          Unit: r.unit,
          AsOfDate: r.asOfDate,
          Source: r.source,
          Notes: r.notes,
        });
      }
    }
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Market Data Nov 2026");
    XLSX.writeFile(wb, "market_data_2026-11-20.xlsx");
    toast.success("Market data Excel downloaded");
  }

  if (loading) return <div className="p-6"><Skeleton className="h-96 w-full" /></div>;
  if (!data) return <div className="p-6 text-sm text-muted-foreground">No market data available.</div>;

  // Flatten all rows for search
  const allRows = data.categories.flatMap((c) => c.rows.map((r) => ({ ...r, category: c.name, color: c.color })));
  const filteredRows = search.trim()
    ? allRows.filter((r) => {
        const q = search.toLowerCase();
        return (
          r.metric.toLowerCase().includes(q) ||
          r.value.toLowerCase().includes(q) ||
          r.source.toLowerCase().includes(q) ||
          r.notes.toLowerCase().includes(q) ||
          r.category.toLowerCase().includes(q)
        );
      })
    : [];

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <ChartLine className="size-6 text-blue-600" />
            Market Data, FX Rates & Macro Assumptions
          </h1>
          <p className="text-sm text-muted-foreground">
            All key inputs for FP&A, lending, valuation, consolidation, and tax models. 5 categories · {data.stats.totalRows} data points · Last refreshed {data.stats.lastRefreshed}.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={downloadExcel}>
          <FileSpreadsheet className="size-3.5" /> Excel
        </Button>
      </div>

      {/* Refresh banner */}
      <Card className={cn("border-l-4", "border-l-blue-500")}>
        <CardContent className="py-3">
          <div className="flex flex-wrap items-center gap-3">
            <RefreshCw className="size-4 text-blue-600" />
            <div className="text-sm">
              <span className="font-semibold">Refresh cadence: </span>
              <span className="text-muted-foreground">{data.stats.refreshCadence}</span>
            </div>
            <div className="text-sm">
              <span className="font-semibold">Last refreshed: </span>
              <Badge variant="outline" className="text-[10px] border-blue-500/30 text-blue-700 dark:text-blue-300">{data.stats.lastRefreshed}</Badge>
            </div>
            <div className="text-sm">
              <span className="font-semibold">Total data points: </span>
              <span className="font-bold">{data.stats.totalRows}</span>
              <span className="text-muted-foreground"> · {data.stats.totalCategories} categories</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Intro */}
      <div className="rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-3 text-xs text-muted-foreground">
        {data.intro}
      </div>

      {/* Global search */}
      <div className="relative">
        <Search className="absolute left-2 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
        <input
          type="text"
          placeholder={`Search all ${data.stats.totalRows} data points — e.g. 'Fed Funds', 'GBP', 'ERP', 'BBB', '12.5%', 'CPP'...`}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full rounded-md border border-input bg-background pl-7 pr-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Search results (visible when search active) */}
      {search.trim() && (
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <CardTitle className="text-base">Search Results</CardTitle>
            <CardDescription>{filteredRows.length} of {data.stats.totalRows} data points matching "<strong>{search}</strong>"</CardDescription>
          </CardHeader>
          <CardContent>
            {filteredRows.length === 0 ? (
              <p className="text-sm text-muted-foreground py-6 text-center">No data points match "{search}".</p>
            ) : (
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-xs">
                  <thead className="bg-amber-700 text-white">
                    <tr>
                      <th className="px-2 py-2 text-left font-semibold">Category</th>
                      <th className="px-2 py-2 text-left font-semibold">Metric</th>
                      <th className="px-2 py-2 text-right font-semibold">Value</th>
                      <th className="px-2 py-2 text-left font-semibold">Unit</th>
                      <th className="px-2 py-2 text-left font-semibold">As of</th>
                      <th className="px-2 py-2 text-left font-semibold">Source</th>
                      <th className="px-2 py-2 text-left font-semibold">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRows.map((r, i) => (
                      <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                        <td className="px-2 py-2">
                          <Badge variant="outline" className={cn("text-[10px]", COLOR_BADGE[r.color])}>{r.category}</Badge>
                        </td>
                        <td className="px-2 py-2 font-medium">{r.metric}</td>
                        <td className="px-2 py-2 text-right font-mono font-bold">{r.value}</td>
                        <td className="px-2 py-2 text-muted-foreground">{r.unit}</td>
                        <td className="px-2 py-2 font-mono text-[10px]">{r.asOfDate}</td>
                        <td className="px-2 py-2 text-muted-foreground text-[10px]">{r.source}</td>
                        <td className="px-2 py-2 text-muted-foreground">{r.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Category tabs */}
      <Tabs defaultValue={data.categories[0].id}>
        <TabsList className="grid w-full grid-cols-5">
          {data.categories.map((c) => {
            const Icon = ICONS[c.icon] ?? Globe;
            return (
              <TabsTrigger key={c.id} value={c.id} className="flex items-center gap-1.5">
                <Icon className="size-3.5" />
                <span className="hidden md:inline">{c.name.split(" ")[0]}</span>
                <span className="md:hidden">{c.name.split(" ")[0]}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {data.categories.map((cat) => {
          const Icon = ICONS[cat.icon] ?? Globe;
          return (
            <TabsContent key={cat.id} value={cat.id} className="space-y-4">
              <Card className={cn("border-l-4", COLORS[cat.color])}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Icon className="size-5" />
                    {cat.name}
                  </CardTitle>
                  <CardDescription>{cat.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto rounded-md border">
                    <table className="w-full text-xs">
                      <thead className={cn("text-white", COLOR_HEADER[cat.color])}>
                        <tr>
                          <th className="px-2 py-2 text-left font-semibold w-72">Metric</th>
                          <th className="px-2 py-2 text-right font-semibold w-24">Value</th>
                          <th className="px-2 py-2 text-left font-semibold w-40">Unit</th>
                          <th className="px-2 py-2 text-left font-semibold w-24">As of Date</th>
                          <th className="px-2 py-2 text-left font-semibold w-64">Source</th>
                          <th className="px-2 py-2 text-left font-semibold">Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {cat.rows.map((r, i) => (
                          <tr key={i} className={cn("border-t align-top", i % 2 === 0 ? "bg-muted/20" : "")}>
                            <td className="px-2 py-2 font-medium">{r.metric}</td>
                            <td className="px-2 py-2 text-right font-mono font-bold text-sm">{r.value}</td>
                            <td className="px-2 py-2 text-muted-foreground">{r.unit}</td>
                            <td className="px-2 py-2 font-mono text-[10px] text-muted-foreground">{r.asOfDate}</td>
                            <td className="px-2 py-2 text-[10px] text-muted-foreground">
                              <div className="font-medium text-foreground">{r.source.split(" (")[0]}</div>
                              {r.source.includes("(") && (
                                <div className="text-[9px] italic">{r.source.match(/\(([^)]+)\)/)?.[1]}</div>
                              )}
                            </td>
                            <td className="px-2 py-2 text-muted-foreground leading-relaxed">{r.notes}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          );
        })}
      </Tabs>

      {/* Primary sources panel */}
      <Card className="border-l-4 border-l-slate-500">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <BookOpen className="size-4" />
            Primary Trusted Sources
          </CardTitle>
          <CardDescription>All figures sourced from primary auditable resources — central banks, treasuries, NYU Stern, S&P Global Ratings, Kroll</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
            {data.stats.primarySources.map((src: string, i: number) => (
              <div key={i} className="rounded-md border border-slate-500/20 p-2 text-[10px]">
                <div className="flex items-start gap-1.5">
                  <Badge variant="outline" className="text-[9px] border-slate-500/30 text-slate-700 dark:text-slate-300 shrink-0 py-0 px-1">SRC</Badge>
                  <span className="text-muted-foreground">{src}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 rounded-md bg-slate-500/5 border-l-4 border-l-slate-400 p-3 text-[10px] text-muted-foreground italic">
            {data.stats.disclaimer}
          </div>
        </CardContent>
      </Card>

      {/* ============ CONCEPTS APPLIED — Cross-Reference Matrix ============ */}
      <ConceptsAppliedPanel reportName="Market Data" />
    </div>
  );
}
