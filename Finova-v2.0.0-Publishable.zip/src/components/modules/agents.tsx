"use client";

import * as React from "react";
import { Bot, Briefcase, Calculator, ScrollText, Send, Sparkles, User, Loader2, RotateCcw } from "lucide-react";
import ReactMarkdown from "react-markdown";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Role = "ceo" | "cfo" | "accountant" | "tax";

const AGENTS: Array<{
  role: Role;
  name: string;
  icon: React.ElementType;
  tagline: string;
  responsibilities: string[];
  accent: string;
}> = [
  {
    role: "cfo",
    name: "CFO Agent",
    icon: Briefcase,
    tagline: "Cash, P&L, runway, board reporting",
    responsibilities: ["Cash flow & runway", "Budget vs. actuals", "FP&A scenarios", "Investor narrative"],
    accent: "emerald",
  },
  {
    role: "accountant",
    name: "Accountant Agent",
    icon: ScrollText,
    tagline: "Ledger, journal entries, reconciliation",
    responsibilities: ["Categorize & post", "Dr/Cr journal entries", "Reconcile bank & Stripe", "Chart of accounts"],
    accent: "amber",
  },
  {
    role: "tax",
    name: "Tax Agent",
    icon: Calculator,
    tagline: "USA / UK / EU tax, VAT, deadlines",
    responsibilities: ["Federal/state/CT", "VAT & MTD", "Gewerbesteuer", "Filing deadlines"],
    accent: "rose",
  },
  {
    role: "ceo",
    name: "CEO Agent",
    icon: Sparkles,
    tagline: "Strategy, OKRs, capital allocation",
    responsibilities: ["Strategic decisions", "Pricing & expansion", "M&A & fundraising", "Board narrative"],
    accent: "violet",
  },
];

const ACCENT_BG: Record<string, string> = {
  emerald: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  amber: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30",
  rose: "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30",
  violet: "bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/30",
};

const SUGGESTIONS: Record<Role, string[]> = {
  cfo: [
    "Give me a Q1 cash position summary",
    "What's our runway if revenue drops 20%?",
    "Draft a board KPI digest for this week",
  ],
  accountant: [
    "Post a $4,200 AWS bill to the right accounts",
    "Reconcile the latest Stripe payout",
    "What journal entry records a $1,500 refund?",
  ],
  tax: [
    "What's due for VAT this quarter?",
    "Calculate US estimated tax for $500k profit",
    "Explain UK marginal relief for £150k profit",
  ],
  ceo: [
    "Should we expand into the EU market?",
    "Recommend a pricing strategy for our SMB tier",
    "Draft a fundraising narrative from Q1 metrics",
  ],
};

type ChatMessage = { role: "user" | "assistant"; content: string };

export function AgentsModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [activeRole, setActiveRole] = React.useState<Role>("cfo");
  const [messages, setMessages] = React.useState<ChatMessage[]>([]);
  const [input, setInput] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [loadingHistory, setLoadingHistory] = React.useState(true);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  // Load prior chat history for the active company + role
  React.useEffect(() => {
    setLoadingHistory(true);
    setMessages([]);
    let cancelled = false;
    fetch(`/api/dashboard?companyId=${activeCompanyId}`)
      .then(() => {
        // We don't have a chat history endpoint yet; just start fresh
        // and seed with a welcome message.
        if (cancelled) return;
        setMessages([
          {
            role: "assistant",
            content: `Hello — I'm the **${activeRole.toUpperCase()} Agent** from Finova, working for ${activeCompany?.name ?? "your company"} (${activeCompany?.industry ?? "—"}, ${activeCompany?.country ?? "—"}).\n\nI can see your live ledger, journal entries, integrations and upcoming tax filings. Ask me anything within my remit, or pick a starter prompt below. Use **⌘K** anywhere to jump between clients or modules.`,
          },
        ]);
      })
      .finally(() => !cancelled && setLoadingHistory(false));
    return () => {
      cancelled = true;
    };
  }, [activeCompanyId, activeRole, activeCompany?.name, activeCompany?.country]);

  // Auto-scroll on new message
  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  async function send(prompt?: string) {
    const content = (prompt ?? input).trim();
    if (!content || loading) return;
    const userMsg: ChatMessage = { role: "user", content };
    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);
    try {
      const history = nextMessages.slice(-10).map((m) => ({ role: m.role, content: m.content }));
      const res = await fetch("/api/agent/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyId: activeCompanyId, role: activeRole, message: content, history }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error ?? `HTTP ${res.status}`);
      }
      setMessages((m) => [...m, { role: "assistant", content: data.reply }]);
    } catch (e: any) {
      toast.error(`Agent error: ${e.message}`);
      setMessages((m) => [
        ...m,
        { role: "assistant", content: `I hit an issue responding: ${e.message}. Please retry.` },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  const activeAgent = AGENTS.find((a) => a.role === activeRole)!;

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">AI Agents</h1>
        <p className="text-sm text-muted-foreground">
          Four specialist agents — CEO, CFO, Accountant, Tax — share one model but think and act differently.
          Each is grounded in your live ledger, integrations and tax filings.
        </p>
      </div>

      {/* Agent selector cards */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {AGENTS.map((a) => {
          const Icon = a.icon;
          const active = activeRole === a.role;
          return (
            <button
              key={a.role}
              onClick={() => setActiveRole(a.role)}
              className={cn(
                "group text-left rounded-lg border p-4 transition-all",
                active
                  ? "border-emerald-500/40 bg-emerald-500/5 ring-2 ring-emerald-500/30"
                  : "border-border hover:border-emerald-500/30 hover:bg-muted/40"
              )}
            >
              <div className="flex items-center justify-between">
                <div className={cn("flex size-9 items-center justify-center rounded-md border", ACCENT_BG[a.accent])}>
                  <Icon className="size-5" />
                </div>
                {active && <Badge className="text-[10px]">Active</Badge>}
              </div>
              <div className="mt-3 text-sm font-semibold">{a.name}</div>
              <div className="mt-0.5 text-xs text-muted-foreground">{a.tagline}</div>
            </button>
          );
        })}
      </div>

      {/* Active agent detail + chat */}
      <div className="grid gap-4 lg:grid-cols-3">
        {/* Left: agent detail */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className={cn("flex size-10 items-center justify-center rounded-md border", ACCENT_BG[activeAgent.accent])}>
                <activeAgent.icon className="size-5" />
              </div>
              <div>
                <CardTitle className="text-base">{activeAgent.name}</CardTitle>
                <CardDescription>{activeAgent.tagline}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Responsibilities</div>
              <ul className="mt-2 space-y-1">
                {activeAgent.responsibilities.map((r) => (
                  <li key={r} className="flex items-start gap-2 text-sm">
                    <span className="mt-1 size-1.5 shrink-0 rounded-full bg-emerald-500" />
                    {r}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-t pt-3">
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Try asking</div>
              <div className="mt-2 space-y-1.5">
                {SUGGESTIONS[activeRole].map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    disabled={loading}
                    className="block w-full rounded-md border bg-muted/40 px-3 py-2 text-left text-xs transition-colors hover:border-emerald-500/30 hover:bg-muted disabled:opacity-50"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Right: chat */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-base">{activeAgent.name} · Chat</CardTitle>
              <CardDescription>
                Live context: {activeCompany?.name ?? "—"} · {activeCompany?.country ?? "—"}
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setMessages([])}
              aria-label="Clear conversation"
            >
              <RotateCcw className="size-3.5" />
              Clear
            </Button>
          </CardHeader>
          <CardContent className="flex h-[60vh] min-h-[420px] flex-col">
            {loadingHistory ? (
              <div className="flex-1 space-y-3">
                <Skeleton className="h-12 w-3/4" />
                <Skeleton className="h-12 w-1/2" />
              </div>
            ) : (
              <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto pr-1">
                {messages.map((m, i) => (
                  <div key={i} className={cn("flex gap-3", m.role === "user" ? "justify-end" : "justify-start")}>
                    {m.role === "assistant" && (
                      <div className={cn("mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md border", ACCENT_BG[activeAgent.accent])}>
                        <Bot className="size-4" />
                      </div>
                    )}
                    <div
                      className={cn(
                        "max-w-[80%] rounded-lg px-3 py-2 text-sm leading-relaxed",
                        m.role === "user"
                          ? "bg-emerald-500/15 text-foreground"
                          : "bg-muted/60"
                      )}
                    >
                      {m.role === "assistant" ? (
                        <div className="prose prose-sm dark:prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0 [&_li]:my-0.5 [&_p]:my-1.5 [&_table]:text-xs [&_th]:px-2 [&_td]:px-2 [&_th]:py-1 [&_td]:py-1">
                          <ReactMarkdown>{m.content}</ReactMarkdown>
                        </div>
                      ) : (
                        m.content
                      )}
                    </div>
                    {m.role === "user" && (
                      <div className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md bg-muted">
                        <User className="size-4" />
                      </div>
                    )}
                  </div>
                ))}
                {loading && (
                  <div className="flex gap-3">
                    <div className={cn("mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md border", ACCENT_BG[activeAgent.accent])}>
                      <Loader2 className="size-4 animate-spin" />
                    </div>
                    <div className="rounded-lg bg-muted/60 px-3 py-2 text-sm text-muted-foreground">
                      Thinking…
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="mt-3 border-t pt-3">
              <div className="flex items-end gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={onKeyDown}
                  placeholder={`Ask the ${activeAgent.name}…`}
                  rows={2}
                  className="resize-none"
                  disabled={loading}
                />
                <Button onClick={() => send()} disabled={loading || !input.trim()} size="icon" aria-label="Send">
                  <Send className="size-4" />
                </Button>
              </div>
              <div className="mt-1 text-[10px] text-muted-foreground">
                Press Enter to send · Shift+Enter for newline · The agent sees your live ledger & filings.
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
