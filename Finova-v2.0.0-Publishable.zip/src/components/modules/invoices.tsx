"use client";

import * as React from "react";
import { ReceiptText, Plus, Download, RefreshCw, Trash2, Eye, Send, CheckCircle2 } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Line = { description: string; qty: number; unitPrice: number; taxRate: number; account?: string; total: number };
type Invoice = {
  id: string;
  type: "customer" | "vendor";
  number: string;
  partyName: string;
  partyEmail?: string | null;
  partyAddress?: string | null;
  date: string;
  dueDate: string;
  currency: string;
  lines: Line[];
  subtotal: number;
  taxTotal: number;
  total: number;
  status: string;
  template: string;
  notes?: string | null;
};

const TEMPLATES: Array<{ id: string; label: string; industry: string; type: "customer" | "vendor"; lines: Line[]; notes: string }> = [
  {
    id: "standard",
    label: "Standard Invoice",
    industry: "Any",
    type: "customer",
    lines: [{ description: "Professional services", qty: 1, unitPrice: 5000, taxRate: 20, total: 5000 }],
    notes: "Payment due within 30 days.",
  },
  {
    id: "aia-construction",
    label: "AIA Progress Billing (Construction)",
    industry: "Construction",
    type: "customer",
    lines: [
      { description: "Project #2148 — Progress billing (35% complete)", qty: 1, unitPrice: 62500, taxRate: 0, total: 62500 },
      { description: "Retention (10% held until acceptance)", qty: 1, unitPrice: -6250, taxRate: 0, total: -6250 },
    ],
    notes: "AIA Document G702/G703 attached. Retention released upon project acceptance.",
  },
  {
    id: "pos-retail",
    label: "Retail POS Receipt",
    industry: "Retail",
    type: "customer",
    lines: [
      { description: "SKU-1001 Widget × 10", qty: 10, unitPrice: 19.99, taxRate: 19, total: 199.90 },
      { description: "SKU-2002 Gadget × 5", qty: 5, unitPrice: 34.50, taxRate: 19, total: 172.50 },
    ],
    notes: "Includes 19% VAT. Return within 14 days with receipt.",
  },
  {
    id: "subscription-saas",
    label: "SaaS Subscription Invoice",
    industry: "SaaS",
    type: "customer",
    lines: [
      { description: "Enterprise plan — 50 seats × monthly", qty: 50, unitPrice: 89, taxRate: 0, total: 4450 },
      { description: "Premium support add-on", qty: 1, unitPrice: 500, taxRate: 0, total: 500 },
    ],
    notes: "Auto-renews on the 1st of each month. Cancel anytime with 30 days notice.",
  },
  {
    id: "rent-real-estate",
    label: "Rent Invoice (Real Estate)",
    industry: "Real Estate",
    type: "customer",
    lines: [
      { description: "Monthly rent — Unit 4B (1,200 sqft)", qty: 1, unitPrice: 4200, taxRate: 0, total: 4200 },
      { description: "Service charge & utilities", qty: 1, unitPrice: 380, taxRate: 20, total: 380 },
    ],
    notes: "Late fee: 5% after 5 days. Security deposit held separately.",
  },
  {
    id: "po-manufacturing",
    label: "Purchase Order (Manufacturing)",
    industry: "Manufacturing",
    type: "vendor",
    lines: [
      { description: "Raw steel — Grade 304 (sheet 2m × 1m)", qty: 200, unitPrice: 92, taxRate: 0, total: 18400 },
      { description: "Delivery & handling", qty: 1, unitPrice: 450, taxRate: 0, total: 450 },
    ],
    notes: "FOB shipping point. Inspection within 5 days of receipt.",
  },
  {
    id: "services-ai",
    label: "AI Services Invoice",
    industry: "AI",
    type: "customer",
    lines: [
      { description: "API usage — 1.2M tokens × $0.006/1K", qty: 1200, unitPrice: 6, taxRate: 0, total: 7200 },
      { description: "Custom model fine-tuning engagement", qty: 1, unitPrice: 25000, taxRate: 0, total: 25000 },
    ],
    notes: "Usage-based line item billed monthly. R&D-eligible for US Form 6765.",
  },
];

const STATUS_BADGE: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  sent: "bg-blue-500/15 text-blue-600 dark:text-blue-400",
  paid: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  overdue: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  void: "bg-muted text-muted-foreground line-through",
};

export function InvoicesModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [invoices, setInvoices] = React.useState<Invoice[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filterType, setFilterType] = React.useState<"all" | "customer" | "vendor">("all");
  const [createOpen, setCreateOpen] = React.useState(false);
  const [previewInvoice, setPreviewInvoice] = React.useState<Invoice | null>(null);

  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";

  function load() {
    setLoading(true);
    fetch(`/api/invoices?companyId=${activeCompanyId}&type=${filterType === "all" ? "" : filterType}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setInvoices(d.invoices);
      })
      .catch((e) => toast.error(`Failed to load: ${e.message}`))
      .finally(() => setLoading(false));
  }

  React.useEffect(() => { load(); }, [activeCompanyId, filterType]);

  async function updateStatus(inv: Invoice, status: string) {
    setInvoices((arr) => arr.map((i) => (i.id === inv.id ? { ...i, status } : i)));
    try {
      const res = await fetch("/api/invoices", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: inv.id, status }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`Marked as ${status}`);
    } catch (e: any) {
      toast.error(e.message);
      setInvoices((arr) => arr.map((i) => (i.id === inv.id ? { ...i, status: inv.status } : i)));
    }
  }

  function downloadPdf(inv: Invoice) {
    window.open(`/api/invoices/${inv.id}/pdf`, "_blank");
    toast.success("PDF downloading…");
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Invoices</h1>
          <p className="text-sm text-muted-foreground">
            Create professional customer invoices and vendor bills. Industry-specific templates (AIA construction, retail POS, SaaS subscription, real estate rent, manufacturing PO, AI services). One-click PDF download.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load}>
            <RefreshCw className="size-3.5" />
            Refresh
          </Button>
          <Button size="sm" onClick={() => setCreateOpen(true)}>
            <Plus className="size-3.5" />
            New Invoice
          </Button>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(["all", "customer", "vendor"] as const).map((t) => (
          <Button
            key={t}
            variant={filterType === t ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType(t)}
            className="capitalize"
          >
            {t === "all" ? "All" : t === "customer" ? "Customer invoices" : "Vendor bills"}
          </Button>
        ))}
      </div>

      {/* Templates gallery */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Industry Templates</CardTitle>
          <CardDescription>Click to start a new invoice from a template</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              onClick={() => { setCreateOpen(true); /* could pre-select template here */ }}
              className="group text-left rounded-md border p-3 transition-all hover:border-emerald-500/30 hover:bg-muted/40"
            >
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="text-[10px]">{t.industry}</Badge>
                <Badge variant="secondary" className="text-[10px] capitalize">{t.type}</Badge>
              </div>
              <div className="mt-2 text-sm font-medium">{t.label}</div>
              <div className="mt-1 text-xs text-muted-foreground">{t.lines.length} line item{t.lines.length === 1 ? "" : "s"} · {sym}{t.lines.reduce((s, l) => s + l.total, 0).toLocaleString()} subtotal</div>
            </button>
          ))}
        </CardContent>
      </Card>

      {/* List */}
      <Card>
        <CardHeader>
          <CardTitle>{filterType === "all" ? "All Invoices" : filterType === "customer" ? "Customer Invoices" : "Vendor Bills"}</CardTitle>
          <CardDescription>{invoices.length} document{invoices.length === 1 ? "" : "s"}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {loading ? (
            <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
          ) : invoices.length === 0 ? (
            <p className="text-sm text-muted-foreground">No invoices yet. Click "New Invoice" above to create one.</p>
          ) : (
            invoices.map((inv) => (
              <div key={inv.id} className="flex flex-col gap-3 rounded-md border p-4 sm:flex-row sm:items-center">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-semibold">{inv.number}</span>
                    <Badge variant="outline" className="text-[10px] capitalize">{inv.type}</Badge>
                    <Badge className={cn("text-[10px]", STATUS_BADGE[inv.status] ?? "bg-muted")}>{inv.status}</Badge>
                    <Badge variant="outline" className="text-[10px]">{inv.template}</Badge>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    {inv.type === "customer" ? "Bill to" : "Bill from"}: {inv.partyName} · {new Date(inv.date).toLocaleDateString()} → due {new Date(inv.dueDate).toLocaleDateString()}
                  </div>
                  <div className="mt-1 text-sm font-medium">{sym}{inv.total.toLocaleString()} <span className="text-xs text-muted-foreground">({inv.lines.length} lines)</span></div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => setPreviewInvoice(inv)}>
                    <Eye className="size-3.5" />
                    Preview
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => downloadPdf(inv)}>
                    <Download className="size-3.5" />
                    PDF
                  </Button>
                  {inv.status === "draft" && (
                    <Button size="sm" variant="outline" onClick={() => updateStatus(inv, "sent")}>
                      <Send className="size-3.5" />
                      Mark sent
                    </Button>
                  )}
                  {inv.status === "sent" && (
                    <Button size="sm" onClick={() => updateStatus(inv, "paid")}>
                      <CheckCircle2 className="size-3.5" />
                      Mark paid
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      <CreateInvoiceDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        companyId={activeCompanyId}
        currency={activeCompany?.currency ?? "USD"}
        industry={activeCompany?.industry ?? "Any"}
        onSaved={() => { setCreateOpen(false); load(); }}
      />

      <PreviewDialog invoice={previewInvoice} onClose={() => setPreviewInvoice(null)} sym={sym} onDownload={downloadPdf} />
    </div>
  );
}

function CreateInvoiceDialog({
  open, onOpenChange, companyId, currency, industry, onSaved,
}: {
  open: boolean; onOpenChange: (b: boolean) => void; companyId: string; currency: string; industry: string;
  onSaved: () => void;
}) {
  const [type, setType] = React.useState<"customer" | "vendor">("customer");
  const [number, setNumber] = React.useState(`INV-${Math.floor(1000 + Math.random() * 9000)}`);
  const [partyName, setPartyName] = React.useState("");
  const [partyEmail, setPartyEmail] = React.useState("");
  const [partyAddress, setPartyAddress] = React.useState("");
  const [date, setDate] = React.useState(new Date().toISOString().slice(0, 10));
  const [dueDate, setDueDate] = React.useState(new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10));
  const [templateId, setTemplateId] = React.useState("standard");
  const [notes, setNotes] = React.useState("");
  const [lines, setLines] = React.useState<Line[]>([{ description: "", qty: 1, unitPrice: 0, taxRate: 0, total: 0 }]);
  const [saving, setSaving] = React.useState(false);

  // When template changes, populate lines + notes
  React.useEffect(() => {
    if (!open) return;
    const t = TEMPLATES.find((x) => x.id === templateId);
    if (t) {
      setType(t.type);
      setLines(t.lines.map((l) => ({ ...l })));
      setNotes(t.notes);
    }
  }, [templateId, open]);

  function updateLine(i: number, patch: Partial<Line>) {
    setLines((arr) => arr.map((l, idx) => {
      if (idx !== i) return l;
      const next = { ...l, ...patch };
      next.total = next.qty * next.unitPrice;
      return next;
    }));
  }
  function addLine() { setLines((a) => [...a, { description: "", qty: 1, unitPrice: 0, taxRate: 0, total: 0 }]); }
  function removeLine(i: number) { setLines((a) => a.filter((_, idx) => idx !== i)); }

  const subtotal = lines.reduce((s, l) => s + l.qty * l.unitPrice, 0);
  const taxTotal = lines.reduce((s, l) => s + l.qty * l.unitPrice * (l.taxRate || 0) / 100, 0);
  const total = subtotal + taxTotal;

  async function save() {
    if (!partyName || !number || lines.length === 0 || lines.some((l) => !l.description)) {
      toast.error("Fill in party name, invoice number, and at least one line description");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyId, type, number, partyName, partyEmail, partyAddress, date, dueDate, currency, lines, template: templateId, notes }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`${type === "customer" ? "Invoice" : "Bill"} ${number} created`);
      setPartyName(""); setPartyEmail(""); setPartyAddress("");
      onSaved();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  const sym = currency === "USD" ? "$" : currency === "GBP" ? "£" : "€";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>New {type === "customer" ? "Invoice" : "Vendor Bill"}</DialogTitle>
          <DialogDescription>Industry template pre-fills the line items. Edit, then download as PDF.</DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Template</Label>
              <Select value={templateId} onValueChange={setTemplateId}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TEMPLATES.map((t) => <SelectItem key={t.id} value={t.id}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Type</Label>
              <Select value={type} onValueChange={(v) => setType(v as any)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="customer">Customer invoice (sales)</SelectItem>
                  <SelectItem value="vendor">Vendor bill (purchase)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="grid gap-2">
              <Label htmlFor="num">Invoice #</Label>
              <Input id="num" value={number} onChange={(e) => setNumber(e.target.value)} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="pname">{type === "customer" ? "Customer" : "Vendor"} name</Label>
              <Input id="pname" value={partyName} onChange={(e) => setPartyName(e.target.value)} placeholder="Acme Corp" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="pemail">Email</Label>
              <Input id="pemail" value={partyEmail} onChange={(e) => setPartyEmail(e.target.value)} placeholder="ap@acme.com" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label htmlFor="addr">Address</Label>
              <Input id="addr" value={partyAddress} onChange={(e) => setPartyAddress(e.target.value)} placeholder="123 Main St, City, ZIP" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="grid gap-2">
                <Label htmlFor="date">Date</Label>
                <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="due">Due date</Label>
                <Input id="due" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </div>
            </div>
          </div>

          {/* Lines */}
          <div className="rounded-md border">
            <div className="grid grid-cols-[1fr_60px_100px_70px_100px_36px] gap-2 border-b bg-muted/40 px-3 py-2 text-xs font-medium text-muted-foreground">
              <div>Description</div>
              <div className="text-right">Qty</div>
              <div className="text-right">Unit ({sym})</div>
              <div className="text-right">Tax %</div>
              <div className="text-right">Total ({sym})</div>
              <div></div>
            </div>
            {lines.map((l, i) => (
              <div key={i} className="grid grid-cols-[1fr_60px_100px_70px_100px_36px] gap-2 border-b px-3 py-2 last:border-b-0 items-center">
                <Input value={l.description} onChange={(e) => updateLine(i, { description: e.target.value })} placeholder="Item or service" className="text-sm" />
                <Input type="number" min="0" step="1" value={l.qty || ""} onChange={(e) => updateLine(i, { qty: Number(e.target.value) || 0 })} className="text-right text-sm" />
                <Input type="number" min="0" step="0.01" value={l.unitPrice || ""} onChange={(e) => updateLine(i, { unitPrice: Number(e.target.value) || 0 })} className="text-right text-sm" />
                <Input type="number" min="0" step="0.1" value={l.taxRate || ""} onChange={(e) => updateLine(i, { taxRate: Number(e.target.value) || 0 })} className="text-right text-sm" />
                <div className="text-right text-sm font-medium">{sym}{l.total.toFixed(2)}</div>
                <Button variant="ghost" size="icon" className="size-7" onClick={() => removeLine(i)} disabled={lines.length <= 1} aria-label="Remove line">
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            ))}
            <div className="flex justify-between px-3 py-2">
              <Button variant="outline" size="sm" onClick={addLine}><Plus className="size-3" /> Add line</Button>
              <div className="flex gap-3 text-sm">
                <span className="text-muted-foreground">Subtotal: <strong className="font-medium text-foreground">{sym}{subtotal.toFixed(2)}</strong></span>
                <span className="text-muted-foreground">Tax: <strong className="font-medium text-foreground">{sym}{taxTotal.toFixed(2)}</strong></span>
                <span className="text-muted-foreground">Total: <strong className="font-medium text-emerald-600 dark:text-emerald-400">{sym}{total.toFixed(2)}</strong></span>
              </div>
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Payment terms, late fees, retention, etc." />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || !partyName || !number}>{saving ? "Saving…" : "Create invoice"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PreviewDialog({ invoice, onClose, sym, onDownload }: { invoice: Invoice | null; onClose: () => void; sym: string; onDownload: (i: Invoice) => void }) {
  if (!invoice) return null;
  return (
    <Dialog open={!!invoice} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ReceiptText className="size-4" />
            {invoice.number} — {invoice.partyName}
          </DialogTitle>
          <DialogDescription>{invoice.type === "customer" ? "Customer invoice" : "Vendor bill"} · {invoice.template} template · {invoice.status}</DialogDescription>
        </DialogHeader>
        <div className="rounded-md border p-4">
          <div className="flex items-start justify-between border-b pb-3">
            <div>
              <div className="text-sm font-bold">Finova</div>
              <div className="text-[10px] text-muted-foreground">Finance · Accounting · AI Agents · USA / UK / EU</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold uppercase">{invoice.type === "customer" ? "Invoice" : "Bill"}</div>
              <div className="text-xs text-muted-foreground">{invoice.number}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 py-3 text-xs">
            <div>
              <div className="font-medium uppercase text-muted-foreground">{invoice.type === "customer" ? "Bill to" : "Bill from"}</div>
              <div className="text-sm font-medium">{invoice.partyName}</div>
              {invoice.partyAddress && <div className="text-muted-foreground">{invoice.partyAddress}</div>}
              {invoice.partyEmail && <div className="text-muted-foreground">{invoice.partyEmail}</div>}
            </div>
            <div className="text-right">
              <div><span className="text-muted-foreground">Date:</span> {new Date(invoice.date).toLocaleDateString()}</div>
              <div><span className="text-muted-foreground">Due:</span> {new Date(invoice.dueDate).toLocaleDateString()}</div>
              <div><span className="text-muted-foreground">Status:</span> {invoice.status}</div>
            </div>
          </div>
          <Separator />
          <table className="w-full text-sm mt-3">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b">
                <th className="py-1 font-medium">Description</th>
                <th className="py-1 text-right font-medium">Qty</th>
                <th className="py-1 text-right font-medium">Unit</th>
                <th className="py-1 text-right font-medium">Tax</th>
                <th className="py-1 text-right font-medium">Total</th>
              </tr>
            </thead>
            <tbody>
              {invoice.lines.map((l, i) => (
                <tr key={i} className="border-b">
                  <td className="py-1.5">{l.description}</td>
                  <td className="py-1.5 text-right">{l.qty}</td>
                  <td className="py-1.5 text-right">{sym}{l.unitPrice.toFixed(2)}</td>
                  <td className="py-1.5 text-right">{(l.taxRate || 0).toFixed(1)}%</td>
                  <td className="py-1.5 text-right">{sym}{l.total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-3 ml-auto w-48 space-y-1 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{sym}{invoice.subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Tax</span><span>{sym}{invoice.taxTotal.toFixed(2)}</span></div>
            <Separator />
            <div className="flex justify-between font-bold"><span>Total</span><span className="text-emerald-600 dark:text-emerald-400">{sym}{invoice.total.toFixed(2)}</span></div>
          </div>
          {invoice.notes && (
            <div className="mt-3 rounded bg-muted/40 p-2 text-xs text-muted-foreground">{invoice.notes}</div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Close</Button>
          <Button onClick={() => onDownload(invoice)}><Download className="size-3.5" /> Download PDF</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
