"use client";

import * as React from "react";
import { Upload, FileText, FileSpreadsheet, File, CheckCircle2, AlertTriangle, X, Loader2 } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type ImportedFile = {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  parsedCount: number;
  postedCount: number;
  status: string;
  summary: string | null;
  createdAt: string;
};

const ACCEPTED = ".pdf,.xlsx,.xls,.csv,.tsv,.xml,.json,.txt,.docx,.doc,.html,.htm,.png,.jpg,.jpeg,.webp";

export function ImportModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [dragging, setDragging] = React.useState(false);
  const [uploading, setUploading] = React.useState(false);
  const [lastResult, setLastResult] = React.useState<any>(null);
  const [history, setHistory] = React.useState<ImportedFile[]>([]);
  const [loadingHistory, setLoadingHistory] = React.useState(true);
  const inputRef = React.useRef<HTMLInputElement>(null);

  // History isn't currently fetched via an API; we keep it client-side per session.
  React.useEffect(() => {
    setLoadingHistory(false);
  }, []);

  async function handleFile(file: File) {
    setUploading(true);
    setLastResult(null);
    try {
      const fd = new FormData();
      fd.append("companyId", activeCompanyId);
      fd.append("file", file);
      const res = await fetch("/api/import", { method: "POST", body: fd });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Upload failed");
      setLastResult(d);
      toast.success(d.message ?? `Imported ${d.postedCount} transactions`);
      // Prepend to history
      setHistory((h) => [
        {
          id: d.importedFileId,
          fileName: d.fileName,
          fileType: d.fileType,
          fileSize: file.size,
          parsedCount: d.parsedCount,
          postedCount: d.postedCount,
          status: d.postedCount > 0 ? "posted" : "parsed",
          summary: d.message ?? `Imported ${d.postedCount} transactions`,
          createdAt: new Date().toISOString(),
        },
        ...h,
      ]);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setUploading(false);
    }
  }

  function onDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  }

  function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    e.target.value = "";
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Import Files</h1>
        <p className="text-sm text-muted-foreground">
          Upload <strong>any file</strong> — PDF bank statements, Excel, CSV, JSON, XML, Word docs, text files, even photos of receipts. Finova extracts every transaction using structured parsing, PDF text extraction, and AI vision for images. All transactions auto-post to the GL with SAP FICO account codes. Trial Balance, P&L, Balance Sheet, Cash Flow and Equity reports update instantly.
        </p>
      </div>

      {/* Drop zone */}
      <Card
        className={cn(
          "border-2 border-dashed transition-colors",
          dragging ? "border-emerald-500 bg-emerald-500/5" : "border-border"
        )}
      >
        <CardContent className="p-8">
          <div
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            className="flex flex-col items-center justify-center gap-3 text-center"
          >
            <div className={cn("flex size-14 items-center justify-center rounded-full", dragging ? "bg-emerald-500/15 text-emerald-500" : "bg-muted text-muted-foreground")}>
              {uploading ? <Loader2 className="size-7 animate-spin" /> : <Upload className="size-7" />}
            </div>
            <div>
              <div className="text-sm font-medium">
                {uploading ? "Parsing and posting to GL…" : "Drop a file here, or click to browse"}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                Supports PDF, Excel (.xlsx/.xls), CSV, TSV, JSON, XML, Word, TXT, HTML, and images (PNG/JPG/WebP) · AI vision extraction for unstructured files · up to 500 transactions per file
              </div>
            </div>
            <input
              ref={inputRef}
              type="file"
              accept={ACCEPTED}
              onChange={onPick}
              className="hidden"
              disabled={uploading}
            />
            <Button
              variant="outline"
              onClick={() => inputRef.current?.click()}
              disabled={uploading}
            >
              <Upload className="size-3.5" />
              Choose file
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Last import result */}
      {lastResult && (
        <Card className={cn("border-l-4", lastResult.postedCount > 0 ? "border-l-emerald-500" : "border-l-amber-500")}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  {lastResult.postedCount > 0 ? <CheckCircle2 className="size-4 text-emerald-500" /> : <AlertTriangle className="size-4 text-amber-500" />}
                  Last import: {lastResult.fileName}
                </CardTitle>
                <CardDescription>{lastResult.fileType.toUpperCase()} · parsed {lastResult.parsedCount} rows · posted {lastResult.postedCount} to GL</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm">{lastResult.message}</p>
            {lastResult.sampleRows && lastResult.sampleRows.length > 0 && (
              <div>
                <div className="text-xs font-medium uppercase text-muted-foreground mb-2">Sample rows imported</div>
                <div className="overflow-x-auto rounded-md border">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/40">
                      <tr className="text-left">
                        <th className="px-2 py-1 font-medium">Date</th>
                        <th className="px-2 py-1 font-medium">Description</th>
                        <th className="px-2 py-1 font-medium">Category</th>
                        <th className="px-2 py-1 font-medium">Type</th>
                        <th className="px-2 py-1 text-right font-medium">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lastResult.sampleRows.map((r: any, i: number) => (
                        <tr key={i} className="border-t">
                          <td className="px-2 py-1">{r.date || "—"}</td>
                          <td className="px-2 py-1">{r.description || "—"}</td>
                          <td className="px-2 py-1">{r.category || "auto"}</td>
                          <td className="px-2 py-1">{r.type || "—"}</td>
                          <td className="px-2 py-1 text-right">{r.amount?.toLocaleString() ?? "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            {lastResult.extractedTextPreview && (
              <div>
                <div className="text-xs font-medium uppercase text-muted-foreground mb-2">Extracted text (preview)</div>
                <pre className="rounded-md bg-muted/40 p-3 text-[10px] overflow-x-auto max-h-32">{lastResult.extractedTextPreview}</pre>
                <div className="mt-2 text-xs text-muted-foreground">
                  Copy this text into the AI Agents tab and ask the Accountant agent: "Extract transactions from this text and post each to the GL."
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* What updates */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">What updates after import</CardTitle>
          <CardDescription>Every import flows through to all reports automatically</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3 lg:grid-cols-4">
          {[
            { label: "General Ledger", desc: "Each row becomes a posted transaction" },
            { label: "Trial Balance", desc: "Account balances recalculate immediately" },
            { label: "P&L Statement", desc: "Revenue & expense totals update live" },
            { label: "Balance Sheet", desc: "Cash, A/R, A/P, retained earnings all flow" },
            { label: "Cash Flow", desc: "Operating, investing & financing refresh" },
            { label: "Equity Statement", desc: "Net profit rolls into retained earnings" },
            { label: "VAT / GST Return", desc: "Output VAT on revenue, input VAT on expenses" },
            { label: "Dashboard KPIs", desc: "Cash, runway, margin — all recomputed" },
          ].map((r) => (
            <div key={r.label} className="rounded-md border p-3">
              <div className="text-sm font-medium">{r.label}</div>
              <div className="mt-0.5 text-xs text-muted-foreground">{r.desc}</div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Compliance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Compliance standards supported</CardTitle>
          <CardDescription>Reports can be generated in any of these frameworks</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3">
          {[
            { code: "IFRS", desc: "International Financial Reporting Standards — required for EU listed companies, common globally." },
            { code: "US GAAP", desc: "United States Generally Accepted Accounting Principles — FASB ASC." },
            { code: "UK GAAP / FRS 102", desc: "United Kingdom — FRS 102 / FRS 105 for small cos." },
            { code: "German HGB", desc: "Handelsgesetzbuch — German commercial code." },
            { code: "French PCG", desc: "Plan Comptable Général — French chart of accounts." },
            { code: "Irish FRS 102", desc: "Ireland — same framework as UK FRS 102." },
          ].map((r) => (
            <div key={r.code} className="rounded-md border p-3">
              <Badge variant="outline" className="text-[10px] mb-1">{r.code}</Badge>
              <div className="text-xs text-muted-foreground">{r.desc}</div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* History */}
      <Card>
        <CardHeader>
          <CardTitle>Import History</CardTitle>
          <CardDescription>Files imported in this session</CardDescription>
        </CardHeader>
        <CardContent>
          {loadingHistory ? (
            <Skeleton className="h-16 w-full" />
          ) : history.length === 0 ? (
            <p className="text-sm text-muted-foreground">No files imported yet this session. Upload one above.</p>
          ) : (
            <div className="space-y-2">
              {history.map((f) => {
                const Icon = f.fileType === "pdf" ? FileText : f.fileType === "xlsx" || f.fileType === "csv" ? FileSpreadsheet : File;
                return (
                  <div key={f.id} className="flex items-center gap-3 rounded-md border p-3">
                    <div className="flex size-9 items-center justify-center rounded-md bg-muted">
                      <Icon className="size-5 text-muted-foreground" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium truncate">{f.fileName}</div>
                      <div className="mt-0.5 text-xs text-muted-foreground">
                        {f.fileType.toUpperCase()} · {(f.fileSize / 1024).toFixed(1)} KB · {new Date(f.createdAt).toLocaleString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">{f.postedCount} posted</div>
                      <Badge variant={f.status === "posted" ? "default" : "secondary"} className="text-[10px]">
                        {f.status === "posted" ? <CheckCircle2 className="size-3" /> : <AlertTriangle className="size-3" />}
                        {f.status}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
