"use client";

import * as React from "react";
import { FileText, Download, FileSpreadsheet, CheckCircle2, AlertTriangle, Search, TrendingUp, Landmark, Building2, LineChart, Home, HardHat, ShoppingBag, Cloud, Coins, BookOpen, Layers, Receipt, Building, Network, Globe, Wallet, Package, Brain, MapPin } from "lucide-react";
import { PDFDocument, StandardFonts, rgb, PageSizes } from "pdf-lib";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { ConceptsAppliedPanel } from "@/components/concepts-applied-panel";

type ReportData = any;

export function ReportsModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [data, setData] = React.useState<ReportData>(null);
  const [loading, setLoading] = React.useState(true);
  const [standard, setStandard] = React.useState("IFRS");

  // ============ Concepts (Laws) state — MUST be before early returns (Rules of Hooks) ============
  const [search, setSearch] = React.useState("");
  const [activeCat, setActiveCat] = React.useState<string>("All");
  const concepts = data?.concepts;
  const filteredTerms = React.useMemo(() => {
    if (!concepts?.allTerms) return [];
    let terms = concepts.allTerms;
    if (activeCat !== "All") terms = terms.filter((t: any) => t.category === activeCat);
    if (search.trim()) {
      const q = search.toLowerCase();
      terms = terms.filter((t: any) =>
        t.term.toLowerCase().includes(q) ||
        t.definition.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q)
      );
    }
    return terms;
  }, [concepts, search, activeCat]);

  // ============ GAAP vs IFRS state — search + active area (Rules of Hooks) ============
  const [gvSearch, setGvSearch] = React.useState("");
  const [gvActiveArea, setGvActiveArea] = React.useState<string>("All");
  const gaapVsIfrs = data?.gaapVsIfrs;
  const filteredGvRows = React.useMemo(() => {
    if (!gaapVsIfrs?.allRows) return [];
    let rows = gaapVsIfrs.allRows;
    if (gvActiveArea !== "All") rows = rows.filter((r: any) => r.area === gvActiveArea);
    if (gvSearch.trim()) {
      const q = gvSearch.toLowerCase();
      rows = rows.filter((r: any) =>
        r.topic.toLowerCase().includes(q) ||
        r.usGaapStandard.toLowerCase().includes(q) ||
        r.ifrsStandard.toLowerCase().includes(q) ||
        r.criticalDifference.toLowerCase().includes(q) ||
        r.fpaImpact.toLowerCase().includes(q)
      );
    }
    return rows;
  }, [gaapVsIfrs, gvSearch, gvActiveArea]);

  React.useEffect(() => {
    setLoading(true);
    fetch(`/api/financial-reports?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, [activeCompanyId]);

  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";
  const fmt = (n: number) => `${sym}${Math.round(Math.abs(n)).toLocaleString()}`;

  async function downloadExcel(type: string, rows: any[], sheetName: string) {
    const XLSX = await import("xlsx");
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    XLSX.writeFile(wb, `${type}_${activeCompanyId}.xlsx`);
    toast.success(`${type} Excel downloaded`);
  }

  if (loading) return <div className="p-6"><Skeleton className="h-96 w-full" /></div>;
  if (!data) return <div className="p-6 text-sm text-muted-foreground">No data available.</div>;

  const { pnl, balanceSheet, cashFlow, trialBalance, totalDr, totalCr, equityStatement, oci, vatReturn, corpTax, payroll, payrollTotal, selfAssessment, bankReconciliation, kpis, ratios, disclosureNotes, summary } = data;

  // ============ Excel export rows ============
  const pnlRows = [
    ...pnl.revenue.map((r: any) => ({ Line: r.line, Note: r.note, Amount: r.amount })),
    ...pnl.costOfSales.map((r: any) => ({ Line: r.line, Note: r.note, Amount: r.amount })),
    ...pnl.operatingExpenses.map((r: any) => ({ Line: r.line, Note: r.note, Amount: r.amount })),
    { Line: "Operating Profit", Note: "", Amount: pnl.operatingProfit },
    { Line: "Corporation Tax", Note: "10", Amount: -pnl.corporationTax },
    { Line: "Net Profit", Note: "", Amount: pnl.netProfit },
  ];

  const bsRows = [
    ...balanceSheet.currentAssets.map((r: any) => ({ Line: r.line, Note: r.note, Amount: r.amount })),
    ...balanceSheet.nonCurrentAssets.map((r: any) => ({ Line: r.line, Note: r.note, Amount: r.amount })),
    ...balanceSheet.currentLiabilities.map((r: any) => ({ Line: r.line, Note: r.note, Amount: r.amount })),
    ...balanceSheet.equity.map((r: any) => ({ Line: r.line, Note: r.note, Amount: r.amount })),
  ];

  const tbRows = trialBalance.map((t: any) => ({
    "GL Code": t.code, "Account": t.account, "Type": t.type,
    "Final Dr": t.finalDr, "Final Cr": t.finalCr,
  }));

  const iconFor = (name: string) => {
    const map: Record<string, any> = {
      TrendingUp, Landmark, Building2, LineChart, Home, HardHat, ShoppingBag, Cloud, Coins, BookOpen, Layers,
      Receipt, Building, Network, Globe, Wallet, Package, Brain, MapPin,
    };
    return map[name] ?? BookOpen;
  };
  const colorFor = (c: string) => {
    const map: Record<string, string> = {
      emerald: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
      rose: "bg-rose-500/15 text-rose-700 dark:text-rose-300 border-rose-500/30",
      blue: "bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-500/30",
      violet: "bg-violet-500/15 text-violet-700 dark:text-violet-300 border-violet-500/30",
      amber: "bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30",
      orange: "bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-500/30",
      pink: "bg-pink-500/15 text-pink-700 dark:text-pink-300 border-pink-500/30",
      cyan: "bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 border-cyan-500/30",
      yellow: "bg-yellow-500/15 text-yellow-700 dark:text-yellow-300 border-yellow-500/30",
      slate: "bg-slate-500/15 text-slate-700 dark:text-slate-300 border-slate-500/30",
      teal: "bg-teal-500/15 text-teal-700 dark:text-teal-300 border-teal-500/30",
    };
    return map[c] ?? map.slate;
  };

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Financial Reports</h1>
          <p className="text-sm text-muted-foreground">
            10 reports — Concepts (laws), GAAP vs IFRS comparison, OCI Report, P&L (incl. OCI), Balance Sheet, Cash Flow, Trial Balance, Equity, VAT/Tax, Payroll. All per IAS 1 / FRS 102 / US GAAP — data sourced from the uploaded TechFlow UK Practice Set (Dr = Cr = £2,965,683).
          </p>
        </div>
        <Select value={standard} onValueChange={setStandard}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="IFRS">IFRS (IAS 1)</SelectItem>
            <SelectItem value="US-GAAP">US GAAP (FASB ASC)</SelectItem>
            <SelectItem value="UK-FRS-102">UK FRS 102 Section 1A</SelectItem>
            <SelectItem value="German-HGB">German HGB</SelectItem>
            <SelectItem value="French-PCG">French PCG</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">
        {[
          { label: "Revenue", value: fmt(summary.revenue) },
          { label: "Gross Profit", value: fmt(summary.grossProfit) },
          { label: "Net Profit", value: fmt(summary.netProfit) },
          { label: "Total Comprehensive Income", value: fmt(summary.totalComprehensiveIncome), highlight: true },
          { label: "Total Assets", value: fmt(summary.totalAssets) },
          { label: "Equity (incl. OCI Reserve)", value: fmt(summary.totalEquity) },
          { label: "Cash", value: fmt(summary.cashAtBank) },
        ].map((k) => (
          <Card key={k.label} className={k.highlight ? "border-teal-500/40 bg-teal-500/5" : ""}><CardContent className="py-3">
            <div className="text-xs text-muted-foreground">{k.label}</div>
            <div className={"text-lg font-bold " + (k.highlight ? "text-teal-700 dark:text-teal-300" : "")}>{k.value}</div>
          </CardContent></Card>
        ))}
      </div>

      <Tabs defaultValue="concepts">
        <TabsList className="grid w-full grid-cols-4 md:grid-cols-10">
          <TabsTrigger value="concepts" className="bg-emerald-500/10 font-semibold">1. Concepts</TabsTrigger>
          <TabsTrigger value="gaap-vs-ifrs" className="bg-amber-500/10 font-semibold">2. GAAP vs IFRS</TabsTrigger>
          <TabsTrigger value="oci" className="bg-teal-500/10 font-semibold">3. OCI Report</TabsTrigger>
          <TabsTrigger value="pnl">4. P&L</TabsTrigger>
          <TabsTrigger value="bs">5. Balance Sheet</TabsTrigger>
          <TabsTrigger value="cf">6. Cash Flow</TabsTrigger>
          <TabsTrigger value="tb">7. Trial Balance</TabsTrigger>
          <TabsTrigger value="equity">8. Equity</TabsTrigger>
          <TabsTrigger value="vat">9. VAT / Tax</TabsTrigger>
          <TabsTrigger value="payroll">10. Payroll</TabsTrigger>
        </TabsList>

        {/* ============================= TAB 1: CONCEPTS (LAWS) ============================= */}
        <TabsContent value="concepts" className="space-y-4">
          <Card className="border-l-4 border-l-emerald-500">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="size-5 text-emerald-600" />
                  Concepts Glossary — Laws on which FP&A Reports are Built
                </CardTitle>
                <CardDescription>
                  {concepts.stats.totalTerms} terms · {concepts.stats.totalCategories} categories ·
                  Source: {concepts.stats.sourceWorkbooks.join(" + ")}
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => downloadExcel(
                  "concepts-glossary",
                  concepts.allTerms.map((t: any) => ({
                    No: t.no, Term: t.term, Category: t.category,
                    Definition: t.definition, "USA/UK Note": t.usaUkNote, "Sheet Ref": t.sheetRef,
                  })),
                  "Concepts Glossary"
                )}
              >
                <FileSpreadsheet className="size-3.5" /> Excel
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Intro panel */}
              <div className="rounded-md bg-emerald-500/5 border-l-4 border-l-emerald-500 p-3 text-xs text-muted-foreground">
                {concepts.intro}
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Total Terms</div>
                  <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{concepts.stats.totalTerms}</div>
                </div>
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Categories</div>
                  <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{concepts.stats.totalCategories}</div>
                </div>
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Standards Covered</div>
                  <div className="text-sm font-bold">US GAAP · IFRS · UK FRS</div>
                </div>
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Industries</div>
                  <div className="text-sm font-bold">10 verticals</div>
                </div>
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Cadence</div>
                  <div className="text-sm font-bold">1 cat / day Wk 1</div>
                </div>
              </div>

              {/* Category chips */}
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setActiveCat("All")}
                  className={cn(
                    "rounded-md border px-2.5 py-1 text-xs font-medium transition",
                    activeCat === "All"
                      ? "border-emerald-500 bg-emerald-500 text-white"
                      : "bg-muted/30 hover:bg-muted/50"
                  )}
                >
                  All ({concepts.allTerms.length})
                </button>
                {concepts.categories.map((cat: any) => {
                  const Icon = iconFor(cat.icon);
                  const active = activeCat === cat.name;
                  return (
                    <button
                      key={cat.name}
                      onClick={() => setActiveCat(cat.name)}
                      className={cn(
                        "rounded-md border px-2.5 py-1 text-xs font-medium transition flex items-center gap-1.5",
                        active
                          ? "border-emerald-500 bg-emerald-500 text-white"
                          : cn(colorFor(cat.color), "hover:opacity-80")
                      )}
                    >
                      <Icon className="size-3" />
                      {cat.name} ({cat.terms.length})
                    </button>
                  );
                })}
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search 97 terms — e.g. 'WACC', 'CECL', 'IFRS 9', 'cap rate'..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full rounded-md border border-input bg-background pl-7 pr-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Terms table */}
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-xs">
                  <thead className="bg-emerald-700 text-white sticky top-0">
                    <tr>
                      <th className="px-2 py-2 text-left font-semibold w-10">#</th>
                      <th className="px-2 py-2 text-left font-semibold w-44">Term</th>
                      <th className="px-2 py-2 text-left font-semibold w-24">Category</th>
                      <th className="px-2 py-2 text-left font-semibold">Definition</th>
                      <th className="px-2 py-2 text-left font-semibold w-40">USA / UK Note</th>
                      <th className="px-2 py-2 text-left font-semibold w-40">Sheet Ref</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTerms.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-3 py-8 text-center text-muted-foreground">
                          No terms match "{search}"
                        </td>
                      </tr>
                    )}
                    {filteredTerms.map((t: any, i: number) => {
                      const cat = concepts.categories.find((c: any) => c.name === t.category);
                      const Icon = cat ? iconFor(cat.icon) : BookOpen;
                      return (
                        <tr key={t.no} className={cn("border-t align-top", i % 2 === 0 ? "bg-muted/20" : "")}>
                          <td className="px-2 py-2 font-mono text-muted-foreground">{t.no}</td>
                          <td className="px-2 py-2 font-semibold text-emerald-700 dark:text-emerald-300">{t.term}</td>
                          <td className="px-2 py-2">
                            <span className={cn("inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-[10px] font-medium", colorFor(cat?.color ?? "slate"))}>
                              <Icon className="size-2.5" />
                              {t.category}
                            </span>
                          </td>
                          <td className="px-2 py-2 text-muted-foreground leading-relaxed">{t.definition}</td>
                          <td className="px-2 py-2 text-muted-foreground">{t.usaUkNote}</td>
                          <td className="px-2 py-2 font-mono text-[10px] text-muted-foreground">{t.sheetRef}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="text-xs text-muted-foreground">
                Showing <strong>{filteredTerms.length}</strong> of <strong>{concepts.allTerms.length}</strong> terms
                {activeCat !== "All" && <> in <strong>{activeCat}</strong></>}
                {search.trim() && <> matching "<strong>{search}</strong>"</>}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============================= TAB 2: GAAP vs IFRS ============================= */}
        <TabsContent value="gaap-vs-ifrs" className="space-y-4">
          <Card className="border-l-4 border-l-amber-500">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Network className="size-5 text-amber-600" />
                  US GAAP vs IFRS — Framework Comparison for FP&A Professionals
                </CardTitle>
                <CardDescription>
                  {gaapVsIfrs.stats.totalRows} comparison rows · {gaapVsIfrs.stats.totalAreas} areas ·
                  Source: {gaapVsIfrs.stats.sourceWorkbook}
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => downloadExcel(
                  "gaap-vs-ifrs",
                  gaapVsIfrs.allRows.map((r: any) => ({
                    No: r.no, Topic: r.topic, Area: r.area,
                    "US GAAP Standard": r.usGaapStandard, "IFRS Standard": r.ifrsStandard,
                    "EU Status": r.euStatus, "Critical Difference": r.criticalDifference,
                    "FP&A Impact": r.fpaImpact, "Forecast Adjustment": r.forecastAdjustment,
                  })),
                  "GAAP vs IFRS"
                )}
              >
                <FileSpreadsheet className="size-3.5" /> Excel
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Intro panel */}
              <div className="rounded-md bg-amber-500/5 border-l-4 border-l-amber-500 p-3 text-xs text-muted-foreground">
                {gaapVsIfrs.intro}
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Comparison Rows</div>
                  <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{gaapVsIfrs.stats.totalRows}</div>
                </div>
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Areas</div>
                  <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{gaapVsIfrs.stats.totalAreas}</div>
                </div>
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Jurisdictional Scope</div>
                  <div className="text-xs font-bold leading-tight">US GAAP · IFRS · IFRS-EU</div>
                </div>
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Target Audience</div>
                  <div className="text-xs font-bold leading-tight">FP&A — Multi-jurisdiction</div>
                </div>
                <div className="rounded-md border p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Updated</div>
                  <div className="text-xs font-bold">{gaapVsIfrs.stats.lastUpdated}</div>
                </div>
              </div>

              {/* Area filter chips */}
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setGvActiveArea("All")}
                  className={cn(
                    "rounded-md border px-2.5 py-1 text-xs font-medium transition",
                    gvActiveArea === "All"
                      ? "border-amber-500 bg-amber-500 text-white"
                      : "bg-muted/30 hover:bg-muted/50"
                  )}
                >
                  All ({gaapVsIfrs.allRows.length})
                </button>
                {gaapVsIfrs.areas.map((area: any) => {
                  const Icon = iconFor(area.icon);
                  const active = gvActiveArea === area.name;
                  return (
                    <button
                      key={area.name}
                      onClick={() => setGvActiveArea(area.name)}
                      className={cn(
                        "rounded-md border px-2.5 py-1 text-xs font-medium transition flex items-center gap-1.5",
                        active
                          ? "border-amber-500 bg-amber-500 text-white"
                          : cn(colorFor(area.color), "hover:opacity-80")
                      )}
                    >
                      <Icon className="size-3" />
                      {area.name} ({area.rows.length})
                    </button>
                  );
                })}
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search comparisons — e.g. 'LIFO', 'CECL', 'VIE', 'IAS 16', 'goodwill'..."
                  value={gvSearch}
                  onChange={(e) => setGvSearch(e.target.value)}
                  className="w-full rounded-md border border-input bg-background pl-7 pr-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* Comparison table */}
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-xs">
                  <thead className="bg-amber-700 text-white sticky top-0">
                    <tr>
                      <th className="px-2 py-2 text-left font-semibold w-8">#</th>
                      <th className="px-2 py-2 text-left font-semibold w-40">Topic</th>
                      <th className="px-2 py-2 text-left font-semibold w-44">US GAAP Standard</th>
                      <th className="px-2 py-2 text-left font-semibold w-44">IFRS Standard</th>
                      <th className="px-2 py-2 text-left font-semibold w-32">EU Status</th>
                      <th className="px-2 py-2 text-left font-semibold">Critical Difference</th>
                      <th className="px-2 py-2 text-left font-semibold">FP&A Impact</th>
                      <th className="px-2 py-2 text-left font-semibold">Forecast Adjustment</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredGvRows.length === 0 && (
                      <tr>
                        <td colSpan={8} className="px-3 py-8 text-center text-muted-foreground">
                          No comparisons match "{gvSearch}"
                        </td>
                      </tr>
                    )}
                    {filteredGvRows.map((r: any, i: number) => {
                      const area = gaapVsIfrs.areas.find((a: any) => a.name === r.area);
                      const Icon = area ? iconFor(area.icon) : BookOpen;
                      return (
                        <tr key={r.no} className={cn("border-t align-top", i % 2 === 0 ? "bg-muted/20" : "")}>
                          <td className="px-2 py-2 font-mono text-muted-foreground">{r.no}</td>
                          <td className="px-2 py-2 font-semibold text-amber-700 dark:text-amber-300">
                            <div>{r.topic}</div>
                            <span className={cn("mt-1 inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-[10px] font-medium", colorFor(area?.color ?? "slate"))}>
                              <Icon className="size-2.5" />
                              {r.area}
                            </span>
                          </td>
                          <td className="px-2 py-2 text-blue-700 dark:text-blue-300 font-medium">{r.usGaapStandard}</td>
                          <td className="px-2 py-2 text-emerald-700 dark:text-emerald-300 font-medium">{r.ifrsStandard}</td>
                          <td className="px-2 py-2 text-muted-foreground italic">{r.euStatus}</td>
                          <td className="px-2 py-2 text-muted-foreground leading-relaxed">{r.criticalDifference}</td>
                          <td className="px-2 py-2 text-muted-foreground leading-relaxed">{r.fpaImpact}</td>
                          <td className="px-2 py-2 text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-500/5">
                            <span className="font-semibold text-[10px] uppercase block mb-1 text-slate-500">Action:</span>
                            {r.forecastAdjustment}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="text-xs text-muted-foreground">
                Showing <strong>{filteredGvRows.length}</strong> of <strong>{gaapVsIfrs.allRows.length}</strong> comparisons
                {gvActiveArea !== "All" && <> in <strong>{gvActiveArea}</strong></>}
                {gvSearch.trim() && <> matching "<strong>{gvSearch}</strong>"</>}
              </div>

              {/* Standards panel */}
              <div className="rounded-md border-l-4 border-l-amber-500 bg-amber-500/5 p-3">
                <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Jurisdictional Standards Reference</div>
                <div className="grid gap-2 text-xs md:grid-cols-3">
                  <div className="rounded border border-blue-500/30 p-2">
                    <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">US GAAP (FASB)</div>
                    <div className="text-muted-foreground leading-relaxed">
                      Financial Accounting Standards Board · Accounting Standards Codification (ASC) · SEC-registrant companies · Primary users: US public companies and US subsidiaries of foreign groups.
                    </div>
                  </div>
                  <div className="rounded border border-emerald-500/30 p-2">
                    <div className="font-semibold text-emerald-700 dark:text-emerald-300 mb-1">IFRS (IASB)</div>
                    <div className="text-muted-foreground leading-relaxed">
                      International Accounting Standards Board · International Financial Reporting Standards · Required in 140+ jurisdictions including UK, EU, Canada, Australia, Brazil, South Africa.
                    </div>
                  </div>
                  <div className="rounded border border-amber-500/30 p-2">
                    <div className="font-semibold text-amber-700 dark:text-amber-300 mb-1">EU (IFRS-EU)</div>
                    <div className="text-muted-foreground leading-relaxed">
                      IFRS as endorsed by the European Commission via Accounting Directive · Substantively identical to IFRS as issued by IASB · Carve-outs for IFRS 9 (transitional relief) and IAS 39 (legacy).
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============================= TAB 3: OCI REPORT (Statement of Comprehensive Income) ============================= */}
        <TabsContent value="oci" className="space-y-4">
          <Card className="border-l-4 border-l-teal-500">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="size-5 text-teal-600" />
                  Statement of Comprehensive Income — Other Comprehensive Income (OCI)
                </CardTitle>
                <CardDescription>
                  Year Ended 31 December 2025 · IAS 1.82 · ASC 220 · FRS 102 s6 · EU IFRS-EU · net of deferred tax per IAS 12.91
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => downloadExcel(
                  "oci-statement",
                  [
                    { Section: "Profit for the Year", Item: "Net profit per P&L", Amount: oci.netProfit, Standard: "IAS 1" },
                    ...oci.itemsNotReclassified.map((it: any) => ({ Section: "(a) Not Reclassified to P&L", Item: it.item, Amount: it.amount, Standard: it.standard })),
                    ...oci.itemsMayBeReclassified.map((it: any) => ({ Section: "(b) May be Reclassified to P&L", Item: it.item, Amount: it.amount, Standard: it.standard })),
                    { Section: "TOTALS", Item: "Total OCI (gross)", Amount: oci.totalOciGross, Standard: "IAS 1.82" },
                    { Section: "TOTALS", Item: "Tax on OCI (25%)", Amount: -oci.taxOnOciItems, Standard: "IAS 12.91" },
                    { Section: "TOTALS", Item: "Total OCI (net of tax)", Amount: oci.totalOciNetOfTax, Standard: "IAS 1.82" },
                    { Section: "TOTALS", Item: "Total Comprehensive Income", Amount: oci.totalComprehensiveIncome, Standard: "IAS 1.82" },
                  ],
                  "OCI Statement"
                )}
              >
                <FileSpreadsheet className="size-3.5" /> Excel
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* OCI KPI strip */}
              <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6">
                <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Net Profit</div>
                  <div className="font-bold text-emerald-700 dark:text-emerald-300">{fmt(oci.netProfit)}</div>
                </div>
                <div className="rounded-md border border-violet-500/30 bg-violet-500/5 p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Non-Recyclable (gross)</div>
                  <div className="font-bold text-violet-700 dark:text-violet-300">{fmt(oci.ociNotReclassifiedGross)}</div>
                </div>
                <div className="rounded-md border border-pink-500/30 bg-pink-500/5 p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Recyclable (gross)</div>
                  <div className="font-bold text-pink-700 dark:text-pink-300">{fmt(oci.ociMayBeReclassifiedGross)}</div>
                </div>
                <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Total OCI (gross)</div>
                  <div className="font-bold text-amber-700 dark:text-amber-300">{fmt(oci.totalOciGross)}</div>
                </div>
                <div className="rounded-md border border-rose-500/30 bg-rose-500/5 p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Tax on OCI @ 25%</div>
                  <div className="font-bold text-rose-700 dark:text-rose-300">({fmt(oci.taxOnOciItems)})</div>
                </div>
                <div className="rounded-md border border-teal-500/40 bg-teal-500/10 p-2 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground">Total Comp. Income</div>
                  <div className="font-bold text-teal-700 dark:text-teal-300">{fmt(oci.totalComprehensiveIncome)}</div>
                </div>
              </div>

              {/* Main OCI Statement Table */}
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-teal-700 text-white">
                    <tr>
                      <th className="px-3 py-2 text-left font-semibold w-96">Item</th>
                      <th className="px-3 py-2 text-center font-semibold w-28">Standard</th>
                      <th className="px-3 py-2 text-right font-semibold w-32">Gross £</th>
                      <th className="px-3 py-2 text-right font-semibold w-32">Tax £</th>
                      <th className="px-3 py-2 text-right font-semibold w-32">Net £</th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Profit for the year */}
                    <tr className="border-t-2 bg-emerald-500/15 font-bold">
                      <td className="px-3 py-2" colSpan={5}>
                        <span className="uppercase text-xs">Profit for the Year (from Income Statement)</span>
                      </td>
                    </tr>
                    <tr className="border-t font-bold">
                      <td className="px-3 py-2">Profit for the year attributable to owners</td>
                      <td className="px-3 py-2 text-center text-[10px] text-muted-foreground">IAS 1</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(oci.netProfit)}</td>
                      <td className="px-3 py-2 text-right font-mono">—</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(oci.netProfit)}</td>
                    </tr>

                    {/* Section header */}
                    <tr className="border-t-2 bg-teal-700 text-white">
                      <td className="px-3 py-2 font-semibold uppercase text-xs" colSpan={5}>
                        Other Comprehensive Income
                      </td>
                    </tr>
                    <tr className="bg-teal-500/10 text-[10px] text-muted-foreground">
                      <td className="px-3 py-1.5 italic" colSpan={5}>
                        Per IAS 1.82 — presented in two categories with deferred tax per IAS 12.91
                      </td>
                    </tr>

                    {/* (a) Not Reclassified */}
                    <tr className="border-t bg-muted/40 font-semibold">
                      <td className="px-3 py-1.5 text-xs uppercase text-muted-foreground" colSpan={5}>
                        (a) Items that will NOT be reclassified to profit or loss (non-recyclable)
                      </td>
                    </tr>
                    {oci.itemsNotReclassified.map((it: any, i: number) => (
                      <tr key={`nr-${i}`} className="border-t bg-teal-500/5">
                        <td className="px-3 py-1.5 text-sm">{it.item}<div className="text-[10px] text-muted-foreground mt-0.5">{it.note}</div></td>
                        <td className="px-3 py-1.5 text-center text-[10px]"><Badge variant="outline" className="text-[10px] border-teal-500/30 text-teal-700 dark:text-teal-300">{it.standard}</Badge></td>
                        <td className="px-3 py-1.5 text-right font-mono text-sm">{it.amount < 0 ? `(${fmt(it.amount)})` : fmt(it.amount)}</td>
                        <td className="px-3 py-1.5 text-right font-mono text-sm text-muted-foreground">({fmt(Math.abs(it.amount) * 0.25)})</td>
                        <td className="px-3 py-1.5 text-right font-mono text-sm">{it.amount < 0 ? `(${fmt(Math.abs(it.amount) * 0.75)})` : fmt(it.amount * 0.75)}</td>
                      </tr>
                    ))}
                    <tr className="border-t bg-teal-500/15 font-semibold">
                      <td className="px-3 py-1.5 text-xs" colSpan={2}>Subtotal — non-recyclable</td>
                      <td className="px-3 py-1.5 text-right font-mono text-sm">{fmt(oci.ociNotReclassifiedGross)}</td>
                      <td className="px-3 py-1.5 text-right font-mono text-sm text-muted-foreground">({fmt(Math.abs(oci.ociNotReclassifiedGross) * 0.25)})</td>
                      <td className="px-3 py-1.5 text-right font-mono text-sm">{fmt(oci.ociNotReclassifiedGross * 0.75)}</td>
                    </tr>

                    {/* (b) May be Reclassified */}
                    <tr className="border-t bg-muted/40 font-semibold">
                      <td className="px-3 py-1.5 text-xs uppercase text-muted-foreground" colSpan={5}>
                        (b) Items that MAY be reclassified subsequently to profit or loss (recyclable)
                      </td>
                    </tr>
                    {oci.itemsMayBeReclassified.map((it: any, i: number) => (
                      <tr key={`r-${i}`} className="border-t bg-teal-500/5">
                        <td className="px-3 py-1.5 text-sm">{it.item}<div className="text-[10px] text-muted-foreground mt-0.5">{it.note}</div></td>
                        <td className="px-3 py-1.5 text-center text-[10px]"><Badge variant="outline" className="text-[10px] border-teal-500/30 text-teal-700 dark:text-teal-300">{it.standard}</Badge></td>
                        <td className="px-3 py-1.5 text-right font-mono text-sm">{it.amount < 0 ? `(${fmt(it.amount)})` : fmt(it.amount)}</td>
                        <td className="px-3 py-1.5 text-right font-mono text-sm text-muted-foreground">({fmt(Math.abs(it.amount) * 0.25)})</td>
                        <td className="px-3 py-1.5 text-right font-mono text-sm">{it.amount < 0 ? `(${fmt(Math.abs(it.amount) * 0.75)})` : fmt(it.amount * 0.75)}</td>
                      </tr>
                    ))}
                    <tr className="border-t bg-teal-500/15 font-semibold">
                      <td className="px-3 py-1.5 text-xs" colSpan={2}>Subtotal — recyclable</td>
                      <td className="px-3 py-1.5 text-right font-mono text-sm">{fmt(oci.ociMayBeReclassifiedGross)}</td>
                      <td className="px-3 py-1.5 text-right font-mono text-sm text-muted-foreground">({fmt(Math.abs(oci.ociMayBeReclassifiedGross) * 0.25)})</td>
                      <td className="px-3 py-1.5 text-right font-mono text-sm">{fmt(oci.ociMayBeReclassifiedGross * 0.75)}</td>
                    </tr>

                    {/* Totals */}
                    <tr className="border-t-2 bg-teal-600/30 font-bold">
                      <td className="px-3 py-2 text-sm" colSpan={2}>TOTAL OTHER COMPREHENSIVE INCOME (gross of tax)</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(oci.totalOciGross)}</td>
                      <td className="px-3 py-2 text-right font-mono text-rose-600 dark:text-rose-400">({fmt(oci.taxOnOciItems)})</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(oci.totalOciNetOfTax)}</td>
                    </tr>
                    <tr className="border-t-2 bg-teal-700 font-bold text-white text-lg">
                      <td className="px-3 py-3 text-base" colSpan={4}>TOTAL COMPREHENSIVE INCOME FOR THE YEAR</td>
                      <td className="px-3 py-3 text-right font-mono text-base">{fmt(oci.totalComprehensiveIncome)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Accumulated OCI Reserve Movement */}
              <Card className="border-l-4 border-l-violet-500">
                <CardHeader><CardTitle className="text-base">Accumulated OCI Reserve — Movement Schedule</CardTitle></CardHeader>
                <CardContent>
                  <div className="overflow-x-auto rounded-md border">
                    <table className="w-full text-sm">
                      <thead className="bg-violet-700 text-white">
                        <tr>
                          <th className="px-3 py-2 text-left font-semibold">Component</th>
                          <th className="px-3 py-2 text-right font-semibold">Opening £</th>
                          <th className="px-3 py-2 text-right font-semibold">Movement £</th>
                          <th className="px-3 py-2 text-right font-semibold">Closing £</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-t">
                          <td className="px-3 py-2">Accumulated OCI Reserve (per IAS 1.106)</td>
                          <td className="px-3 py-2 text-right font-mono">{fmt(oci.openingAccumulatedOci)}</td>
                          <td className="px-3 py-2 text-right font-mono text-teal-700 dark:text-teal-300">+{fmt(oci.totalOciNetOfTax)}</td>
                          <td className="px-3 py-2 text-right font-mono font-bold text-teal-700 dark:text-teal-300">{fmt(oci.closingAccumulatedOci)}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Standards panel */}
              <div className="rounded-md border-l-4 border-l-teal-500 bg-teal-500/5 p-3">
                <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Standards Applied — OCI Report</div>
                <div className="grid gap-2 text-xs md:grid-cols-4">
                  <div className="rounded border border-emerald-500/30 p-2">
                    <div className="font-semibold text-emerald-700 dark:text-emerald-300 mb-1">IFRS (IASB)</div>
                    <div className="text-muted-foreground leading-relaxed">{oci.standards.ifrs}</div>
                  </div>
                  <div className="rounded border border-blue-500/30 p-2">
                    <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">US GAAP (FASB)</div>
                    <div className="text-muted-foreground leading-relaxed">{oci.standards.usGaap}</div>
                  </div>
                  <div className="rounded border border-amber-500/30 p-2">
                    <div className="font-semibold text-amber-700 dark:text-amber-300 mb-1">UK FRS 102</div>
                    <div className="text-muted-foreground leading-relaxed">FRS 102 s6 — Statement of Comprehensive Income. Small companies (Section 1A) can present a simplified version, but full OCI required when relevant items arise.</div>
                  </div>
                  <div className="rounded border border-violet-500/30 p-2">
                    <div className="font-semibold text-violet-700 dark:text-violet-300 mb-1">EU (IFRS-EU)</div>
                    <div className="text-muted-foreground leading-relaxed">{oci.standards.euIfrs}</div>
                  </div>
                </div>
              </div>

              {/* Disclosure Note 21 */}
              <div className="rounded-md border-l-4 border-l-teal-500 bg-teal-500/5 p-4">
                <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Disclosure Note 21 — Other Comprehensive Income (IAS 1.82 / ASC 220 / IFRS-EU)</div>
                <p className="text-xs text-muted-foreground leading-relaxed">{oci.disclosureNote}</p>
              </div>

              {/* Recycling Summary Table */}
              <div className="rounded-md border p-3">
                <div className="text-sm font-semibold mb-2">Recycling (Reclassification) Summary</div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/40">
                      <tr>
                        <th className="px-2 py-1.5 text-left font-semibold">Item</th>
                        <th className="px-2 py-1.5 text-center font-semibold">Recyclable?</th>
                        <th className="px-2 py-1.5 text-left font-semibold">When Recycled?</th>
                        <th className="px-2 py-1.5 text-left font-semibold">P&L Line on Recycling</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-t"><td className="px-2 py-1.5">PPE Revaluation Surplus (IAS 16)</td><td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[10px] border-rose-500/30 text-rose-700 dark:text-rose-300">No</Badge></td><td className="px-2 py-1.5">On disposal — direct transfer to Retained Earnings (NOT through P&L)</td><td className="px-2 py-1.5">N/A</td></tr>
                      <tr className="border-t bg-muted/20"><td className="px-2 py-1.5">Pension Remeasurement (IAS 19)</td><td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[10px] border-rose-500/30 text-rose-700 dark:text-rose-300">No</Badge></td><td className="px-2 py-1.5">Never recycled — non-recyclable per IAS 19 (post-2013 revision)</td><td className="px-2 py-1.5">N/A</td></tr>
                      <tr className="border-t"><td className="px-2 py-1.5">FVOCI Equity Instruments (IFRS 9)</td><td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[10px] border-rose-500/30 text-rose-700 dark:text-rose-300">No</Badge></td><td className="px-2 py-1.5">Never recycled — irrevocable election at acquisition</td><td className="px-2 py-1.5">N/A (only dividends in P&L)</td></tr>
                      <tr className="border-t bg-muted/20"><td className="px-2 py-1.5">FX Translation (IAS 21)</td><td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[10px] border-emerald-500/30 text-emerald-700 dark:text-emerald-300">Yes</Badge></td><td className="px-2 py-1.5">On disposal of foreign operation</td><td className="px-2 py-1.5">Gain/loss on disposal (P&L)</td></tr>
                      <tr className="border-t"><td className="px-2 py-1.5">Cash Flow Hedge (IFRS 9)</td><td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[10px] border-emerald-500/30 text-emerald-700 dark:text-emerald-300">Yes</Badge></td><td className="px-2 py-1.5">When hedged forecast transaction affects P&L</td><td className="px-2 py-1.5">Same P&L line as hedged item</td></tr>
                      <tr className="border-t bg-muted/20"><td className="px-2 py-1.5">Debt at FVOCI (IFRS 9)</td><td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[10px] border-emerald-500/30 text-emerald-700 dark:text-emerald-300">Yes</Badge></td><td className="px-2 py-1.5">On derecognition of the debt instrument</td><td className="px-2 py-1.5">Interest income / gain on disposal</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============================= TAB 4: P&L ============================= */}
        <TabsContent value="pnl" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Income Statement (Profit and Loss Account)</CardTitle>
                <CardDescription>Year Ended 31 December 2025 · {activeCompany?.currency} · {standard}</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => downloadExcel("pnl", pnlRows, "P&L")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-700 text-white">
                    <tr><th className="px-3 py-2 text-left font-semibold">Item</th><th className="px-3 py-2 w-16 text-center font-semibold">Note</th><th className="px-3 py-2 text-right font-semibold">£</th><th className="px-3 py-2 text-right font-semibold">2024 Comp.</th></tr>
                  </thead>
                  <tbody>
                    {pnl.revenue.map((r: any, i: number) => (
                      <tr key={i} className={cn("border-t", r.isTotal && "bg-emerald-500/15 font-bold", i % 2 === 0 && !r.isTotal && "bg-muted/20")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-center text-xs text-muted-foreground">{r.note}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(r.amount)}</td>
                        <td className="px-3 py-1.5 text-right text-muted-foreground">{r.comparative ? fmt(r.comparative) : "—"}</td>
                      </tr>
                    ))}
                    {pnl.costOfSales.map((r: any, i: number) => (
                      <tr key={`cs-${i}`} className={cn("border-t", r.isTotal && "bg-rose-500/15 font-bold", i % 2 === 0 && !r.isTotal && "bg-muted/20")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-center text-xs text-muted-foreground">{r.note}</td>
                        <td className="px-3 py-1.5 text-right font-mono">({fmt(r.amount)})</td>
                        <td className="px-3 py-1.5 text-right text-muted-foreground">—</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 bg-emerald-600 font-bold text-white"><td className="px-3 py-2" colSpan={2}>GROSS PROFIT</td><td className="px-3 py-2 text-right font-mono">{fmt(pnl.grossProfit)}</td><td className="px-3 py-2 text-right">—</td></tr>
                    {pnl.operatingExpenses.map((r: any, i: number) => (
                      <tr key={`op-${i}`} className={cn("border-t", r.isTotal && "bg-rose-500/15 font-bold", i % 2 === 0 && !r.isTotal && "bg-muted/20")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-center text-xs text-muted-foreground">{r.note}</td>
                        <td className="px-3 py-1.5 text-right font-mono">({fmt(r.amount)})</td>
                        <td className="px-3 py-1.5 text-right text-muted-foreground">—</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 bg-emerald-600 font-bold text-white"><td className="px-3 py-2" colSpan={2}>OPERATING PROFIT</td><td className="px-3 py-2 text-right font-mono">{fmt(pnl.operatingProfit)}</td><td>—</td></tr>
                    <tr className="border-t bg-amber-500/15"><td className="px-3 py-2" colSpan={2}>Corporation Tax (Note 10)</td><td className="px-3 py-2 text-right font-mono">({fmt(pnl.corporationTax)})</td><td>—</td></tr>
                    <tr className="border-t-2 bg-emerald-700 font-bold text-white text-lg"><td className="px-3 py-3" colSpan={2}>PROFIT FOR THE YEAR</td><td className="px-3 py-3 text-right font-mono">{fmt(pnl.netProfit)}</td><td>—</td></tr>

                    {/* ============ OTHER COMPREHENSIVE INCOME (per IAS 1 / ASC 220 / IFRS-EU) ============ */}
                    <tr className="border-t-2 bg-teal-700 text-white"><td className="px-3 py-2 font-semibold uppercase text-xs" colSpan={4}>Other Comprehensive Income</td></tr>
                    <tr className="bg-teal-500/10 text-[11px] text-muted-foreground"><td className="px-3 py-1.5 italic" colSpan={4}>
                      Per IAS 1.82 — two categories: (a) items not reclassified to P&amp;L (non-recyclable), (b) items that may be reclassified (recyclable). All items shown net of deferred tax per IAS 12.91.
                    </td></tr>
                    {/* (a) Items NOT reclassified to P&L */}
                    <tr className="bg-muted/40"><td className="px-3 py-1.5 text-xs font-semibold uppercase text-muted-foreground" colSpan={4}>Items that will NOT be reclassified to profit or loss (non-recyclable)</td></tr>
                    {oci.itemsNotReclassified.map((it: any, i: number) => (
                      <tr key={`nr-${i}`} className="border-t bg-teal-500/5">
                        <td className="px-3 py-1.5 text-sm">{it.item}</td>
                        <td className="px-3 py-1.5 text-center text-xs"><Badge variant="outline" className="text-[10px] border-teal-500/30 text-teal-700 dark:text-teal-300">{it.standard}</Badge></td>
                        <td className="px-3 py-1.5 text-right font-mono text-sm">{it.amount < 0 ? `(${fmt(it.amount)})` : fmt(it.amount)}</td>
                        <td className="px-3 py-1.5 text-right text-muted-foreground">—</td>
                      </tr>
                    ))}
                    <tr className="border-t bg-teal-500/15 font-semibold"><td className="px-3 py-1.5 text-xs" colSpan={2}>Subtotal — non-recyclable (gross)</td><td className="px-3 py-1.5 text-right font-mono text-sm">{fmt(oci.ociNotReclassifiedGross)}</td><td>—</td></tr>
                    {/* (b) Items MAY be reclassified to P&L */}
                    <tr className="bg-muted/40"><td className="px-3 py-1.5 text-xs font-semibold uppercase text-muted-foreground" colSpan={4}>Items that MAY be reclassified subsequently to profit or loss (recyclable)</td></tr>
                    {oci.itemsMayBeReclassified.map((it: any, i: number) => (
                      <tr key={`r-${i}`} className="border-t bg-teal-500/5">
                        <td className="px-3 py-1.5 text-sm">{it.item}</td>
                        <td className="px-3 py-1.5 text-center text-xs"><Badge variant="outline" className="text-[10px] border-teal-500/30 text-teal-700 dark:text-teal-300">{it.standard}</Badge></td>
                        <td className="px-3 py-1.5 text-right font-mono text-sm">{it.amount < 0 ? `(${fmt(it.amount)})` : fmt(it.amount)}</td>
                        <td className="px-3 py-1.5 text-right text-muted-foreground">—</td>
                      </tr>
                    ))}
                    <tr className="border-t bg-teal-500/15 font-semibold"><td className="px-3 py-1.5 text-xs" colSpan={2}>Subtotal — recyclable (gross)</td><td className="px-3 py-1.5 text-right font-mono text-sm">{fmt(oci.ociMayBeReclassifiedGross)}</td><td>—</td></tr>
                    {/* Total OCI gross */}
                    <tr className="border-t bg-teal-600/30 font-bold"><td className="px-3 py-2 text-sm" colSpan={2}>TOTAL OTHER COMPREHENSIVE INCOME (gross)</td><td className="px-3 py-2 text-right font-mono">{fmt(oci.totalOciGross)}</td><td>—</td></tr>
                    {/* Tax on OCI */}
                    <tr className="border-t bg-muted/20"><td className="px-3 py-1.5 text-sm" colSpan={2}>Less: Income tax relating to OCI (IAS 12.91 @ 25%)</td><td className="px-3 py-1.5 text-right font-mono text-sm">({fmt(oci.taxOnOciItems)})</td><td>—</td></tr>
                    {/* Total OCI net of tax */}
                    <tr className="border-t bg-teal-600 font-bold text-white"><td className="px-3 py-2 text-sm" colSpan={2}>TOTAL OCI FOR THE YEAR (net of tax)</td><td className="px-3 py-2 text-right font-mono">{fmt(oci.totalOciNetOfTax)}</td><td>—</td></tr>
                    {/* TOTAL COMPREHENSIVE INCOME */}
                    <tr className="border-t-2 bg-teal-700 font-bold text-white text-lg"><td className="px-3 py-3 text-base" colSpan={2}>TOTAL COMPREHENSIVE INCOME FOR THE YEAR</td><td className="px-3 py-3 text-right font-mono text-base">{fmt(oci.totalComprehensiveIncome)}</td><td>—</td></tr>
                  </tbody>
                </table>
              </div>

              {/* OCI Standards & Disclosure panel */}
              <div className="mt-4 rounded-md border-l-4 border-l-teal-500 bg-teal-500/5 p-4 space-y-3">
                <div className="text-xs font-semibold uppercase text-muted-foreground">OCI Standards Applied — IFRS · US GAAP · EU</div>
                <div className="grid gap-2 text-xs md:grid-cols-3">
                  <div className="rounded border border-teal-500/30 p-2">
                    <div className="font-semibold text-teal-700 dark:text-teal-300 mb-1">IFRS (IASB)</div>
                    <div className="text-muted-foreground leading-relaxed">{oci.standards.ifrs}</div>
                  </div>
                  <div className="rounded border border-teal-500/30 p-2">
                    <div className="font-semibold text-teal-700 dark:text-teal-300 mb-1">US GAAP (FASB ASC)</div>
                    <div className="text-muted-foreground leading-relaxed">{oci.standards.usGaap}</div>
                  </div>
                  <div className="rounded border border-teal-500/30 p-2">
                    <div className="font-semibold text-teal-700 dark:text-teal-300 mb-1">EU (IFRS-EU)</div>
                    <div className="text-muted-foreground leading-relaxed">{oci.standards.euIfrs}</div>
                  </div>
                </div>
                <div className="rounded border border-teal-500/20 bg-teal-500/5 p-3 text-xs text-muted-foreground leading-relaxed">
                  <strong className="text-teal-700 dark:text-teal-300">Disclosure Note 21 — Other Comprehensive Income:</strong> {oci.disclosureNote}
                </div>
                {/* Reconciliation summary */}
                <div className="grid grid-cols-2 gap-2 md:grid-cols-5 text-xs">
                  <div className="rounded border p-2"><div className="text-muted-foreground text-[10px] uppercase">Net Profit (P&L)</div><div className="font-bold font-mono">{fmt(oci.netProfit)}</div></div>
                  <div className="rounded border p-2"><div className="text-muted-foreground text-[10px] uppercase">Non-Recyclable (gross)</div><div className="font-bold font-mono">{fmt(oci.ociNotReclassifiedGross)}</div></div>
                  <div className="rounded border p-2"><div className="text-muted-foreground text-[10px] uppercase">Recyclable (gross)</div><div className="font-bold font-mono">{fmt(oci.ociMayBeReclassifiedGross)}</div></div>
                  <div className="rounded border p-2"><div className="text-muted-foreground text-[10px] uppercase">Tax on OCI</div><div className="font-bold font-mono text-rose-600 dark:text-rose-400">({fmt(oci.taxOnOciItems)})</div></div>
                  <div className="rounded border border-teal-500/40 bg-teal-500/10 p-2"><div className="text-muted-foreground text-[10px] uppercase">Total Comp. Income</div><div className="font-bold font-mono text-teal-700 dark:text-teal-300">{fmt(oci.totalComprehensiveIncome)}</div></div>
                </div>
              </div>

              {/* Inline disclosures (must be part of financial statements per IAS 1) */}
              <div className="mt-4 rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-4">
                <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Disclosure Notes — Income Statement</div>
                <div className="space-y-2 text-xs text-muted-foreground">
                  {disclosureNotes.filter((n: any) => [2, 4, 5, 7, 8, 9].includes(n.note)).map((n: any) => (
                    <div key={n.note}><strong>Note {n.note} — {n.title}:</strong> {n.body}</div>
                  ))}
                </div>
              </div>

              {/* Ratios */}
              <div className="mt-3 grid grid-cols-3 gap-2 md:grid-cols-7">
                {ratios.map((r: any) => (
                  <div key={r.ratio} className={cn("rounded p-2 text-center", r.status === "healthy" ? "bg-emerald-500/10" : "bg-amber-500/10")}>
                    <div className="text-[10px] text-muted-foreground">{r.ratio}</div>
                    <div className="font-bold text-sm">{r.value}</div>
                    <div className="text-[9px] text-muted-foreground">{r.benchmark}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Balance Sheet */}
        <TabsContent value="bs" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Balance Sheet (Statement of Financial Position)</CardTitle>
                <CardDescription>As at 31 December 2025 · {activeCompany?.currency} · {standard}</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => downloadExcel("balance-sheet", bsRows, "Balance Sheet")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-700 text-white"><tr><th className="px-3 py-2 text-left font-semibold">Item</th><th className="px-3 py-2 w-16 text-center font-semibold">Note</th><th className="px-3 py-2 text-right font-semibold">£</th></tr></thead>
                  <tbody>
                    <tr className="bg-blue-500/15 font-semibold"><td className="px-3 py-1.5" colSpan={3}>ASSETS</td></tr>
                    <tr className="bg-muted/30 font-semibold text-xs"><td className="px-3 py-1.5" colSpan={3}>Current Assets</td></tr>
                    {balanceSheet.currentAssets.map((r: any, i: number) => (
                      <tr key={i} className={cn("border-t", r.isTotal && "bg-emerald-500/15 font-bold", i % 2 === 0 && !r.isTotal && "bg-muted/20")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-center text-xs text-muted-foreground">{r.note}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(r.amount)}</td>
                      </tr>
                    ))}
                    <tr className="bg-muted/30 font-semibold text-xs"><td className="px-3 py-1.5" colSpan={3}>Non-Current Assets</td></tr>
                    {balanceSheet.nonCurrentAssets.map((r: any, i: number) => (
                      <tr key={`nc-${i}`} className={cn("border-t", r.isTotal && "bg-emerald-500/15 font-bold", i % 2 === 0 && !r.isTotal && "bg-muted/20")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-center text-xs text-muted-foreground">{r.note}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(r.amount)}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 bg-emerald-600 font-bold text-white"><td className="px-3 py-2" colSpan={2}>TOTAL ASSETS</td><td className="px-3 py-2 text-right font-mono">{fmt(balanceSheet.totalAssets)}</td></tr>
                    <tr className="bg-rose-500/15 font-semibold"><td className="px-3 py-1.5" colSpan={3}>CURRENT LIABILITIES</td></tr>
                    {balanceSheet.currentLiabilities.map((r: any, i: number) => (
                      <tr key={`cl-${i}`} className={cn("border-t", r.isTotal && "bg-rose-500/15 font-bold", i % 2 === 0 && !r.isTotal && "bg-muted/20")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-center text-xs text-muted-foreground">{r.note}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(r.amount)}</td>
                      </tr>
                    ))}
                    <tr className="bg-violet-500/15 font-semibold"><td className="px-3 py-1.5" colSpan={3}>EQUITY</td></tr>
                    {balanceSheet.equity.map((r: any, i: number) => (
                      <tr key={`eq-${i}`} className={cn("border-t", r.isTotal && "bg-violet-500/15 font-bold", i % 2 === 0 && !r.isTotal && "bg-muted/20")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-center text-xs text-muted-foreground">{r.note}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(r.amount)}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 bg-emerald-700 font-bold text-white text-lg"><td className="px-3 py-3" colSpan={2}>TOTAL EQUITY AND LIABILITIES</td><td className="px-3 py-3 text-right font-mono">{fmt(balanceSheet.totalEquityAndLiabilities)}</td></tr>
                    <tr className="border-t bg-muted/40">
                      <td className="px-3 py-2 text-xs text-muted-foreground">Balance Check</td>
                      <td></td>
                      <td className="px-3 py-2 text-right">
                        <Badge variant={balanceSheet.balanceCheck === 0 ? "default" : "destructive"} className="text-[10px]">
                          {balanceSheet.balanceCheck === 0 ? <><CheckCircle2 className="size-3" /> Balanced</> : <><AlertTriangle className="size-3" /> Out of balance</>}
                        </Badge>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Inline disclosures for BS */}
              <div className="mt-4 rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-4">
                <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Disclosure Notes — Balance Sheet</div>
                <div className="space-y-2 text-xs text-muted-foreground">
                  {disclosureNotes.filter((n: any) => [1, 3, 4, 5, 6, 7, 8, 10, 12, 14].includes(n.note)).map((n: any) => (
                    <div key={n.note}><strong>Note {n.note} — {n.title}:</strong> {n.body}</div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cash Flow */}
        <TabsContent value="cf" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Cash Flow Statement (Indirect Method)</CardTitle><CardDescription>Year Ended 31 December 2025 · {activeCompany?.currency} · {standard}</CardDescription></CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-700 text-white"><tr><th className="px-3 py-2 text-left font-semibold">Item</th><th className="px-3 py-2 text-right font-semibold">£</th></tr></thead>
                  <tbody>
                    <tr className="bg-blue-500/15 font-semibold"><td className="px-3 py-1.5" colSpan={2}>OPERATING ACTIVITIES</td></tr>
                    {cashFlow.operating.map((r: any, i: number) => (
                      <tr key={i} className={cn("border-t", r.isTotal && "bg-emerald-500/15 font-bold", r.isHeader && "bg-muted/30 font-semibold text-xs", i % 2 === 0 && !r.isTotal && !r.isHeader && "bg-muted/20")}>
                        <td className="px-3 py-1.5">{r.isTotal || r.isHeader ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{r.amount !== 0 ? (r.amount < 0 ? `(${fmt(r.amount)})` : fmt(r.amount)) : ""}</td>
                      </tr>
                    ))}
                    <tr className="bg-amber-500/15 font-semibold"><td className="px-3 py-1.5" colSpan={2}>INVESTING ACTIVITIES</td></tr>
                    {cashFlow.investing.map((r: any, i: number) => (
                      <tr key={`inv-${i}`} className={cn("border-t", r.isTotal && "bg-amber-500/15 font-bold")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{r.amount < 0 ? `(${fmt(r.amount)})` : fmt(r.amount)}</td>
                      </tr>
                    ))}
                    <tr className="bg-violet-500/15 font-semibold"><td className="px-3 py-1.5" colSpan={2}>FINANCING ACTIVITIES</td></tr>
                    {cashFlow.financing.map((r: any, i: number) => (
                      <tr key={`fin-${i}`} className={cn("border-t", r.isTotal && "bg-violet-500/15 font-bold")}>
                        <td className="px-3 py-1.5">{r.isTotal ? <strong>{r.line}</strong> : r.line}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(r.amount)}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 bg-emerald-600 font-bold text-white text-lg"><td className="px-3 py-3">CLOSING CASH</td><td className="px-3 py-3 text-right font-mono">{fmt(cashFlow.closingCash)}</td></tr>
                  </tbody>
                </table>
              </div>
              {/* Bank reconciliation */}
              <div className="mt-3 rounded-md border p-3">
                <div className="text-xs font-semibold mb-2">Bank Reconciliation</div>
                <div className="grid grid-cols-2 gap-2 text-xs md:grid-cols-4">
                  <div><div className="text-muted-foreground">Balance per bank</div><div className="font-bold">{fmt(bankReconciliation.balancePerBank)}</div></div>
                  <div><div className="text-muted-foreground">Outstanding receipts</div><div className="font-bold">{fmt(bankReconciliation.outstandingReceipts)}</div></div>
                  <div><div className="text-muted-foreground">Outstanding payments</div><div className="font-bold">{fmt(bankReconciliation.outstandingPayments)}</div></div>
                  <div><div className="text-muted-foreground">Balance per GL</div><div className="font-bold">{fmt(bankReconciliation.balancePerGL)}</div></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trial Balance (SAP FICO) */}
        <TabsContent value="tb" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Trial Balance (SAP FICO Style)</CardTitle>
                <CardDescription>GL codes 1010–8000 · {standard} · {activeCompany?.currency}</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => downloadExcel("trial-balance", tbRows, "Trial Balance")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-700 text-white">
                    <tr><th className="px-3 py-2 text-left font-semibold w-20">GL Code</th><th className="px-3 py-2 text-left font-semibold">Account</th><th className="px-3 py-2 text-left font-semibold w-24">Type</th><th className="px-3 py-2 text-right font-semibold w-32">Final Dr</th><th className="px-3 py-2 text-right font-semibold w-32">Final Cr</th></tr>
                  </thead>
                  <tbody>
                    {trialBalance.map((t: any, i: number) => (
                      <tr key={t.code} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                        <td className="px-3 py-1.5 font-mono text-xs">{t.code}</td>
                        <td className="px-3 py-1.5">{t.account}</td>
                        <td className="px-3 py-1.5 text-xs"><Badge variant="outline" className="text-[10px]">{t.type}</Badge></td>
                        <td className="px-3 py-1.5 text-right font-mono">{t.finalDr > 0 ? fmt(t.finalDr) : "—"}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{t.finalCr > 0 ? fmt(t.finalCr) : "—"}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 bg-emerald-600 font-bold text-white">
                      <td className="px-3 py-2" colSpan={3}>TOTAL</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(totalDr)}</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(totalCr)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="mt-2 flex items-center gap-3">
                <Badge variant={totalDr === totalCr ? "default" : "destructive"} className="text-[10px]">
                  {totalDr === totalCr ? <><CheckCircle2 className="size-3" /> Balanced — Dr = Cr</> : <><AlertTriangle className="size-3" /> Out of balance</>}
                </Badge>
                <span className="text-xs text-muted-foreground">Dr {fmt(totalDr)} = Cr {fmt(totalCr)}</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Equity Statement */}
        <TabsContent value="equity" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Statement of Changes in Equity</CardTitle><CardDescription>Year Ended 31 December 2025 · {standard} · incl. Accumulated OCI Reserve per IAS 1 / ASC 220</CardDescription></CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-700 text-white"><tr><th className="px-3 py-2 text-left font-semibold">Component</th><th className="px-3 py-2 text-right font-semibold">Opening</th><th className="px-3 py-2 text-right font-semibold">Movements</th><th className="px-3 py-2 text-right font-semibold">Closing</th></tr></thead>
                  <tbody>
                    <tr className="border-t"><td className="px-3 py-2 font-medium">Share Capital</td><td className="px-3 py-2 text-right font-mono">{fmt(equityStatement.shareCapital.opening)}</td><td className="px-3 py-2 text-right font-mono">{fmt(equityStatement.shareCapital.newShares)}</td><td className="px-3 py-2 text-right font-mono font-bold">{fmt(equityStatement.shareCapital.closing)}</td></tr>
                    <tr className="border-t bg-muted/20"><td className="px-3 py-2 font-medium">Retained Earnings</td><td className="px-3 py-2 text-right font-mono">{fmt(equityStatement.retainedEarnings.opening)}</td><td className="px-3 py-2 text-right font-mono text-emerald-600 dark:text-emerald-400">+{fmt(equityStatement.retainedEarnings.netProfit)}</td><td className="px-3 py-2 text-right font-mono font-bold">{fmt(equityStatement.retainedEarnings.closing)}</td></tr>
                    <tr className="border-t bg-teal-500/10"><td className="px-3 py-2 font-medium"><span className="text-teal-700 dark:text-teal-300">Accumulated OCI Reserve</span> <span className="text-[10px] text-muted-foreground">(net of tax, per IAS 1.106)</span></td><td className="px-3 py-2 text-right font-mono">{fmt(equityStatement.accumulatedOciReserve.opening)}</td><td className="px-3 py-2 text-right font-mono text-teal-600 dark:text-teal-400">+{fmt(equityStatement.accumulatedOciReserve.totalOciForYear)}</td><td className="px-3 py-2 text-right font-mono font-bold text-teal-700 dark:text-teal-300">{fmt(equityStatement.accumulatedOciReserve.closing)}</td></tr>
                    <tr className="border-t-2 bg-emerald-600 font-bold text-white"><td className="px-3 py-2">TOTAL EQUITY</td><td className="px-3 py-2 text-right font-mono">{fmt(equityStatement.totalEquity.opening)}</td><td className="px-3 py-2 text-right font-mono">+{fmt(equityStatement.totalEquity.movements)}</td><td className="px-3 py-2 text-right font-mono">{fmt(equityStatement.totalEquity.closing)}</td></tr>
                  </tbody>
                </table>
              </div>

              {/* OCI Reserve Breakdown */}
              <div className="mt-4 rounded-md border-l-4 border-l-teal-500 bg-teal-500/5 p-4">
                <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Accumulated OCI Reserve — Movement Breakdown</div>
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between"><span className="text-muted-foreground">Opening balance (1 Jan 2025)</span><span className="font-mono font-bold">{fmt(oci.openingAccumulatedOci)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Total OCI for year (net of tax)</span><span className="font-mono text-teal-700 dark:text-teal-300">+{fmt(oci.totalOciNetOfTax)}</span></div>
                  <div className="flex justify-between border-t pt-1.5 font-bold"><span>Closing balance (31 Dec 2025)</span><span className="font-mono">{fmt(oci.closingAccumulatedOci)}</span></div>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 md:grid-cols-4">
                  {[
                    { label: "PPE Revaluation (IAS 16)", val: oci.ociNotReclassifiedGross > 0 ? "+£1,200" : "£0", note: "non-recyclable" },
                    { label: "FX Translation (IAS 21)", val: "+£1,850", note: "recyclable" },
                    { label: "Cash Flow Hedges (IFRS 9)", val: "+£500", note: "recyclable" },
                    { label: "Pension Remeasure (IAS 19)", val: "(£500)", note: "non-recyclable" },
                  ].map((r) => (
                    <div key={r.label} className="rounded border border-teal-500/30 bg-teal-500/5 p-2">
                      <div className="text-[10px] text-muted-foreground">{r.label}</div>
                      <div className="font-mono font-bold text-sm text-teal-700 dark:text-teal-300">{r.val}</div>
                      <div className="text-[9px] text-muted-foreground italic">{r.note}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* VAT & Tax */}
        <TabsContent value="vat" className="space-y-4">
          {/* VAT Returns */}
          <Card>
            <CardHeader><CardTitle>VAT Returns (VAT100) — Quarterly</CardTitle><CardDescription>Making Tax Digital · UK 20% standard rate</CardDescription></CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-700 text-white"><tr><th className="px-3 py-2 text-left">Quarter</th><th className="px-3 py-2 text-right">Box 1 Output VAT</th><th className="px-3 py-2 text-right">Box 4 Input VAT</th><th className="px-3 py-2 text-right">Box 5 Net Payable</th><th className="px-3 py-2 text-right">Box 6 Total Sales</th><th className="px-3 py-2 text-right">Box 7 Total Purchases</th></tr></thead>
                  <tbody>
                    {vatReturn.map((v: any, i: number) => (
                      <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                        <td className="px-3 py-1.5 font-medium">{v.quarter}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(v.box1_OutputVAT)}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(v.box4_InputVAT)}</td>
                        <td className="px-3 py-1.5 text-right font-mono font-bold text-rose-600 dark:text-rose-400">{fmt(v.box5_NetPayable)}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(v.box6_TotalSales)}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(v.box7_TotalPurchases)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Corporation Tax */}
          <Card>
            <CardHeader><CardTitle>Corporation Tax Computation (CT600)</CardTitle><CardDescription>Year Ended 31 December 2025 · UK 25% main rate</CardDescription></CardHeader>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-md border p-3 space-y-1 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Accounting Profit</span><span className="font-mono font-bold">{fmt(corpTax.accountingProfit)}</span></div>
                  {corpTax.adjustments.map((a: any, i: number) => (
                    <div key={i} className="flex justify-between text-xs"><span className="text-muted-foreground">{a.item}</span><span className="font-mono">{a.amount < 0 ? `(${fmt(a.amount)})` : fmt(a.amount)}</span></div>
                  ))}
                  <div className="flex justify-between border-t pt-1 font-bold"><span>Taxable Profit</span><span className="font-mono">{fmt(corpTax.taxableProfit)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Tax Rate</span><span>{corpTax.taxRate}</span></div>
                  <div className="flex justify-between border-t pt-1 font-bold text-lg text-rose-600 dark:text-rose-400"><span>CT Due</span><span className="font-mono">{fmt(corpTax.corporationTaxDue)}</span></div>
                </div>
                <div className="space-y-2">
                  <div className="rounded-md border p-3 text-sm">
                    <div className="text-xs font-semibold uppercase text-muted-foreground mb-1">Filing & Payment</div>
                    <div className="text-xs">CT600 filing: <strong>{corpTax.ct600FilingDeadline}</strong></div>
                    <div className="text-xs">Payment due: <strong>{corpTax.ctPaymentDeadline}</strong></div>
                  </div>
                  <div className="rounded-md border p-3 text-sm">
                    <div className="text-xs font-semibold uppercase text-muted-foreground mb-1">Capital Allowances (AIA)</div>
                    <div className="flex justify-between text-xs"><span>Claimed</span><span className="font-mono">{fmt(corpTax.aiaClaimed)}</span></div>
                    <div className="flex justify-between text-xs"><span>Limit</span><span className="font-mono">{fmt(corpTax.aiaLimit)}</span></div>
                    <div className="flex justify-between text-xs"><span>Remaining</span><span className="font-mono text-emerald-600 dark:text-emerald-400">{fmt(corpTax.aiaRemaining)}</span></div>
                  </div>
                  <div className="rounded-md border p-3 text-sm">
                    <div className="text-xs font-semibold uppercase text-muted-foreground mb-1">Self Assessment (SA302)</div>
                    <div className="flex justify-between text-xs"><span>Salary</span><span className="font-mono">{fmt(selfAssessment.salary)}</span></div>
                    <div className="flex justify-between text-xs"><span>Total Tax Due</span><span className="font-mono">{fmt(selfAssessment.totalTaxDue)}</span></div>
                    <div className="flex justify-between text-xs"><span>Paid via PAYE</span><span className="font-mono">{fmt(selfAssessment.taxPaidViaPAYE)}</span></div>
                    <div className="flex justify-between text-xs font-bold"><span>Balance Due</span><span className="font-mono text-rose-600 dark:text-rose-400">{fmt(selfAssessment.balanceDue)}</span></div>
                    <div className="text-[10px] text-muted-foreground mt-1">Filing: {selfAssessment.filingDeadline} · Payment: {selfAssessment.paymentDeadline}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payroll */}
        <TabsContent value="payroll" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Payroll Schedule — December 2025</CardTitle><CardDescription>PAYE/NI · HMRC RTI · Pension auto-enrolment</CardDescription></CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-700 text-white"><tr><th className="px-3 py-2 text-left">Employee</th><th className="px-3 py-2 text-right">Gross</th><th className="px-3 py-2 text-right">PAYE</th><th className="px-3 py-2 text-right">Emp NI</th><th className="px-3 py-2 text-right">Er NI</th><th className="px-3 py-2 text-right">Net Pay</th><th className="px-3 py-2 text-right">Total Cost</th><th className="px-3 py-2 text-right">Pension</th></tr></thead>
                  <tbody>
                    {payroll.map((p: any, i: number) => (
                      <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                        <td className="px-3 py-1.5 font-medium">{p.employee}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(p.grossPay)}</td>
                        <td className="px-3 py-1.5 text-right font-mono">({fmt(p.paye)})</td>
                        <td className="px-3 py-1.5 text-right font-mono">({fmt(p.employeeNI)})</td>
                        <td className="px-3 py-1.5 text-right font-mono">({fmt(p.employerNI)})</td>
                        <td className="px-3 py-1.5 text-right font-mono font-bold">{fmt(p.netPay)}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(p.totalCost)}</td>
                        <td className="px-3 py-1.5 text-right font-mono">{fmt(p.pension)}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 bg-emerald-600 font-bold text-white">
                      <td className="px-3 py-2">TOTAL</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(payrollTotal.grossPay)}</td>
                      <td className="px-3 py-2 text-right font-mono">({fmt(payrollTotal.paye)})</td>
                      <td className="px-3 py-2 text-right font-mono">({fmt(payrollTotal.employeeNI)})</td>
                      <td className="px-3 py-2 text-right font-mono">({fmt(payrollTotal.employerNI)})</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(payrollTotal.netPay)}</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(payrollTotal.totalCost)}</td>
                      <td className="px-3 py-2 text-right font-mono">{fmt(payrollTotal.pension)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">
                <div className="rounded-md border p-3 text-center"><div className="text-xs text-muted-foreground">PAYE/NI to HMRC</div><div className="font-bold text-lg">{fmt(payrollTotal.payeNICtoHMRC)}</div></div>
                <div className="rounded-md border p-3 text-center"><div className="text-xs text-muted-foreground">Annual Gross Payroll</div><div className="font-bold text-lg">{fmt(payrollTotal.annualGrossPayroll)}</div></div>
                <div className="rounded-md border p-3 text-center"><div className="text-xs text-muted-foreground">Filing</div><div className="font-bold text-sm">Monthly FPS/EPS</div></div>
                <div className="rounded-md border p-3 text-center"><div className="text-xs text-muted-foreground">P60 Deadline</div><div className="font-bold text-sm">19 April 2026</div></div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Full disclosure notes section (always visible) */}
      <Card className="border-l-4 border-l-emerald-500">
        <CardHeader>
          <CardTitle className="text-base">Notes to the Financial Statements — Full Disclosures</CardTitle>
          <CardDescription>Inline per IAS 1 — disclosures are part of the financial statements, not separate</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2">
            {disclosureNotes.map((n: any) => (
              <div key={n.note} className="rounded-md border p-3">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px]">Note {n.note}</Badge>
                  <span className="text-sm font-medium">{n.title}</span>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">{n.body}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* ============ CONCEPTS APPLIED — Cross-Reference Matrix ============ */}
      <ConceptsAppliedPanel reportName="Financial Reports" />
    </div>
  );
}
