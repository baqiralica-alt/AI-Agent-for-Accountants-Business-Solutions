"use client";

import * as React from "react";
import { Workflow, Mail, Receipt, CalendarClock, Zap, Bell, Plus, RefreshCw, Play } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Automation = {
  id: string;
  name: string;
  description: string;
  trigger: string;
  action: string;
  agentRole: string;
  enabled: boolean;
  lastRunAt: string | null;
  nextRunAt: string | null;
  runsCount: number;
};

const TRIGGER_ICON: Record<string, React.ElementType> = {
  daily: CalendarClock,
  weekly: CalendarClock,
  monthly: CalendarClock,
  "on-event": Zap,
  "email-received": Mail,
  "invoice-paid": Receipt,
};

const ROLE_COLOR: Record<string, string> = {
  ceo: "bg-violet-500/15 text-violet-600 dark:text-violet-400",
  cfo: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  accountant: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  tax: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
};

export function AutomationsModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const [items, setItems] = React.useState<Automation[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [addOpen, setAddOpen] = React.useState(false);

  function load() {
    setLoading(true);
    fetch(`/api/automations?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setItems(d.automations);
      })
      .catch((e) => toast.error(`Failed to load: ${e.message}`))
      .finally(() => setLoading(false));
  }

  React.useEffect(() => { load(); }, [activeCompanyId]);

  async function toggle(id: string, enabled: boolean) {
    // optimistic
    setItems((arr) => arr.map((a) => (a.id === id ? { ...a, enabled } : a)));
    try {
      const res = await fetch("/api/automations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, enabled }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(enabled ? "Automation enabled" : "Automation paused");
    } catch (e: any) {
      toast.error(e.message);
      setItems((arr) => arr.map((a) => (a.id === id ? { ...a, enabled: !enabled } : a)));
    }
  }

  function runNow(a: Automation) {
    toast.success(`"${a.name}" triggered — agent is now working in the background.`);
    setItems((arr) => arr.map((x) => (x.id === a.id ? { ...x, lastRunAt: new Date().toISOString(), runsCount: x.runsCount + 1 } : x)));
  }

  const enabledCount = items.filter((i) => i.enabled).length;
  const totalRuns = items.reduce((s, i) => s + i.runsCount, 0);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Automations</h1>
          <p className="text-sm text-muted-foreground">
            Recurring tasks the AI agents run for you — Gmail triage, daily cash reports, tax reminders, payroll sign-off.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load}>
            <RefreshCw className="size-3.5" />
            Refresh
          </Button>
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="size-3.5" />
                New Automation
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create automation</DialogTitle>
                <DialogDescription>
                  Define a trigger and an agent. The agent will execute the action on schedule.
                </DialogDescription>
              </DialogHeader>
              <NewAutomationForm
                companyId={activeCompanyId}
                onCreated={() => { setAddOpen(false); load(); }}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Total</div>
          <div className="text-xl font-bold">{items.length}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Enabled</div>
          <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{enabledCount}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Total Runs</div>
          <div className="text-xl font-bold">{totalRuns.toLocaleString()}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Agents in Use</div>
          <div className="text-xl font-bold">{new Set(items.map((i) => i.agentRole)).size}</div>
        </CardContent></Card>
      </div>

      {/* Templates */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Templates</CardTitle>
          <CardDescription>One-click automations for the most common repeated asks</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {[
            { name: "Daily Cash Position Email", desc: "CFO agent emails the CEO every morning with cash balance & runway.", trigger: "daily", role: "cfo", icon: Mail },
            { name: "Invoice Triage from Gmail", desc: "Accountant agent extracts invoices from Gmail and drafts them in Xero.", trigger: "email-received", role: "accountant", icon: Mail },
            { name: "VAT / Sales Tax Reminder", desc: "Tax agent opens a return task 30 days before each filing deadline.", trigger: "monthly", role: "tax", icon: Bell },
            { name: "Weekly Board KPI Digest", desc: "CEO agent posts KPI digest to the board every Friday at 5pm.", trigger: "weekly", role: "ceo", icon: CalendarClock },
            { name: "Stripe Payout Auto-Categorize", desc: "Accountant agent posts a journal entry when a Stripe payout lands.", trigger: "on-event", role: "accountant", icon: Zap },
            { name: "Payroll Sign-off Reminder", desc: "Accountant agent pings CFO two business days before payroll.", trigger: "weekly", role: "accountant", icon: Bell },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.name}
                onClick={() => toast.success(`"${t.name}" template applied — review and enable below.`)}
                className="group text-left rounded-md border p-3 transition-colors hover:border-emerald-500/30 hover:bg-muted/40"
              >
                <div className="flex items-center justify-between">
                  <div className={cn("flex size-7 items-center justify-center rounded-md", ROLE_COLOR[t.role])}>
                    <Icon className="size-4" />
                  </div>
                  <Badge variant="outline" className="text-[10px]">{t.trigger}</Badge>
                </div>
                <div className="mt-2 text-sm font-medium">{t.name}</div>
                <div className="mt-1 text-xs text-muted-foreground">{t.desc}</div>
              </button>
            );
          })}
        </CardContent>
      </Card>

      {/* List */}
      <Card>
        <CardHeader>
          <CardTitle>Active Automations</CardTitle>
          <CardDescription>Toggle, run now, or pause any automation</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {loading ? (
            <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
          ) : items.length === 0 ? (
            <p className="text-sm text-muted-foreground">No automations yet. Use a template above or create one.</p>
          ) : (
            items.map((a) => {
              const Icon = TRIGGER_ICON[a.trigger] ?? Workflow;
              const lastRun = a.lastRunAt ? new Date(a.lastRunAt) : null;
              const nextRun = a.nextRunAt ? new Date(a.nextRunAt) : null;
              return (
                <div key={a.id} className="flex flex-col gap-3 rounded-md border p-4 sm:flex-row sm:items-center">
                  <div className={cn("flex size-10 shrink-0 items-center justify-center rounded-md", ROLE_COLOR[a.agentRole])}>
                    <Icon className="size-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium">{a.name}</span>
                      <Badge variant="outline" className="text-[10px] capitalize">{a.agentRole} agent</Badge>
                      <Badge variant="outline" className="text-[10px]">{a.trigger}</Badge>
                      {a.enabled ? (
                        <Badge className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">Enabled</Badge>
                      ) : (
                        <Badge variant="secondary" className="text-[10px]">Paused</Badge>
                      )}
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">{a.description}</div>
                    <div className="mt-1 text-[11px] text-muted-foreground">
                      {a.runsCount} runs · last {lastRun ? lastRun.toLocaleString() : "never"} · next {nextRun ? nextRun.toLocaleDateString() : "—"}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => runNow(a)}>
                      <Play className="size-3" />
                      Run now
                    </Button>
                    <Switch checked={a.enabled} onCheckedChange={(v) => toggle(a.id, v)} aria-label="Toggle automation" />
                  </div>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function NewAutomationForm({ companyId, onCreated }: { companyId: string; onCreated: () => void }) {
  const [name, setName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [trigger, setTrigger] = React.useState("daily");
  const [action, setAction] = React.useState("send-report");
  const [agentRole, setAgentRole] = React.useState("cfo");
  const [saving, setSaving] = React.useState(false);

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/automations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyId, name, description, trigger, action, agentRole }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`Automation "${name}" created`);
      setName("");
      setDescription("");
      onCreated();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid gap-4 py-2">
      <div className="grid gap-2">
        <Label htmlFor="name">Name</Label>
        <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Daily Cash Report" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="desc">Description</Label>
        <Textarea id="desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="What this automation does" />
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div className="grid gap-2">
          <Label>Trigger</Label>
          <Select value={trigger} onValueChange={setTrigger}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="on-event">On event</SelectItem>
              <SelectItem value="email-received">Email received</SelectItem>
              <SelectItem value="invoice-paid">Invoice paid</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-2">
          <Label>Action</Label>
          <Select value={action} onValueChange={setAction}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="send-report">Send report</SelectItem>
              <SelectItem value="reconcile">Reconcile</SelectItem>
              <SelectItem value="remind-tax">Remind tax</SelectItem>
              <SelectItem value="categorize">Categorize</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-2">
          <Label>Agent</Label>
          <Select value={agentRole} onValueChange={setAgentRole}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ceo">CEO</SelectItem>
              <SelectItem value="cfo">CFO</SelectItem>
              <SelectItem value="accountant">Accountant</SelectItem>
              <SelectItem value="tax">Tax</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <DialogFooter>
        <Button onClick={save} disabled={saving || !name}>{saving ? "Creating…" : "Create automation"}</Button>
      </DialogFooter>
    </div>
  );
}
