"use client";

import * as React from "react";
import { BookText, Plus, Trash2, RefreshCw, CheckCircle2, AlertTriangle, Bot, FileText } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Line = { account: string; debit: number; credit: number; description?: string };

type Entry = {
  id: string;
  date: string;
  memo: string;
  reference?: string | null;
  source: string;
  postedBy?: string | null;
  lines: Line[];
  totalDebit: number;
  totalCredit: number;
  status: string;
};

const COMMON_ACCOUNTS = [
  "1000 Cash & Bank",
  "1200 Accounts Receivable",
  "1400 Inventory / Raw Materials",
  "1500 Property, Plant & Equipment",
  "1900 Accumulated Depreciation",
  "2000 Accounts Payable",
  "2100 Accrued Expenses",
  "2200 VAT / Sales Tax Payable",
  "2300 Payroll Liabilities",
  "2400 Deferred Revenue",
  "2500 Long-Term Debt",
  "3000 Shareholder Equity",
  "3100 Retained Earnings",
  "4000 Revenue",
  "4010 Service Revenue",
  "4020 Subscription Revenue",
  "4030 Contract Revenue",
  "4040 Rental Income",
  "5000 COGS",
  "5100 Compute Expense",
  "5200 Materials",
  "5300 Subcontractors",
  "5400 Payroll",
  "5500 Rent",
  "5600 Software",
  "5700 Marketing",
  "5800 Travel",
  "5900 Insurance",
  "6000 Tax Expense",
  "6100 Interest Expense",
  "6200 Depreciation Expense",
];

export function JournalModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [entries, setEntries] = React.useState<Entry[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [addOpen, setAddOpen] = React.useState(false);

  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";

  function load() {
    setLoading(true);
    fetch(`/api/journal?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setEntries(d.entries);
      })
      .catch((e) => toast.error(`Failed to load: ${e.message}`))
      .finally(() => setLoading(false));
  }

  React.useEffect(() => { load(); }, [activeCompanyId]);

  const totalDebit = entries.reduce((s, e) => s + e.totalDebit, 0);
  const totalCredit = entries.reduce((s, e) => s + e.totalCredit, 0);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Journal Entries</h1>
          <p className="text-sm text-muted-foreground">
            Double-entry Dr/Cr postings. Every entry must balance — debits = credits.
            The Accountant agent can post entries for you from the AI Agents tab.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load}>
            <RefreshCw className="size-3.5" />
            Refresh
          </Button>
          <NewEntryDialog
            open={addOpen}
            onOpenChange={setAddOpen}
            companyId={activeCompanyId}
            currency={sym}
            onSaved={() => { setAddOpen(false); load(); }}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Entries</div>
          <div className="text-xl font-bold">{entries.length}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Total Debits</div>
          <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{sym}{totalDebit.toLocaleString()}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Total Credits</div>
          <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{sym}{totalCredit.toLocaleString()}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Balance Check</div>
          <div className={cn("flex items-center gap-1 text-xl font-bold", Math.abs(totalDebit - totalCredit) < 0.01 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>
            {Math.abs(totalDebit - totalCredit) < 0.01 ? <CheckCircle2 className="size-5" /> : <AlertTriangle className="size-5" />}
            {Math.abs(totalDebit - totalCredit) < 0.01 ? "Balanced" : "Off"}
          </div>
        </CardContent></Card>
      </div>

      {/* Quick templates */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Industry Templates</CardTitle>
          <CardDescription>One-click balanced templates the Accountant agent uses</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {[
            { name: "Customer invoice (B2B)", desc: "Dr A/R, Cr Revenue", lines: [{ account: "1200 Accounts Receivable", debit: 1000, credit: 0 }, { account: "4000 Revenue", debit: 0, credit: 1000 }] },
            { name: "Customer invoice (with VAT)", desc: "Dr A/R, Cr Revenue + Cr VAT Payable", lines: [{ account: "1200 Accounts Receivable", debit: 1200, credit: 0 }, { account: "4000 Revenue", debit: 0, credit: 1000 }, { account: "2200 VAT / Sales Tax Payable", debit: 0, credit: 200 }] },
            { name: "Vendor bill", desc: "Dr Expense, Cr A/P", lines: [{ account: "5200 Materials", debit: 500, credit: 0 }, { account: "2000 Accounts Payable", debit: 0, credit: 500 }] },
            { name: "Payroll (gross + employer)", desc: "Dr Wages, Dr Employer Tax, Cr Cash + Cr Liabilities", lines: [{ account: "5400 Payroll", debit: 8000, credit: 0 }, { account: "5400 Payroll", debit: 1200, credit: 0 }, { account: "1000 Cash & Bank", debit: 0, credit: 6800 }, { account: "2300 Payroll Liabilities", debit: 0, credit: 2400 }] },
            { name: "Depreciation (monthly)", desc: "Dr Depreciation Expense, Cr Accumulated Depreciation", lines: [{ account: "6200 Depreciation Expense", debit: 1500, credit: 0 }, { account: "1900 Accumulated Depreciation", debit: 0, credit: 1500 }] },
            { name: "Deferred revenue (SaaS)", desc: "Dr Cash, Cr Deferred Revenue", lines: [{ account: "1000 Cash & Bank", debit: 12000, credit: 0 }, { account: "2400 Deferred Revenue", debit: 0, credit: 12000 }] },
          ].map((t) => (
            <div key={t.name} className="rounded-md border p-3">
              <div className="flex items-center gap-2">
                <FileText className="size-4 text-muted-foreground" />
                <div className="text-sm font-medium">{t.name}</div>
              </div>
              <div className="mt-1 text-xs text-muted-foreground">{t.desc}</div>
              <div className="mt-2 text-[11px] text-muted-foreground">
                {t.lines.length} lines · Dr {sym}{t.lines.reduce((s, l) => s + l.debit, 0).toLocaleString()} / Cr {sym}{t.lines.reduce((s, l) => s + l.credit, 0).toLocaleString()}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* List */}
      <Card>
        <CardHeader>
          <CardTitle>Journal</CardTitle>
          <CardDescription>{entries.length} entries</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>
          ) : entries.length === 0 ? (
            <p className="text-sm text-muted-foreground">No journal entries yet. Post one with the button above, or ask the Accountant agent to post for you.</p>
          ) : (
            <div className="space-y-3">
              {entries.map((e) => (
                <div key={e.id} className="rounded-md border p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-sm font-medium">{e.memo}</div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(e.date).toLocaleDateString()} · ref {e.reference ?? "n/a"}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Badge variant="outline" className="text-[10px] capitalize">{e.source}</Badge>
                      {e.postedBy === "accountant-agent" && (
                        <Badge className="text-[10px] bg-amber-500/15 text-amber-600 dark:text-amber-400"><Bot className="size-3" /> Agent</Badge>
                      )}
                      <Badge variant="secondary" className="text-[10px]">{e.status}</Badge>
                    </div>
                  </div>
                  <Separator className="my-3" />
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-left text-xs text-muted-foreground">
                          <th className="py-1 font-medium">Account</th>
                          <th className="py-1 text-right font-medium">Debit</th>
                          <th className="py-1 text-right font-medium">Credit</th>
                        </tr>
                      </thead>
                      <tbody>
                        {e.lines.map((l, i) => (
                          <tr key={i} className="border-t">
                            <td className="py-1.5">{l.account}</td>
                            <td className="py-1.5 text-right">{l.debit > 0 ? `${sym}${l.debit.toLocaleString()}` : ""}</td>
                            <td className="py-1.5 text-right">{l.credit > 0 ? `${sym}${l.credit.toLocaleString()}` : ""}</td>
                          </tr>
                        ))}
                        <tr className="border-t font-medium">
                          <td className="py-1.5">Total</td>
                          <td className="py-1.5 text-right">{sym}{e.totalDebit.toLocaleString()}</td>
                          <td className="py-1.5 text-right">{sym}{e.totalCredit.toLocaleString()}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function NewEntryDialog({
  open,
  onOpenChange,
  companyId,
  currency,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (b: boolean) => void;
  companyId: string;
  currency: string;
  onSaved: () => void;
}) {
  const [date, setDate] = React.useState(new Date().toISOString().slice(0, 10));
  const [memo, setMemo] = React.useState("");
  const [reference, setReference] = React.useState("");
  const [lines, setLines] = React.useState<Line[]>([
    { account: COMMON_ACCOUNTS[0], debit: 0, credit: 0 },
    { account: COMMON_ACCOUNTS[13], debit: 0, credit: 0 },
  ]);
  const [saving, setSaving] = React.useState(false);

  const totalDebit = lines.reduce((s, l) => s + (Number(l.debit) || 0), 0);
  const totalCredit = lines.reduce((s, l) => s + (Number(l.credit) || 0), 0);
  const balanced = Math.abs(totalDebit - totalCredit) < 0.01 && totalDebit > 0;

  function updateLine(i: number, patch: Partial<Line>) {
    setLines((arr) => arr.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  }
  function addLine() {
    setLines((arr) => [...arr, { account: COMMON_ACCOUNTS[0], debit: 0, credit: 0 }]);
  }
  function removeLine(i: number) {
    setLines((arr) => arr.filter((_, idx) => idx !== i));
  }

  async function save() {
    if (!balanced) {
      toast.error("Entry is not balanced — debits must equal credits");
      return;
    }
    // Validate no line has both Dr and Cr > 0
    for (const l of lines) {
      if (l.debit > 0 && l.credit > 0) {
        toast.error(`Line "${l.account}" has both debit and credit — split into two lines`);
        return;
      }
    }
    setSaving(true);
    try {
      const res = await fetch("/api/journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyId, date, memo, reference, lines, source: "manual", postedBy: "user" }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success("Journal entry posted");
      setMemo(""); setReference("");
      setLines([{ account: COMMON_ACCOUNTS[0], debit: 0, credit: 0 }, { account: COMMON_ACCOUNTS[13], debit: 0, credit: 0 }]);
      onSaved();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="size-3.5" />
          New Entry
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>New Journal Entry</DialogTitle>
          <DialogDescription>
            Double-entry posting. Debits must equal credits before the entry can be saved.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-3 gap-3">
            <div className="grid gap-2">
              <Label htmlFor="jdate">Date</Label>
              <Input id="jdate" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="col-span-2 grid gap-2">
              <Label htmlFor="jmemo">Memo</Label>
              <Input id="jmemo" value={memo} onChange={(e) => setMemo(e.target.value)} placeholder="e.g. Record progress billing — Project #2148" />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="jref">Reference (optional)</Label>
            <Input id="jref" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="PO / invoice / contract number" />
          </div>

          {/* Lines */}
          <div className="rounded-md border">
            <div className="grid grid-cols-[1fr_120px_120px_40px] gap-2 border-b bg-muted/40 px-3 py-2 text-xs font-medium text-muted-foreground">
              <div>Account</div>
              <div className="text-right">Debit ({currency})</div>
              <div className="text-right">Credit ({currency})</div>
              <div></div>
            </div>
            {lines.map((l, i) => (
              <div key={i} className="grid grid-cols-[1fr_120px_120px_40px] gap-2 border-b px-3 py-2 last:border-b-0">
                <select
                  className="rounded-md border bg-background px-2 py-1 text-sm"
                  value={l.account}
                  onChange={(e) => updateLine(i, { account: e.target.value })}
                >
                  {COMMON_ACCOUNTS.map((a) => <option key={a} value={a}>{a}</option>)}
                </select>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  className="text-right"
                  value={l.debit || ""}
                  onChange={(e) => updateLine(i, { debit: Number(e.target.value) || 0, credit: 0 })}
                />
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  className="text-right"
                  value={l.credit || ""}
                  onChange={(e) => updateLine(i, { credit: Number(e.target.value) || 0, debit: 0 })}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-7"
                  onClick={() => removeLine(i)}
                  disabled={lines.length <= 2}
                  aria-label="Remove line"
                >
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            ))}
            <div className="flex items-center justify-between px-3 py-2">
              <Button variant="outline" size="sm" onClick={addLine}>
                <Plus className="size-3" />
                Add line
              </Button>
              <div className="flex items-center gap-3 text-sm">
                <span className="text-muted-foreground">Dr <strong className="font-medium text-foreground">{currency}{totalDebit.toLocaleString()}</strong></span>
                <span className="text-muted-foreground">Cr <strong className="font-medium text-foreground">{currency}{totalCredit.toLocaleString()}</strong></span>
                <Badge variant={balanced ? "default" : "destructive"} className={balanced ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : ""}>
                  {balanced ? <><CheckCircle2 className="size-3" /> Balanced</> : <><AlertTriangle className="size-3" /> Unbalanced</>}
                </Badge>
              </div>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || !balanced || !memo}>{saving ? "Posting…" : "Post entry"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
