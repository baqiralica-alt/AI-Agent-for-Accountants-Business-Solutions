"use client";

import * as React from "react";
import { Code2, Plug, Webhook, Plus, Copy, RefreshCw, Trash2, ExternalLink, Key, ShieldCheck, Zap, BookOpen } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from "@/components/ui/tabs";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Webhook = {
  id: string;
  url: string;
  events: string[];
  enabled: boolean;
  secretMasked: string;
  lastFiredAt: string | null;
  lastStatus: number | null;
  deliveries: number;
};

const EVENTS = [
  { id: "transaction.created", desc: "A new transaction was posted to the GL" },
  { id: "transaction.reconciled", desc: "A transaction was matched to a bank feed entry" },
  { id: "journal.posted", desc: "A double-entry journal entry was posted" },
  { id: "invoice.created", desc: "A new customer invoice or vendor bill was created" },
  { id: "invoice.paid", desc: "An invoice was marked as paid" },
  { id: "tax.due", desc: "A tax filing is approaching its due date" },
  { id: "file.imported", desc: "A file (PDF/Excel/CSV) was imported to the GL" },
  { id: "automation.run", desc: "An automation was triggered and completed" },
];

const PROVIDER_LINKS = [
  {
    name: "QuickBooks Online",
    auth: "OAuth 2.0",
    docs: "https://developer.intuit.com/app/developer/qbo/docs/develop",
    console: "https://developer.intuit.com/app/developer/myapps",
    scopes: "com.intuit.quickbooks.accounting",
    description: "Sync chart of accounts, invoices, bills, journal entries, customers, vendors.",
    useCase: "Best for US-based clients already on QuickBooks.",
  },
  {
    name: "Xero",
    auth: "OAuth 2.0",
    docs: "https://developer.xero.com/documentation/oauth2/auth-flow",
    console: "https://app.xero.com/app/manageapps",
    scopes: "accounting.transactions accounting.settings bankfeeds",
    description: "Sync contacts, invoices, bank feeds, tracking categories, manual journals.",
    useCase: "Best for UK / EU / APAC clients on Xero.",
  },
  {
    name: "Sage (Business Cloud / Sage 50)",
    auth: "OAuth 2.0",
    docs: "https://developer.sage.com/accounting/reference/",
    console: "https://developer.sage.com/",
    scopes: "sage.accounting.read sage.accounting.write",
    description: "Sync ledgers, contacts, VAT returns, invoices, bank transactions.",
    useCase: "UK SMEs and accountancy practices on Sage.",
  },
  {
    name: "SAP S/4HANA FICO",
    auth: "OAuth 2.0 / Basic",
    docs: "https://api.sap.com/",
    console: "https://api.sap.com/developer",
    scopes: "FI_DOC_CREATE FI_DOC_READ",
    description: "Post financial documents to the SAP FI general ledger; read cost-center and profit-center accounting from CO. Supports IDoc and OData.",
    useCase: "Large enterprises running SAP S/4HANA or SAP ECC.",
    note: "Requires an SAP BTP destination + service key. Finova maps each client to a SAP Company Code.",
  },
  {
    name: "Oracle NetSuite / Fusion Financials",
    auth: "OAuth 2.0 / TBA",
    docs: "https://docs.oracle.com/en/cloud/saas/financials/",
    console: "https://system.netsuite.com/",
    scopes: "REST_RECORDS REST_REPORTS",
    description: "Post GL journals, create invoices and vendor bills, pull trial balance and financial reports via the NetSuite SuiteTalk REST API.",
    useCase: "Mid-market and enterprise clients on Oracle NetSuite or Fusion.",
    note: "For TBA (Token-Based Auth), provide Consumer Key/Secret + Token ID/Secret in the Integrations tab.",
  },
  {
    name: "Zoho Books",
    auth: "OAuth 2.0",
    docs: "https://www.zoho.com/books/api/v3/",
    console: "https://api-console.zoho.com/",
    scopes: "ZohoBooks.invoices.CREATE ZohoBooks.estimates.READ",
    description: "Sync invoices, bills, chart of accounts, contacts, bank transactions.",
    useCase: "SMBs and freelancers on Zoho Finance Suite.",
  },
];

const REST_ENDPOINTS = [
  { method: "GET", path: "/api/companies", desc: "List all clients" },
  { method: "POST", path: "/api/companies", desc: "Add a new client" },
  { method: "GET", path: "/api/transactions?companyId=…", desc: "List transactions" },
  { method: "POST", path: "/api/transactions", desc: "Post a transaction" },
  { method: "GET", path: "/api/journal?companyId=…", desc: "List journal entries" },
  { method: "POST", path: "/api/journal", desc: "Post a balanced Dr/Cr entry" },
  { method: "GET", path: "/api/invoices?companyId=…&type=customer", desc: "List customer invoices" },
  { method: "POST", path: "/api/invoices", desc: "Create an invoice or bill" },
  { method: "GET", path: "/api/invoices/[id]/pdf", desc: "Download invoice as PDF" },
  { method: "POST", path: "/api/import", desc: "Upload PDF/Excel/CSV → auto-post to GL" },
  { method: "GET", path: "/api/reports/pdf?type=pnl&companyId=…", desc: "Download any report as PDF" },
  { method: "POST", path: "/api/agent/chat", desc: "Send a prompt to an AI agent" },
  { method: "GET", path: "/api/tax?companyId=…", desc: "List tax filings" },
  { method: "POST", path: "/api/tax/calculate", desc: "Run tax calculator" },
  { method: "GET", path: "/api/webhooks?companyId=…", desc: "List your webhooks" },
  { method: "POST", path: "/api/webhooks", desc: "Subscribe a webhook" },
];

export function ApiModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const [hooks, setHooks] = React.useState<Webhook[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [createOpen, setCreateOpen] = React.useState(false);

  function load() {
    setLoading(true);
    fetch(`/api/webhooks?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setHooks(d.webhooks); })
      .catch((e) => toast.error(`Failed: ${e.message}`))
      .finally(() => setLoading(false));
  }
  React.useEffect(() => { load(); }, [activeCompanyId]);

  async function toggleHook(h: Webhook, enabled: boolean) {
    setHooks((arr) => arr.map((x) => (x.id === h.id ? { ...x, enabled } : x)));
    try {
      const res = await fetch("/api/webhooks", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: h.id, enabled }) });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(enabled ? "Webhook enabled" : "Webhook paused");
    } catch (e: any) {
      toast.error(e.message);
      setHooks((arr) => arr.map((x) => (x.id === h.id ? { ...x, enabled: h.enabled } : x)));
    }
  }

  async function deleteHook(h: Webhook) {
    setHooks((arr) => arr.filter((x) => x.id !== h.id));
    try {
      const res = await fetch("/api/webhooks", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: h.id } )});
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success("Webhook deleted");
    } catch (e: any) {
      toast.error(e.message);
      load();
    }
  }

  function copyApiKey() {
    const demoKey = `bq_live_${activeCompanyId}_a1b2c3d4e5f6`;
    navigator.clipboard.writeText(demoKey);
    toast.success("API key copied (demo key — replace with a real one in production)");
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">API & Webhooks</h1>
        <p className="text-sm text-muted-foreground">
          Connect Finova to QuickBooks, Xero, Sage, SAP FICO, Oracle NetSuite, Zoho Books and your own apps via REST API and event webhooks.
        </p>
      </div>

      <Tabs defaultValue="connect">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="connect"><Plug className="mr-1.5 size-3.5" /> Connect ERPs</TabsTrigger>
          <TabsTrigger value="rest"><Code2 className="mr-1.5 size-3.5" /> REST API</TabsTrigger>
          <TabsTrigger value="webhooks"><Webhook className="mr-1.5 size-3.5" /> Webhooks ({hooks.length})</TabsTrigger>
        </TabsList>

        {/* Connect ERPs */}
        <TabsContent value="connect" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Connect accounting & ERP software</CardTitle>
              <CardDescription>Click Connect to start the OAuth flow. The AI agents sync data bi-directionally once connected.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-2">
              {PROVIDER_LINKS.map((p) => (
                <div key={p.name} className="rounded-md border p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold">{p.name}</div>
                      <Badge variant="outline" className="text-[10px] mt-1">{p.auth}</Badge>
                    </div>
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">{p.description}</p>
                  {p.note && (
                    <div className="mt-2 rounded bg-amber-500/10 p-2 text-[11px] text-amber-700 dark:text-amber-300">{p.note}</div>
                  )}
                  <div className="mt-2 text-[10px] text-muted-foreground">
                    <div className="font-medium">Scopes</div>
                    <div className="mt-0.5 font-mono">{p.scopes}</div>
                  </div>
                  <div className="mt-1 text-[10px] text-muted-foreground italic">{p.useCase}</div>
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => toast.info(`OAuth flow for ${p.name} — configure credentials in the Integrations tab.`)}>
                      <Plug className="size-3.5" /> Connect
                    </Button>
                    <a href={p.docs} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 hover:underline px-2">
                      <ExternalLink className="size-3" /> Docs
                    </a>
                    <a href={p.console} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 hover:underline px-2">
                      <Key className="size-3" /> Console
                    </a>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* API key */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Your API Key</CardTitle>
              <CardDescription>Use this Bearer token in the Authorization header of every API call.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className="flex-1 rounded-md border bg-muted/30 px-3 py-2 font-mono text-xs">
                  bq_live_{activeCompanyId}_a1b2c3d4e5f6
                </div>
                <Button size="sm" variant="outline" onClick={copyApiKey}>
                  <Copy className="size-3.5" /> Copy
                </Button>
              </div>
              <div className="mt-2 text-[11px] text-muted-foreground flex items-center gap-1">
                <ShieldCheck className="size-3" />
                Demo key — in production, generate a unique secret per client in Settings → API Keys.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* REST API */}
        <TabsContent value="rest" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>REST API endpoints</CardTitle>
              <CardDescription>Base URL: <code className="font-mono text-xs">https://your-domain.com</code>. All routes accept JSON and require a Bearer token.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                {REST_ENDPOINTS.map((e) => (
                  <div key={e.path} className="flex flex-wrap items-center gap-2 rounded-md border px-3 py-2">
                    <Badge className={cn("text-[10px] font-mono", e.method === "GET" ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : e.method === "POST" ? "bg-blue-500/15 text-blue-600 dark:text-blue-400" : "bg-amber-500/15 text-amber-600 dark:text-amber-400")}>
                      {e.method}
                    </Badge>
                    <code className="font-mono text-xs">{e.path}</code>
                    <span className="text-xs text-muted-foreground ml-auto">{e.desc}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 rounded-md bg-muted/30 p-3 text-xs">
                <div className="font-medium mb-1">Example: post a transaction via cURL</div>
                <pre className="font-mono text-[11px] overflow-x-auto">curl -X POST https://your-domain.com/api/transactions \
  -H "Authorization: Bearer bq_live_…" \
  -H "Content-Type: application/json" \
  -d &apos;{`{&quot;companyId&quot;:&quot;co_usa_mfg&quot;,&quot;description&quot;:&quot;AWS bill&quot;,&quot;category&quot;:&quot;Software&quot;,&quot;type&quot;:&quot;expense&quot;,&quot;amount&quot;:4200}`}&apos;</pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Webhooks */}
        <TabsContent value="webhooks" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Webhooks</CardTitle>
                <CardDescription>Finova POSTs events to your URL with an HMAC signature</CardDescription>
              </div>
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <Plus className="size-3.5" /> New Webhook
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {loading ? (
                <Skeleton className="h-20 w-full" />
              ) : hooks.length === 0 ? (
                <p className="text-sm text-muted-foreground">No webhooks yet. Create one to receive real-time events.</p>
              ) : (
                hooks.map((h) => (
                  <div key={h.id} className="rounded-md border p-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-mono truncate">{h.url}</div>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {h.events.map((ev) => (
                            <Badge key={ev} variant="outline" className="text-[10px]">{ev}</Badge>
                          ))}
                        </div>
                        <div className="mt-1 text-[11px] text-muted-foreground">
                          {h.deliveries} deliveries · last {h.lastFiredAt ? new Date(h.lastFiredAt).toLocaleString() : "never"} · {h.lastStatus ? `HTTP ${h.lastStatus}` : "—"}
                        </div>
                        <div className="mt-1 text-[10px] text-muted-foreground">
                          Secret: <code className="font-mono">{h.secretMasked}</code>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={h.enabled} onCheckedChange={(v) => toggleHook(h, v)} aria-label="Toggle webhook" />
                        <Button size="sm" variant="ghost" onClick={() => deleteHook(h)} aria-label="Delete webhook">
                          <Trash2 className="size-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Available events</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-2 md:grid-cols-2">
              {EVENTS.map((e) => (
                <div key={e.id} className="rounded-md border p-2">
                  <code className="text-xs font-mono">{e.id}</code>
                  <div className="mt-0.5 text-[11px] text-muted-foreground">{e.desc}</div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Webhook payload example</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="rounded-md bg-muted/30 p-3 text-[11px] font-mono overflow-x-auto">{`POST /your-webhook-url HTTP/1.1
Host: your-app.com
Content-Type: application/json
X-Finova-Signature: sha256=a1b2c3...

{
  "event": "invoice.paid",
  "companyId": "co_usa_mfg",
  "timestamp": "2026-11-19T10:30:00Z",
  "data": {
    "invoiceId": "cmw...",
    "number": "INV-1234",
    "partyName": "Acme Corp",
    "total": 5000,
    "currency": "USD",
    "status": "paid"
  }
}`}</pre>
              <div className="mt-2 text-[11px] text-muted-foreground flex items-center gap-1">
                <Zap className="size-3" /> Always verify the HMAC signature with your webhook secret before processing.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <CreateWebhookDialog open={createOpen} onOpenChange={setCreateOpen} companyId={activeCompanyId} onSaved={() => { setCreateOpen(false); load(); }} />
    </div>
  );
}

function CreateWebhookDialog({ open, onOpenChange, companyId, onSaved }: { open: boolean; onOpenChange: (b: boolean) => void; companyId: string; onSaved: () => void }) {
  const [url, setUrl] = React.useState("");
  const [selectedEvents, setSelectedEvents] = React.useState<string[]>(["transaction.created", "invoice.paid"]);
  const [newSecret, setNewSecret] = React.useState<string | null>(null);
  const [saving, setSaving] = React.useState(false);

  function toggleEvent(id: string) {
    setSelectedEvents((arr) => arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]);
  }

  async function save() {
    if (!url || selectedEvents.length === 0) { toast.error("URL and at least one event are required"); return; }
    setSaving(true);
    try {
      const res = await fetch("/api/webhooks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyId, url, events: selectedEvents }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      setNewSecret(d.secret);
      toast.success("Webhook created — copy your secret now (shown once)");
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  function copySecret() {
    if (newSecret) {
      navigator.clipboard.writeText(newSecret);
      toast.success("Secret copied");
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) { setNewSecret(null); setUrl(""); } onOpenChange(o); }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New Webhook</DialogTitle>
          <DialogDescription>Finova will POST events to your URL with an HMAC signature header.</DialogDescription>
        </DialogHeader>
        {newSecret ? (
          <div className="space-y-3 py-2">
            <div className="rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-3">
              <div className="text-sm font-medium">Webhook created. Copy your secret now:</div>
              <div className="mt-2 flex items-center gap-2">
                <code className="flex-1 rounded bg-muted/40 px-2 py-1 font-mono text-xs break-all">{newSecret}</code>
                <Button size="sm" variant="outline" onClick={copySecret}><Copy className="size-3.5" /> Copy</Button>
              </div>
              <div className="mt-2 text-[11px] text-muted-foreground">This secret is shown only once. Store it securely — you'll need it to verify HMAC signatures.</div>
            </div>
            <DialogFooter>
              <Button onClick={() => { setNewSecret(null); setUrl(""); onSaved(); }}>Done</Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="space-y-3 py-2">
            <div className="grid gap-2">
              <Label htmlFor="wurl">Webhook URL</Label>
              <Input id="wurl" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://your-app.com/webhooks/finova" />
            </div>
            <div className="grid gap-2">
              <Label>Events to subscribe</Label>
              <div className="max-h-60 space-y-1.5 overflow-y-auto rounded-md border p-2">
                {EVENTS.map((e) => (
                  <label key={e.id} className="flex items-start gap-2 cursor-pointer p-1 hover:bg-muted/40 rounded">
                    <input
                      type="checkbox"
                      checked={selectedEvents.includes(e.id)}
                      onChange={() => toggleEvent(e.id)}
                      className="mt-0.5"
                    />
                    <div className="flex-1 min-w-0">
                      <code className="text-xs font-mono">{e.id}</code>
                      <div className="text-[11px] text-muted-foreground">{e.desc}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}
        {!newSecret && (
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving || !url || selectedEvents.length === 0}>{saving ? "Creating…" : "Create webhook"}</Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
