"use client";

import * as React from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  Percent,
  TimerReset,
  Workflow,
  Plug,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

type DashboardData = {
  company: {
    id: string;
    name: string;
    industry: string;
    country: string;
    currency: string;
    symbol: string;
    taxId: string | null;
  };
  kpis: {
    revenue: { value: number; currency: string; symbol: string; deltaPct: number };
    expenses: { value: number; currency: string; symbol: string; deltaPct: number };
    netProfit: { value: number; currency: string; symbol: string; deltaPct: number };
    margin: { value: number; deltaPct: number };
    cashNow: { value: number; currency: string; symbol: string };
    runwayMonths: number;
    activeAutomations: number;
    connectedIntegrations: number;
  };
  cashFlowSeries: Array<{ date: string; inflow: number; outflow: number; net: number }>;
  expenseBreakdown: Array<{ category: string; amount: number }>;
  recentActivity: Array<{
    id: string;
    date: string;
    description: string;
    category: string;
    type: string;
    amount: number;
    currency: string;
    source: string;
    status: string;
  }>;
  upcomingTax: Array<{
    id: string;
    country: string;
    taxType: string;
    period: string;
    dueDate: string;
    filingStatus: string;
    amount: number | null;
  }>;
  automations: Array<{
    id: string;
    name: string;
    role: string;
    trigger: string;
    lastRunAt: string | null;
    nextRunAt: string | null;
    runsCount: number;
  }>;
  integrations: Array<{
    id: string;
    provider: string;
    label: string;
    status: string;
    lastSyncAt: string | null;
    accountEmail: string | null;
  }>;
};

const PIE_COLORS = ["#10b981", "#34d399", "#6ee7b7", "#a7f3d0", "#fbbf24", "#f59e0b", "#ef4444", "#f87171", "#60a5fa", "#93c5fd"];

function fmtMoney(value: number, symbol: string) {
  if (Math.abs(value) >= 1_000_000) return `${symbol}${(value / 1_000_000).toFixed(2)}M`;
  if (Math.abs(value) >= 1_000) return `${symbol}${(value / 1_000).toFixed(1)}K`;
  return `${symbol}${value.toFixed(0)}`;
}

function KpiCard({
  title,
  value,
  deltaPct,
  icon: Icon,
  positiveIsGood = true,
  sub,
}: {
  title: string;
  value: string;
  deltaPct?: number;
  icon: React.ElementType;
  positiveIsGood?: boolean;
  sub?: string;
}) {
  const positive = (deltaPct ?? 0) >= 0;
  const good = positive === positiveIsGood;
  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xs font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="size-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold tracking-tight">{value}</div>
        <div className="mt-1 flex items-center gap-1.5 text-xs">
          {deltaPct !== undefined && (
            <span className={cn("inline-flex items-center gap-0.5 font-medium", good ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>
              {positive ? <ArrowUpRight className="size-3" /> : <ArrowDownRight className="size-3" />}
              {Math.abs(deltaPct).toFixed(1)}%
            </span>
          )}
          {sub && <span className="text-muted-foreground">{sub}</span>}
        </div>
      </CardContent>
    </Card>
  );
}

export function DashboardModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const [data, setData] = React.useState<DashboardData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetch(`/api/dashboard?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => {
        if (cancelled) return;
        if (d.error) {
          setError(d.error);
        } else {
          setData(d);
        }
      })
      .catch((e) => !cancelled && setError(e.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [activeCompanyId]);

  if (loading) {
    return (
      <div className="space-y-4 p-4 md:p-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }
  if (error || !data) {
    return <div className="p-6 text-sm text-destructive">Failed to load dashboard: {error}</div>;
  }

  const { company, kpis } = data;
  const sym = company.symbol;

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{company.name}</h1>
        <p className="text-sm text-muted-foreground">
          {company.industry} · {company.country} · {company.currency} · Tax ID {company.taxId ?? "n/a"}
        </p>
      </div>

      {/* KPI grid */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard
          title="Revenue (90d)"
          value={fmtMoney(kpis.revenue.value, sym)}
          deltaPct={kpis.revenue.deltaPct}
          icon={TrendingUp}
          sub="vs. prior period"
        />
        <KpiCard
          title="Expenses (90d)"
          value={fmtMoney(kpis.expenses.value, sym)}
          deltaPct={kpis.expenses.deltaPct}
          icon={TrendingDown}
          positiveIsGood={false}
          sub="vs. prior period"
        />
        <KpiCard
          title="Net Profit"
          value={fmtMoney(kpis.netProfit.value, sym)}
          deltaPct={kpis.netProfit.deltaPct}
          icon={PiggyBank}
          sub={`Margin ${kpis.margin.value.toFixed(1)}%`}
        />
        <KpiCard
          title="Cash on Hand"
          value={fmtMoney(kpis.cashNow.value, sym)}
          icon={Wallet}
          sub={`Runway ${kpis.runwayMonths} mo`}
        />
      </div>

      {/* Secondary stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Margin</CardTitle>
            <Percent className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpis.margin.value.toFixed(1)}%</div>
            <div className="mt-1 text-xs text-muted-foreground">Net / Revenue</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Runway</CardTitle>
            <TimerReset className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpis.runwayMonths} mo</div>
            <div className="mt-1 text-xs text-muted-foreground">at current burn</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Active Automations</CardTitle>
            <Workflow className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpis.activeAutomations}</div>
            <div className="mt-1 text-xs text-muted-foreground">running</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Integrations</CardTitle>
            <Plug className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpis.connectedIntegrations}</div>
            <div className="mt-1 text-xs text-muted-foreground">connected</div>
          </CardContent>
        </Card>
      </div>

      {/* Cash flow + Expense breakdown */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Cash Flow — last 30 days</CardTitle>
            <CardDescription>Daily inflow vs. outflow</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={data.cashFlowSeries}>
                <defs>
                  <linearGradient id="inflow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="outflow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" vertical={false} />
                <XAxis
                  dataKey="date"
                  tickFormatter={(d) => String(d).slice(5)}
                  fontSize={10}
                  className="text-muted-foreground"
                  tickMargin={8}
                />
                <YAxis
                  tickFormatter={(v) => fmtMoney(Number(v), sym)}
                  fontSize={10}
                  className="text-muted-foreground"
                  width={60}
                />
                <Tooltip
                  formatter={(value: number, name: string) => [fmtMoney(Number(value), sym), name === "inflow" ? "Inflow" : name === "outflow" ? "Outflow" : "Net"]}
                  labelFormatter={(l) => `Date: ${l}`}
                  contentStyle={{ borderRadius: 8, border: "1px solid var(--border)", fontSize: 12 }}
                />
                <Area type="monotone" dataKey="inflow" stroke="#10b981" fill="url(#inflow)" strokeWidth={2} />
                <Area type="monotone" dataKey="outflow" stroke="#f43f5e" fill="url(#outflow)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Expense Breakdown</CardTitle>
            <CardDescription>By category, last 90 days</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={data.expenseBreakdown.slice(0, 8)}
                  dataKey="amount"
                  nameKey="category"
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={90}
                  paddingAngle={2}
                >
                  {data.expenseBreakdown.slice(0, 8).map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => fmtMoney(Number(v), sym)} contentStyle={{ borderRadius: 8, border: "1px solid var(--border)", fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-muted-foreground">
              {data.expenseBreakdown.slice(0, 8).map((c, i) => (
                <div key={c.category} className="flex items-center gap-1">
                  <span className="inline-block size-2 rounded-full" style={{ backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }} />
                  {c.category}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent activity + Upcoming tax */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest 10 transactions across all sources</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <div className="max-h-80 overflow-y-auto rounded-md border">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-muted/60 backdrop-blur">
                  <tr className="text-left text-xs text-muted-foreground">
                    <th className="px-3 py-2 font-medium">Date</th>
                    <th className="px-3 py-2 font-medium">Description</th>
                    <th className="px-3 py-2 font-medium">Category</th>
                    <th className="px-3 py-2 font-medium">Source</th>
                    <th className="px-3 py-2 text-right font-medium">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recentActivity.map((t) => (
                    <tr key={t.id} className="border-t">
                      <td className="px-3 py-2 text-xs text-muted-foreground">{new Date(t.date).toLocaleDateString()}</td>
                      <td className="px-3 py-2">{t.description}</td>
                      <td className="px-3 py-2 text-xs">{t.category}</td>
                      <td className="px-3 py-2 text-xs">
                        <Badge variant="outline" className="text-[10px]">{t.source}</Badge>
                      </td>
                      <td className={cn("px-3 py-2 text-right font-medium", t.type === "income" ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>
                        {t.type === "income" ? "+" : "-"}{fmtMoney(t.amount, sym)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Tax Filings</CardTitle>
            <CardDescription>Next 4 deadlines</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {data.upcomingTax.length === 0 && <p className="text-sm text-muted-foreground">No upcoming filings.</p>}
            {data.upcomingTax.map((t) => {
              const days = Math.ceil((new Date(t.dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
              const urgent = days <= 14;
              return (
                <div key={t.id} className="rounded-md border p-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium">{t.taxType}</div>
                    <Badge variant={urgent ? "destructive" : "secondary"} className="text-[10px]">{days}d</Badge>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">{t.period}</div>
                  <div className="mt-1 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Due {new Date(t.dueDate).toLocaleDateString()}</span>
                    <Badge variant="outline" className="text-[10px]">{t.filingStatus}</Badge>
                  </div>
                  {t.amount != null && t.amount > 0 && (
                    <div className="mt-1 text-xs font-medium">{fmtMoney(t.amount, sym)} estimated</div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>

      {/* Active automations + integrations summary */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Active Automations</CardTitle>
            <CardDescription>Recurring tasks currently enabled</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {data.automations.length === 0 && <p className="text-sm text-muted-foreground">No automations enabled.</p>}
            {data.automations.slice(0, 5).map((a) => (
              <div key={a.id} className="flex items-start justify-between gap-3 rounded-md border p-3">
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium">{a.name}</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">
                    {a.role.toUpperCase()} · {a.trigger} · {a.runsCount} runs
                  </div>
                </div>
                <Badge variant="secondary" className="text-[10px]">{a.trigger}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Connected Integrations</CardTitle>
            <CardDescription>Gmail, accounting software & banks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {data.integrations.map((i) => (
              <div key={i.id} className="flex items-center justify-between gap-3 rounded-md border p-3">
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium capitalize">{i.provider}</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">{i.label}</div>
                </div>
                <Badge variant={i.status === "connected" ? "default" : "destructive"} className="text-[10px]">{i.status}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
