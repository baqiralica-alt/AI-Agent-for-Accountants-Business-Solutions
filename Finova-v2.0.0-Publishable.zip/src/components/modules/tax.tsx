"use client";

import * as React from "react";
import { Landmark, Calculator, FileText, AlertTriangle, CheckCircle2, Clock, Flag, Receipt, BookOpen, ArrowRightCircle } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { ConceptsAppliedPanel } from "@/components/concepts-applied-panel";

type TaxRecord = {
  id: string;
  country: string;
  taxType: string;
  period: string;
  dueDate: string;
  filingStatus: string;
  amount: number | null;
  notes: string | null;
};

type DeferredTaxData = {
  totals: any;
  movement: any;
  reconciliation: any;
  tempDiffsPAndL: any[];
  tempDiffsOci: any[];
  journalEntries: any[];
  jeVerification: any;
  standards: any;
  disclosureNote: string;
  rates: any;
};

const COUNTRY_LABEL: Record<string, string> = {
  USA: "United States",
  UK: "United Kingdom",
  Germany: "Germany (EU)",
  France: "France (EU)",
  Ireland: "Ireland (EU)",
  Canada: "Canada",
};

const COUNTRY_FLAG: Record<string, string> = {
  USA: "🇺🇸",
  UK: "🇬🇧",
  Germany: "🇩🇪",
  France: "🇫🇷",
  Ireland: "🇮🇪",
  Canada: "🇨🇦",
};

const TAX_TYPE_LABEL: Record<string, string> = {
  "federal-income": "Federal Income Tax",
  "state-income": "State Income Tax",
  "sales-tax": "Sales / Use Tax",
  "corporation-tax": "Corporation Tax",
  "vat": "VAT / MTD",
  "payroll": "Payroll (PAYE / NI / Lohnsteuer)",
  "self-assessment": "Self-Assessment",
};

const STATUS_STYLE: Record<string, string> = {
  pending: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  filed: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  paid: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  overdue: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
};

export function TaxModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [records, setRecords] = React.useState<TaxRecord[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [deferredTax, setDeferredTax] = React.useState<DeferredTaxData | null>(null);
  const [deferredLoading, setDeferredLoading] = React.useState(false);

  // Calculator inputs
  const country = activeCompany?.country ?? "USA";
  const [calcCountry, setCalcCountry] = React.useState(country);
  const [taxType, setTaxType] = React.useState("corporation-tax");
  const [revenue, setRevenue] = React.useState("500000");
  const [expenses, setExpenses] = React.useState("320000");
  const [calcResult, setCalcResult] = React.useState<any>(null);
  const [calculating, setCalculating] = React.useState(false);

  React.useEffect(() => {
    setCalcCountry(country);
  }, [country]);

  function load() {
    setLoading(true);
    fetch(`/api/tax?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setRecords(d.taxRecords);
      })
      .catch((e) => toast.error(`Failed to load: ${e.message}`))
      .finally(() => setLoading(false));
  }

  function loadDeferredTax() {
    setDeferredLoading(true);
    fetch(`/api/tax/deferred?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setDeferredTax(d);
      })
      .catch((e) => toast.error(`Deferred tax load failed: ${e.message}`))
      .finally(() => setDeferredLoading(false));
  }

  React.useEffect(() => { load(); loadDeferredTax(); }, [activeCompanyId]);

  async function markFiled(rec: TaxRecord, status: "filed" | "paid") {
    setRecords((arr) => arr.map((r) => (r.id === rec.id ? { ...r, filingStatus: status } : r)));
    try {
      const res = await fetch("/api/tax", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: rec.id, filingStatus: status }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`Marked as ${status}`);
    } catch (e: any) {
      toast.error(e.message);
      setRecords((arr) => arr.map((r) => (r.id === rec.id ? { ...r, filingStatus: rec.filingStatus } : r)));
    }
  }

  async function runCalc() {
    setCalculating(true);
    setCalcResult(null);
    try {
      const res = await fetch("/api/tax/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          country: calcCountry,
          taxType,
          revenue: Number(revenue),
          expenses: Number(expenses),
        }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      setCalcResult(d);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setCalculating(false);
    }
  }

  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";

  // Stats
  const pendingCount = records.filter((r) => r.filingStatus === "pending").length;
  const filedCount = records.filter((r) => r.filingStatus === "filed" || r.filingStatus === "paid").length;
  const overdueCount = records.filter((r) => {
    return r.filingStatus !== "filed" && r.filingStatus !== "paid" && new Date(r.dueDate) < new Date();
  }).length;
  const totalLiability = records
    .filter((r) => r.filingStatus === "pending")
    .reduce((s, r) => s + (r.amount ?? 0), 0);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Tax Center</h1>
        <p className="text-sm text-muted-foreground">
          Country-aware tax management for USA, UK and EU — Filings, Normal Tax, Deferred Tax (IAS 12 / ASC 740 / FRS 102 / IFRS-EU), Calculator, and Regimes. Journal entries included.
        </p>
      </div>

      {/* Country banner */}
      <Card className={cn("border-l-4", country === "USA" ? "border-l-blue-500" : country === "UK" ? "border-l-rose-500" : "border-l-amber-500")}>
        <CardContent className="flex flex-wrap items-center justify-between gap-3 py-4">
          <div className="flex items-center gap-3">
            <div className="text-2xl">{COUNTRY_FLAG[country] ?? "🏳️"}</div>
            <div>
              <div className="text-sm font-semibold">{COUNTRY_LABEL[country] ?? country}</div>
              <div className="text-xs text-muted-foreground">
                Active regime for {activeCompany?.name} — {activeCompany?.taxId ?? "no tax ID"}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-3 text-center">
            <div>
              <div className="text-xl font-bold">{pendingCount}</div>
              <div className="text-[10px] text-muted-foreground">Pending</div>
            </div>
            <div>
              <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{filedCount}</div>
              <div className="text-[10px] text-muted-foreground">Filed</div>
            </div>
            <div>
              <div className="text-xl font-bold text-destructive">{overdueCount}</div>
              <div className="text-[10px] text-muted-foreground">Overdue</div>
            </div>
            <div>
              <div className="text-xl font-bold">{sym}{(totalLiability / 1000).toFixed(1)}K</div>
              <div className="text-[10px] text-muted-foreground">Liability</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="filings">
        <TabsList className="grid w-full grid-cols-3 md:grid-cols-5">
          <TabsTrigger value="filings"><FileText className="mr-1.5 size-3.5" /> Filings</TabsTrigger>
          <TabsTrigger value="normal-tax"><Receipt className="mr-1.5 size-3.5" /> Normal Tax</TabsTrigger>
          <TabsTrigger value="deferred-tax"><ArrowRightCircle className="mr-1.5 size-3.5" /> Deferred Tax</TabsTrigger>
          <TabsTrigger value="calc"><Calculator className="mr-1.5 size-3.5" /> Calculator</TabsTrigger>
          <TabsTrigger value="regimes"><Landmark className="mr-1.5 size-3.5" /> Regimes</TabsTrigger>
        </TabsList>

        {/* Filings */}
        <TabsContent value="filings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Filings & Deadlines</CardTitle>
              <CardDescription>All upcoming and historical tax filings for this company</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
              ) : records.length === 0 ? (
                <p className="text-sm text-muted-foreground">No tax records.</p>
              ) : (
                <div className="space-y-2">
                  {records.map((r) => {
                    const due = new Date(r.dueDate);
                    const days = Math.ceil((due.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
                    const overdue = days < 0 && r.filingStatus !== "filed" && r.filingStatus !== "paid";
                    const urgent = days >= 0 && days <= 14;
                    return (
                      <div key={r.id} className="flex flex-col gap-3 rounded-md border p-3 sm:flex-row sm:items-center">
                        <div className="flex size-10 shrink-0 items-center justify-center rounded-md bg-muted">
                          {overdue ? <AlertTriangle className="size-5 text-destructive" /> : urgent ? <Clock className="size-5 text-amber-500" /> : <Flag className="size-5 text-muted-foreground" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-medium">{TAX_TYPE_LABEL[r.taxType] ?? r.taxType}</span>
                            <Badge variant="outline" className="text-[10px]">{COUNTRY_FLAG[r.country]} {r.country}</Badge>
                            <span className={cn("rounded px-1.5 py-0.5 text-[10px] font-medium", STATUS_STYLE[r.filingStatus] ?? "bg-muted")}>{r.filingStatus}</span>
                          </div>
                          <div className="mt-1 text-xs text-muted-foreground">
                            {r.period} · due {due.toLocaleDateString()} ({overdue ? `${Math.abs(days)}d overdue` : `${days}d`})
                          </div>
                          {r.amount != null && r.amount > 0 && (
                            <div className="mt-1 text-xs font-medium">Estimated: {sym}{r.amount.toLocaleString()}</div>
                          )}
                        </div>
                        <div className="flex gap-2">
                          {r.filingStatus !== "filed" && r.filingStatus !== "paid" && (
                            <>
                              <Button size="sm" variant="outline" onClick={() => markFiled(r, "filed")}>Mark filed</Button>
                              <Button size="sm" onClick={() => markFiled(r, "paid")}>Mark paid</Button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Normal Tax (Current Tax) — per IAS 12.80 / FRS 102 s29 / ASC 740-30 / EU IFRS-EU */}
        <TabsContent value="normal-tax" className="space-y-4">
          <Card className="border-l-4 border-l-emerald-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Receipt className="size-5 text-emerald-600" /> Normal (Current) Tax Computation</CardTitle>
              <CardDescription>Year Ended 31 December 2025 · IAS 12.80 · FRS 102 s29 · ASC 740-30 · EU IFRS-EU</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {deferredLoading ? (
                <Skeleton className="h-72 w-full" />
              ) : deferredTax ? (
                <>
                  {/* Tax reconciliation table */}
                  <div className="overflow-x-auto rounded-md border">
                    <table className="w-full text-sm">
                      <thead className="bg-emerald-700 text-white">
                        <tr>
                          <th className="px-3 py-2 text-left font-semibold">Item</th>
                          <th className="px-3 py-2 text-right font-semibold">£</th>
                          <th className="px-3 py-2 text-center font-semibold w-28">Type</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-t bg-muted/30 font-semibold"><td className="px-3 py-2" colSpan={3}>Accounting Profit Before Tax</td></tr>
                        <tr className="border-t font-bold"><td className="px-3 py-2">Profit per Income Statement</td><td className="px-3 py-2 text-right font-mono">{sym}{Math.round(deferredTax.reconciliation.accountingProfitBeforeTax).toLocaleString()}</td><td></td></tr>
                        <tr className="border-t bg-muted/30 font-semibold"><td className="px-3 py-2" colSpan={3}>Adjustments to Taxable Profit</td></tr>
                        {deferredTax.reconciliation.currentTaxAdjustments.map((adj: any, i: number) => (
                          <tr key={i} className="border-t">
                            <td className="px-3 py-1.5">{adj.item}</td>
                            <td className="px-3 py-1.5 text-right font-mono">{adj.amount < 0 ? `(${sym}${Math.abs(Math.round(adj.amount)).toLocaleString()})` : `${sym}${Math.round(adj.amount).toLocaleString()}`}</td>
                            <td className="px-3 py-1.5 text-center"><Badge variant="outline" className="text-[10px]">{adj.type}</Badge></td>
                          </tr>
                        ))}
                        <tr className="border-t-2 bg-emerald-500/15 font-bold"><td className="px-3 py-2">Taxable Profit</td><td className="px-3 py-2 text-right font-mono">{sym}{Math.round(deferredTax.reconciliation.taxableProfit).toLocaleString()}</td><td></td></tr>
                        <tr className="border-t"><td className="px-3 py-1.5">UK Corporation Tax Rate</td><td className="px-3 py-1.5 text-right">{(deferredTax.reconciliation.currentTaxRate * 100).toFixed(0)}%</td><td></td></tr>
                        <tr className="border-t-2 bg-emerald-600 font-bold text-white"><td className="px-3 py-3 text-base">Current (Normal) Tax Liability</td><td className="px-3 py-3 text-right font-mono text-base">{sym}{Math.round(deferredTax.reconciliation.currentTax).toLocaleString()}</td><td></td></tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Standards applied */}
                  <div className="rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-3">
                    <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Standards Applied — Normal Tax</div>
                    <div className="grid gap-2 text-xs md:grid-cols-4">
                      <div className="rounded border border-emerald-500/30 p-2">
                        <div className="font-semibold text-emerald-700 dark:text-emerald-300">IFRS (IASB)</div>
                        <div className="text-muted-foreground">IAS 12.80 — current tax = amount expected to be paid to/recovered from tax authorities based on enacted rates at reporting date.</div>
                      </div>
                      <div className="rounded border border-blue-500/30 p-2">
                        <div className="font-semibold text-blue-700 dark:text-blue-300">US GAAP (FASB)</div>
                        <div className="text-muted-foreground">ASC 740-30 — current tax expense = estimated taxable income × enacted statutory rate. Payable within 12 months → current.</div>
                      </div>
                      <div className="rounded border border-amber-500/30 p-2">
                        <div className="font-semibold text-amber-700 dark:text-amber-300">UK FRS 102</div>
                        <div className="text-muted-foreground">FRS 102 s29 — current tax based on UK Corporation Tax Act 2010. Main rate 25% for profits ≥ £250,000; small profits rate 19% for profits ≤ £50,000; marginal relief in between.</div>
                      </div>
                      <div className="rounded border border-violet-500/30 p-2">
                        <div className="font-semibold text-violet-700 dark:text-violet-300">EU (IFRS-EU)</div>
                        <div className="text-muted-foreground">IAS 12 as endorsed by European Commission via IAS Regulation 1606/2002. Member state national tax codes (Germany KStG, France CGI, Ireland TCA) determine taxable profit.</div>
                      </div>
                    </div>
                  </div>

                  {/* Payment & filing deadlines */}
                  <div className="grid gap-3 md:grid-cols-3">
                    <div className="rounded-md border p-3">
                      <div className="text-xs font-semibold uppercase text-muted-foreground mb-1">CT600 Filing Deadline</div>
                      <div className="text-sm font-bold">31 December 2026</div>
                      <div className="text-[10px] text-muted-foreground">12 months after FY-end</div>
                    </div>
                    <div className="rounded-md border p-3">
                      <div className="text-xs font-semibold uppercase text-muted-foreground mb-1">CT Payment Deadline</div>
                      <div className="text-sm font-bold">1 October 2026</div>
                      <div className="text-[10px] text-muted-foreground">9 months + 1 day after FY-end</div>
                    </div>
                    <div className="rounded-md border p-3">
                      <div className="text-xs font-semibold uppercase text-muted-foreground mb-1">Quarterly Instalments?</div>
                      <div className="text-sm font-bold">No</div>
                      <div className="text-[10px] text-muted-foreground">Small company — annual payment</div>
                    </div>
                  </div>

                  {/* Journal entry for normal tax */}
                  <div className="rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-4">
                    <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Journal Entry — Normal Tax Provision (JE-TAX-001)</div>
                    <div className="overflow-x-auto rounded-md border">
                      <table className="w-full text-xs">
                        <thead className="bg-emerald-700/80 text-white">
                          <tr>
                            <th className="px-2 py-1.5 text-left font-semibold">Date</th>
                            <th className="px-2 py-1.5 text-left font-semibold">Account</th>
                            <th className="px-2 py-1.5 text-right font-semibold">Debit £</th>
                            <th className="px-2 py-1.5 text-right font-semibold">Credit £</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-t"><td className="px-2 py-1.5 font-mono">2025-12-31</td><td className="px-2 py-1.5">8000 — Corporation Tax (P&L expense)</td><td className="px-2 py-1.5 text-right font-mono">{Math.round(deferredTax.reconciliation.currentTax).toLocaleString()}</td><td className="px-2 py-1.5 text-right font-mono">—</td></tr>
                          <tr className="border-t"><td className="px-2 py-1.5 font-mono">2025-12-31</td><td className="px-2 py-1.5">2400 — Corporation Tax Payable (BS liability)</td><td className="px-2 py-1.5 text-right font-mono">—</td><td className="px-2 py-1.5 text-right font-mono">{Math.round(deferredTax.reconciliation.currentTax).toLocaleString()}</td></tr>
                          <tr className="border-t-2 font-bold bg-emerald-500/15"><td className="px-2 py-1.5" colSpan={2}>Total (balanced)</td><td className="px-2 py-1.5 text-right font-mono">{Math.round(deferredTax.reconciliation.currentTax).toLocaleString()}</td><td className="px-2 py-1.5 text-right font-mono">{Math.round(deferredTax.reconciliation.currentTax).toLocaleString()}</td></tr>
                        </tbody>
                      </table>
                    </div>
                    <div className="mt-2 text-[10px] text-muted-foreground">
                      <strong>Standard:</strong> IAS 12.80 / FRS 102 s29 / ASC 740-30 / EU IFRS-EU. Recognises the current tax obligation at the enacted UK CT rate of 25%.
                      Payable 9 months + 1 day after year-end (1 October 2026) per UK Corporation Tax Act 2010 s14.
                    </div>
                  </div>
                </>
              ) : (
                <p className="text-sm text-muted-foreground">Deferred tax data not available.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Deferred Tax — per IAS 12 / ASC 740 / FRS 102 s29 / EU IFRS-EU */}
        <TabsContent value="deferred-tax" className="space-y-4">
          {deferredLoading ? (
            <Skeleton className="h-96 w-full" />
          ) : deferredTax ? (
            <>
              {/* Deferred Tax Summary Card */}
              <Card className="border-l-4 border-l-violet-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><ArrowRightCircle className="size-5 text-violet-600" /> Deferred Tax Computation</CardTitle>
                  <CardDescription>Year Ended 31 December 2025 · IAS 12 · ASC 740 · FRS 102 s29 · EU IFRS-EU</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* KPI strip */}
                  <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
                    <div className="rounded-md border border-violet-500/30 bg-violet-500/5 p-2 text-center">
                      <div className="text-[10px] uppercase text-muted-foreground">Total DTL</div>
                      <div className="font-bold text-violet-700 dark:text-violet-300">{sym}{Math.round(deferredTax.totals.totalDtl).toLocaleString()}</div>
                    </div>
                    <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2 text-center">
                      <div className="text-[10px] uppercase text-muted-foreground">Total DTA</div>
                      <div className="font-bold text-emerald-700 dark:text-emerald-300">{sym}{Math.round(deferredTax.totals.totalDta).toLocaleString()}</div>
                    </div>
                    <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-2 text-center">
                      <div className="text-[10px] uppercase text-muted-foreground">Net DTL (BS)</div>
                      <div className="font-bold">{sym}{Math.round(deferredTax.totals.netDeferredTaxLiability).toLocaleString()}</div>
                    </div>
                    <div className="rounded-md border border-rose-500/30 bg-rose-500/5 p-2 text-center">
                      <div className="text-[10px] uppercase text-muted-foreground">Deferred Tax P&L Charge</div>
                      <div className="font-bold text-rose-700 dark:text-rose-300">{sym}{Math.round(deferredTax.totals.netDtlPAndL).toLocaleString()}</div>
                    </div>
                    <div className="rounded-md border border-teal-500/30 bg-teal-500/5 p-2 text-center">
                      <div className="text-[10px] uppercase text-muted-foreground">Deferred Tax OCI Charge</div>
                      <div className="font-bold text-teal-700 dark:text-teal-300">{sym}{Math.round(deferredTax.totals.netDtlOci).toLocaleString()}</div>
                    </div>
                  </div>

                  {/* Temporary Differences — P&L */}
                  <div>
                    <div className="text-sm font-semibold mb-2 flex items-center gap-2">
                      <Badge variant="outline" className="text-[10px] border-violet-500/30 text-violet-700 dark:text-violet-300">P&L</Badge>
                      Temporary Differences affecting Profit or Loss
                    </div>
                    <div className="overflow-x-auto rounded-md border">
                      <table className="w-full text-xs">
                        <thead className="bg-violet-700 text-white">
                          <tr>
                            <th className="px-2 py-2 text-left font-semibold">Item</th>
                            <th className="px-2 py-2 text-right font-semibold">Carrying £</th>
                            <th className="px-2 py-2 text-right font-semibold">Tax Base £</th>
                            <th className="px-2 py-2 text-right font-semibold">Temp Diff £</th>
                            <th className="px-2 py-2 text-right font-semibold">DTL £</th>
                            <th className="px-2 py-2 text-right font-semibold">DTA £</th>
                            <th className="px-2 py-2 text-left font-semibold">Standard</th>
                          </tr>
                        </thead>
                        <tbody>
                          {deferredTax.tempDiffsPAndL.map((t: any, i: number) => (
                            <tr key={i} className={cn("border-t align-top", i % 2 === 0 ? "bg-muted/20" : "")}>
                              <td className="px-2 py-2 font-medium">{t.item}<div className="text-[10px] text-muted-foreground mt-1">{t.note}</div></td>
                              <td className="px-2 py-2 text-right font-mono">{t.carryingAmount.toLocaleString()}</td>
                              <td className="px-2 py-2 text-right font-mono">{t.taxBase.toLocaleString()}</td>
                              <td className="px-2 py-2 text-right font-mono">{t.temporaryDifference > 0 ? `+${t.temporaryDifference.toLocaleString()}` : t.temporaryDifference.toLocaleString()}</td>
                              <td className="px-2 py-2 text-right font-mono text-violet-700 dark:text-violet-300">{t.dtl > 0 ? t.dtl.toLocaleString() : "—"}</td>
                              <td className="px-2 py-2 text-right font-mono text-emerald-700 dark:text-emerald-300">{t.dta > 0 ? t.dta.toLocaleString() : "—"}</td>
                              <td className="px-2 py-2 text-[10px] text-muted-foreground">{t.standard}</td>
                            </tr>
                          ))}
                          <tr className="border-t-2 bg-violet-500/15 font-bold">
                            <td className="px-2 py-2" colSpan={4}>Subtotal — P&L Temporary Differences</td>
                            <td className="px-2 py-2 text-right font-mono text-violet-700 dark:text-violet-300">{sym}{Math.round(deferredTax.totals.totalDtlPAndL).toLocaleString()}</td>
                            <td className="px-2 py-2 text-right font-mono text-emerald-700 dark:text-emerald-300">{sym}{Math.round(deferredTax.totals.totalDtaPAndL).toLocaleString()}</td>
                            <td></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Temporary Differences — OCI */}
                  <div>
                    <div className="text-sm font-semibold mb-2 flex items-center gap-2">
                      <Badge variant="outline" className="text-[10px] border-teal-500/30 text-teal-700 dark:text-teal-300">OCI</Badge>
                      Temporary Differences affecting Other Comprehensive Income (IAS 12.91)
                    </div>
                    <div className="overflow-x-auto rounded-md border">
                      <table className="w-full text-xs">
                        <thead className="bg-teal-700 text-white">
                          <tr>
                            <th className="px-2 py-2 text-left font-semibold">Item</th>
                            <th className="px-2 py-2 text-right font-semibold">Carrying £</th>
                            <th className="px-2 py-2 text-right font-semibold">Tax Base £</th>
                            <th className="px-2 py-2 text-right font-semibold">Temp Diff £</th>
                            <th className="px-2 py-2 text-right font-semibold">DTL £</th>
                            <th className="px-2 py-2 text-right font-semibold">DTA £</th>
                            <th className="px-2 py-2 text-left font-semibold">Standard</th>
                          </tr>
                        </thead>
                        <tbody>
                          {deferredTax.tempDiffsOci.map((t: any, i: number) => (
                            <tr key={i} className={cn("border-t align-top", i % 2 === 0 ? "bg-muted/20" : "")}>
                              <td className="px-2 py-2 font-medium">{t.item}<div className="text-[10px] text-muted-foreground mt-1">{t.note}</div></td>
                              <td className="px-2 py-2 text-right font-mono">{t.carryingAmount.toLocaleString()}</td>
                              <td className="px-2 py-2 text-right font-mono">{t.taxBase.toLocaleString()}</td>
                              <td className="px-2 py-2 text-right font-mono">{t.temporaryDifference > 0 ? `+${t.temporaryDifference.toLocaleString()}` : t.temporaryDifference.toLocaleString()}</td>
                              <td className="px-2 py-2 text-right font-mono text-violet-700 dark:text-violet-300">{t.dtl > 0 ? t.dtl.toLocaleString() : "—"}</td>
                              <td className="px-2 py-2 text-right font-mono text-emerald-700 dark:text-emerald-300">{t.dta > 0 ? t.dta.toLocaleString() : "—"}</td>
                              <td className="px-2 py-2 text-[10px] text-muted-foreground">{t.standard}</td>
                            </tr>
                          ))}
                          <tr className="border-t-2 bg-teal-500/15 font-bold">
                            <td className="px-2 py-2" colSpan={4}>Subtotal — OCI Temporary Differences (tax debited/credited to OCI per IAS 12.91)</td>
                            <td className="px-2 py-2 text-right font-mono text-violet-700 dark:text-violet-300">{sym}{Math.round(deferredTax.totals.totalDtlOci).toLocaleString()}</td>
                            <td className="px-2 py-2 text-right font-mono text-emerald-700 dark:text-emerald-300">{sym}{Math.round(deferredTax.totals.totalDtaOci).toLocaleString()}</td>
                            <td></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Movement Schedule */}
                  <div className="rounded-md border p-3">
                    <div className="text-sm font-semibold mb-2">Deferred Tax Movement Schedule</div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead className="bg-muted/40">
                          <tr>
                            <th className="px-2 py-1.5 text-left font-semibold">Component</th>
                            <th className="px-2 py-1.5 text-right font-semibold">Opening £</th>
                            <th className="px-2 py-1.5 text-right font-semibold">P&L Movement £</th>
                            <th className="px-2 py-1.5 text-right font-semibold">OCI Movement £</th>
                            <th className="px-2 py-1.5 text-right font-semibold">Closing £</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-t"><td className="px-2 py-1.5">Deferred Tax Liability (DTL)</td><td className="px-2 py-1.5 text-right font-mono">{deferredTax.movement.openingDtl.toLocaleString()}</td><td className="px-2 py-1.5 text-right font-mono text-violet-700 dark:text-violet-300">+{Math.round(deferredTax.totals.totalDtlPAndL).toLocaleString()}</td><td className="px-2 py-1.5 text-right font-mono text-teal-700 dark:text-teal-300">+{Math.round(deferredTax.totals.totalDtlOci).toLocaleString()}</td><td className="px-2 py-1.5 text-right font-mono font-bold">{Math.round(deferredTax.movement.closingDtl).toLocaleString()}</td></tr>
                          <tr className="border-t bg-muted/20"><td className="px-2 py-1.5">Deferred Tax Asset (DTA)</td><td className="px-2 py-1.5 text-right font-mono">{deferredTax.movement.openingDta.toLocaleString()}</td><td className="px-2 py-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300">+{Math.round(deferredTax.totals.totalDtaPAndL).toLocaleString()}</td><td className="px-2 py-1.5 text-right font-mono text-teal-700 dark:text-teal-300">+{Math.round(deferredTax.totals.totalDtaOci).toLocaleString()}</td><td className="px-2 py-1.5 text-right font-mono font-bold">{Math.round(deferredTax.movement.closingDta).toLocaleString()}</td></tr>
                          <tr className="border-t-2 bg-violet-500/15 font-bold"><td className="px-2 py-2">Net Deferred Tax Liability</td><td className="px-2 py-2 text-right font-mono">0</td><td className="px-2 py-2 text-right font-mono text-rose-700 dark:text-rose-400">+{Math.round(deferredTax.totals.netDtlPAndL).toLocaleString()}</td><td className="px-2 py-2 text-right font-mono text-teal-700 dark:text-teal-300">+{Math.round(deferredTax.totals.netDtlOci).toLocaleString()}</td><td className="px-2 py-2 text-right font-mono">{Math.round(deferredTax.movement.closingNetDeferredTaxLiability).toLocaleString()}</td></tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Effective Tax Rate Reconciliation */}
                  <div className="rounded-md border-l-4 border-l-amber-500 bg-amber-500/5 p-3">
                    <div className="text-sm font-semibold mb-2">Effective Tax Rate Reconciliation</div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between"><span className="text-muted-foreground">Accounting profit before tax</span><span className="font-mono font-bold">{sym}{Math.round(deferredTax.reconciliation.accountingProfitBeforeTax).toLocaleString()}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">Current tax @ 25%</span><span className="font-mono">{sym}{Math.round(deferredTax.reconciliation.currentTax).toLocaleString()}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">Deferred tax (P&L)</span><span className="font-mono text-violet-700 dark:text-violet-300">+{sym}{Math.round(deferredTax.reconciliation.deferredTaxPAndL).toLocaleString()}</span></div>
                      <div className="flex justify-between border-t pt-1 font-bold"><span>Total tax expense (P&L)</span><span className="font-mono">{sym}{Math.round(deferredTax.reconciliation.totalTaxExpensePAndL).toLocaleString()}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">Effective tax rate</span><span className="font-bold text-amber-700 dark:text-amber-300">{(deferredTax.reconciliation.effectiveTaxRate * 100).toFixed(2)}%</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">UK statutory rate</span><span className="font-bold">25.00%</span></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Journal Entries for Deferred Tax */}
              <Card className="border-l-4 border-l-violet-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><BookOpen className="size-5 text-violet-600" /> Deferred Tax Journal Entries</CardTitle>
                  <CardDescription>{deferredTax.journalEntries.length} entries · Total debits = Total credits = {sym}{Math.round(deferredTax.jeVerification.totalDebits).toLocaleString()}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {deferredTax.journalEntries.map((je: any) => (
                    <div key={je.jeNo} className="rounded-md border p-3">
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <Badge variant="outline" className="text-[10px] font-mono">{je.jeNo}</Badge>
                        <span className="text-xs font-mono text-muted-foreground">{je.date}</span>
                        <span className="text-sm font-semibold">{je.description}</span>
                      </div>
                      <div className="overflow-x-auto rounded-md border bg-muted/20">
                        <table className="w-full text-xs">
                          <thead className="bg-muted/40">
                            <tr>
                              <th className="px-2 py-1.5 text-left font-semibold">Account</th>
                              <th className="px-2 py-1.5 text-right font-semibold">Debit £</th>
                              <th className="px-2 py-1.5 text-right font-semibold">Credit £</th>
                            </tr>
                          </thead>
                          <tbody>
                            {je.entries.map((e: any, i: number) => (
                              <tr key={i} className="border-t">
                                <td className="px-2 py-1.5">{e.account}</td>
                                <td className="px-2 py-1.5 text-right font-mono">{e.debit > 0 ? e.debit.toLocaleString() : "—"}</td>
                                <td className="px-2 py-1.5 text-right font-mono">{e.credit > 0 ? e.credit.toLocaleString() : "—"}</td>
                              </tr>
                            ))}
                            <tr className="border-t font-bold bg-muted/40">
                              <td className="px-2 py-1.5">Total</td>
                              <td className="px-2 py-1.5 text-right font-mono">{je.entries.reduce((s: number, e: any) => s + e.debit, 0).toLocaleString()}</td>
                              <td className="px-2 py-1.5 text-right font-mono">{je.entries.reduce((s: number, e: any) => s + e.credit, 0).toLocaleString()}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="mt-2 text-[10px] text-muted-foreground">
                        <strong className="text-violet-700 dark:text-violet-300">Standard:</strong> {je.standard}
                      </div>
                      <div className="mt-1 text-[10px] text-muted-foreground leading-relaxed">{je.narrative}</div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Disclosure Note */}
              <Card className="border-l-4 border-l-slate-500">
                <CardHeader><CardTitle className="text-base">Disclosure Note — Deferred Tax (IAS 12.79)</CardTitle></CardHeader>
                <CardContent>
                  <p className="text-xs text-muted-foreground leading-relaxed">{deferredTax.disclosureNote}</p>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card><CardContent className="py-12 text-center text-sm text-muted-foreground">No deferred tax data available.</CardContent></Card>
          )}
        </TabsContent>

        {/* Calculator */}
        <TabsContent value="calc" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Cross-Border Tax Calculator</CardTitle>
              <CardDescription>
                Headline-rate estimates for planning. Always verify with a licensed CPA / tax adviser before filing.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-3 md:grid-cols-4">
                <div className="grid gap-2">
                  <Label>Country</Label>
                  <Select value={calcCountry} onValueChange={setCalcCountry}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.keys(COUNTRY_LABEL).map((c) => (
                        <SelectItem key={c} value={c}>{COUNTRY_FLAG[c]} {COUNTRY_LABEL[c]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Tax type</Label>
                  <Select value={taxType} onValueChange={setTaxType}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="corporation-tax">Corporation / Income Tax</SelectItem>
                      <SelectItem value="vat">VAT / Sales Tax</SelectItem>
                      <SelectItem value="payroll">Payroll Tax</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="rev">Revenue ({calcCountry === "USA" ? "$" : calcCountry === "UK" ? "£" : "€"})</Label>
                  <Input id="rev" type="number" value={revenue} onChange={(e) => setRevenue(e.target.value)} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="exp">Expenses ({calcCountry === "USA" ? "$" : calcCountry === "UK" ? "£" : "€"})</Label>
                  <Input id="exp" type="number" value={expenses} onChange={(e) => setExpenses(e.target.value)} />
                </div>
              </div>
              <Button onClick={runCalc} disabled={calculating}>
                {calculating ? <><Clock className="size-4 animate-spin" /> Calculating…</> : <><Calculator className="size-4" /> Calculate</>}
              </Button>

              {calcResult && (
                <div className="rounded-md border bg-muted/30 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-sm font-semibold">
                      {COUNTRY_FLAG[calcResult.country]} {calcResult.country} · {TAX_TYPE_LABEL[calcResult.taxType] ?? calcResult.taxType}
                    </div>
                    <div className="text-xs text-muted-foreground">Profit: {calcResult.formatted?.profit ?? calcResult.formatted?.revenue ?? "—"}</div>
                  </div>
                  <div className="mt-3 space-y-1.5">
                    {calcResult.lines?.map((l: any, i: number) => (
                      <div key={i} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <span className="size-1.5 rounded-full bg-emerald-500" />
                          {l.label}
                          <Badge variant="outline" className="text-[10px]">{l.rate}</Badge>
                        </div>
                        <div className="font-medium">{calcResult.currency === "USD" ? "$" : calcResult.currency === "GBP" ? "£" : "€"}{Math.round(l.amount).toLocaleString()}</div>
                      </div>
                    ))}
                  </div>
                  {calcResult.lines?.length > 0 && (
                    <div className="mt-3 flex items-center justify-between border-t pt-3">
                      <div className="text-sm font-semibold">Total estimated liability</div>
                      <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                        {calcResult.currency === "USD" ? "$" : calcResult.currency === "GBP" ? "£" : "€"}{Math.round(calcResult.total).toLocaleString()}
                      </div>
                    </div>
                  )}
                  {calcResult.note && (
                    <div className="mt-2 rounded bg-amber-500/10 p-2 text-xs text-amber-700 dark:text-amber-300">
                      {calcResult.note}
                    </div>
                  )}
                  {calcResult.advisory && (
                    <div className="mt-2 text-[10px] text-muted-foreground">{calcResult.advisory}</div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Regimes */}
        <TabsContent value="regimes" className="space-y-4">
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
            {[
              {
                country: "USA",
                flag: "🇺🇸",
                items: [
                  { t: "Federal Corp Tax", d: "21% flat (with bracketed progressive structure for small corps)" },
                  { t: "State Income Tax", d: "Varies — CA ~8.84%, TX 0% (franchise tax instead)" },
                  { t: "Sales Tax", d: "State + local; CA base 7.25%, NY 8.875%" },
                  { t: "Payroll", d: "FICA 7.65% employer, FUTA 0.6%, SUTA varies" },
                  { t: "Form 941", d: "Quarterly payroll tax return" },
                  { t: "Form 1120", d: "Federal corporation income tax return" },
                ],
              },
              {
                country: "UK",
                flag: "🇬🇧",
                items: [
                  { t: "Corporation Tax", d: "19% profits ≤ £50k, taper to 25% at £250k" },
                  { t: "VAT", d: "Standard 20%, reduced 5%, zero-rated; MTD for VAT" },
                  { t: "PAYE / NI", d: "Employer NI 13.8%, employee 8% (2024-25)" },
                  { t: "Self-Assessment", d: "Deadline 31 Jan for online filing & payment" },
                  { t: "CT600", d: "Corporation Tax return — file within 12 months of year-end" },
                  { t: "VAT100", d: "Quarterly VAT return via MTD software" },
                ],
              },
              {
                country: "Germany",
                flag: "🇩🇪",
                items: [
                  { t: "Körperschaftsteuer", d: "15% on corporate profits" },
                  { t: "Solidaritätszuschlag", d: "5.5% on the KSt" },
                  { t: "Gewerbesteuer", d: "Trade tax ~14-17% (varies by municipality Hebesatz)" },
                  { t: "Umsatzsteuer (VAT)", d: "Standard 19%, reduced 7%" },
                  { t: "Lohnsteuer", d: "Payroll tax withheld monthly by 10th" },
                  { t: "ZM (Zusammenfassende Meldung)", d: "Monthly intra-EU recapitulative statement" },
                ],
              },
              {
                country: "Canada",
                flag: "🇨🇦",
                items: [
                  { t: "Federal T2 Corp Tax", d: "15% general / 9% SBD on first C$500K CCPC active income" },
                  { t: "Provincial Tax (Ontario demo)", d: "11.5% general / 3.2% small business — combined 26.5% / 12.2%" },
                  { t: "HST / GST", d: "Ontario HST 13% (5% GST + 8% provincial); Alberta GST 5% only; Quebec TVQ+TPS 14.975%" },
                  { t: "CPP / EI", d: "CPP 5.95% (matched, YMPE C$68,500); EI 1.64% employee, 1.4× employer (max C$63,200)" },
                  { t: "T2 Return", d: "Federal corporation income tax return — file within 6 months of year-end" },
                  { t: "T4 / T4 Summary", d: "Annual employee remittance — file by end-February following calendar year" },
                  { t: "Ontario EHT", d: "Employer Health Tax 1.95% on Ontario remuneration above C$1M exemption" },
                  { t: "ITC (Input Tax Credits)", d: "GST/HST paid on business inputs — reclaimable via net tax return" },
                ],
              },
            ].map((r) => (
              <Card key={r.country}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <span className="text-xl">{r.flag}</span> {r.country}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {r.items.map((i) => (
                    <div key={i.t} className="rounded-md border p-2">
                      <div className="text-xs font-medium">{i.t}</div>
                      <div className="mt-0.5 text-[11px] text-muted-foreground">{i.d}</div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* ============ CONCEPTS APPLIED — Cross-Reference Matrix ============ */}
      <ConceptsAppliedPanel reportName="Tax Center" />
    </div>
  );
}
