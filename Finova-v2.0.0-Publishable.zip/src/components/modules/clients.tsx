"use client";

import * as React from "react";
import { Users, Plus, Building2, ArrowRight, Flag, RefreshCw, Briefcase, MoreVertical, Lock, CheckCircle2, AlertTriangle } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const INDUSTRIES = ["Manufacturing", "Construction", "Real Estate", "Retail", "SaaS", "AI", "Logistics", "Hospitality", "Healthcare", "Professional Services"];
const COUNTRIES = ["USA", "UK", "Germany", "France", "Ireland", "Spain", "Netherlands", "Italy", "Canada"];
const CURRENCY_BY_COUNTRY: Record<string, string> = {
  USA: "USD", UK: "GBP", Germany: "EUR", France: "EUR", Ireland: "EUR", Spain: "EUR", Netherlands: "EUR", Italy: "EUR", Canada: "CAD",
};
const COUNTRY_FLAG: Record<string, string> = {
  USA: "🇺🇸", UK: "🇬🇧", Germany: "🇩🇪", France: "🇫🇷", Ireland: "🇮🇪", Spain: "🇪🇸", Netherlands: "🇳🇱", Italy: "🇮🇹", Canada: "🇨🇦",
};
const INDUSTRY_COLOR: Record<string, string> = {
  Manufacturing: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  Construction: "bg-orange-500/15 text-orange-600 dark:text-orange-400",
  "Real Estate": "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  Retail: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  SaaS: "bg-violet-500/15 text-violet-600 dark:text-violet-400",
  AI: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400",
};

type Client = {
  id: string;
  name: string;
  industry: string;
  country: string;
  currency: string;
  taxId?: string | null;
};

export function ClientsModule() {
  const companies = useAppStore((s) => s.companies);
  const setActiveCompanyId = useAppStore((s) => s.setActiveCompanyId);
  const setActiveModule = useAppStore((s) => s.setActiveModule);
  const addCompany = useAppStore((s) => s.addCompany);
  const bumpReloadCompanies = useAppStore((s) => s.bumpReloadCompanies);
  const [addOpen, setAddOpen] = React.useState(false);

  const byIndustry = React.useMemo(() => {
    const m = new Map<string, Client[]>();
    for (const c of companies) {
      const arr = m.get(c.industry) ?? [];
      arr.push(c);
      m.set(c.industry, arr);
    }
    return Array.from(m.entries());
  }, [companies]);

  function openClient(c: Client) {
    setActiveCompanyId(c.id);
    setActiveModule("dashboard");
    toast.success(`Switched to ${c.name}`);
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Clients</h1>
          <p className="text-sm text-muted-foreground">
            Your book of business — {companies.length} clients across {byIndustry.length} industries and {new Set(companies.map(c => c.country)).size} countries.
          </p>
        </div>
        <AddClientDialog
          open={addOpen}
          onOpenChange={setAddOpen}
          onAdded={(c) => {
            addCompany(c);
            setAddOpen(false);
            toast.success(`Client "${c.name}" added and switched to active`);
          }}
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Total Clients</div>
          <div className="text-xl font-bold">{companies.length}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Industries</div>
          <div className="text-xl font-bold">{byIndustry.length}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Countries</div>
          <div className="text-xl font-bold">{new Set(companies.map(c => c.country)).size}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Currencies</div>
          <div className="text-xl font-bold">{new Set(companies.map(c => c.currency)).size}</div>
        </CardContent></Card>
      </div>

      {/* By industry */}
      {byIndustry.map(([industry, clients]) => (
        <Card key={industry}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`flex size-8 items-center justify-center rounded-md ${INDUSTRY_COLOR[industry] ?? "bg-muted text-muted-foreground"}`}>
                  <Briefcase className="size-4" />
                </div>
                <div>
                  <CardTitle className="text-base">{industry}</CardTitle>
                  <CardDescription>{clients.length} client{clients.length === 1 ? "" : "s"}</CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {clients.map((c) => {
              const status = c.paymentStatus ?? "paid";
              const STATUS_BADGE: Record<string, { label: string; cls: string }> = {
                paid: { label: "Paid", cls: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
                overdue: { label: "Overdue", cls: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
                blocked: { label: "Blocked", cls: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
              };
              const badge = STATUS_BADGE[status] ?? STATUS_BADGE.paid;
              return (
                <div
                  key={c.id}
                  className={cn("group flex flex-col gap-2 rounded-md border p-4 text-left transition-all", status === "blocked" ? "border-rose-500/40 opacity-75" : "hover:border-emerald-500/30 hover:bg-muted/40")}
                >
                  <button onClick={() => status !== "blocked" && openClient(c)} className="text-left flex flex-col gap-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <Building2 className="size-4 text-muted-foreground" />
                        <div className="text-sm font-semibold">{c.name}</div>
                      </div>
                      <ArrowRight className="size-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                      <span className="flex items-center gap-1"><Flag className="size-3" />{COUNTRY_FLAG[c.country] ?? ""} {c.country}</span>
                      <span>·</span>
                      <span>{c.currency}</span>
                    </div>
                    {c.taxId && <div className="text-[10px] text-muted-foreground">Tax ID: {c.taxId}</div>}
                  </button>
                  <div className="mt-auto flex items-center justify-between border-t pt-2">
                    <Badge className={cn("text-[10px]", badge.cls)}>{badge.label}</Badge>
                    <PaymentStatusMenu clientId={c.id} current={status} onUpdated={bumpReloadCompanies} />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function AddClientDialog({
  open,
  onOpenChange,
  onAdded,
}: {
  open: boolean;
  onOpenChange: (b: boolean) => void;
  onAdded: (c: Client) => void;
}) {
  const [name, setName] = React.useState("");
  const [industry, setIndustry] = React.useState("Manufacturing");
  const [country, setCountry] = React.useState("USA");
  const [taxId, setTaxId] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/companies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, industry, country, currency: CURRENCY_BY_COUNTRY[country], taxId }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      setName(""); setTaxId("");
      onAdded(d.company);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="size-3.5" />
          Add Client
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add a new client</DialogTitle>
          <DialogDescription>
            Onboard a new client. The AI agents will adapt to the chosen industry and country regime.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="cname">Client name</Label>
            <Input id="cname" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Bridgepoint Construction LLC" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Industry</Label>
              <Select value={industry} onValueChange={setIndustry}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">
                  {INDUSTRIES.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Country</Label>
              <Select value={country} onValueChange={setCountry}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {COUNTRIES.map((c) => <SelectItem key={c} value={c}>{COUNTRY_FLAG[c]} {c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="ctax">Tax ID (optional)</Label>
            <Input id="ctax" value={taxId} onChange={(e) => setTaxId(e.target.value)} placeholder="EIN / CRN / VAT ID" />
          </div>
          <div className="rounded-md bg-muted/40 p-3 text-xs text-muted-foreground">
            Currency auto-set to <strong>{CURRENCY_BY_COUNTRY[country]}</strong> for {country}.
            You can connect Gmail, accounting software and bank feeds after onboarding from the Integrations tab.
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || !name}>{saving ? "Saving…" : "Add client"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PaymentStatusMenu({ clientId, current, onUpdated }: { clientId: string; current: string; onUpdated: () => void }) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  async function setStatus(status: "paid" | "overdue" | "blocked") {
    setOpen(false);
    try {
      const res = await fetch("/api/companies", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: clientId, paymentStatus: status, lastPaymentDate: status === "paid" ? new Date().toISOString() : undefined }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`Client marked as ${status}`);
      onUpdated();
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  return (
    <div className="relative" ref={ref}>
      <Button size="sm" variant="ghost" className="size-7 p-0" onClick={() => setOpen(!open)} aria-label="Payment status menu">
        <MoreVertical className="size-3.5" />
      </Button>
      {open && (
        <div className="absolute right-0 top-8 z-20 w-44 rounded-md border bg-background shadow-lg">
          <div className="border-b px-2 py-1.5 text-[10px] font-semibold uppercase text-muted-foreground">Payment status</div>
          <button onClick={() => setStatus("paid")} className="flex w-full items-center gap-2 px-2 py-1.5 text-xs hover:bg-muted">
            <CheckCircle2 className="size-3 text-emerald-500" /> Mark as paid
          </button>
          <button onClick={() => setStatus("overdue")} className="flex w-full items-center gap-2 px-2 py-1.5 text-xs hover:bg-muted">
            <AlertTriangle className="size-3 text-amber-500" /> Mark as overdue
          </button>
          <button onClick={() => setStatus("blocked")} className="flex w-full items-center gap-2 px-2 py-1.5 text-xs hover:bg-muted text-rose-600 dark:text-rose-400">
            <Lock className="size-3" /> Block access
          </button>
        </div>
      )}
    </div>
  );
}
