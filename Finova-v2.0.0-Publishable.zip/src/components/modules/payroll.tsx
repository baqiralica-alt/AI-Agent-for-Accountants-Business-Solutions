"use client";

import * as React from "react";
import { Wallet, Search, FileSpreadsheet, Download, BookOpen, Landmark, Globe } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { ConceptsAppliedPanel } from "@/components/concepts-applied-panel";

type Deduction = {
  label: string;
  rate: number | null;
  rateStr: string;
  employeeShare: number;
  employerShare: number;
  statutory: boolean;
  capped: boolean;
  ytdCap?: number;
  standard: string;
};

type Employee = {
  employeeId: string;
  name: string;
  role: string;
  grossPay: number;
  currency: string;
  deductions: Deduction[];
  netPay: number;
  totalDeductions: number;
  employerCost: number;
};

type Country = {
  countryCode: string;
  countryName: string;
  flag: string;
  currency: string;
  symbol: string;
  taxYear: string;
  minimumWage: string;
  taxAuthority: string;
  filingFrequency: string;
  payeLabel: string;
  statutoryStandards: string;
  employees: Employee[];
  totals: {
    grossPayroll: number;
    totalEmployeeTax: number;
    totalEmployerContributions: number;
    totalNetPay: number;
    totalEmployerCost: number;
  };
  journalEntry: {
    jeNo: string;
    description: string;
    debitAccount: string;
    creditAccount: string;
    debitAmount: number;
    creditAmount: number;
  };
  laws: { name: string; description: string; reference: string }[];
};

export function PayrollModule() {
  const [data, setData] = React.useState<{ countries: Country[]; stats: any; intro: string } | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");

  React.useEffect(() => {
    setLoading(true);
    fetch("/api/payroll")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  async function downloadCountryExcel(country: Country) {
    const XLSX = await import("xlsx");
    const rows = country.employees.flatMap((emp) =>
      emp.deductions.map((ded) => ({
        "Employee ID": emp.employeeId,
        "Employee Name": emp.name,
        "Role": emp.role,
        "Gross Pay": emp.grossPay,
        "Currency": emp.currency,
        "Deduction": ded.label,
        "Rate": ded.rateStr,
        "Employee Share": ded.employeeShare,
        "Employer Share": ded.employerShare,
        "Statutory": ded.statutory ? "Yes" : "No",
        "Capped": ded.capped ? "Yes" : "No",
        "YTD Cap": ded.ytdCap ?? "",
        "Standard": ded.standard,
        "Net Pay": emp.netPay,
        "Employer Cost": emp.employerCost,
      }))
    );
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `${country.countryCode} Payroll`);
    XLSX.writeFile(wb, `payroll_${country.countryCode}.xlsx`);
    toast.success(`${country.countryName} payroll Excel downloaded`);
  }

  if (loading) return <div className="p-6"><Skeleton className="h-96 w-full" /></div>;
  if (!data) return <div className="p-6 text-sm text-muted-foreground">No payroll data available.</div>;

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Payroll Center</h1>
          <p className="text-sm text-muted-foreground">
            Multi-country payroll computation per each jurisdiction's tax laws, social security, pension, and statutory deductions. Covers USA (FICA/FUTA/401k), UK (PAYE/NI/AE), Germany/EU (Lohnsteuer/Soli/SGB), and Canada (ITA/CPP/EI/EHT).
          </p>
        </div>
      </div>

      {/* Global KPI strip */}
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6">
        {data.countries.map((c) => (
          <Card key={c.countryCode} className="border-l-4 border-l-emerald-500">
            <CardContent className="py-3">
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <span className="text-base">{c.flag}</span> {c.countryName}
              </div>
              <div className="text-lg font-bold">{c.symbol}{Math.round(c.totals.grossPayroll).toLocaleString()}</div>
              <div className="text-[10px] text-muted-foreground">{c.employees.length} employees · {c.taxYear}</div>
            </CardContent>
          </Card>
        ))}
        <Card className="border-l-4 border-l-amber-500 bg-amber-500/5">
          <CardContent className="py-3">
            <div className="text-xs text-muted-foreground uppercase">Total Employees</div>
            <div className="text-lg font-bold text-amber-700 dark:text-amber-300">{data.stats.totalEmployees}</div>
            <div className="text-[10px] text-muted-foreground">across {data.stats.totalCountries} countries</div>
          </CardContent>
        </Card>
      </div>

      {/* Intro panel */}
      <div className="rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-3 text-xs text-muted-foreground">
        {data.intro}
      </div>

      {/* Country tabs */}
      <Tabs defaultValue={data.countries[0].countryCode}>
        <TabsList className="grid w-full grid-cols-4">
          {data.countries.map((c) => (
            <TabsTrigger key={c.countryCode} value={c.countryCode}>
              {c.flag} {c.countryName}
            </TabsTrigger>
          ))}
        </TabsList>

        {data.countries.map((country) => (
          <TabsContent key={country.countryCode} value={country.countryCode} className="space-y-4">
            {/* Country header card */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">{country.flag}</span>
                    {country.countryName} Payroll
                  </CardTitle>
                  <CardDescription>
                    Tax year {country.taxYear} · Currency {country.currency} · Tax authority: {country.taxAuthority} · Filing: {country.filingFrequency}
                  </CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={() => downloadCountryExcel(country)}>
                  <FileSpreadsheet className="size-3.5" /> Excel
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* KPI strip */}
                <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
                  <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2 text-center">
                    <div className="text-[10px] uppercase text-muted-foreground">Gross Payroll</div>
                    <div className="font-bold text-emerald-700 dark:text-emerald-300">{country.symbol}{Math.round(country.totals.grossPayroll).toLocaleString()}</div>
                  </div>
                  <div className="rounded-md border border-rose-500/30 bg-rose-500/5 p-2 text-center">
                    <div className="text-[10px] uppercase text-muted-foreground">Employee Tax Withheld</div>
                    <div className="font-bold text-rose-700 dark:text-rose-300">{country.symbol}{Math.round(country.totals.totalEmployeeTax).toLocaleString()}</div>
                  </div>
                  <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-2 text-center">
                    <div className="text-[10px] uppercase text-muted-foreground">Employer Contributions</div>
                    <div className="font-bold text-amber-700 dark:text-amber-300">{country.symbol}{Math.round(country.totals.totalEmployerContributions).toLocaleString()}</div>
                  </div>
                  <div className="rounded-md border border-blue-500/30 bg-blue-500/5 p-2 text-center">
                    <div className="text-[10px] uppercase text-muted-foreground">Net Pay to Employees</div>
                    <div className="font-bold text-blue-700 dark:text-blue-300">{country.symbol}{Math.round(country.totals.totalNetPay).toLocaleString()}</div>
                  </div>
                  <div className="rounded-md border border-violet-500/30 bg-violet-500/5 p-2 text-center">
                    <div className="text-[10px] uppercase text-muted-foreground">Total Employer Cost</div>
                    <div className="font-bold text-violet-700 dark:text-violet-300">{country.symbol}{Math.round(country.totals.totalEmployerCost).toLocaleString()}</div>
                  </div>
                </div>

                {/* Country info panel */}
                <div className="grid grid-cols-1 gap-2 md:grid-cols-3 text-xs">
                  <div className="rounded-md border p-2">
                    <div className="text-muted-foreground uppercase text-[10px] mb-0.5">Minimum Wage</div>
                    <div className="font-medium">{country.minimumWage}</div>
                  </div>
                  <div className="rounded-md border p-2">
                    <div className="text-muted-foreground uppercase text-[10px] mb-0.5">PAYE Label</div>
                    <div className="font-medium">{country.payeLabel}</div>
                  </div>
                  <div className="rounded-md border p-2">
                    <div className="text-muted-foreground uppercase text-[10px] mb-0.5">Statutory Standards</div>
                    <div className="font-medium">{country.statutoryStandards}</div>
                  </div>
                </div>

                {/* Employee payslips table */}
                <div className="overflow-x-auto rounded-md border">
                  <table className="w-full text-xs">
                    <thead className="bg-emerald-700 text-white">
                      <tr>
                        <th className="px-2 py-2 text-left font-semibold">Emp ID</th>
                        <th className="px-2 py-2 text-left font-semibold">Name</th>
                        <th className="px-2 py-2 text-left font-semibold">Role</th>
                        <th className="px-2 py-2 text-right font-semibold">Gross</th>
                        <th className="px-2 py-2 text-left font-semibold w-72">Deductions (with statutory law)</th>
                        <th className="px-2 py-2 text-right font-semibold">Total Deduct</th>
                        <th className="px-2 py-2 text-right font-semibold">Net Pay</th>
                        <th className="px-2 py-2 text-right font-semibold">Er Cost</th>
                      </tr>
                    </thead>
                    <tbody>
                      {country.employees.map((emp, i) => (
                        <tr key={emp.employeeId} className={cn("border-t align-top", i % 2 === 0 ? "bg-muted/20" : "")}>
                          <td className="px-2 py-2 font-mono text-[10px]">{emp.employeeId}</td>
                          <td className="px-2 py-2 font-medium">{emp.name}</td>
                          <td className="px-2 py-2 text-muted-foreground">{emp.role}</td>
                          <td className="px-2 py-2 text-right font-mono font-semibold">{country.symbol}{emp.grossPay.toLocaleString()}</td>
                          <td className="px-2 py-2">
                            <div className="space-y-1">
                              {emp.deductions.map((ded, di) => (
                                <div key={di} className="flex items-start justify-between gap-2">
                                  <div className="min-w-0">
                                    <div className="flex flex-wrap items-center gap-1">
                                      <span className="font-medium">{ded.label}</span>
                                      {ded.statutory && <Badge variant="outline" className="text-[9px] border-emerald-500/30 text-emerald-700 dark:text-emerald-300 py-0 px-1">statutory</Badge>}
                                      {ded.capped && <Badge variant="outline" className="text-[9px] border-amber-500/30 text-amber-700 dark:text-amber-300 py-0 px-1">capped</Badge>}
                                    </div>
                                    <div className="text-[10px] text-muted-foreground">
                                      {ded.rateStr} · <span className="font-mono">{ded.standard}</span>
                                    </div>
                                  </div>
                                  <div className="text-right font-mono shrink-0">
                                    <div className="text-rose-700 dark:text-rose-300">-{country.symbol}{ded.employeeShare.toLocaleString()}</div>
                                    {ded.employerShare > 0 && (
                                      <div className="text-[10px] text-amber-700 dark:text-amber-300">+Er {country.symbol}{ded.employerShare.toLocaleString()}</div>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </td>
                          <td className="px-2 py-2 text-right font-mono text-rose-700 dark:text-rose-300 font-semibold">
                            -{country.symbol}{emp.totalDeductions.toLocaleString()}
                          </td>
                          <td className="px-2 py-2 text-right font-mono text-blue-700 dark:text-blue-300 font-bold">
                            {country.symbol}{emp.netPay.toLocaleString()}
                          </td>
                          <td className="px-2 py-2 text-right font-mono text-violet-700 dark:text-violet-300 font-semibold">
                            {country.symbol}{emp.employerCost.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                      <tr className="border-t-2 bg-emerald-600 font-bold text-white">
                        <td className="px-2 py-2" colSpan={3}>TOTAL ({country.employees.length} employees)</td>
                        <td className="px-2 py-2 text-right font-mono">{country.symbol}{Math.round(country.totals.grossPayroll).toLocaleString()}</td>
                        <td className="px-2 py-2 text-[10px] text-muted-foreground italic">— see detail above —</td>
                        <td className="px-2 py-2 text-right font-mono">-{country.symbol}{Math.round(country.totals.totalEmployeeTax).toLocaleString()}</td>
                        <td className="px-2 py-2 text-right font-mono">{country.symbol}{Math.round(country.totals.totalNetPay).toLocaleString()}</td>
                        <td className="px-2 py-2 text-right font-mono">{country.symbol}{Math.round(country.totals.totalEmployerCost).toLocaleString()}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Journal Entry */}
                <Card className="border-l-4 border-l-violet-500">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <BookOpen className="size-4 text-violet-600" />
                      Journal Entry — Monthly Payroll Posting
                    </CardTitle>
                    <CardDescription>{country.journalEntry.jeNo} · {country.journalEntry.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border bg-muted/20 p-3 text-xs">
                      <div className="grid gap-2 md:grid-cols-2">
                        <div>
                          <div className="text-muted-foreground uppercase text-[10px] mb-1">Debit (Dr)</div>
                          <div className="font-mono">{country.journalEntry.debitAccount}</div>
                          <div className="text-right font-bold mt-1 font-mono">{country.symbol}{Math.round(country.journalEntry.debitAmount).toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground uppercase text-[10px] mb-1">Credit (Cr)</div>
                          <div className="font-mono">{country.journalEntry.creditAccount}</div>
                          <div className="text-right font-bold mt-1 font-mono">{country.symbol}{Math.round(country.journalEntry.creditAmount).toLocaleString()}</div>
                        </div>
                      </div>
                      <div className="mt-2 border-t pt-2 flex justify-between font-bold">
                        <span>Balanced</span>
                        <span className="font-mono">{country.journalEntry.debitAmount === country.journalEntry.creditAmount ? "✓ Dr = Cr" : "✗ Out of balance"}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Statutory Laws */}
                <Card className="border-l-4 border-l-amber-500">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Landmark className="size-4 text-amber-600" />
                      Statutory Payroll Laws & Frameworks — {country.countryName}
                    </CardTitle>
                    <CardDescription>{country.laws.length} statutes covering income tax, social security, pension, minimum wage, and benefits</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-2 md:grid-cols-2">
                      {country.laws.map((law, i) => (
                        <div key={i} className="rounded-md border border-amber-500/20 p-2">
                          <div className="flex items-start gap-2">
                            <Badge variant="outline" className="text-[10px] border-amber-500/40 text-amber-700 dark:text-amber-300 shrink-0">LAW</Badge>
                            <div className="min-w-0">
                              <div className="text-xs font-semibold">{law.name}</div>
                              <div className="text-[10px] text-muted-foreground mt-0.5">{law.description}</div>
                              <div className="text-[10px] font-mono mt-1 text-amber-700 dark:text-amber-300">{law.reference}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      {/* Cross-country comparison */}
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="size-5 text-blue-600" />
            Cross-Country Payroll Comparison
          </CardTitle>
          <CardDescription>Employer cost vs net pay ratio across USA, UK, EU, Canada</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-blue-700 text-white">
                <tr>
                  <th className="px-3 py-2 text-left font-semibold">Country</th>
                  <th className="px-3 py-2 text-right font-semibold">Gross Payroll</th>
                  <th className="px-3 py-2 text-right font-semibold">Employee Tax</th>
                  <th className="px-3 py-2 text-right font-semibold">Employer Cost</th>
                  <th className="px-3 py-2 text-right font-semibold">Er Cost / Gross %</th>
                  <th className="px-3 py-2 text-right font-semibold">Net Pay / Gross %</th>
                  <th className="px-3 py-2 text-left font-semibold">Statutory Framework</th>
                </tr>
              </thead>
              <tbody>
                {data.countries.map((c, i) => (
                  <tr key={c.countryCode} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-3 py-2 font-medium">{c.flag} {c.countryName} ({c.currency})</td>
                    <td className="px-3 py-2 text-right font-mono">{c.symbol}{Math.round(c.totals.grossPayroll).toLocaleString()}</td>
                    <td className="px-3 py-2 text-right font-mono text-rose-700 dark:text-rose-300">{c.symbol}{Math.round(c.totals.totalEmployeeTax).toLocaleString()}</td>
                    <td className="px-3 py-2 text-right font-mono text-violet-700 dark:text-violet-300">{c.symbol}{Math.round(c.totals.totalEmployerCost).toLocaleString()}</td>
                    <td className="px-3 py-2 text-right font-mono">{((c.totals.totalEmployerCost / c.totals.grossPayroll - 1) * 100).toFixed(1)}%</td>
                    <td className="px-3 py-2 text-right font-mono text-blue-700 dark:text-blue-300">{((c.totals.totalNetPay / c.totals.grossPayroll) * 100).toFixed(1)}%</td>
                    <td className="px-3 py-2 text-[10px] text-muted-foreground">{c.statutoryStandards}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-3 text-xs text-muted-foreground">
            <strong>Interpretation:</strong> Employer Cost / Gross % shows the total employment burden above gross wages (employer social contributions + benefits + taxes).
            Net Pay / Gross % shows the employee take-home ratio after all statutory and elective deductions.
            Germany typically shows the highest employer burden (~25%) due to comprehensive SGB social insurance. Canada and USA tend to be lower (~15-18%).
          </div>
        </CardContent>
      </Card>

      {/* ============ CONCEPTS APPLIED — Cross-Reference Matrix ============ */}
      <ConceptsAppliedPanel reportName="Payroll" />
    </div>
  );
}
