"use client";

import * as React from "react";
import { TrendingUp, Plus, Calculator, Briefcase, BarChart3, FileText, Download, RefreshCw, Sparkles, Upload, Landmark, FileSpreadsheet, AlertTriangle, CheckCircle2 } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { ConceptsAppliedPanel } from "@/components/concepts-applied-panel";

export function CorporateFinanceModule() {
  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Corporate Finance</h1>
        <p className="text-sm text-muted-foreground">
          M&A, Valuation (DCF + WACC), FP&A, FMVA (9 methodologies), 3-Statement Model, Driver Tree & Scenario Engine (4 scenarios + sensitivity tables), Loan Portfolio (amortization + covenants + ECL).
        </p>
      </div>

      <Tabs defaultValue="ma">
        <TabsList className="grid w-full grid-cols-9">
          <TabsTrigger value="ma"><Briefcase className="mr-1.5 size-3.5" /> M&A</TabsTrigger>
          <TabsTrigger value="valuation"><Calculator className="mr-1.5 size-3.5" /> Valuation</TabsTrigger>
          <TabsTrigger value="fpa"><BarChart3 className="mr-1.5 size-3.5" /> FP&A</TabsTrigger>
          <TabsTrigger value="fmva"><Sparkles className="mr-1.5 size-3.5" /> FMVA</TabsTrigger>
          <TabsTrigger value="3stmt"><FileText className="mr-1.5 size-3.5" /> 3-Statement</TabsTrigger>
          <TabsTrigger value="scenario"><TrendingUp className="mr-1.5 size-3.5" /> Scenario</TabsTrigger>
          <TabsTrigger value="boardpack"><BarChart3 className="mr-1.5 size-3.5" /> Board Pack</TabsTrigger>
          <TabsTrigger value="lrp"><TrendingUp className="mr-1.5 size-3.5" /> LRP</TabsTrigger>
          <TabsTrigger value="loan"><Landmark className="mr-1.5 size-3.5" /> Loans</TabsTrigger>
        </TabsList>

        <TabsContent value="ma"><MASection /></TabsContent>
        <TabsContent value="valuation"><ValuationSection /></TabsContent>
        <TabsContent value="fpa"><FPASection /></TabsContent>
        <TabsContent value="fmva"><FMVASection /></TabsContent>
        <TabsContent value="3stmt"><ThreeStatementSection /></TabsContent>
        <TabsContent value="scenario"><ScenarioEngineSection /></TabsContent>
        <TabsContent value="boardpack"><BoardPackSection /></TabsContent>
        <TabsContent value="lrp"><LRPSection /></TabsContent>
        <TabsContent value="loan"><LoanPortfolioSection /></TabsContent>
      </Tabs>

      {/* ============ CONCEPTS APPLIED — Cross-Reference Matrix ============ */}
      <ConceptsAppliedPanel reportName="Corporate Finance" />
    </div>
  );
}

// =================== M&A ===================
type Deal = {
  id: string; targetName: string; targetIndustry: string; dealDate: string; status: string;
  purchasePrice: number; fairValueAssets: number; liabilitiesAssumed: number; goodwill: number;
  netIdentifiableAssets: number; synergy?: number | null; structure: string; notes?: string | null;
};

function MASection() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const [deals, setDeals] = React.useState<Deal[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [addOpen, setAddOpen] = React.useState(false);

  function load() {
    setLoading(true);
    fetch(`/api/deals?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setDeals(d.deals); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }
  React.useEffect(() => { load(); }, [activeCompanyId]);

  const sym = useAppStore((s) => s.activeCompany?.currency === "USD" ? "$" : s.activeCompany?.currency === "GBP" ? "£" : "€");
  const fmt = (n: number) => `${sym}${Math.round(n).toLocaleString()}`;

  const totalGoodwill = deals.reduce((s, d) => s + d.goodwill, 0);
  const totalConsideration = deals.reduce((s, d) => s + d.purchasePrice, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">M&A deal tracker — purchase price allocation (PPA) per IFRS 3 / ASC 805</div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="size-3.5" /> Refresh</Button>
          <Button size="sm" onClick={() => setAddOpen(true)}><Plus className="size-3.5" /> New Deal</Button>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Total deals</div><div className="text-xl font-bold">{deals.length}</div></CardContent></Card>
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Total consideration</div><div className="text-xl font-bold">{fmt(totalConsideration)}</div></CardContent></Card>
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Total goodwill recognized</div><div className="text-xl font-bold text-amber-600 dark:text-amber-400">{fmt(totalGoodwill)}</div></CardContent></Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Deals</CardTitle><CardDescription>Goodwill = Purchase Price − (FV of identifiable assets − Liabilities assumed)</CardDescription></CardHeader>
        <CardContent className="space-y-3">
          {loading ? <Skeleton className="h-24 w-full" /> : deals.length === 0 ? (
            <p className="text-sm text-muted-foreground">No deals yet. Click "New Deal" to record an acquisition.</p>
          ) : deals.map((d) => (
            <div key={d.id} className="rounded-md border p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="text-sm font-semibold">{d.targetName}</div>
                  <div className="text-xs text-muted-foreground">{d.targetIndustry} · closed {new Date(d.dealDate).toLocaleDateString()}</div>
                </div>
                <div className="flex gap-1.5">
                  <Badge variant="outline" className="text-[10px] capitalize">{d.structure}</Badge>
                  <Badge variant={d.status === "closed" ? "default" : "secondary"} className="text-[10px] capitalize">{d.status}</Badge>
                </div>
              </div>
              <div className="mt-3 grid gap-2 md:grid-cols-5 text-sm">
                <div className="rounded bg-muted/40 p-2"><div className="text-[10px] text-muted-foreground">Purchase price</div><div className="font-bold">{fmt(d.purchasePrice)}</div></div>
                <div className="rounded bg-muted/40 p-2"><div className="text-[10px] text-muted-foreground">FV assets</div><div className="font-bold">{fmt(d.fairValueAssets)}</div></div>
                <div className="rounded bg-muted/40 p-2"><div className="text-[10px] text-muted-foreground">Liabilities assumed</div><div className="font-bold">{fmt(d.liabilitiesAssumed)}</div></div>
                <div className="rounded bg-muted/40 p-2"><div className="text-[10px] text-muted-foreground">Net identifiable</div><div className="font-bold">{fmt(d.netIdentifiableAssets)}</div></div>
                <div className="rounded bg-amber-500/15 p-2"><div className="text-[10px] text-muted-foreground">Goodwill (Dr)</div><div className="font-bold text-amber-600 dark:text-amber-400">{fmt(d.goodwill)}</div></div>
              </div>
              {d.notes && <div className="mt-2 text-xs text-muted-foreground">{d.notes}</div>}
            </div>
          ))}
        </CardContent>
      </Card>

      <DealDialog open={addOpen} onOpenChange={setAddOpen} companyId={activeCompanyId} sym={sym} onSaved={() => { setAddOpen(false); load(); }} />

      {/* Comprehensive M&A Deal Tracker with PPA */}
      <ComprehensiveMASection />
    </div>
  );
}

// ============ COMPREHENSIVE M&A SECTION (full tabular PPA) ============
function ComprehensiveMASection() {
  const [data, setData] = React.useState<any>(null);
  const [selectedDeal, setSelectedDeal] = React.useState<string | null>(null);

  React.useEffect(() => {
    fetch("/api/ma-deals")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); if (d.deals?.length > 0) setSelectedDeal(d.deals[0].dealId); })
      .catch(() => {});
  }, []);

  if (!data) return null;

  const fmtM = (n: number) => n >= 0 ? `$${n.toFixed(1)}M` : `($${Math.abs(n).toFixed(1)}M)`;
  const s = data.summary;
  const selected = data.deals.find((d: any) => d.dealId === selectedDeal);
  const fmtVal = (v: number, isPct: boolean = false) => isPct ? `${v}%` : fmtM(v);
  const fmtDelta = (v: number, isPct: boolean = false) => {
    if (isPct) return `${v > 0 ? "+" : ""}${v}pp`;
    return v >= 0 ? `+$${v.toFixed(1)}M` : `-$${Math.abs(v).toFixed(1)}M`;
  };

  const statusColors: Record<string, string> = {
    Closed: "border-emerald-500/30 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10",
    Announced: "border-amber-500/30 text-amber-700 dark:text-amber-300 bg-amber-500/10",
    Pending: "border-blue-500/30 text-blue-700 dark:text-blue-300 bg-blue-500/10",
  };

  return (
    <div className="space-y-4">
      <Card className="border-l-4 border-l-violet-500">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Briefcase className="size-4 text-violet-600" /> {data.meta.title}</CardTitle>
          <CardDescription>{data.meta.standard} · {data.meta.methodology}</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Portfolio summary KPI strip */}
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6">
            <div className="rounded-md border border-violet-500/30 bg-violet-500/5 p-2 text-center"><div className="text-[10px] uppercase text-muted-foreground">Total Deals</div><div className="font-bold text-violet-700 dark:text-violet-300">{s.totalDeals}</div><div className="text-[9px] text-muted-foreground">{s.closedDeals} closed · {s.pendingDeals} pending</div></div>
            <div className="rounded-md border border-blue-500/30 bg-blue-500/5 p-2 text-center"><div className="text-[10px] uppercase text-muted-foreground">Total Consideration</div><div className="font-bold text-blue-700 dark:text-blue-300">{fmtM(s.totalConsideration)}</div></div>
            <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-2 text-center"><div className="text-[10px] uppercase text-muted-foreground">Total Goodwill</div><div className="font-bold text-amber-700 dark:text-amber-300">{fmtM(s.totalGoodwill)}</div></div>
            <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2 text-center"><div className="text-[10px] uppercase text-muted-foreground">Synergy NPV</div><div className="font-bold text-emerald-700 dark:text-emerald-300">{fmtM(s.totalSynergyNPV)}</div></div>
            <div className="rounded-md border border-rose-500/30 bg-rose-500/5 p-2 text-center"><div className="text-[10px] uppercase text-muted-foreground">Annual Amortization</div><div className="font-bold text-rose-700 dark:text-rose-300">{fmtM(s.totalAnnualAmortization)}/yr</div></div>
            <div className="rounded-md border border-slate-500/30 bg-slate-500/5 p-2 text-center"><div className="text-[10px] uppercase text-muted-foreground">Wtd Avg Premium</div><div className="font-bold">{s.weightedAvgPremium}%</div></div>
          </div>
        </CardContent>
      </Card>

      {/* Deal selector tabs */}
      <div className="flex flex-wrap gap-1.5">
        {data.deals.map((d: any) => (
          <button
            key={d.dealId}
            onClick={() => setSelectedDeal(d.dealId)}
            className={cn(
              "rounded-md border px-2.5 py-1 text-xs font-medium transition flex items-center gap-1.5",
              selectedDeal === d.dealId ? "border-violet-500 bg-violet-500 text-white" : "bg-muted/30 hover:bg-muted/50"
            )}
          >
            <Badge variant="outline" className={cn("text-[8px]", statusColors[d.status])}>{d.status}</Badge>
            {d.dealId} · {d.targetName.slice(0, 20)}
          </button>
        ))}
      </div>

      {selected && (() => {
        const deal = selected;
        return (
          <div className="space-y-4">
            {/* Deal header */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">{deal.dealId} — {deal.targetName}</CardTitle>
                    <CardDescription>{deal.acquirerName} acquires {deal.targetName} · {deal.targetIndustry} · Closed {deal.dealDate} · {deal.structure}</CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2 text-xs">
                    <div className="rounded border p-2"><div className="text-[9px] text-muted-foreground">Consideration</div><div className="font-bold font-mono">{fmtM(deal.consideration)}</div></div>
                    <div className="rounded border p-2"><div className="text-[9px] text-muted-foreground">Premium</div><div className="font-bold font-mono">{deal.premiumPct}%</div></div>
                    <div className="rounded border p-2"><div className="text-[9px] text-muted-foreground">EV/Rev</div><div className="font-bold font-mono">{deal.evRevenueMultiple}x</div></div>
                    <div className="rounded border p-2"><div className="text-[9px] text-muted-foreground">EV/EBITDA</div><div className="font-bold font-mono">{deal.evEbitdaMultiple > 0 ? `${deal.evEbitdaMultiple}x` : "N/A"}</div></div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Deal structure */}
                <div className="grid grid-cols-2 gap-2 md:grid-cols-4 text-xs">
                  <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Cash Portion</div><div className="font-mono font-bold">{fmtM(deal.cashPortion)}</div></div>
                  <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Stock Portion</div><div className="font-mono font-bold">{fmtM(deal.stockPortion)}</div></div>
                  <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Exchange Ratio</div><div className="font-mono font-bold">{deal.exchangeRatio > 0 ? `${deal.exchangeRatio}x` : "—"}</div></div>
                  <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">New Shares Issued</div><div className="font-mono font-bold">{deal.newSharesIssued > 0 ? `${deal.newSharesIssued}M` : "—"}</div></div>
                  <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Target Revenue (LTM)</div><div className="font-mono">{fmtM(deal.targetRevenue)}</div></div>
                  <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Target EBITDA (LTM)</div><div className="font-mono">{deal.targetEBITDA >= 0 ? fmtM(deal.targetEBITDA) : `(${fmtM(-deal.targetEBITDA)})`}</div></div>
                  <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Earnout FV</div><div className="font-mono">{deal.earnout > 0 ? `${fmtM(deal.earnout)} (${deal.earnoutProbability}%)` : "—"}</div></div>
                  <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Synergy NPV</div><div className="font-mono font-bold text-emerald-700 dark:text-emerald-300">{fmtM(deal.synergyNPV)}</div></div>
                </div>

                {/* PPA Table */}
                <div>
                  <div className="text-sm font-semibold mb-1">Purchase Price Allocation (PPA) — All Cells</div>
                  <div className="overflow-x-auto rounded-md border">
                    <table className="w-full text-[10px]">
                      <thead className="bg-violet-700 text-white">
                        <tr>
                          <th className="px-2 py-1.5 text-left font-semibold">Category</th>
                          <th className="px-2 py-1.5 text-left font-semibold">Line Item</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Book Value ($M)</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Fair Value ($M)</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Step-Up ($M)</th>
                          <th className="px-2 py-1.5 text-left font-semibold">Notes / Formula</th>
                        </tr>
                      </thead>
                      <tbody>
                        {deal.ppa.map((p: any, i: number) => {
                          const isGoodwill = p.category === "Goodwill";
                          const isConsideration = p.category === "Consideration";
                          const isIntangible = p.category === "Intangibles Identified";
                          return (
                            <tr key={i} className={cn("border-t",
                              isGoodwill && (p.fairValue < 0 ? "bg-emerald-500/15 font-bold" : "bg-amber-500/15 font-bold"),
                              isConsideration && "bg-violet-500/15 font-bold",
                              isIntangible && "bg-blue-500/5",
                              i % 2 === 0 && !isGoodwill && !isConsideration && !isIntangible && "bg-muted/20"
                            )}>
                              <td className="px-2 py-1"><Badge variant="outline" className="text-[8px]">{p.category}</Badge></td>
                              <td className="px-2 py-1 font-medium">{p.lineItem}</td>
                              <td className="px-2 py-1 text-right font-mono">{p.bookValue === 0 ? "—" : fmtM(p.bookValue)}</td>
                              <td className="px-2 py-1 text-right font-mono font-bold">{fmtM(p.fairValue)}</td>
                              <td className={cn("px-2 py-1 text-right font-mono", p.stepUp > 0 ? "text-blue-700 dark:text-blue-300" : p.stepUp < 0 ? "text-rose-700 dark:text-rose-400" : "text-muted-foreground")}>{p.stepUp === 0 ? "—" : fmtDelta(p.stepUp)}</td>
                              <td className="px-2 py-1 text-[9px] text-muted-foreground">{p.notes}</td>
                            </tr>
                          );
                        })}
                        {/* Summary rows */}
                        <tr className="border-t-2 bg-violet-500/20 font-bold">
                          <td colSpan={2} className="px-2 py-2">Net Identifiable Assets = FV Assets + FV Intangibles − FV Liabilities</td>
                          <td colSpan={2} className="px-2 py-2 text-right font-mono">{fmtM(deal.netIdentifiableAssets)}</td>
                          <td colSpan={2} className="px-2 py-2 text-[9px] text-muted-foreground italic">Formula: Σ(FV Assets) + Σ(FV Intangibles) − Σ(FV Liabilities)</td>
                        </tr>
                        <tr className="border-t bg-amber-500/20 font-bold text-base">
                          <td colSpan={2} className="px-2 py-2">{deal.goodwill < 0 ? "BARGAIN PURCHASE GAIN (Cr)" : "GOODWILL (Dr)"}</td>
                          <td colSpan={2} className="px-2 py-2 text-right font-mono">{deal.goodwill < 0 ? `+${fmtM(-deal.goodwill)}` : fmtM(deal.goodwill)}</td>
                          <td colSpan={2} className="px-2 py-2 text-[9px] text-muted-foreground italic">Formula: Goodwill = Consideration − Net Identifiable Assets. {deal.goodwill < 0 && "Negative → Bargain Purchase Gain per IFRS 3.34"}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Intangibles & Amortization */}
                {deal.intangibles.length > 0 && (
                  <div>
                    <div className="text-sm font-semibold mb-1">Identified Intangibles — Valuation & Amortization Schedule</div>
                    <div className="overflow-x-auto rounded-md border">
                      <table className="w-full text-[10px]">
                        <thead className="bg-blue-700 text-white">
                          <tr>
                            <th className="px-2 py-1.5 text-left font-semibold">Intangible</th>
                            <th className="px-2 py-1.5 text-right font-semibold">Fair Value ($M)</th>
                            <th className="px-2 py-1.5 text-right font-semibold">Useful Life (yrs)</th>
                            <th className="px-2 py-1.5 text-right font-semibold">Annual Amort ($M/yr)</th>
                            <th className="px-2 py-1.5 text-left font-semibold">Valuation Method</th>
                            <th className="px-2 py-1.5 text-left font-semibold">IFRS Reference</th>
                          </tr>
                        </thead>
                        <tbody>
                          {deal.intangibles.map((int: any, i: number) => (
                            <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                              <td className="px-2 py-1.5 font-medium">{int.name}</td>
                              <td className="px-2 py-1.5 text-right font-mono font-bold">{fmtM(int.fairValue)}</td>
                              <td className="px-2 py-1.5 text-right font-mono">{int.usefulLifeYears}</td>
                              <td className="px-2 py-1.5 text-right font-mono text-rose-700 dark:text-rose-400">{fmtM(int.annualAmortization)}</td>
                              <td className="px-2 py-1.5 text-[9px] text-muted-foreground">{int.valuationMethod}</td>
                              <td className="px-2 py-1.5 text-[9px] font-mono text-blue-700 dark:text-blue-300">{int.ifrsReference}</td>
                            </tr>
                          ))}
                          <tr className="border-t-2 bg-blue-500/15 font-bold">
                            <td className="px-2 py-2">Total Intangibles</td>
                            <td className="px-2 py-2 text-right font-mono">{fmtM(deal.intangibles.reduce((s: number, i: any) => s + i.fairValue, 0))}</td>
                            <td colSpan={2} className="px-2 py-2 text-right font-mono">{fmtM(deal.intangibles.reduce((s: number, i: any) => s + i.annualAmortization, 0))}/yr total amort</td>
                            <td colSpan={2}></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <div className="mt-1 text-[9px] text-muted-foreground italic">Formula: Annual Amortization = Fair Value ÷ Useful Life (straight-line per IAS 38.97 / ASC 350-30-35)</div>
                  </div>
                )}

                {/* Scenario comparison */}
                <div>
                  <div className="text-sm font-semibold mb-1">Deal Structure Scenarios — Cash vs Stock vs Mixed</div>
                  <div className="overflow-x-auto rounded-md border">
                    <table className="w-full text-[10px]">
                      <thead className="bg-emerald-700 text-white">
                        <tr>
                          <th className="px-2 py-1.5 text-left font-semibold">Scenario</th>
                          <th className="px-2 py-1.5 text-center font-semibold">Consideration Type</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Consideration ($M)</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Premium %</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Goodwill ($M)</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Accr/(Dil) %</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Synergy NPV ($M)</th>
                          <th className="px-2 py-1.5 text-left font-semibold">Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {deal.scenarios.map((sc: any, i: number) => (
                          <tr key={i} className={cn("border-t", i === 0 && "bg-emerald-500/10 font-semibold")}>
                            <td className="px-2 py-1.5 font-medium">{sc.scenario}</td>
                            <td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[8px]">{sc.considerationType}</Badge></td>
                            <td className="px-2 py-1.5 text-right font-mono">{fmtM(sc.consideration)}</td>
                            <td className="px-2 py-1.5 text-right font-mono">{sc.premiumPct}%</td>
                            <td className="px-2 py-1.5 text-right font-mono text-amber-700 dark:text-amber-300">{fmtM(sc.goodwill)}</td>
                            <td className={cn("px-2 py-1.5 text-right font-mono font-bold", sc.accretionDilutionPct >= 0 ? "text-emerald-700 dark:text-emerald-300" : "text-rose-700 dark:text-rose-300")}>{sc.accretionDilutionPct > 0 ? "+" : ""}{sc.accretionDilutionPct}%</td>
                            <td className="px-2 py-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300">{fmtM(sc.synergyNPV)}</td>
                            <td className="px-2 py-1.5 text-[9px] text-muted-foreground">{sc.notes}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Journal entries */}
                {deal.journalEntries.filter((je: any) => je.debitAmount > 0 || je.creditAmount > 0).length > 0 && (
                  <div>
                    <div className="text-sm font-semibold mb-1">Journal Entries — Acquisition Accounting</div>
                    <div className="space-y-2">
                      {deal.journalEntries.filter((je: any) => je.debitAmount > 0 || je.creditAmount > 0).map((je: any, i: number) => (
                        <div key={i} className="rounded-md border p-3">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="text-[9px] font-mono">{je.jeNo}</Badge>
                            <span className="text-xs font-semibold">{je.description}</span>
                          </div>
                          <div className="grid gap-2 md:grid-cols-2">
                            <div className="rounded bg-muted/20 p-2 text-[10px]">
                              <div className="font-semibold text-emerald-700 dark:text-emerald-300 mb-0.5">DEBIT (Dr)</div>
                              <div>{je.debitAccount}</div>
                              <div className="text-right font-mono font-bold mt-1">{fmtM(je.debitAmount)}</div>
                            </div>
                            <div className="rounded bg-muted/20 p-2 text-[10px]">
                              <div className="font-semibold text-rose-700 dark:text-rose-300 mb-0.5">CREDIT (Cr)</div>
                              <div>{je.creditAccount}</div>
                              <div className="text-right font-mono font-bold mt-1">{fmtM(je.creditAmount)}</div>
                            </div>
                          </div>
                          <div className="mt-1 text-[9px] text-muted-foreground"><strong>Standard:</strong> {je.standard}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Pending deal note */}
                {deal.status === "Announced" && (
                  <div className="rounded-md border-l-4 border-l-amber-500 bg-amber-500/5 p-3 text-xs text-muted-foreground">
                    <strong className="text-amber-700 dark:text-amber-300">PENDING DEAL:</strong> No journal entries recorded until acquisition date. PPA is preliminary — final measurement within 12 months per IFRS 3.45-49. Disclosure only in notes per IAS 10 (subsequent events) / ASC 855.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        );
      })()}

      {/* Goodwill Roll-Forward */}
      <Card className="border-l-4 border-l-amber-500">
        <CardHeader><CardTitle className="text-base">Goodwill Roll-Forward — All Deals</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="bg-amber-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold">Component</th>
                  <th className="px-2 py-1.5 text-right font-semibold">$M</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-t"><td className="px-2 py-1.5">Opening Balance (1 Jan 2026)</td><td className="px-2 py-1.5 text-right font-mono">{fmtM(data.goodwillRollforward.openingBalance)}</td></tr>
                <tr className="border-t"><td className="px-2 py-1.5">+ Additions from Acquisitions (Goodwill recognized)</td><td className="px-2 py-1.5 text-right font-mono text-amber-700 dark:text-amber-300">{fmtM(data.goodwillRollforward.additionsFromAcquisitions)}</td></tr>
                <tr className="border-t"><td className="px-2 py-1.5">− Bargain Purchase Gains (recognized in P&L)</td><td className="px-2 py-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300">{fmtM(data.goodwillRollforward.bargainPurchaseGains)}</td></tr>
                <tr className="border-t"><td className="px-2 py-1.5">− Impairment Losses</td><td className="px-2 py-1.5 text-right font-mono">{fmtM(data.goodwillRollforward.impairmentLosses)}</td></tr>
                <tr className="border-t"><td className="px-2 py-1.5">− Disposals</td><td className="px-2 py-1.5 text-right font-mono">{fmtM(data.goodwillRollforward.disposalProceeds)}</td></tr>
                <tr className="border-t-2 bg-amber-500/15 font-bold text-base"><td className="px-2 py-2">= Closing Balance (31 Dec 2026)</td><td className="px-2 py-2 text-right font-mono">{fmtM(data.goodwillRollforward.closingBalance)}</td></tr>
              </tbody>
            </table>
          </div>
          <div className="mt-1 text-[9px] text-muted-foreground italic">{data.goodwillRollforward.formula}</div>
        </CardContent>
      </Card>

      {/* Combined Amortization Schedule */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Combined Intangible Amortization Schedule — All Deals</CardTitle>
          <CardDescription>{data.amortizationSchedule.length} intangible assets · Total annual amortization {fmtM(data.totalAnnualAmortization)}/yr</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[10px]">
              <thead className="bg-blue-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold">Deal</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Target</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Intangible</th>
                  <th className="px-2 py-1.5 text-right font-semibold">FV ($M)</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Life (yrs)</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Annual Amort ($M)</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Total Amort ($M)</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Valuation Method</th>
                </tr>
              </thead>
              <tbody>
                {data.amortizationSchedule.map((a: any, i: number) => (
                  <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1.5 font-mono text-[9px]">{a.dealId}</td>
                    <td className="px-2 py-1.5">{a.targetName.slice(0, 20)}</td>
                    <td className="px-2 py-1.5 font-medium">{a.intangible}</td>
                    <td className="px-2 py-1.5 text-right font-mono font-bold">{fmtM(a.fairValue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{a.usefulLife}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-rose-700 dark:text-rose-400">{fmtM(a.annualAmortization)}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-muted-foreground">{fmtM(a.totalAmortization)}</td>
                    <td className="px-2 py-1.5 text-[8px] text-muted-foreground">{a.valuationMethod}</td>
                  </tr>
                ))}
                <tr className="border-t-2 bg-blue-500/15 font-bold">
                  <td colSpan={3} className="px-2 py-2">TOTAL</td>
                  <td className="px-2 py-2 text-right font-mono">{fmtM(data.amortizationSchedule.reduce((s: number, a: any) => s + a.fairValue, 0))}</td>
                  <td></td>
                  <td className="px-2 py-2 text-right font-mono text-rose-700 dark:text-rose-400">{fmtM(data.totalAnnualAmortization)}</td>
                  <td className="px-2 py-2 text-right font-mono">{fmtM(data.amortizationSchedule.reduce((s: number, a: any) => s + a.totalAmortization, 0))}</td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DealDialog({ open, onOpenChange, companyId, sym, onSaved }: { open: boolean; onOpenChange: (b: boolean) => void; companyId: string; sym: string; onSaved: () => void }) {
  const [targetName, setTargetName] = React.useState("");
  const [targetIndustry, setTargetIndustry] = React.useState("SaaS");
  const [purchasePrice, setPurchasePrice] = React.useState("50000000");
  const [fairValueAssets, setFairValueAssets] = React.useState("38000000");
  const [liabilitiesAssumed, setLiabilitiesAssumed] = React.useState("8000000");
  const [structure, setStructure] = React.useState("cash");
  const [notes, setNotes] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  const pp = Number(purchasePrice) || 0;
  const fv = Number(fairValueAssets) || 0;
  const liab = Number(liabilitiesAssumed) || 0;
  const goodwill = pp - (fv - liab);

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/deals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ acquirerId: companyId, targetName, targetIndustry, purchasePrice: pp, fairValueAssets: fv, liabilitiesAssumed: liab, structure, notes, dealDate: new Date().toISOString(), status: "closed" }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`Deal recorded — goodwill ${sym}${goodwill.toLocaleString()}`);
      setTargetName(""); setNotes("");
      onSaved();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Record M&A Deal</DialogTitle>
          <DialogDescription>Goodwill is auto-computed per IFRS 3 / ASC 805.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2"><Label>Target name</Label><Input value={targetName} onChange={(e) => setTargetName(e.target.value)} placeholder="Acme Corp" /></div>
            <div className="grid gap-2"><Label>Industry</Label><Input value={targetIndustry} onChange={(e) => setTargetIndustry(e.target.value)} /></div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="grid gap-2"><Label>Purchase price ({sym})</Label><Input type="number" value={purchasePrice} onChange={(e) => setPurchasePrice(e.target.value)} /></div>
            <div className="grid gap-2"><Label>FV assets ({sym})</Label><Input type="number" value={fairValueAssets} onChange={(e) => setFairValueAssets(e.target.value)} /></div>
            <div className="grid gap-2"><Label>Liabilities ({sym})</Label><Input type="number" value={liabilitiesAssumed} onChange={(e) => setLiabilitiesAssumed(e.target.value)} /></div>
          </div>
          <div className="grid gap-2"><Label>Structure</Label>
            <Select value={structure} onValueChange={setStructure}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">Cash</SelectItem>
                <SelectItem value="stock">Stock</SelectItem>
                <SelectItem value="mixed">Mixed (Cash + Stock)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="rounded-md bg-amber-500/10 p-3">
            <div className="text-xs text-muted-foreground">Computed goodwill</div>
            <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{sym}{goodwill.toLocaleString()}</div>
            <div className="text-[10px] text-muted-foreground">= {sym}{pp.toLocaleString()} − ({sym}{fv.toLocaleString()} − {sym}{liab.toLocaleString()})</div>
          </div>
          <div className="grid gap-2"><Label>Notes</Label><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Strategic rationale, synergies, earnout terms..." /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || !targetName || !pp}>{saving ? "Saving…" : "Record deal"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// =================== Valuation ===================
// =================== VALUATION (Comprehensive Multi-Jurisdictional) ===================
function ValuationSection() {
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [activeSection, setActiveSection] = React.useState<string>("wacc");

  React.useEffect(() => {
    setLoading(true);
    fetch("/api/valuation-reports")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Skeleton className="h-96 w-full" />;
  if (!data) return <p className="text-sm text-muted-foreground">No valuation data available.</p>;

  const targets = data.targets;
  const sections = data.sections;
  const laws = data.laws;
  const meta = data.meta;
  const currencies: Record<string, string> = { usa: "$", uk: "\u00a3", eu: "\u20ac", canada: "C$" };
  const fmtVal = (v: any, j: string) => {
    if (typeof v !== "number") return String(v);
    const sym = currencies[j];
    return v > 100 ? `${sym}${v.toFixed(0)}` : v > 1 ? `${sym}${v.toFixed(2)}` : `${sym}${v.toFixed(4)}`;
  };
  const sectionKeys = Object.keys(sections);
  const currentSection = sections[activeSection];

  async function downloadExcel() {
    const XLSX = await import("xlsx");
    const wb = XLSX.utils.book_new();
    for (const [sKey, sData] of Object.entries(sections)) {
      const sd = sData as any;
      const rows = sd.rows.map((r: any) => ({ "Line Item": r.lineItem, "USA": r.usa, "UK": r.uk, "EU": r.eu, "Canada": r.canada, "Formula": r.formula, "Standard": r.standard, "Notes": r.note }));
      rows.unshift({ "Line Item": sd.title, "USA": "", "UK": "", "EU": "", "Canada": "", "Formula": sd.standard, "Standard": "", "Notes": "" });
      const ws = XLSX.utils.json_to_sheet(rows);
      ws["!cols"] = [{ wch: 35 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 40 }, { wch: 30 }, { wch: 50 }];
      XLSX.utils.book_append_sheet(wb, ws, sd.title.substring(0, 30));
    }
    const lawRows = laws.map((l: any) => ({ "Law / Standard": l.law, "Application": l.application }));
    const lawWs = XLSX.utils.json_to_sheet(lawRows);
    lawWs["!cols"] = [{ wch: 40 }, { wch: 80 }];
    XLSX.utils.book_append_sheet(wb, lawWs, "Laws & Standards");
    XLSX.writeFile(wb, "Valuation_Reports_Multi_Jurisdictional.xlsx");
    toast.success("Excel downloaded with color-coded sheets");
  }

  async function downloadCSV() {
    let csv = "";
    for (const [sKey, sData] of Object.entries(sections)) {
      const sd = sData as any;
      csv += `${sd.title}\n`;
      csv += "Line Item,USA,UK,EU,Canada,Formula,Standard,Notes\n";
      for (const r of sd.rows) { csv += `"${r.lineItem}",${r.usa},${r.uk},${r.eu},${r.canada},"${r.formula}","${r.standard}","${r.note}"\n`; }
      csv += "\n";
    }
    csv += "\nLaws & Standards Applied\nLaw / Standard,Application\n";
    for (const l of laws) { csv += `"${l.law}","${l.application}"\n`; }
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "Valuation_Reports_Multi_Jurisdictional.csv"; a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV downloaded");
  }

  async function downloadPDF() {
    let html = `<html><head><title>Valuation Reports</title><style>body{font-family:Arial;margin:20px;color:#333}h1{color:#059669;font-size:18px;border-bottom:3px solid #059669;padding-bottom:8px}h2{color:#7c3aed;font-size:14px;margin-top:20px;border-left:4px solid #7c3aed;padding-left:8px}table{width:100%;border-collapse:collapse;margin:10px 0;font-size:10px}th{background:#059669;color:white;padding:6px 8px;text-align:left}td{padding:4px 8px;border:1px solid #ddd}tr:nth-child(even){background:#f0fdf4}.formula{font-style:italic;color:#666;font-size:9px}.standard{color:#2563eb;font-size:9px}.note{color:#999;font-size:9px}.footer{margin-top:30px;font-size:8px;color:#999;border-top:1px solid #ddd;padding-top:10px}</style></head><body>`;
    html += `<h1>${meta.title}</h1><p>${meta.subtitle}</p><p style="font-size:10px;color:#666">${meta.standards}</p>`;
    for (const [sKey, sData] of Object.entries(sections)) {
      const sd = sData as any;
      html += `<h2>${sd.title}</h2><p style="font-size:9px;color:#666">${sd.standard}</p>`;
      html += `<table><tr><th>Line Item</th><th>USA</th><th>UK</th><th>EU</th><th>Canada</th><th>Formula</th></tr>`;
      for (const r of sd.rows) { html += `<tr><td><strong>${r.lineItem}</strong></td><td>${r.usa}</td><td>${r.uk}</td><td>${r.eu}</td><td>${r.canada}</td><td class="formula">${r.formula}</td></tr>`; }
      html += `</table>`;
    }
    html += `<h2>Laws & Standards (${laws.length})</h2><table><tr><th>Law</th><th>Application</th></tr>`;
    for (const l of laws) { html += `<tr><td><strong>${l.law}</strong></td><td>${l.application}</td></tr>`; }
    html += `</table><div class="footer">Generated by Finova ${meta.lastUpdated}</div></body></html>`;
    const w = window.open("", "_blank");
    if (w) { w.document.write(html); w.document.close(); setTimeout(() => w.print(), 500); toast.success("PDF print dialog opened"); }
  }

  return (
    <div className="space-y-4">
      <Card className="border-l-4 border-l-violet-500">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div><CardTitle className="text-base">{meta.title}</CardTitle><CardDescription>{meta.subtitle} - {meta.standards}</CardDescription></div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={downloadPDF}><FileText className="size-3.5" /> PDF</Button>
              <Button variant="outline" size="sm" onClick={downloadExcel}><FileSpreadsheet className="size-3.5" /> Excel</Button>
              <Button variant="outline" size="sm" onClick={downloadCSV}><Download className="size-3.5" /> CSV</Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
            {Object.entries(targets).map(([key, t]: any) => (
              <div key={key} className="rounded-md border p-2 text-center">
                <Badge variant="outline" className="text-[9px] mb-1">{t.country}</Badge>
                <div className="text-xs font-semibold">{t.name}</div>
                <div className="text-[10px] text-muted-foreground">Rev: {currencies[key]}{t.revenue}M</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-wrap gap-1.5">
        {sectionKeys.map((sKey: string) => (
          <button key={sKey} onClick={() => setActiveSection(sKey)}
            className={cn("rounded-md border px-2.5 py-1 text-xs font-medium transition",
              activeSection === sKey ? "border-violet-500 bg-violet-500 text-white" : "bg-muted/30 hover:bg-muted/50")}>
            {sections[sKey].title.split("-")[0].trim()}
          </button>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">{currentSection.title}</CardTitle><CardDescription>{currentSection.standard}</CardDescription></CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[10px]">
              <thead className="bg-violet-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold sticky left-0 bg-violet-700">Line Item</th>
                  <th className="px-2 py-1.5 text-right font-semibold bg-blue-600">USA</th>
                  <th className="px-2 py-1.5 text-right font-semibold bg-rose-600">UK</th>
                  <th className="px-2 py-1.5 text-right font-semibold bg-amber-600">EU</th>
                  <th className="px-2 py-1.5 text-right font-semibold bg-red-600">Canada</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Formula</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Standard</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Notes</th>
                </tr>
              </thead>
              <tbody>
                {currentSection.rows.map((r: any, i: number) => {
                  const isTotal = r.lineItem.includes("WACC") || r.lineItem.includes("Equity Value") || r.lineItem.includes("OVERALL") || r.lineItem.includes("Enterprise Value") || r.lineItem.includes("Value per Share") || r.lineItem.includes("Cost of Equity") || r.lineItem.includes("Implied Price") || r.lineItem.includes("Implied Upside") || r.lineItem.includes("Sensitivity Range");
                  return (
                    <tr key={i} className={cn("border-t", isTotal && "bg-violet-500/15 font-bold", !isTotal && i % 2 === 0 && "bg-muted/20")}>
                      <td className="px-2 py-1.5 font-medium sticky left-0 bg-inherit whitespace-nowrap">{isTotal ? <strong>{r.lineItem}</strong> : r.lineItem}</td>
                      <td className="px-2 py-1.5 text-right font-mono bg-blue-500/5">{fmtVal(r.usa, "usa")}</td>
                      <td className="px-2 py-1.5 text-right font-mono bg-rose-500/5">{fmtVal(r.uk, "uk")}</td>
                      <td className="px-2 py-1.5 text-right font-mono bg-amber-500/5">{fmtVal(r.eu, "eu")}</td>
                      <td className="px-2 py-1.5 text-right font-mono bg-red-500/5">{fmtVal(r.canada, "canada")}</td>
                      <td className="px-2 py-1.5 text-[8px] text-muted-foreground italic">{r.formula}</td>
                      <td className="px-2 py-1.5 text-[8px] text-blue-700 dark:text-blue-300">{r.standard}</td>
                      <td className="px-2 py-1.5 text-[8px] text-muted-foreground">{r.note}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-slate-500">
        <CardHeader><CardTitle className="text-base">Laws & Standards Applied - {laws.length} Statutes</CardTitle><CardDescription>CFA / FRM / CA professional standards</CardDescription></CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2">
            {laws.map((law: any, i: number) => (
              <div key={i} className="rounded-md border border-slate-500/20 p-2">
                <div className="flex items-start gap-1.5">
                  <Badge variant="outline" className="text-[9px] border-slate-500/30 text-slate-700 dark:text-slate-300 shrink-0 py-0 px-1">LAW</Badge>
                  <div><div className="text-xs font-semibold">{law.law}</div><div className="text-[10px] text-muted-foreground mt-0.5">{law.application}</div></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-emerald-500 bg-emerald-500/5">
        <CardHeader><CardTitle className="text-base">Download Reports - PDF / Excel / CSV with Color Schemes</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-3">
            <Button variant="outline" onClick={downloadPDF} className="h-auto py-4 flex-col"><FileText className="size-6 mb-1 text-rose-600" /><span className="text-sm font-semibold">Download PDF</span><span className="text-[10px] text-muted-foreground mt-1">Color-coded: emerald headers, violet sections, blue standards, alternating green rows</span></Button>
            <Button variant="outline" onClick={downloadExcel} className="h-auto py-4 flex-col"><FileSpreadsheet className="size-6 mb-1 text-emerald-600" /><span className="text-sm font-semibold">Download Excel</span><span className="text-[10px] text-muted-foreground mt-1">{sectionKeys.length} sheets + Laws sheet, optimized column widths</span></Button>
            <Button variant="outline" onClick={downloadCSV} className="h-auto py-4 flex-col"><Download className="size-6 mb-1 text-blue-600" /><span className="text-sm font-semibold">Download CSV</span><span className="text-[10px] text-muted-foreground mt-1">All sections + laws in single UTF-8 file</span></Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}


// =================== FP&A ===================
function FPASection() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    setLoading(true);
    fetch(`/api/fpa?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, [activeCompanyId]);

  if (loading) return <Skeleton className="h-96 w-full" />;
  if (!data) return null;
  const fmt = (n: number) => `${sym}${Math.round(n).toLocaleString()}`;

  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-4">
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Budget revenue</div><div className="text-xl font-bold">{fmt(data.totals.budgetIncome)}</div></CardContent></Card>
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Actual revenue</div><div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{fmt(data.totals.actualIncome)}</div></CardContent></Card>
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Budget net profit</div><div className="text-xl font-bold">{fmt(data.totals.budgetNet)}</div></CardContent></Card>
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Actual net profit</div><div className={cn("text-xl font-bold", data.totals.actualNet >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>{fmt(data.totals.actualNet)}</div></CardContent></Card>
      </div>

      {/* Budget vs Actual table */}
      <Card>
        <CardHeader><CardTitle className="text-base">Budget vs Actual — Variance Analysis</CardTitle><CardDescription>{data.period}</CardDescription></CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-emerald-600 text-white">
                <tr className="text-left">
                  <th className="px-3 py-2 font-semibold">Category</th>
                  <th className="px-3 py-2 text-right font-semibold">Budget</th>
                  <th className="px-3 py-2 text-right font-semibold">Actual</th>
                  <th className="px-3 py-2 text-right font-semibold">Variance</th>
                  <th className="px-3 py-2 text-right font-semibold">Var %</th>
                </tr>
              </thead>
              <tbody>
                {data.lines.map((l: any, i: number) => {
                  const good = l.type === "income" ? l.variance >= 0 : l.variance <= 0;
                  return (
                    <tr key={l.category} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                      <td className="px-3 py-2"><Badge variant="outline" className="text-[10px] mr-2">{l.type === "income" ? "Rev" : "Exp"}</Badge>{l.category}</td>
                      <td className="px-3 py-2 text-right">{fmt(l.budget)}</td>
                      <td className="px-3 py-2 text-right">{fmt(l.actual)}</td>
                      <td className={cn("px-3 py-2 text-right font-medium", good ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>{l.variance >= 0 ? "+" : ""}{fmt(l.variance)}</td>
                      <td className={cn("px-3 py-2 text-right", good ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>{l.variancePct >= 0 ? "+" : ""}{l.variancePct.toFixed(1)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Scenarios + Ratios */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">Next-Quarter Scenarios</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {["best", "base", "worst"].map((k) => {
              const s = data.scenarios[k];
              const color = k === "best" ? "text-emerald-600 dark:text-emerald-400" : k === "worst" ? "text-destructive" : "";
              return (
                <div key={k} className={cn("rounded-md border p-3", k === "worst" ? "border-l-4 border-l-rose-500" : k === "best" ? "border-l-4 border-l-emerald-500" : "border-l-4 border-l-amber-500")}>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                  <div className="grid grid-cols-3 gap-2 mt-1 text-sm">
                    <div><div className="text-[10px] text-muted-foreground">Revenue</div><div className="font-medium">{fmt(s.revenue)}</div></div>
                    <div><div className="text-[10px] text-muted-foreground">Expense</div><div className="font-medium">{fmt(s.expense)}</div></div>
                    <div><div className="text-[10px] text-muted-foreground">Net</div><div className={cn("font-bold", color)}>{fmt(s.netProfit)}</div></div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Ratio Analysis</CardTitle><CardDescription>FMVA framework — Corporate Finance Institute</CardDescription></CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2 text-sm">
              {Object.entries(data.ratios).map(([k, v]: any) => (
                <div key={k} className="rounded bg-muted/30 p-2">
                  <div className="text-[10px] text-muted-foreground capitalize">{k.replace(/([A-Z])/g, " $1").trim()}</div>
                  <div className="font-bold">{typeof v === "number" ? v.toFixed(2) : v}{k.toLowerCase().includes("ratio") || k === "interestCoverage" || k === "roe" || k === "roa" || k === "assetTurnover" ? (k === "interestCoverage" ? "x" : "%") : ""}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Commentary */}
      <Card className="border-l-4 border-l-emerald-500">
        <CardHeader><CardTitle className="text-base">FP&A Commentary</CardTitle></CardHeader>
        <CardContent>
          <div className="prose prose-sm dark:prose-invert max-w-none text-sm">
            <ReactMarkdown>{data.commentary}</ReactMarkdown>
          </div>
        </CardContent>
      </Card>

      {/* Budget vs Actual Variance Analysis */}
      <BudgetVarianceAnalysis />
    </div>
  );
}

// ============ BUDGET VS ACTUAL VARIANCE ANALYSIS ============
function BudgetVarianceAnalysis() {
  const [data, setData] = React.useState<any>(null);

  React.useEffect(() => {
    fetch("/api/budget-variance")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch(() => {});
  }, []);

  if (!data) return null;

  const fmtM = (n: number) => `$${Math.abs(n).toFixed(1)}M`;
  const fmtPct = (n: number) => `${n}%`;
  const months = data.monthlyTrend.months;

  const flagColors: Record<string, string> = {
    OK: "border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10",
    Watch: "border-amber-500/40 text-amber-700 dark:text-amber-300 bg-amber-500/10",
    Investigate: "border-orange-500/40 text-orange-700 dark:text-orange-300 bg-orange-500/10",
    Critical: "border-rose-500/40 text-rose-700 dark:text-rose-300 bg-rose-500/10",
  };

  const s = data.summary;
  const sections = ["Revenue & Margins", "Operating Expenses", "EBITDA"];

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><BarChart3 className="size-4 text-blue-600" /> {data.meta.title}</CardTitle>
          <CardDescription>{data.meta.entity} · {data.meta.fiscalYear} · {data.meta.standards}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground">{data.meta.methodology}</p>
        </CardContent>
      </Card>

      {/* Summary KPI strip */}
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6">
        <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2 text-center">
          <div className="text-[10px] uppercase text-muted-foreground">Revenue Actual</div>
          <div className="font-bold text-emerald-700 dark:text-emerald-300">{fmtM(s.totalRevenueActual)}</div>
          <div className="text-[9px] text-muted-foreground">vs Budget {fmtM(s.totalRevenueBudget)} ({s.revenueVariancePct > 0 ? "+" : ""}{s.revenueVariancePct}%)</div>
        </div>
        <div className="rounded-md border border-violet-500/30 bg-violet-500/5 p-2 text-center">
          <div className="text-[10px] uppercase text-muted-foreground">EBITDA Actual</div>
          <div className="font-bold text-violet-700 dark:text-violet-300">{fmtM(s.ebitdaActual)}</div>
          <div className="text-[9px] text-muted-foreground">vs Budget {fmtM(s.ebitdaBudget)} ({s.ebitdaVariancePct > 0 ? "+" : ""}{s.ebitdaVariancePct}%)</div>
        </div>
        <div className="rounded-md border border-blue-500/30 bg-blue-500/5 p-2 text-center">
          <div className="text-[10px] uppercase text-muted-foreground">EBITDA Margin</div>
          <div className="font-bold text-blue-700 dark:text-blue-300">{s.ebitdaMarginActual}%</div>
          <div className="text-[9px] text-muted-foreground">vs Budget {s.ebitdaMarginBudget}%</div>
        </div>
        <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2 text-center">
          <div className="text-[10px] uppercase text-muted-foreground">OK</div>
          <div className="font-bold text-emerald-700 dark:text-emerald-300">{s.flags.ok}</div>
        </div>
        <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-2 text-center">
          <div className="text-[10px] uppercase text-muted-foreground">Watch</div>
          <div className="font-bold text-amber-700 dark:text-amber-300">{s.flags.watch}</div>
        </div>
        <div className="rounded-md border border-rose-500/30 bg-rose-500/5 p-2 text-center">
          <div className="text-[10px] uppercase text-muted-foreground">Investigate + Critical</div>
          <div className="font-bold text-rose-700 dark:text-rose-300">{s.flags.investigate + s.flags.critical}</div>
        </div>
      </div>

      {/* Main variance table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Monthly Variance Detail — Jan-Dec FY2024 ($M)</CardTitle>
          <CardDescription>YTD Actual vs YTD Budget with Variance % and F/U Flag per line item</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[10px]">
              <thead className="bg-blue-700 text-white">
                <tr>
                  <th className="px-1.5 py-1.5 text-left font-semibold sticky left-0 bg-blue-700">Line Item</th>
                  {months.map((m: string) => <th key={m} className="px-1.5 py-1.5 text-right font-mono">{m}</th>)}
                  <th className="px-1.5 py-1.5 text-right font-semibold bg-blue-800">YTD Actual</th>
                  <th className="px-1.5 py-1.5 text-right font-semibold bg-blue-800">YTD Budget</th>
                  <th className="px-1.5 py-1.5 text-right font-semibold bg-blue-800">Var %</th>
                  <th className="px-1.5 py-1.5 text-center font-semibold bg-blue-800">F/U Flag</th>
                </tr>
              </thead>
              <tbody>
                {sections.map(sec => (
                  <React.Fragment key={sec}>
                    <tr className="border-t-2 bg-muted/40">
                      <td colSpan={17} className="px-1.5 py-1 text-[10px] font-semibold uppercase text-muted-foreground">{sec}</td>
                    </tr>
                    {data.rows.filter((r: any) => r.section === sec).map((r: any, i: number) => (
                      <tr key={i} className={cn("border-t", r.isTotal && "bg-blue-500/10 font-semibold", i % 2 === 0 && !r.isTotal && "bg-muted/20")}>
                        <td className="px-1.5 py-1 whitespace-nowrap sticky left-0 bg-inherit">{r.isTotal ? <strong>{r.lineItem}</strong> : r.lineItem}</td>
                        {r.monthly.map((v: number, mi: number) => (
                          <td key={mi} className="px-1.5 py-1 text-right font-mono">
                            {r.isPct ? `${v}%` : fmtM(v)}
                          </td>
                        ))}
                        <td className="px-1.5 py-1 text-right font-mono font-bold bg-blue-500/5">
                          {r.isPct ? `${r.ytdActual}%` : fmtM(r.ytdActual)}
                        </td>
                        <td className="px-1.5 py-1 text-right font-mono text-muted-foreground bg-blue-500/5">
                          {r.isPct ? `${r.ytdBudget}%` : fmtM(r.ytdBudget)}
                        </td>
                        <td className={cn("px-1.5 py-1 text-right font-mono font-bold bg-blue-500/5",
                          (!r.isPct && (r.section === "Revenue & Margins" && r.lineItem.includes("Revenue") || r.section === "EBITDA")) ? 
                            (r.variancePct > 0 ? "text-emerald-700 dark:text-emerald-300" : "text-rose-700 dark:text-rose-300") :
                            (r.variancePct > 0 ? "text-rose-700 dark:text-rose-300" : "text-emerald-700 dark:text-emerald-300")
                        )}>
                          {r.variancePct > 0 ? "+" : ""}{r.variancePct}{r.isPct ? "pp" : "%"}
                        </td>
                        <td className="px-1.5 py-1 text-center bg-blue-500/5">
                          <Badge variant="outline" className={cn("text-[9px]", flagColors[r.fuFlag])}>{r.fuFlag}</Badge>
                        </td>
                      </tr>
                    ))}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Management Commentary */}
      <Card className="border-l-4 border-l-amber-500">
        <CardHeader>
          <CardTitle className="text-base">Management Commentary — Key Findings & Recommended Actions</CardTitle>
          <CardDescription>{s.keyFindings.length} findings from FY2024 YTD variance analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {s.keyFindings.map((f: string, i: number) => (
              <div key={i} className="rounded-md border p-2 flex items-start gap-2">
                <Badge variant="outline" className="text-[9px] border-amber-500/30 text-amber-700 dark:text-amber-300 shrink-0">Finding {i + 1}</Badge>
                <span className="text-xs text-muted-foreground">{f}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Per-line-item commentary */}
      <Card>
        <CardHeader><CardTitle className="text-base">Line-Item Commentary — Root Cause & Action Plan</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2">
            {data.rows.filter((r: any) => r.fuFlag !== "OK").map((r: any, i: number) => (
              <div key={i} className="rounded-md border p-2">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold">{r.lineItem}</span>
                  <Badge variant="outline" className={cn("text-[9px]", flagColors[r.fuFlag])}>{r.fuFlag}</Badge>
                </div>
                <div className="text-[10px] text-muted-foreground">{r.commentary}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Laws & Standards */}
      <Card className="border-l-4 border-l-slate-500">
        <CardHeader>
          <CardTitle className="text-base">Laws & Standards Applied — Variance Analysis</CardTitle>
          <CardDescription>{data.laws.length} statutes governing the variance computations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2">
            {data.laws.map((law: any, i: number) => (
              <div key={i} className="rounded-md border border-slate-500/20 p-2">
                <div className="flex items-start gap-1.5">
                  <Badge variant="outline" className="text-[9px] border-slate-500/30 text-slate-700 dark:text-slate-300 shrink-0 py-0 px-1">LAW</Badge>
                  <div>
                    <div className="text-xs font-semibold">{law.law}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{law.application}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// =================== FMVA ===================
function FMVASection() {
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    setLoading(true);
    fetch("/api/fmva")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Skeleton className="h-96 w-full" />;
  if (!data) return <p className="text-sm text-muted-foreground">No FMVA data available.</p>;

  const meta = data.meta;
  const wacc = data.wacc;
  const dcf = data.dcf;
  const tc = data.tradingComps;
  const pt = data.precedentTx;
  const sens = data.sensitivity;
  const ff = data.footballField;
  const lbo = data.lbo;
  const ma = data.maAccretion;
  const reports = data.reportsIndex;

  const fmt$ = (n: number, dp = 1) => `$${n.toFixed(dp)}`;
  const fmtM = (n: number) => `$${n.toFixed(0)}M`;
  const pct = (n: number) => `${n}%`;
  const xMult = (n: number) => `${n}x`;

  // Color helpers for football field bars
  const colorMap: Record<string, string> = {
    slate: "bg-slate-500",
    blue: "bg-blue-500",
    cyan: "bg-cyan-500",
    violet: "bg-violet-500",
    emerald: "bg-emerald-500",
    teal: "bg-teal-500",
    amber: "bg-amber-500",
    rose: "bg-rose-500",
  };
  const ffRange = Math.max(...ff.methods.map((m: any) => m.high)) - Math.min(...ff.methods.map((m: any) => m.low));

  return (
    <div className="space-y-4">
      {/* FMVA Framework Header */}
      <Card className="border-l-4 border-l-emerald-500 bg-emerald-500/5">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Sparkles className="size-6 text-emerald-500 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h2 className="text-base font-semibold">{meta.frameworkName}</h2>
              <p className="text-xs text-muted-foreground mt-0.5">{meta.fullForm} · Issued by {meta.issuer} · {meta.methodologyCount} methodologies + {meta.reportsCount} compliant reports · As of {meta.asOfDate}</p>
              <p className="mt-2 text-sm text-muted-foreground">{meta.jurisdictionalScope}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {meta.standards.map((s: any) => (
                  <Badge key={s.code} variant="outline" className="text-[10px]">{s.label}</Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 3x3 Methodology Grid (matching uploaded screenshot layout) */}
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">3-Statement Model</div>
            <div className="mt-1 text-xs text-muted-foreground">Income Statement, Balance Sheet, Cash Flow — all dynamically linked so a change in any assumption flows through to every report.</div>
            <div className="mt-2 text-[10px] text-emerald-700 dark:text-emerald-300">See: Corporate Finance → 3-Statement tab</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-violet-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">DCF Valuation</div>
            <div className="mt-1 text-xs text-muted-foreground">5-year explicit forecast + Gordon Growth terminal value, discounted at WACC. EV = Σ PV(FCFF) + PV(TV).</div>
            <div className="mt-2 text-[10px] text-violet-700 dark:text-violet-300">Value/Share: {fmt$(dcf.bridge.valuePerShare, 2)} · TV % of EV: {dcf.terminalValue.percentOfEV}%</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">Trading Comparables</div>
            <div className="mt-1 text-xs text-muted-foreground">Apply EV/Revenue and EV/EBITDA multiples from peer set to your projected financials.</div>
            <div className="mt-2 text-[10px] text-blue-700 dark:text-blue-300">{tc.peers.length} peers · EV/Rev range: {tc.stats.evRevenueLow}x - {tc.stats.evRevenueHigh}x</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-violet-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">Precedent Transactions</div>
            <div className="mt-1 text-xs text-muted-foreground">Use precedent M&A multiples (EV/Revenue, EV/EBITDA) to triangulate control-premium valuations.</div>
            <div className="mt-2 text-[10px] text-violet-700 dark:text-violet-300">{pt.transactions.length} deals · Avg premium: {pt.stats.avgPremium}%</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">WACC Calculator</div>
            <div className="mt-1 text-xs text-muted-foreground">Weighted average cost of capital from cost of equity (CAPM) + after-tax cost of debt, weighted by capital structure.</div>
            <div className="mt-2 text-[10px] text-amber-700 dark:text-amber-300">WACC: {wacc.result.wacc}% · Re: {wacc.result.costOfEquity}% · Rd: {wacc.result.costOfDebtAfterTax}%</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-rose-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">Sensitivity & Scenarios</div>
            <div className="mt-1 text-xs text-muted-foreground">Best / Base / Worst case scenarios + two-way data tables on WACC vs terminal growth rate.</div>
            <div className="mt-2 text-[10px] text-rose-700 dark:text-rose-300">E[V] per share: {fmt$(sens.expectedValuePerShare, 2)} · 5×5 sensitivity matrix</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-teal-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">Football Field</div>
            <div className="mt-1 text-xs text-muted-foreground">Side-by-side range of equity values across all valuation methods, with high/low/average per share.</div>
            <div className="mt-2 text-[10px] text-teal-700 dark:text-teal-300">{ff.methods.length} methods · Range: {fmt$(ff.summary.overallLow, 2)} - {fmt$(ff.summary.overallHigh, 2)} · Mean: {fmt$(ff.summary.overallMean, 2)}</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">LBO Model</div>
            <div className="mt-1 text-xs text-muted-foreground">Leveraged buyout model — debt paydown schedule, IRR, MOIC under sponsor capital structure.</div>
            <div className="mt-2 text-[10px] text-orange-700 dark:text-orange-300">IRR: {lbo.returns.irr}% · MOIC: {lbo.returns.moic}x · {lbo.returns.holdPeriod}</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-pink-500">
          <CardContent className="p-4">
            <div className="text-sm font-semibold">M&A Accretion/Dilution</div>
            <div className="mt-1 text-xs text-muted-foreground">Pro-forma EPS analysis: cash vs stock deals, synergy impact, breakeven exchange ratio.</div>
            <div className="mt-2 text-[10px] text-pink-700 dark:text-pink-300">Pro Forma EPS: {fmt$(ma.proForma.proFormaEPS, 2)} · Accr/(Dil): {ma.proForma.accretionPct}%</div>
          </CardContent>
        </Card>
      </div>

      {/* WACC CALCULATOR DETAIL */}
      <Card>
        <CardHeader><CardTitle className="text-base">WACC Calculator — CAPM Cost of Equity + After-Tax Cost of Debt</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 text-xs">
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Risk-Free Rate</div><div className="font-bold">{wacc.result.riskFreeRate}%</div><div className="text-[9px]">US 10Y Treasury</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Beta</div><div className="font-bold">{wacc.result.beta}x</div><div className="text-[9px]">Bloomberg 2-yr weekly</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">ERP</div><div className="font-bold">{wacc.result.equityRiskPremium}%</div><div className="text-[9px]">Damodaran Nov 2026</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Tax Rate</div><div className="font-bold">{wacc.result.taxRate}%</div><div className="text-[9px]">US effective</div></div>
          </div>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="bg-amber-700 text-white"><tr>
                <th className="px-2 py-1.5 text-left font-semibold">Component</th>
                <th className="px-2 py-1.5 text-right font-semibold">Weight %</th>
                <th className="px-2 py-1.5 text-right font-semibold">Rate %</th>
                <th className="px-2 py-1.5 text-right font-semibold">Contribution %</th>
                <th className="px-2 py-1.5 text-left font-semibold">Formula</th>
              </tr></thead>
              <tbody>
                {wacc.components.map((c: any, i: number) => (
                  <tr key={i} className="border-t">
                    <td className="px-2 py-1.5 font-medium">{c.component}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{c.weight}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{c.rate}</td>
                    <td className="px-2 py-1.5 text-right font-mono font-bold">{c.contribution}</td>
                    <td className="px-2 py-1.5 text-[10px] text-muted-foreground">{c.formula}</td>
                  </tr>
                ))}
                <tr className="border-t-2 bg-amber-600 text-white font-bold">
                  <td className="px-2 py-2">WACC</td>
                  <td className="px-2 py-2 text-right font-mono">100.0</td>
                  <td className="px-2 py-2"></td>
                  <td className="px-2 py-2 text-right font-mono">{wacc.result.wacc}</td>
                  <td className="px-2 py-2 text-[10px]">{wacc.result.formula}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* DCF VALUATION DETAIL */}
      <Card>
        <CardHeader><CardTitle className="text-base">DCF Valuation — 5-Year FCFF + Gordon Growth Terminal Value</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[10px]">
              <thead className="bg-violet-700 text-white"><tr>
                <th className="px-2 py-1.5 text-left font-semibold">Year</th>
                <th className="px-2 py-1.5 text-right font-semibold">Revenue</th>
                <th className="px-2 py-1.5 text-right font-semibold">Growth %</th>
                <th className="px-2 py-1.5 text-right font-semibold">EBITDA</th>
                <th className="px-2 py-1.5 text-right font-semibold">EBITDA %</th>
                <th className="px-2 py-1.5 text-right font-semibold">D&A</th>
                <th className="px-2 py-1.5 text-right font-semibold">EBIT</th>
                <th className="px-2 py-1.5 text-right font-semibold">NOPAT</th>
                <th className="px-2 py-1.5 text-right font-semibold">+D&A</th>
                <th className="px-2 py-1.5 text-right font-semibold">−Capex</th>
                <th className="px-2 py-1.5 text-right font-semibold">−ΔNWC</th>
                <th className="px-2 py-1.5 text-right font-semibold">FCFF</th>
                <th className="px-2 py-1.5 text-right font-semibold">Disc Fac</th>
                <th className="px-2 py-1.5 text-right font-semibold">PV FCFF</th>
              </tr></thead>
              <tbody>
                {dcf.forecast.map((r: any, i: number) => (
                  <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1 font-mono font-medium">{r.year}</td>
                    <td className="px-2 py-1 text-right font-mono">{fmtM(r.revenue)}</td>
                    <td className="px-2 py-1 text-right font-mono">{r.revenueGrowthPct}%</td>
                    <td className="px-2 py-1 text-right font-mono">{fmtM(r.ebitda)}</td>
                    <td className="px-2 py-1 text-right font-mono">{r.ebitdaMarginPct}%</td>
                    <td className="px-2 py-1 text-right font-mono">({r.da})</td>
                    <td className="px-2 py-1 text-right font-mono">{r.ebit}</td>
                    <td className="px-2 py-1 text-right font-mono">{r.nopat}</td>
                    <td className="px-2 py-1 text-right font-mono">{r.plusDA}</td>
                    <td className="px-2 py-1 text-right font-mono text-rose-700 dark:text-rose-400">({-r.lessCapex})</td>
                    <td className="px-2 py-1 text-right font-mono text-rose-700 dark:text-rose-400">({-r.lessDeltaNWC})</td>
                    <td className="px-2 py-1 text-right font-mono font-bold text-violet-700 dark:text-violet-300">{r.fcff}</td>
                    <td className="px-2 py-1 text-right font-mono text-muted-foreground">{r.discountFactor}</td>
                    <td className="px-2 py-1 text-right font-mono font-semibold">{r.pvOfFcf}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Terminal value */}
          <div className="rounded-md border-l-4 border-l-violet-500 bg-violet-500/5 p-3">
            <div className="text-xs font-semibold mb-2">Terminal Value (Gordon Growth Model)</div>
            <div className="grid gap-2 md:grid-cols-4 text-xs">
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Final Year FCFF</div><div className="font-mono font-bold">{fmtM(dcf.terminalValue.finalYearFcff)}</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Perpetual Growth g</div><div className="font-mono font-bold">{dcf.terminalValue.perpetualGrowthRate}%</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Terminal Value</div><div className="font-mono font-bold">{fmtM(dcf.terminalValue.terminalValue)}</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">PV of TV (% of EV)</div><div className="font-mono font-bold">{fmtM(dcf.terminalValue.pvOfTerminalValue)} ({dcf.terminalValue.percentOfEV}%)</div></div>
            </div>
            <div className="mt-2 text-[10px] text-muted-foreground italic">Formula: {dcf.terminalValue.formula}</div>
          </div>

          {/* DCF Bridge */}
          <div className="rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-3">
            <div className="text-xs font-semibold mb-2">DCF Bridge — Enterprise Value to Equity Value per Share</div>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Sum of PV(FCFF) — explicit period</span><span className="font-mono font-bold">{fmtM(dcf.bridge.sumOfPvFcff)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">+ PV of Terminal Value</span><span className="font-mono">{fmtM(dcf.bridge.pvOfTerminalValue)}</span></div>
              <div className="flex justify-between border-t pt-1 font-bold"><span>= Enterprise Value</span><span className="font-mono text-violet-700 dark:text-violet-300">{fmtM(dcf.bridge.enterpriseValue)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">− Net Debt (Debt − Cash)</span><span className="font-mono">({-dcf.bridge.lessNetDebt}M)</span></div>
              <div className="flex justify-between border-t pt-1 font-bold"><span>= Equity Value</span><span className="font-mono text-emerald-700 dark:text-emerald-300">{fmtM(dcf.bridge.equityValue)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">÷ Shares Outstanding</span><span className="font-mono">{dcf.bridge.sharesOutstanding}M</span></div>
              <div className="flex justify-between border-t-2 pt-1 font-bold text-base"><span>= Value per Share</span><span className="font-mono text-emerald-700 dark:text-emerald-300">{fmt$(dcf.bridge.valuePerShare, 2)}</span></div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* TRADING COMPARABLES */}
      <Card>
        <CardHeader><CardTitle className="text-base">Trading Comparables — Peer Set EV/Revenue & EV/EBITDA Multiples</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="bg-blue-700 text-white"><tr>
                <th className="px-2 py-1.5 text-left font-semibold">Ticker</th>
                <th className="px-2 py-1.5 text-left font-semibold">Company</th>
                <th className="px-2 py-1.5 text-right font-semibold">Market Cap</th>
                <th className="px-2 py-1.5 text-right font-semibold">EV</th>
                <th className="px-2 py-1.5 text-right font-semibold">Revenue</th>
                <th className="px-2 py-1.5 text-right font-semibold">EBITDA</th>
                <th className="px-2 py-1.5 text-right font-semibold">EV/Rev</th>
                <th className="px-2 py-1.5 text-right font-semibold">EV/EBITDA</th>
                <th className="px-2 py-1.5 text-right font-semibold">Growth %</th>
              </tr></thead>
              <tbody>
                {tc.peers.map((p: any, i: number) => (
                  <tr key={p.ticker} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1.5 font-mono font-medium text-blue-700 dark:text-blue-300">{p.ticker}</td>
                    <td className="px-2 py-1.5">{p.company}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(p.marketCap)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(p.enterpriseValue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(p.revenue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{p.ebitda >= 0 ? fmtM(p.ebitda) : `(${fmtM(-p.ebitda)})`}</td>
                    <td className="px-2 py-1.5 text-right font-mono font-bold">{p.evRevenue}x</td>
                    <td className="px-2 py-1.5 text-right font-mono">{p.evEbitda > 0 ? `${p.evEbitda}x` : "N/A"}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{p.growthPct}%</td>
                  </tr>
                ))}
                <tr className="border-t-2 bg-blue-600 text-white font-bold">
                  <td colSpan={6}>Peer Statistics</td>
                  <td className="px-2 py-2 text-right font-mono">Low: {tc.stats.evRevenueLow}x · Mean: {tc.stats.evRevenueMean}x · High: {tc.stats.evRevenueHigh}x</td>
                  <td className="px-2 py-2 text-right font-mono">Mean: {tc.stats.evEbitdaMean}x</td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Implied valuation */}
          <div className="rounded-md border-l-4 border-l-blue-500 bg-blue-500/5 p-3">
            <div className="text-xs font-semibold mb-2">Implied Valuation — Apply Peer Multiples to {meta.targetCompany} FY2024E</div>
            <div className="grid gap-2 md:grid-cols-3 text-xs">
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Target FY24E Revenue</div><div className="font-mono font-bold">{fmtM(tc.valuation.targetRevenue)}</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Target FY24E EBITDA</div><div className="font-mono font-bold">{fmtM(tc.valuation.targetEbitda)}</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Net Debt</div><div className="font-mono font-bold">{fmtM(-dcf.bridge.lessNetDebt)}</div></div>
            </div>
            <div className="mt-2 grid gap-2 md:grid-cols-2 text-xs">
              <div className="rounded border p-2">
                <div className="text-[10px] text-muted-foreground mb-1">EV/Revenue Implied</div>
                <div className="space-y-0.5">
                  <div className="flex justify-between"><span>Low ({tc.stats.evRevenueLow}x)</span><span className="font-mono">EV {fmtM(tc.valuation.evRevLow)} → {fmt$(tc.valuation.perShareLow, 2)}/share</span></div>
                  <div className="flex justify-between"><span>Mean ({tc.stats.evRevenueMean}x)</span><span className="font-mono">EV {fmtM(tc.valuation.evRevMean)} → {fmt$(tc.valuation.perShareMean, 2)}/share</span></div>
                  <div className="flex justify-between font-bold"><span>High ({tc.stats.evRevenueHigh}x)</span><span className="font-mono">EV {fmtM(tc.valuation.evRevHigh)} → {fmt$(tc.valuation.perShareHigh, 2)}/share</span></div>
                </div>
              </div>
              <div className="rounded border p-2">
                <div className="text-[10px] text-muted-foreground mb-1">EV/EBITDA Implied (positive EBITDA peers only)</div>
                <div className="space-y-0.5">
                  <div className="flex justify-between"><span>Mean</span><span className="font-mono">EV {fmtM(tc.valuation.evEbitdaMean)} / share</span></div>
                  <div className="flex justify-between"><span>Low</span><span className="font-mono">EV {fmtM(tc.valuation.evEbitdaLow)}</span></div>
                  <div className="flex justify-between font-bold"><span>High</span><span className="font-mono">EV {fmtM(tc.valuation.evEbitdaHigh)}</span></div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* PRECEDENT TRANSACTIONS */}
      <Card>
        <CardHeader><CardTitle className="text-base">Precedent Transactions — M&A Multiples with Control Premium</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="bg-violet-700 text-white"><tr>
                <th className="px-2 py-1.5 text-left font-semibold">Date</th>
                <th className="px-2 py-1.5 text-left font-semibold">Acquirer</th>
                <th className="px-2 py-1.5 text-left font-semibold">Target</th>
                <th className="px-2 py-1.5 text-right font-semibold">Deal Value</th>
                <th className="px-2 py-1.5 text-right font-semibold">Target Rev</th>
                <th className="px-2 py-1.5 text-right font-semibold">Target EBITDA</th>
                <th className="px-2 py-1.5 text-right font-semibold">EV/Rev</th>
                <th className="px-2 py-1.5 text-right font-semibold">EV/EBITDA</th>
                <th className="px-2 py-1.5 text-right font-semibold">Premium</th>
              </tr></thead>
              <tbody>
                {pt.transactions.map((t: any, i: number) => (
                  <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1.5 font-mono text-[10px]">{t.date}</td>
                    <td className="px-2 py-1.5">{t.acquirer}</td>
                    <td className="px-2 py-1.5">{t.target}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(t.dealValue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(t.targetRevenue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{t.targetEbitda >= 0 ? fmtM(t.targetEbitda) : `(${fmtM(-t.targetEbitda)})`}</td>
                    <td className="px-2 py-1.5 text-right font-mono font-bold">{t.evRevenue}x</td>
                    <td className="px-2 py-1.5 text-right font-mono">{t.evEbitda ? `${t.evEbitda}x` : "N/A"}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300">{t.premiumPct}%</td>
                  </tr>
                ))}
                <tr className="border-t-2 bg-violet-600 text-white font-bold">
                  <td colSpan={6}>Stats</td>
                  <td className="px-2 py-2 text-right font-mono">Low: {pt.stats.evRevenueLow}x · Median: {pt.stats.evRevenueMedian}x · High: {pt.stats.evRevenueHigh}x</td>
                  <td></td>
                  <td className="px-2 py-2 text-right font-mono">Avg: {pt.stats.avgPremium}%</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="rounded-md border-l-4 border-l-violet-500 bg-violet-500/5 p-3 text-xs">
            <div className="font-semibold mb-1">Implied Valuation (apply to {meta.targetCompany} FY24E Revenue {fmtM(pt.valuation.targetRevenue)})</div>
            <div className="space-y-0.5">
              <div className="flex justify-between"><span>Low ({pt.stats.evRevenueLow}x × {fmtM(pt.valuation.targetRevenue)})</span><span className="font-mono">EV {fmtM(pt.valuation.evRevLow)} → {fmt$(pt.valuation.perShareLow, 2)}/share</span></div>
              <div className="flex justify-between"><span>Mean ({pt.stats.evRevenueMean}x)</span><span className="font-mono">EV {fmtM(pt.valuation.evRevMean)} → {fmt$(pt.valuation.perShareMean, 2)}/share</span></div>
              <div className="flex justify-between font-bold"><span>High ({pt.stats.evRevenueHigh}x)</span><span className="font-mono">EV {fmtM(pt.valuation.evRevHigh)} → {fmt$(pt.valuation.perShareHigh, 2)}/share</span></div>
            </div>
            <div className="mt-1 text-[10px] text-muted-foreground">Includes {pt.stats.avgPremium}% average control premium vs trading comps.</div>
          </div>
        </CardContent>
      </Card>

      {/* SENSITIVITY & SCENARIOS */}
      <Card>
        <CardHeader><CardTitle className="text-base">Sensitivity & Scenario Analysis</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {/* Scenarios */}
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="bg-rose-700 text-white"><tr>
                <th className="px-2 py-1.5 text-left font-semibold">Scenario</th>
                <th className="px-2 py-1.5 text-right font-semibold">Rev Growth %</th>
                <th className="px-2 py-1.5 text-right font-semibold">EBITDA Margin %</th>
                <th className="px-2 py-1.5 text-right font-semibold">Terminal FCFF</th>
                <th className="px-2 py-1.5 text-right font-semibold">Terminal Value</th>
                <th className="px-2 py-1.5 text-right font-semibold">Equity Value</th>
                <th className="px-2 py-1.5 text-right font-semibold">Per Share</th>
                <th className="px-2 py-1.5 text-right font-semibold">Probability</th>
              </tr></thead>
              <tbody>
                {sens.scenarios.map((s: any) => (
                  <tr key={s.scenario} className={cn("border-t", s.scenario === "Base Case" && "bg-emerald-500/10 font-semibold")}>
                    <td className="px-2 py-1.5 font-medium">{s.scenario}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{s.revenueGrowthPct}%</td>
                    <td className="px-2 py-1.5 text-right font-mono">{s.ebitdaMarginPct}%</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(s.terminalFcff)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(s.terminalValue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(s.equityValue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono font-bold text-emerald-700 dark:text-emerald-300">{fmt$(s.perShare, 2)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{s.probabilityPct}%</td>
                  </tr>
                ))}
                <tr className="border-t-2 bg-amber-600 text-white font-bold">
                  <td colSpan={6} className="px-2 py-2">Probability-Weighted Expected Value</td>
                  <td className="px-2 py-2 text-right font-mono">{fmt$(sens.expectedValuePerShare, 2)}</td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Two-way sensitivity table */}
          <div className="rounded-md border-l-4 border-l-rose-500 bg-rose-500/5 p-3">
            <div className="text-xs font-semibold mb-2">Two-Way Sensitivity: Implied Value per Share ($) — WACC (rows) × Terminal Growth Rate (cols)</div>
            <div className="overflow-x-auto">
              <table className="w-full text-[11px]">
                <thead>
                  <tr>
                    <th className="px-2 py-1.5 text-left font-semibold border-r-2 border-amber-500/30">WACC ↓ / g →</th>
                    {sens.sensitivityTable.colValues.map((c: any) => (
                      <th key={c} className="px-2 py-1.5 text-right font-mono">{c}%</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sens.sensitivityTable.matrix.map((row: any, ri: number) => (
                    <tr key={ri} className={cn("border-t", sens.sensitivityTable.rowValues[ri] === sens.sensitivityTable.baseCase.wacc && "bg-amber-500/20 font-bold")}>
                      <td className="px-2 py-1.5 text-left font-mono font-semibold border-r-2 border-amber-500/30">{sens.sensitivityTable.rowValues[ri]}%</td>
                      {row.map((v: any, ci: number) => (
                        <td key={ci} className={cn("px-2 py-1.5 text-right font-mono", sens.sensitivityTable.colValues[ci] === sens.sensitivityTable.baseCase.g && sens.sensitivityTable.rowValues[ri] === sens.sensitivityTable.baseCase.wacc && "bg-amber-600 text-white font-bold")}>{fmt$(v, 2)}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-1 text-[10px] text-muted-foreground">Base case: WACC {sens.sensitivityTable.baseCase.wacc}%, g {sens.sensitivityTable.baseCase.g}% → {fmt$(sens.sensitivityTable.baseCase.valuePerShare, 2)}/share</div>
          </div>
        </CardContent>
      </Card>

      {/* FOOTBALL FIELD CHART */}
      <Card>
        <CardHeader><CardTitle className="text-base">Football Field — Multi-Method Valuation Range Comparison</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 text-xs mb-3">
            <div className="rounded border border-teal-500/30 bg-teal-500/5 p-2 text-center"><div className="text-[10px] text-muted-foreground">Overall Low</div><div className="font-bold text-rose-700 dark:text-rose-300">{fmt$(ff.summary.overallLow, 2)}</div></div>
            <div className="rounded border border-emerald-500/30 bg-emerald-500/5 p-2 text-center"><div className="text-[10px] text-muted-foreground">Overall Mean</div><div className="font-bold text-emerald-700 dark:text-emerald-300">{fmt$(ff.summary.overallMean, 2)}</div></div>
            <div className="rounded border border-teal-500/30 bg-teal-500/5 p-2 text-center"><div className="text-[10px] text-muted-foreground">Overall High</div><div className="font-bold text-emerald-700 dark:text-emerald-300">{fmt$(ff.summary.overallHigh, 2)}</div></div>
            <div className="rounded border border-amber-500/30 bg-amber-500/5 p-2 text-center"><div className="text-[10px] text-muted-foreground">Implied Upside vs Current</div><div className={cn("font-bold", ff.summary.impliedUpside >= 0 ? "text-emerald-700 dark:text-emerald-300" : "text-rose-700 dark:text-rose-300")}>{ff.summary.impliedUpside}%</div></div>
          </div>

          {/* Horizontal bar chart */}
          <div className="space-y-2">
            {ff.methods.map((m: any, i: number) => {
              const lowPct = ((m.low - ff.summary.overallLow) / ffRange) * 100;
              const widthPct = ((m.high - m.low) / ffRange) * 100;
              const meanPct = ((m.mean - ff.summary.overallLow) / ffRange) * 100;
              return (
                <div key={i} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-medium">{m.method}</span>
                    <span className="font-mono text-muted-foreground">{fmt$(m.low, 2)} - {fmt$(m.high, 2)} (mean: {fmt$(m.mean, 2)})</span>
                  </div>
                  <div className="relative h-6 rounded-md bg-muted/30 overflow-hidden">
                    <div
                      className={cn("absolute h-full rounded", colorMap[m.color])}
                      style={{ left: `${Math.max(0, lowPct)}%`, width: `${Math.max(2, widthPct)}%` }}
                    />
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-foreground"
                      style={{ left: `${Math.max(0, meanPct)}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-muted-foreground italic">{m.note}</div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* LBO MODEL */}
      <Card>
        <CardHeader><CardTitle className="text-base">LBO Model — Sponsor Returns Analysis (5-Year Hold)</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {/* Entry assumptions */}
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 text-xs">
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Purchase Price (EV)</div><div className="font-mono font-bold">{fmtM(lbo.entryAssumptions.purchasePrice)}</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Debt % / Amount</div><div className="font-mono font-bold">{lbo.entryAssumptions.debtPct}% / {fmtM(lbo.entryAssumptions.debtAmount)}</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Equity % / Amount</div><div className="font-mono font-bold">{lbo.entryAssumptions.equityPct}% / {fmtM(lbo.entryAssumptions.equityAmount)}</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Debt Rate</div><div className="font-mono font-bold">{lbo.entryAssumptions.debtRate}%</div></div>
          </div>

          {/* LBO schedule */}
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="bg-orange-700 text-white"><tr>
                <th className="px-2 py-1.5 text-left font-semibold">Year</th>
                <th className="px-2 py-1.5 text-right font-semibold">Revenue</th>
                <th className="px-2 py-1.5 text-right font-semibold">EBITDA</th>
                <th className="px-2 py-1.5 text-right font-semibold">EBITDA %</th>
                <th className="px-2 py-1.5 text-right font-semibold">−Interest</th>
                <th className="px-2 py-1.5 text-right font-semibold">−Capex</th>
                <th className="px-2 py-1.5 text-right font-semibold">−Tax</th>
                <th className="px-2 py-1.5 text-right font-semibold">FCF</th>
                <th className="px-2 py-1.5 text-right font-semibold">Beg Debt</th>
                <th className="px-2 py-1.5 text-right font-semibold">Paydown</th>
                <th className="px-2 py-1.5 text-right font-semibold">End Debt</th>
              </tr></thead>
              <tbody>
                {lbo.model.map((r: any, i: number) => (
                  <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1.5 font-mono font-medium">{r.year}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmtM(r.revenue)}</td>
                    <td className="px-2 py-1.5 text-right font-mono font-bold text-emerald-700 dark:text-emerald-300">{fmtM(r.ebitda)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{r.ebitdaMarginPct}%</td>
                    <td className="px-2 py-1.5 text-right font-mono text-rose-700 dark:text-rose-400">({-r.lessInterest})</td>
                    <td className="px-2 py-1.5 text-right font-mono text-rose-700 dark:text-rose-400">({-r.lessCapex})</td>
                    <td className="px-2 py-1.5 text-right font-mono text-rose-700 dark:text-rose-400">({-r.lessTax})</td>
                    <td className="px-2 py-1.5 text-right font-mono font-bold">{r.freeCashFlow}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-muted-foreground">{r.beginningDebt}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300">{r.debtPaydown}</td>
                    <td className="px-2 py-1.5 text-right font-mono font-semibold">{r.endingDebt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Exit + returns */}
          <div className="grid gap-2 md:grid-cols-2 text-xs">
            <div className="rounded-md border-l-4 border-l-orange-500 bg-orange-500/5 p-3">
              <div className="text-xs font-semibold mb-2">Exit Calculations</div>
              <div className="space-y-0.5">
                <div className="flex justify-between"><span className="text-muted-foreground">Exit Year EBITDA</span><span className="font-mono">{fmtM(lbo.exit.exitYearEbitda)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">× Exit Multiple</span><span className="font-mono">{lbo.exit.exitMultiple}x</span></div>
                <div className="flex justify-between border-t pt-1 font-bold"><span>= Exit Enterprise Value</span><span className="font-mono text-orange-700 dark:text-orange-300">{fmtM(lbo.exit.exitEnterpriseValue)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">− Ending Debt</span><span className="font-mono">({-lbo.exit.lessEndingDebt})</span></div>
                <div className="flex justify-between border-t pt-1 font-bold"><span>= Exit Equity Value</span><span className="font-mono text-emerald-700 dark:text-emerald-300">{fmtM(lbo.exit.exitEquityValue)}</span></div>
              </div>
            </div>
            <div className="rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-3">
              <div className="text-xs font-semibold mb-2">Sponsor Returns</div>
              <div className="space-y-0.5">
                <div className="flex justify-between"><span className="text-muted-foreground">Initial Equity</span><span className="font-mono">{fmtM(lbo.returns.initialEquity)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Exit Equity</span><span className="font-mono">{fmtM(lbo.returns.exitEquity)}</span></div>
                <div className="flex justify-between border-t pt-1 font-bold"><span>MOIC (Multiple on Invested Capital)</span><span className="font-mono text-emerald-700 dark:text-emerald-300">{lbo.returns.moic}x</span></div>
                <div className="flex justify-between font-bold text-base"><span>IRR (Internal Rate of Return)</span><span className="font-mono text-emerald-700 dark:text-emerald-300">{lbo.returns.irr}%</span></div>
                <div className="flex justify-between text-[10px] text-muted-foreground"><span>Hold period</span><span>{lbo.returns.holdPeriod}</span></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* M&A ACCRETION/DILUTION */}
      <Card>
        <CardHeader><CardTitle className="text-base">M&A Accretion/Dilution — Pro Forma EPS Analysis</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 gap-2 md:grid-cols-2 text-xs">
            <div className="rounded-md border border-blue-500/30 bg-blue-500/5 p-3">
              <div className="text-xs font-semibold mb-2 text-blue-700 dark:text-blue-300">Acquirer: {ma.acquirer.name}</div>
              <div className="space-y-0.5">
                <div className="flex justify-between"><span className="text-muted-foreground">Revenue</span><span className="font-mono">{fmtM(ma.acquirer.revenue)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">EBITDA</span><span className="font-mono">{fmtM(ma.acquirer.ebitda)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Net Income</span><span className="font-mono">{fmtM(ma.acquirer.netIncome)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Shares Outstanding</span><span className="font-mono">{ma.acquirer.sharesOutstanding}M</span></div>
                <div className="flex justify-between border-t pt-1 font-bold"><span>Standalone EPS</span><span className="font-mono">{fmt$(ma.acquirer.eps, 2)}</span></div>
              </div>
            </div>
            <div className="rounded-md border border-violet-500/30 bg-violet-500/5 p-3">
              <div className="text-xs font-semibold mb-2 text-violet-700 dark:text-violet-300">Target: {ma.target.name}</div>
              <div className="space-y-0.5">
                <div className="flex justify-between"><span className="text-muted-foreground">Revenue</span><span className="font-mono">{fmtM(ma.target.revenue)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">EBITDA</span><span className="font-mono">{ma.target.ebitda >= 0 ? fmtM(ma.target.ebitda) : `(${fmtM(-ma.target.ebitda)})`}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Net Income</span><span className="font-mono">{ma.target.netIncome >= 0 ? fmtM(ma.target.netIncome) : `(${fmtM(-ma.target.netIncome)})`}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Shares Outstanding</span><span className="font-mono">{ma.target.sharesOutstanding}M</span></div>
                <div className="flex justify-between border-t pt-1 font-bold"><span>Standalone EPS</span><span className="font-mono">{fmt$(ma.target.eps, 2)}</span></div>
              </div>
            </div>
          </div>

          {/* Deal terms */}
          <div className="rounded-md border-l-4 border-l-pink-500 bg-pink-500/5 p-3">
            <div className="text-xs font-semibold mb-2">Deal Terms</div>
            <div className="grid grid-cols-2 gap-2 md:grid-cols-4 text-xs">
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Offer Price/Share</div><div className="font-mono font-bold">{fmt$(ma.dealTerms.offerPricePerShare, 2)}</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Premium</div><div className="font-mono font-bold text-emerald-700 dark:text-emerald-300">{ma.dealTerms.premiumPct}%</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Deal Value</div><div className="font-mono font-bold">{fmtM(ma.dealTerms.dealValue)}</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Consideration</div><div className="font-bold text-xs">{ma.dealTerms.consideration}</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Exchange Ratio</div><div className="font-mono font-bold">{ma.dealTerms.exchangeRatio}x</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">New Shares Issued</div><div className="font-mono font-bold">{ma.dealTerms.newSharesIssued}M</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Synergy EBITDA</div><div className="font-mono font-bold">{fmtM(ma.dealTerms.synergyEBITDA)}/yr</div></div>
              <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Transaction Costs</div><div className="font-mono font-bold">{fmtM(ma.dealTerms.transactionCosts)}</div></div>
            </div>
          </div>

          {/* Pro forma */}
          <div className="rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-3">
            <div className="text-xs font-semibold mb-2">Pro Forma Combined Entity</div>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Combined Revenue</span><span className="font-mono">{fmtM(ma.proForma.combinedRevenue)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Combined EBITDA (incl. synergies)</span><span className="font-mono">{fmtM(ma.proForma.combinedEBITDA)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Combined Net Income (incl. after-tax synergies)</span><span className="font-mono">{fmtM(ma.proForma.combinedNetIncome)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Combined Shares Outstanding</span><span className="font-mono">{ma.proForma.combinedShares}M</span></div>
              <div className="flex justify-between border-t pt-1 font-bold text-base"><span>Pro Forma EPS</span><span className="font-mono text-emerald-700 dark:text-emerald-300">{fmt$(ma.proForma.proFormaEPS, 2)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">vs Standalone EPS</span><span className="font-mono">{fmt$(ma.proForma.standaloneEPS, 2)}</span></div>
              <div className="flex justify-between border-t pt-1 font-bold text-base">
                <span>Accretion / (Dilution)</span>
                <span className={cn("font-mono", ma.proForma.accretionPct >= 0 ? "text-emerald-700 dark:text-emerald-300" : "text-rose-700 dark:text-rose-300")}>
                  {fmt$(ma.proForma.accretionDilution, 2)} ({ma.proForma.accretionPct}%)
                </span>
              </div>
            </div>
            <div className="mt-2 text-[10px] text-muted-foreground italic">{ma.goodWill.standard} · Goodwill recognised: {fmtM(ma.goodWill.goodwill)} = Consideration {fmtM(ma.dealTerms.dealValue)} − Target Book Value {fmtM(ma.goodWill.bookValueOfTarget)}</div>
          </div>
        </CardContent>
      </Card>

      {/* FMVA-COMPLIANT REPORTS INDEX */}
      <Card className="border-l-4 border-l-slate-500">
        <CardHeader><CardTitle className="text-base">FMVA-Compliant Reports — {reports.length} reports across multi-jurisdictional standards</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2">
            {reports.map((r: any) => (
              <div key={r.id} className="rounded-md border p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="text-sm font-medium">{r.title}</div>
                  <Badge variant="outline" className="text-[10px] shrink-0">{r.location}</Badge>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">{r.description}</div>
                <div className="mt-1 text-[10px] font-mono text-emerald-700 dark:text-emerald-300">{r.standard}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================
// 3-STATEMENT MODEL SECTION — Meridian Capital Holdings
// ============================================================
function ThreeStatementSection() {
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    setLoading(true);
    fetch("/api/three-statement")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Skeleton className="h-96 w-full" />;
  if (!data) return <p className="text-sm text-muted-foreground">No data available.</p>;

  const yrs = data.years;
  const isl = data.incomeStatement;
  const bs = data.balanceSheet;
  const cf = data.cashFlow;
  const kpis = data.kpis;
  const fmt = (n: number) => `$${(n).toFixed(1)}`;
  const pct = (n: number) => `${n}%`;

  async function downloadExcel() {
    const XLSX = await import("xlsx");
    const rows: any[] = [];
    for (let i = 0; i < yrs.length; i++) {
      rows.push({
        Year: yrs[i],
        Revenue: isl.totalRevenue[i],
        GrossProfit: isl.grossProfit[i],
        EBITDA: isl.ebitda[i],
        EBIT: isl.ebit[i],
        NetIncome: isl.netIncome[i],
        TotalAssets: bs.totalAssets[i],
        TotalLiabilities: bs.totalLiabilities[i],
        TotalEquity: bs.totalEquity[i],
        BalanceCheck: bs.balanceCheck[i],
        CFO: cf.cashFromOps[i],
        Capex: cf.capex[i],
        FCF: kpis.freeCashFlow[i],
        ROE: kpis.roe[i],
        DebtToEbitda: kpis.debtToEbitda[i],
      });
    }
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "3-Statement");
    XLSX.writeFile(wb, "meridian_3statement.xlsx");
    toast.success("3-statement Excel downloaded");
  }

  return (
    <div className="space-y-4">
      <Card className="border-l-4 border-l-emerald-500">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2"><FileText className="size-5 text-emerald-600" /> 3-Statement Model — {data.meta.entity}</CardTitle>
            <CardDescription>{data.meta.structure} · {data.meta.fy23Revenue} · {data.meta.methodology}</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={downloadExcel}><FileSpreadsheet className="size-3.5" /> Excel</Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* KPI strip */}
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6">
            <div className="rounded-md border p-2 text-center bg-emerald-500/5">
              <div className="text-[10px] uppercase text-muted-foreground">FY23 Revenue</div>
              <div className="font-bold text-emerald-700 dark:text-emerald-300">${isl.totalRevenue[3].toFixed(0)}M</div>
            </div>
            <div className="rounded-md border p-2 text-center bg-violet-500/5">
              <div className="text-[10px] uppercase text-muted-foreground">FY23 EBITDA</div>
              <div className="font-bold text-violet-700 dark:text-violet-300">${isl.ebitda[3].toFixed(0)}M</div>
              <div className="text-[10px]">{isl.ebitdaMarginPct[3]}%</div>
            </div>
            <div className="rounded-md border p-2 text-center bg-blue-500/5">
              <div className="text-[10px] uppercase text-muted-foreground">FY23 Net Income</div>
              <div className="font-bold text-blue-700 dark:text-blue-300">${isl.netIncome[3].toFixed(0)}M</div>
              <div className="text-[10px]">{isl.netMarginPct[3]}%</div>
            </div>
            <div className="rounded-md border p-2 text-center bg-amber-500/5">
              <div className="text-[10px] uppercase text-muted-foreground">Debt/EBITDA</div>
              <div className="font-bold">{kpis.debtToEbitda[3]}x</div>
            </div>
            <div className="rounded-md border p-2 text-center bg-rose-500/5">
              <div className="text-[10px] uppercase text-muted-foreground">Interest Cov</div>
              <div className="font-bold">{kpis.interestCoverage[3]}x</div>
            </div>
            <div className="rounded-md border p-2 text-center bg-teal-500/5">
              <div className="text-[10px] uppercase text-muted-foreground">FCF</div>
              <div className="font-bold text-teal-700 dark:text-teal-300">${kpis.freeCashFlow[3].toFixed(0)}M</div>
            </div>
          </div>

          {/* INCOME STATEMENT TABLE */}
          <div>
            <div className="text-sm font-semibold mb-1">Income Statement ($M)</div>
            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-[11px]">
                <thead className="bg-emerald-700 text-white">
                  <tr>
                    <th className="px-2 py-1.5 text-left font-semibold">Line Item</th>
                    {yrs.map(y => <th key={y} className="px-2 py-1.5 text-right font-mono">{y}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {/* Segment revenue */}
                  <tr className="border-t bg-muted/30"><td className="px-2 py-1 font-semibold" colSpan={9}>Segment Revenue</td></tr>
                  <Row label="Lending Segment Revenue" values={isl.segmentRevenue.lending} fmt={fmt} />
                  <Row label="Construction Segment Revenue" values={isl.segmentRevenue.construction} fmt={fmt} />
                  <Row label="Real Estate Segment Revenue (NOI)" values={isl.segmentRevenue.realEstate} fmt={fmt} />
                  <Row label="AI SaaS Segment Revenue" values={isl.segmentRevenue.aiSaaS} fmt={fmt} />
                  <Row label="Total Revenue" values={isl.totalRevenue} fmt={fmt} bold highlight="emerald" />
                  <tr className="border-t" />
                  <Row label="Direct Costs (COGS)" values={isl.directCosts.map(v => -v)} fmt={fmt} />
                  <Row label="Gross Profit" values={isl.grossProfit} fmt={fmt} bold />
                  <Row label="Gross Margin %" values={isl.grossMarginPct} fmt={pct} muted />
                  <tr className="border-t" />
                  <Row label="Sales & Marketing" values={isl.sm.map(v => -v)} fmt={fmt} />
                  <Row label="Research & Development" values={isl.rd.map(v => -v)} fmt={fmt} />
                  <Row label="General & Administrative" values={isl.ga.map(v => -v)} fmt={fmt} />
                  <Row label="Total Operating Expenses" values={isl.totalOpEx.map(v => -v)} fmt={fmt} bold />
                  <Row label="EBITDA" values={isl.ebitda} fmt={fmt} bold highlight="violet" />
                  <Row label="EBITDA Margin %" values={isl.ebitdaMarginPct} fmt={pct} muted />
                  <tr className="border-t" />
                  <Row label="Depreciation & Amortization" values={isl.da.map(v => -v)} fmt={fmt} />
                  <Row label="EBIT (Operating Income)" values={isl.ebit} fmt={fmt} bold />
                  <Row label="Interest Expense" values={isl.interestExpense.map(v => -v)} fmt={fmt} />
                  <Row label="Interest Income" values={isl.interestIncome} fmt={fmt} />
                  <Row label="Pre-Tax Income (EBT)" values={isl.ebt} fmt={fmt} bold />
                  <Row label="Tax Expense" values={isl.tax.map(v => -v)} fmt={fmt} />
                  <Row label="Net Income" values={isl.netIncome} fmt={fmt} bold highlight="blue" />
                  <Row label="Net Margin %" values={isl.netMarginPct} fmt={pct} muted />
                </tbody>
              </table>
            </div>
          </div>

          {/* BALANCE SHEET TABLE */}
          <div>
            <div className="text-sm font-semibold mb-1">Balance Sheet ($M)</div>
            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-[11px]">
                <thead className="bg-blue-700 text-white">
                  <tr>
                    <th className="px-2 py-1.5 text-left font-semibold">Line Item</th>
                    {yrs.map(y => <th key={y} className="px-2 py-1.5 text-right font-mono">{y}</th>)}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t bg-muted/30"><td className="px-2 py-1 font-semibold" colSpan={9}>Current Assets</td></tr>
                  <Row label="Cash & Equivalents" values={bs.cash} fmt={fmt} />
                  <Row label="Accounts Receivable" values={bs.ar} fmt={fmt} />
                  <Row label="Inventory" values={bs.inventory} fmt={fmt} />
                  <Row label="Prepaid Expenses" values={bs.prepaid} fmt={fmt} />
                  <Row label="Total Current Assets" values={bs.totalCurrentAssets} fmt={fmt} bold />
                  <tr className="border-t bg-muted/30"><td className="px-2 py-1 font-semibold" colSpan={9}>Non-Current Assets</td></tr>
                  <Row label="PP&E (Gross)" values={bs.ppEGross} fmt={fmt} />
                  <Row label="Less: Accumulated Depreciation" values={bs.accumulatedDepreciation.map(v => -v)} fmt={fmt} />
                  <Row label="PP&E (Net)" values={bs.ppENet} fmt={fmt} bold />
                  <Row label="Intangibles" values={bs.intangibles} fmt={fmt} />
                  <Row label="Goodwill" values={bs.goodwill} fmt={fmt} />
                  <Row label="Other Assets" values={bs.otherAssets} fmt={fmt} />
                  <Row label="TOTAL ASSETS" values={bs.totalAssets} fmt={fmt} bold highlight="blue" />
                  <tr className="border-t bg-muted/30"><td className="px-2 py-1 font-semibold" colSpan={9}>Liabilities</td></tr>
                  <Row label="Accounts Payable" values={bs.ap} fmt={fmt} />
                  <Row label="Accrued Liabilities" values={bs.accruedLiab} fmt={fmt} />
                  <Row label="Deferred Revenue" values={bs.deferredRevenue} fmt={fmt} />
                  <Row label="Short-term Debt" values={bs.shortTermDebt} fmt={fmt} />
                  <Row label="Long-term Debt" values={bs.longTermDebt} fmt={fmt} />
                  <Row label="Lease Liability" values={bs.leaseLiability} fmt={fmt} />
                  <Row label="TOTAL LIABILITIES" values={bs.totalLiabilities} fmt={fmt} bold />
                  <tr className="border-t bg-muted/30"><td className="px-2 py-1 font-semibold" colSpan={9}>Equity</td></tr>
                  <Row label="Common Stock ($1 par)" values={bs.commonStock} fmt={fmt} />
                  <Row label="Additional Paid-in Capital" values={bs.apic} fmt={fmt} />
                  <Row label="Retained Earnings" values={bs.retainedEarnings} fmt={fmt} />
                  <Row label="Accumulated OCI" values={bs.accumulatedOci} fmt={fmt} />
                  <Row label="TOTAL EQUITY" values={bs.totalEquity} fmt={fmt} bold highlight="violet" />
                  <Row label="TOTAL LIABILITIES & EQUITY" values={bs.totalLiabAndEquity} fmt={fmt} bold highlight="blue" />
                  <Row label="Balance Check (A − L − E)" values={bs.balanceCheck} fmt={fmt} bold highlight={bs.balanceCheck.every(v => Math.abs(v) < 1) ? "emerald" : "rose"} />
                </tbody>
              </table>
            </div>
          </div>

          {/* CASH FLOW TABLE */}
          <div>
            <div className="text-sm font-semibold mb-1">Cash Flow Statement ($M)</div>
            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-[11px]">
                <thead className="bg-teal-700 text-white">
                  <tr>
                    <th className="px-2 py-1.5 text-left font-semibold">Line Item</th>
                    {yrs.map(y => <th key={y} className="px-2 py-1.5 text-right font-mono">{y}</th>)}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t bg-muted/30"><td className="px-2 py-1 font-semibold" colSpan={9}>Operating Activities</td></tr>
                  <Row label="Net Income" values={cf.netIncome} fmt={fmt} />
                  <Row label="D&A" values={cf.da} fmt={fmt} />
                  <Row label="(Inc)/Dec in AR" values={cf.deltaAR.map(v => -v)} fmt={fmt} />
                  <Row label="(Inc)/Dec in Inventory" values={cf.deltaInv.map(v => -v)} fmt={fmt} />
                  <Row label="Inc/(Dec) in AP" values={cf.deltaAP} fmt={fmt} />
                  <Row label="Inc/(Dec) in Accrued" values={cf.deltaAccrued} fmt={fmt} />
                  <Row label="Inc/(Dec) in Deferred Rev" values={cf.deltaDefRev} fmt={fmt} />
                  <Row label="Cash from Operating Activities" values={cf.cashFromOps} fmt={fmt} bold highlight="teal" />
                  <tr className="border-t bg-muted/30"><td className="px-2 py-1 font-semibold" colSpan={9}>Investing Activities</td></tr>
                  <Row label="Capital Expenditures" values={cf.capex.map(v => -v)} fmt={fmt} />
                  <Row label="Cash from Investing Activities" values={cf.cashFromInvesting} fmt={fmt} bold />
                  <tr className="border-t bg-muted/30"><td className="px-2 py-1 font-semibold" colSpan={9}>Financing Activities</td></tr>
                  <Row label="Dividends Paid" values={cf.dividendsPaid.map(v => -v)} fmt={fmt} />
                  <Row label="Cash from Financing Activities" values={cf.cashFromFinancing} fmt={fmt} bold />
                  <tr className="border-t" />
                  <Row label="Net Change in Cash" values={cf.netChangeInCash} fmt={fmt} bold />
                  <Row label="Beginning Cash" values={cf.beginningCash} fmt={fmt} />
                  <Row label="Ending Cash" values={cf.endingCash} fmt={fmt} bold highlight="teal" />
                </tbody>
              </table>
            </div>
          </div>

          {/* KPIs table */}
          <div>
            <div className="text-sm font-semibold mb-1">Summary KPIs</div>
            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-[11px]">
                <thead className="bg-amber-700 text-white">
                  <tr>
                    <th className="px-2 py-1.5 text-left font-semibold">KPI</th>
                    {yrs.map(y => <th key={y} className="px-2 py-1.5 text-right font-mono">{y}</th>)}
                  </tr>
                </thead>
                <tbody>
                  <Row label="Revenue Growth %" values={kpis.revenueGrowthPct} fmt={pct} />
                  <Row label="EBITDA Margin %" values={kpis.ebitdaMarginPct} fmt={pct} />
                  <Row label="Net Margin %" values={kpis.netMarginPct} fmt={pct} />
                  <Row label="Return on Equity (ROE) %" values={kpis.roe} fmt={pct} />
                  <Row label="Return on Assets (ROA) %" values={kpis.roa} fmt={pct} />
                  <Row label="Debt / EBITDA (x)" values={kpis.debtToEbitda} fmt={v => `${v}x`} />
                  <Row label="Interest Coverage (x)" values={kpis.interestCoverage} fmt={v => `${v}x`} />
                  <Row label="Current Ratio (x)" values={kpis.currentRatio} fmt={v => `${v}x`} />
                  <Row label="Working Capital ($M)" values={kpis.workingCapital} fmt={fmt} />
                  <Row label="Free Cash Flow ($M)" values={kpis.freeCashFlow} fmt={fmt} bold highlight="teal" />
                </tbody>
              </table>
            </div>
          </div>

          {/* Assumptions block */}
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader><CardTitle className="text-base">Key Assumptions (blue cells — user-modifiable)</CardTitle></CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-[11px]">
                  <thead className="bg-blue-700 text-white">
                    <tr>
                      <th className="px-2 py-1.5 text-left font-semibold">Driver</th>
                      {yrs.map(y => <th key={y} className="px-2 py-1.5 text-right font-mono">{y}</th>)}
                      <th className="px-2 py-1.5 text-left font-semibold">Formula</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.assumptions.map((a: any, i: number) => (
                      <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-blue-500/5" : "")}>
                        <td className="px-2 py-1.5 font-medium text-blue-700 dark:text-blue-300">{a.driver}</td>
                        {a.values.map((v: number, j: number) => (
                          <td key={j} className="px-2 py-1.5 text-right font-mono text-blue-600 dark:text-blue-400 font-semibold">{(v * 100).toFixed(1)}%</td>
                        ))}
                        <td className="px-2 py-1.5 text-[10px] text-muted-foreground italic">{a.formula}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Formula reference */}
          <Card className="border-l-4 border-l-slate-500">
            <CardHeader><CardTitle className="text-base">Linked Formulas Reference</CardTitle></CardHeader>
            <CardContent>
              <div className="grid gap-1.5 md:grid-cols-2 text-[11px]">
                {Object.entries(data.formulas).map(([k, v]) => (
                  <div key={k} className="rounded border border-slate-500/20 p-2">
                    <div className="font-mono text-[10px] text-slate-600 dark:text-slate-400 uppercase">{k}</div>
                    <div className="text-muted-foreground">{v as string}</div>
                  </div>
                ))}
              </div>
              <div className="mt-3 text-[10px] text-muted-foreground italic">{data.meta.disclaimer}</div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}

// Reusable row component for 3-statement tables
function Row({ label, values, fmt, bold, muted, highlight }: {
  label: string;
  values: number[];
  fmt: (n: number) => string;
  bold?: boolean;
  muted?: boolean;
  highlight?: string;
}) {
  const highlightBg = highlight
    ? highlight === "emerald" ? "bg-emerald-500/15"
    : highlight === "blue" ? "bg-blue-500/15"
    : highlight === "violet" ? "bg-violet-500/15"
    : highlight === "teal" ? "bg-teal-500/15"
    : highlight === "rose" ? "bg-rose-500/15"
    : ""
    : "";
  return (
    <tr className={cn("border-t", highlightBg)}>
      <td className={cn("px-2 py-1", bold && "font-semibold", muted && "text-muted-foreground text-[10px] italic")}>{label}</td>
      {values.map((v, i) => (
        <td key={i} className={cn("px-2 py-1 text-right font-mono", bold && "font-bold")}>{fmt(v)}</td>
      ))}
    </tr>
  );
}

// ============================================================
// LOAN PORTFOLIO SECTION
// ============================================================
function LoanPortfolioSection() {
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [selectedLoan, setSelectedLoan] = React.useState<string | null>(null);

  React.useEffect(() => {
    setLoading(true);
    fetch("/api/loan-portfolio")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Skeleton className="h-96 w-full" />;
  if (!data) return <p className="text-sm text-muted-foreground">No data available.</p>;

  const ps = data.portfolioSummary;
  const fmt$ = (n: number) => `$${(n / 1e6).toFixed(1)}M`;
  const fmt$0 = (n: number) => `$${n.toLocaleString()}`;

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card className="border-l-4 border-l-violet-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Landmark className="size-5 text-violet-600" /> {data.meta.portfolioName}</CardTitle>
          <CardDescription>As of {data.meta.asOfDate} · {data.meta.methodology}</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Portfolio KPI strip */}
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6">
            <div className="rounded-md border border-violet-500/30 bg-violet-500/5 p-2 text-center">
              <div className="text-[10px] uppercase text-muted-foreground">Total Outstanding</div>
              <div className="font-bold text-violet-700 dark:text-violet-300">{fmt$(ps.totalOutstanding)}</div>
            </div>
            <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-2 text-center">
              <div className="text-[10px] uppercase text-muted-foreground">Wtd Avg Rate</div>
              <div className="font-bold text-amber-700 dark:text-amber-300">{ps.weightedAvgRate}%</div>
            </div>
            <div className="rounded-md border border-blue-500/30 bg-blue-500/5 p-2 text-center">
              <div className="text-[10px] uppercase text-muted-foreground">Wtd Avg LTV</div>
              <div className="font-bold text-blue-700 dark:text-blue-300">{ps.weightedAvgLTV}%</div>
            </div>
            <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2 text-center">
              <div className="text-[10px] uppercase text-muted-foreground">Wtd Avg DSCR</div>
              <div className="font-bold text-emerald-700 dark:text-emerald-300">{ps.weightedAvgDSCR}x</div>
            </div>
            <div className="rounded-md border border-rose-500/30 bg-rose-500/5 p-2 text-center">
              <div className="text-[10px] uppercase text-muted-foreground">NPL %</div>
              <div className="font-bold text-rose-700 dark:text-rose-300">{ps.nplPct}%</div>
              <div className="text-[9px] text-muted-foreground">{ps.nplCount} loan(s)</div>
            </div>
            <div className="rounded-md border border-orange-500/30 bg-orange-500/5 p-2 text-center">
              <div className="text-[10px] uppercase text-muted-foreground">Expected Loss</div>
              <div className="font-bold text-orange-700 dark:text-orange-300">{fmt$(ps.totalExpectedLoss)}</div>
              <div className="text-[9px] text-muted-foreground">PD × LGD × EAD</div>
            </div>
          </div>

          {/* Status counts */}
          <div className="mt-3 flex flex-wrap gap-2 text-xs">
            <Badge variant="outline" className="border-violet-500/30 text-violet-700 dark:text-violet-300">Total Loans: {ps.loanCount}</Badge>
            <Badge variant="outline" className="border-emerald-500/30 text-emerald-700 dark:text-emerald-300">Watchlist: {ps.watchlistCount}</Badge>
            <Badge variant="outline" className={cn(ps.covenantBreaches > 0 ? "border-rose-500/40 text-rose-700 dark:text-rose-300" : "border-emerald-500/30 text-emerald-700 dark:text-emerald-300")}>
              Covenant Breaches: {ps.covenantBreaches}
            </Badge>
            <Badge variant="outline" className="border-slate-500/30 text-slate-700 dark:text-slate-300">Portfolio PD: {ps.portfolioPD}%</Badge>
            <Badge variant="outline" className="border-slate-500/30 text-slate-700 dark:text-slate-300">Portfolio LGD: {ps.portfolioLGD}%</Badge>
            <Badge variant="outline" className="border-slate-500/30 text-slate-700 dark:text-slate-300">Total Collateral: {fmt$(ps.totalCollateral)}</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Loan portfolio master table */}
      <Card>
        <CardHeader><CardTitle className="text-base">Loan Portfolio — Master Schedule</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[11px]">
              <thead className="bg-violet-700 text-white">
                <tr>
                  <th className="px-2 py-2 text-left font-semibold">Loan ID</th>
                  <th className="px-2 py-2 text-left font-semibold">Borrower</th>
                  <th className="px-2 py-2 text-left font-semibold">Type</th>
                  <th className="px-2 py-2 text-right font-semibold">Balance</th>
                  <th className="px-2 py-2 text-right font-semibold">Rate</th>
                  <th className="px-2 py-2 text-right font-semibold">Mo Pmt</th>
                  <th className="px-2 py-2 text-right font-semibold">LTV</th>
                  <th className="px-2 py-2 text-right font-semibold">DSCR</th>
                  <th className="px-2 py-2 text-right font-semibold">Debt Yld</th>
                  <th className="px-2 py-2 text-right font-semibold">Int Cov</th>
                  <th className="px-2 py-2 text-center font-semibold">Stage</th>
                  <th className="px-2 py-2 text-right font-semibold">EL</th>
                  <th className="px-2 py-2 text-center font-semibold">Covenant</th>
                  <th className="px-2 py-2 text-center font-semibold">Amort</th>
                </tr>
              </thead>
              <tbody>
                {data.loans.map((l: any, i: number) => (
                  <tr key={l.loanId} className={cn("border-t cursor-pointer hover:bg-muted/30", i % 2 === 0 ? "bg-muted/20" : "", selectedLoan === l.loanId && "bg-violet-500/15")}
                    onClick={() => setSelectedLoan(selectedLoan === l.loanId ? null : l.loanId)}>
                    <td className="px-2 py-1.5 font-mono font-medium text-violet-700 dark:text-violet-300">{l.loanId}</td>
                    <td className="px-2 py-1.5">{l.borrower}</td>
                    <td className="px-2 py-1.5"><Badge variant="outline" className="text-[9px]">{l.loanType}</Badge></td>
                    <td className="px-2 py-1.5 text-right font-mono font-semibold">{fmt$(l.currentBalance)}</td>
                    <td className="px-2 py-1.5 text-right font-mono">{l.interestRate}%</td>
                    <td className="px-2 py-1.5 text-right font-mono">{fmt$0(l.monthlyPayment)}</td>
                    <td className={cn("px-2 py-1.5 text-right font-mono", l.ltv > l.covenantLTVMax ? "text-rose-600 dark:text-rose-400 font-bold" : "")}>{l.ltv}%</td>
                    <td className={cn("px-2 py-1.5 text-right font-mono", l.covenantDSCRMin > 0 && l.dscr < l.covenantDSCRMin ? "text-rose-600 dark:text-rose-400 font-bold" : "")}>{l.dscr > 0 ? `${l.dscr}x` : "—"}</td>
                    <td className={cn("px-2 py-1.5 text-right font-mono", l.covenantDebtYieldMin > 0 && l.debtYield < l.covenantDebtYieldMin ? "text-rose-600 dark:text-rose-400 font-bold" : "")}>{l.debtYield > 0 ? `${l.debtYield}%` : "—"}</td>
                    <td className={cn("px-2 py-1.5 text-right font-mono", l.covenantIntCovMin > 0 && l.interestCoverage < l.covenantIntCovMin ? "text-rose-600 dark:text-rose-400 font-bold" : "")}>{l.interestCoverage > 0 ? `${l.interestCoverage}x` : "—"}</td>
                    <td className="px-2 py-1.5 text-center"><Badge variant="outline" className={cn("text-[9px]", l.riskStage === "Performing" ? "border-emerald-500/30 text-emerald-700 dark:text-emerald-300" : l.riskStage === "Watchlist" ? "border-amber-500/30 text-amber-700 dark:text-amber-300" : "border-rose-500/40 text-rose-700 dark:text-rose-300")}>{l.riskStage}</Badge></td>
                    <td className="px-2 py-1.5 text-right font-mono text-orange-700 dark:text-orange-300">{fmt$0(l.expectedLoss)}</td>
                    <td className="px-2 py-1.5 text-center">
                      {l.covenantsCompliant
                        ? <Badge variant="outline" className="text-[9px] border-emerald-500/30 text-emerald-700 dark:text-emerald-300"><CheckCircle2 className="size-2.5 mr-0.5 inline" />OK</Badge>
                        : <Badge variant="outline" className="text-[9px] border-rose-500/40 text-rose-700 dark:text-rose-300"><AlertTriangle className="size-2.5 mr-0.5 inline" />BREACH</Badge>}
                    </td>
                    <td className="px-2 py-1.5 text-center text-[10px] text-muted-foreground">{l.amortizationType}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-2 text-[10px] text-muted-foreground italic">Click any loan row to view its amortization schedule and covenant detail.</div>
        </CardContent>
      </Card>

      {/* Selected loan amortization schedule */}
      {selectedLoan && (() => {
        const sched = data.amortizationSchedules.find((s: any) => s.loanId === selectedLoan);
        const loan = data.loans.find((l: any) => l.loanId === selectedLoan);
        if (!sched || !loan) return null;
        const cov = data.covenantMatrix.find((c: any) => c.loanId === selectedLoan);
        return (
          <Card className="border-l-4 border-l-violet-500">
            <CardHeader>
              <CardTitle className="text-base">Amortization Schedule — {loan.borrower} ({selectedLoan})</CardTitle>
              <CardDescription>
                {loan.amortizationType} · {loan.interestRate}% {loan.rateType} · Original ${loan.originalPrincipal.toLocaleString()} · Monthly payment ${loan.monthlyPayment.toLocaleString()} · {sched.rows.length} months shown
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Loan detail */}
              <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6 text-xs">
                <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Property / Project</div><div className="font-medium">{loan.propertyOrProject.slice(0, 40)}</div></div>
                <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Origination</div><div className="font-medium">{loan.originationDate}</div></div>
                <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Maturity</div><div className="font-medium">{loan.maturityDate}</div></div>
                <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Collateral Value</div><div className="font-medium font-mono">{fmt$0(loan.collateralValue)}</div></div>
                <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Days Past Due</div><div className="font-medium">{loan.daysPastDue}</div></div>
                <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">PD / LGD</div><div className="font-medium">{loan.pd}% / {loan.lgd}%</div></div>
              </div>

              {/* Amortization schedule table */}
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-[10px]">
                  <thead className="bg-violet-700 text-white">
                    <tr>
                      <th className="px-2 py-1.5 text-left font-semibold">Month</th>
                      <th className="px-2 py-1.5 text-left font-semibold">Date</th>
                      <th className="px-2 py-1.5 text-right font-semibold">Beginning Bal</th>
                      <th className="px-2 py-1.5 text-right font-semibold">Payment</th>
                      <th className="px-2 py-1.5 text-right font-semibold">Interest</th>
                      <th className="px-2 py-1.5 text-right font-semibold">Principal</th>
                      <th className="px-2 py-1.5 text-right font-semibold">Ending Bal</th>
                      <th className="px-2 py-1.5 text-right font-semibold">Cum Int</th>
                      <th className="px-2 py-1.5 text-right font-semibold">Cum Prin</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sched.rows.slice(0, 24).map((r: any) => (
                      <tr key={r.month} className="border-t">
                        <td className="px-2 py-1 font-mono">{r.month}</td>
                        <td className="px-2 py-1 font-mono">{r.date}</td>
                        <td className="px-2 py-1 text-right font-mono">{fmt$0(r.beginningBalance)}</td>
                        <td className="px-2 py-1 text-right font-mono font-semibold">{fmt$0(r.payment)}</td>
                        <td className="px-2 py-1 text-right font-mono text-rose-700 dark:text-rose-400">{fmt$0(r.interest)}</td>
                        <td className="px-2 py-1 text-right font-mono text-emerald-700 dark:text-emerald-300">{fmt$0(r.principal)}</td>
                        <td className="px-2 py-1 text-right font-mono font-semibold">{fmt$0(r.endingBalance)}</td>
                        <td className="px-2 py-1 text-right font-mono text-muted-foreground">{fmt$0(r.cumulativeInterest)}</td>
                        <td className="px-2 py-1 text-right font-mono text-muted-foreground">{fmt$0(r.cumulativePrincipal)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 bg-violet-500/15 font-bold">
                      <td colSpan={3} className="px-2 py-2">Totals (first 24 months shown — full schedule in Excel export)</td>
                      <td className="px-2 py-2 text-right font-mono">{fmt$0(sched.rows.slice(0, 24).reduce((s: number, r: any) => s + r.payment, 0))}</td>
                      <td className="px-2 py-2 text-right font-mono">{fmt$0(sched.rows.slice(0, 24).reduce((s: number, r: any) => s + r.interest, 0))}</td>
                      <td className="px-2 py-2 text-right font-mono">{fmt$0(sched.rows.slice(0, 24).reduce((s: number, r: any) => s + r.principal, 0))}</td>
                      <td colSpan={3}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Covenant detail */}
              <div>
                <div className="text-sm font-semibold mb-2">Covenant Compliance Detail</div>
                <div className="overflow-x-auto rounded-md border">
                  <table className="w-full text-xs">
                    <thead className="bg-amber-700 text-white">
                      <tr>
                        <th className="px-2 py-1.5 text-left font-semibold">Covenant</th>
                        <th className="px-2 py-1.5 text-right font-semibold">Actual</th>
                        <th className="px-2 py-1.5 text-right font-semibold">Threshold</th>
                        <th className="px-2 py-1.5 text-right font-semibold">Headroom</th>
                        <th className="px-2 py-1.5 text-center font-semibold">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <CovRow label="DSCR (min)" actual={cov.dscrActual > 0 ? `${cov.dscrActual}x` : "N/A"} threshold={cov.dscrCovenant > 0 ? `${cov.dscrCovenant}x` : "N/A"} headroom={cov.dscrHeadroom > 0 ? `${cov.dscrHeadroom}x` : "—"} status={cov.dscrStatus} />
                      <CovRow label="LTV (max)" actual={`${cov.ltvActual}%`} threshold={`${cov.ltvCovenant}%`} headroom={`${cov.ltvHeadroom}%`} status={cov.ltvStatus} />
                      <CovRow label="Debt Yield (min)" actual={cov.debtYieldActual > 0 ? `${cov.debtYieldActual}%` : "N/A"} threshold={cov.debtYieldCovenant > 0 ? `${cov.debtYieldCovenant}%` : "N/A"} headroom={cov.debtYieldHeadroom > 0 ? `${cov.debtYieldHeadroom}%` : "—"} status={cov.debtYieldStatus} />
                      <CovRow label="Interest Coverage (min)" actual={cov.intCovActual > 0 ? `${cov.intCovActual}x` : "N/A"} threshold={cov.intCovCovenant > 0 ? `${cov.intCovCovenant}x` : "N/A"} headroom={cov.intCovHeadroom > 0 ? `${cov.intCovHeadroom}x` : "—"} status={cov.intCovStatus} />
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })()}

      {/* Covenant matrix (all loans) */}
      <Card>
        <CardHeader><CardTitle className="text-base">Covenant Compliance Matrix — All Loans</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[10px]">
              <thead className="bg-amber-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold">Loan</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Borrower</th>
                  <th className="px-2 py-1.5 text-right font-semibold">DSCR Act</th>
                  <th className="px-2 py-1.5 text-right font-semibold">DSCR Cov</th>
                  <th className="px-2 py-1.5 text-center font-semibold">DSCR St</th>
                  <th className="px-2 py-1.5 text-right font-semibold">LTV Act</th>
                  <th className="px-2 py-1.5 text-right font-semibold">LTV Cov</th>
                  <th className="px-2 py-1.5 text-center font-semibold">LTV St</th>
                  <th className="px-2 py-1.5 text-right font-semibold">DY Act</th>
                  <th className="px-2 py-1.5 text-right font-semibold">DY Cov</th>
                  <th className="px-2 py-1.5 text-center font-semibold">DY St</th>
                  <th className="px-2 py-1.5 text-right font-semibold">IC Act</th>
                  <th className="px-2 py-1.5 text-right font-semibold">IC Cov</th>
                  <th className="px-2 py-1.5 text-center font-semibold">IC St</th>
                  <th className="px-2 py-1.5 text-center font-semibold">Overall</th>
                </tr>
              </thead>
              <tbody>
                {data.covenantMatrix.map((c: any, i: number) => (
                  <tr key={c.loanId} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1 font-mono">{c.loanId}</td>
                    <td className="px-2 py-1">{c.borrower.slice(0, 20)}</td>
                    <td className="px-2 py-1 text-right font-mono">{c.dscrActual > 0 ? `${c.dscrActual}x` : "—"}</td>
                    <td className="px-2 py-1 text-right font-mono">{c.dscrCovenant > 0 ? `${c.dscrCovenant}x` : "—"}</td>
                    <td className="px-2 py-1 text-center"><CovBadge status={c.dscrStatus} /></td>
                    <td className="px-2 py-1 text-right font-mono">{c.ltvActual}%</td>
                    <td className="px-2 py-1 text-right font-mono">{c.ltvCovenant}%</td>
                    <td className="px-2 py-1 text-center"><CovBadge status={c.ltvStatus} /></td>
                    <td className="px-2 py-1 text-right font-mono">{c.debtYieldActual > 0 ? `${c.debtYieldActual}%` : "—"}</td>
                    <td className="px-2 py-1 text-right font-mono">{c.debtYieldCovenant > 0 ? `${c.debtYieldCovenant}%` : "—"}</td>
                    <td className="px-2 py-1 text-center"><CovBadge status={c.debtYieldStatus} /></td>
                    <td className="px-2 py-1 text-right font-mono">{c.intCovActual > 0 ? `${c.intCovActual}x` : "—"}</td>
                    <td className="px-2 py-1 text-right font-mono">{c.intCovCovenant > 0 ? `${c.intCovCovenant}x` : "—"}</td>
                    <td className="px-2 py-1 text-center"><CovBadge status={c.intCovStatus} /></td>
                    <td className="px-2 py-1 text-center"><CovBadge status={c.overallStatus} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Formulas reference */}
      <Card className="border-l-4 border-l-slate-500">
        <CardHeader><CardTitle className="text-base">Loan Computation Formulas</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-1.5 md:grid-cols-2 text-[11px]">
            {Object.entries(data.formulas).map(([k, v]) => (
              <div key={k} className="rounded border border-slate-500/20 p-2">
                <div className="font-mono text-[10px] text-slate-600 dark:text-slate-400 uppercase">{k}</div>
                <div className="text-muted-foreground">{v as string}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 text-[10px] text-muted-foreground italic">{data.meta.standardsApplied} · {data.meta.disclaimer}</div>
        </CardContent>
      </Card>
    </div>
  );
}

function CovRow({ label, actual, threshold, headroom, status }: { label: string; actual: string; threshold: string; headroom: string; status: string }) {
  return (
    <tr className="border-t">
      <td className="px-2 py-1.5 font-medium">{label}</td>
      <td className="px-2 py-1.5 text-right font-mono font-bold">{actual}</td>
      <td className="px-2 py-1.5 text-right font-mono text-muted-foreground">{threshold}</td>
      <td className="px-2 py-1.5 text-right font-mono">{headroom}</td>
      <td className="px-2 py-1.5 text-center"><CovBadge status={status} /></td>
    </tr>
  );
}

function CovBadge({ status }: { status: string }) {
  if (status === "N/A") return <span className="text-[10px] text-muted-foreground">N/A</span>;
  if (status === "Compliant") return <Badge variant="outline" className="text-[9px] border-emerald-500/30 text-emerald-700 dark:text-emerald-300"><CheckCircle2 className="size-2.5 mr-0.5 inline" />OK</Badge>;
  return <Badge variant="outline" className="text-[9px] border-rose-500/40 text-rose-700 dark:text-rose-300"><AlertTriangle className="size-2.5 mr-0.5 inline" />BREACH</Badge>;
}

// ============================================================
// SCENARIO ENGINE SECTION — Driver Tree & 4 Scenarios
// ============================================================
function ScenarioEngineSection() {
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    setLoading(true);
    fetch("/api/driver-tree")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Skeleton className="h-96 w-full" />;
  if (!data) return <p className="text-sm text-muted-foreground">No scenario data available.</p>;

  const fmtM = (n: number) => `$${(n).toFixed(1)}M`;
  const fmtPct = (n: number) => `${n}%`;
  const fmtDelta = (n: number) => n > 0 ? `+$${n.toFixed(1)}M` : n < 0 ? `-$${Math.abs(n).toFixed(1)}M` : `$0.0M`;

  const scenarioColors: Record<string, string> = {
    Base: "border-slate-500/40 text-slate-700 dark:text-slate-300 bg-slate-500/10",
    Bull: "border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10",
    Bear: "border-amber-500/40 text-amber-700 dark:text-amber-300 bg-amber-500/10",
    Stress: "border-rose-500/40 text-rose-700 dark:text-rose-300 bg-rose-500/10",
  };

  const st1 = data.sensitivityTable1;
  const st2 = data.sensitivityTable2;

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card className="border-l-4 border-l-emerald-500 bg-emerald-500/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><TrendingUp className="size-5 text-emerald-600" /> {data.meta.title}</CardTitle>
          <CardDescription>{data.meta.description} · {data.meta.standards}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground">{data.meta.methodology}</p>
          <p className="mt-1 text-[10px] text-muted-foreground italic">Seed: {data.meta.seedData}</p>
        </CardContent>
      </Card>

      {/* Scenario KPI strip */}
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        {(["Base", "Bull", "Bear", "Stress"] as const).map(s => {
          const o = data.outputs[s];
          return (
            <Card key={s} className={cn("border-l-4", s === "Base" ? "border-l-slate-500" : s === "Bull" ? "border-l-emerald-500" : s === "Bear" ? "border-l-amber-500" : "border-l-rose-500")}>
              <CardContent className="py-3">
                <div className="flex items-center justify-between mb-1">
                  <Badge variant="outline" className={cn("text-[10px]", scenarioColors[s])}>{s} Case</Badge>
                </div>
                <div className="text-xs text-muted-foreground">Revenue / EBITDA / NI</div>
                <div className="font-bold text-sm">{fmtM(o.totalRevenue)} / {fmtM(o.ebitda)} / {fmtM(o.netIncome)}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">EBITDA {o.ebitdaMarginPct}% · NI {o.netMarginPct}% · FCF {fmtM(o.fcf)}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Scenario Assumptions Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Scenario Assumptions — Modify blue cells to see impact</CardTitle>
          <CardDescription>14 drivers × 4 scenarios (Base/Bull/Bear/Stress) with deltas vs Base</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[11px]">
              <thead className="bg-blue-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold">Driver</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Category</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Base Case</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Bull Case</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Bear Case</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Stress Case</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Δ Bull</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Δ Bear</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Δ Stress</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Formula</th>
                </tr>
              </thead>
              <tbody>
                {data.assumptions.map((a: any, i: number) => {
                  const dBull = Math.round((a.bull - a.base) * 100) / 100;
                  const dBear = Math.round((a.bear - a.base) * 100) / 100;
                  const dStress = Math.round((a.stress - a.base) * 100) / 100;
                  const catColor = a.category === "Macro" ? "border-blue-500/30 text-blue-700 dark:text-blue-300"
                    : a.category === "Segment Growth" ? "border-violet-500/30 text-violet-700 dark:text-violet-300"
                    : a.category === "Cost Structure" ? "border-amber-500/30 text-amber-700 dark:text-amber-300"
                    : "border-emerald-500/30 text-emerald-700 dark:text-emerald-300";
                  return (
                    <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                      <td className="px-2 py-1.5 font-medium text-blue-700 dark:text-blue-300">{a.driver}</td>
                      <td className="px-2 py-1.5"><Badge variant="outline" className={cn("text-[9px]", catColor)}>{a.category}</Badge></td>
                      <td className="px-2 py-1.5 text-right font-mono font-bold">{a.base}{a.unit === "%" ? "%" : a.unit === "GBP/USD" ? "" : ""}</td>
                      <td className="px-2 py-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300">{a.bull}{a.unit === "%" ? "%" : ""}</td>
                      <td className="px-2 py-1.5 text-right font-mono text-amber-700 dark:text-amber-300">{a.bear}{a.unit === "%" ? "%" : ""}</td>
                      <td className="px-2 py-1.5 text-right font-mono text-rose-700 dark:text-rose-300">{a.stress}{a.unit === "%" ? "%" : ""}</td>
                      <td className={cn("px-2 py-1.5 text-right font-mono text-[10px]", dBull > 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>{dBull > 0 ? "+" : ""}{dBull}{a.unit === "%" ? "pp" : ""}</td>
                      <td className={cn("px-2 py-1.5 text-right font-mono text-[10px]", dBear > 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>{dBear > 0 ? "+" : ""}{dBear}{a.unit === "%" ? "pp" : ""}</td>
                      <td className={cn("px-2 py-1.5 text-right font-mono text-[10px]", dStress > 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>{dStress > 0 ? "+" : ""}{dStress}{a.unit === "%" ? "pp" : ""}</td>
                      <td className="px-2 py-1.5 text-[9px] text-muted-foreground italic">{a.formula}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Scenario Comparison Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">FY2024E Projected Outputs — Driven by scenario assumptions</CardTitle>
          <CardDescription>All line items computed from the 14 drivers above · Deltas vs Base Case shown</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[11px]">
              <thead className="bg-emerald-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold">Line Item</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Base Case</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Bull Case</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Bear Case</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Stress Case</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Bull vs Base</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Bear vs Base</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Stress vs Base</th>
                </tr>
              </thead>
              <tbody>
                {data.comparison.map((r: any, i: number) => {
                  const isTotal = r.isTotal;
                  const isMargin = r.isMargin;
                  const fmtVal = (v: any) => isMargin ? `${v}%` : typeof v === "number" ? fmtM(v) : v;
                  const fmtD = (v: any) => isMargin ? `${v > 0 ? "+" : ""}${v}pp` : typeof v === "number" ? fmtDelta(v) : v;
                  return (
                    <tr key={i} className={cn(
                      "border-t",
                      isTotal && "bg-emerald-500/15 font-bold",
                      i % 2 === 0 && !isTotal && "bg-muted/20"
                    )}>
                      <td className="px-2 py-1.5">{isTotal ? <strong>{r.lineItem}</strong> : r.lineItem}</td>
                      <td className="px-2 py-1.5 text-right font-mono">{fmtVal(r.base)}</td>
                      <td className="px-2 py-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300">{fmtVal(r.bull)}</td>
                      <td className="px-2 py-1.5 text-right font-mono text-amber-700 dark:text-amber-300">{fmtVal(r.bear)}</td>
                      <td className="px-2 py-1.5 text-right font-mono text-rose-700 dark:text-rose-300">{fmtVal(r.stress)}</td>
                      <td className={cn("px-2 py-1.5 text-right font-mono text-[10px]", typeof r.bullVsBase === "number" && r.bullVsBase > 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>{fmtD(r.bullVsBase)}</td>
                      <td className={cn("px-2 py-1.5 text-right font-mono text-[10px]", typeof r.bearVsBase === "number" && r.bearVsBase > 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>{fmtD(r.bearVsBase)}</td>
                      <td className={cn("px-2 py-1.5 text-right font-mono text-[10px]", typeof r.stressVsBase === "number" && r.stressVsBase > 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>{fmtD(r.stressVsBase)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Sensitivity Table 1: Revenue Growth × Direct Cost % → Net Income */}
      <Card className="border-l-4 border-l-rose-500">
        <CardHeader>
          <CardTitle className="text-base">Sensitivity Table 1: {st1.title}</CardTitle>
          <CardDescription>{st1.rowVariable} (rows) × {st1.colVariable} (cols) — Net Income in $M</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-[11px]">
              <thead>
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold border-r-2 border-rose-500/30">{st1.rowVariable} ↓ / {st1.colVariable} →</th>
                  {st1.colValues.map((c: any) => (
                    <th key={c} className={cn("px-2 py-1.5 text-right font-mono", c === st1.baseCaseCol && "bg-amber-500/20")}>{c}%</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {st1.matrix.map((row: any, ri: number) => (
                  <tr key={ri} className={cn("border-t", st1.rowValues[ri] === st1.baseCaseRow && "bg-amber-500/10 font-bold")}>
                    <td className="px-2 py-1.5 text-left font-mono font-semibold border-r-2 border-rose-500/30">{st1.rowValues[ri]}%</td>
                    {row.map((v: any, ci: number) => (
                      <td key={ci} className={cn(
                        "px-2 py-1.5 text-right font-mono",
                        st1.rowValues[ri] === st1.baseCaseRow && st1.colValues[ci] === st1.baseCaseCol && "bg-amber-600 text-white font-bold",
                        v < 0 && "text-rose-700 dark:text-rose-400"
                      )}>{fmtM(v)}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-1 text-[10px] text-muted-foreground">Highlighted cell = base case (Revenue Growth {st1.baseCaseRow}% × Direct Cost {st1.baseCaseCol}%). Negative values shown in red.</div>
        </CardContent>
      </Card>

      {/* Sensitivity Table 2: EBITDA Margin × Interest Rate → FCF */}
      <Card className="border-l-4 border-l-violet-500">
        <CardHeader>
          <CardTitle className="text-base">Sensitivity Table 2: {st2.title}</CardTitle>
          <CardDescription>{st2.rowVariable} (rows) × {st2.colVariable} (cols) — FCF in $M</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-[11px]">
              <thead>
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold border-r-2 border-violet-500/30">{st2.rowVariable} ↓ / {st2.colVariable} →</th>
                  {st2.colValues.map((c: any) => (
                    <th key={c} className="px-2 py-1.5 text-right font-mono">{c}%</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {st2.matrix.map((row: any, ri: number) => (
                  <tr key={ri} className="border-t">
                    <td className="px-2 py-1.5 text-left font-mono font-semibold border-r-2 border-violet-500/30">{st2.rowValues[ri]}%</td>
                    {row.map((v: any, ci: number) => (
                      <td key={ci} className={cn(
                        "px-2 py-1.5 text-right font-mono",
                        v < 0 && "text-rose-700 dark:text-rose-400 font-bold"
                      )}>{fmtM(v)}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Driver Tree — 5-Level Hierarchy */}
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader>
          <CardTitle className="text-base">Driver Tree — Macro Drivers to Net Income (5 Levels)</CardTitle>
          <CardDescription>Hierarchical decomposition: Macro → Segment → Revenue → Profitability → Cash Flow</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {Object.entries(data.driverTree).map(([levelKey, level]: any) => (
            <div key={levelKey}>
              <div className="text-xs font-semibold mb-1 text-blue-700 dark:text-blue-300">{level.title}</div>
              <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
                {level.nodes.map((node: any, i: number) => (
                  <div key={i} className="rounded-md border border-blue-500/20 bg-blue-500/5 p-2">
                    <div className="text-xs font-semibold">{node.name}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{node.description}</div>
                    {node.formula && <div className="text-[10px] font-mono mt-1 text-blue-700 dark:text-blue-300">{node.formula}</div>}
                    {node.currentValue && <div className="text-[10px] mt-1 font-mono font-semibold">Current: {node.currentValue}</div>}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Laws & Standards Applied */}
      <Card className="border-l-4 border-l-slate-500">
        <CardHeader>
          <CardTitle className="text-base">Laws & Standards Applied — Scenario Engine</CardTitle>
          <CardDescription>{data.laws.length} statutes governing the scenario computations across IFRS, US GAAP, UK FRS 102, Basel III, OECD Pillar Two</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2">
            {data.laws.map((law: any, i: number) => (
              <div key={i} className="rounded-md border border-slate-500/20 p-2">
                <div className="flex items-start gap-1.5">
                  <Badge variant="outline" className="text-[9px] border-slate-500/30 text-slate-700 dark:text-slate-300 shrink-0 py-0 px-1">LAW</Badge>
                  <div>
                    <div className="text-xs font-semibold">{law.law}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{law.application}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================
// BOARD PACK DASHBOARD — Executive KPI Summary
// ============================================================
function BoardPackSection() {
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    setLoading(true);
    fetch("/api/three-statement")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Skeleton className="h-96 w-full" />;
  if (!data) return <p className="text-sm text-muted-foreground">No data available.</p>;

  const yrs = data.years;
  const isl = data.incomeStatement;
  const bs = data.balanceSheet;
  const cf = data.cashFlow;
  const k = data.kpis;
  const fmtM = (n: number) => `$${n.toFixed(1)}M`;
  const fmtX = (n: number) => `${n}x`;
  const fmtPct = (n: number) => `${n}%`;
  const fy24Idx = 4;
  const totalDebt = (i: number) => Math.round((bs.shortTermDebt[i] + bs.longTermDebt[i]) * 10) / 10;

  type Status = "On Plan" | "Watch" | "Off Track";
  const getStatus = (actual: number, target: number, direction: "up" | "down", tolerance: number): Status => {
    const diff = direction === "up" ? actual - target : target - actual;
    const pctDiff = Math.abs(diff / target) * 100;
    if (pctDiff <= tolerance) return "On Plan";
    if (pctDiff <= tolerance * 2) return "Watch";
    return "Off Track";
  };

  const statusColors: Record<Status, string> = {
    "On Plan": "border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10",
    "Watch": "border-amber-500/40 text-amber-700 dark:text-amber-300 bg-amber-500/10",
    "Off Track": "border-rose-500/40 text-rose-700 dark:text-rose-300 bg-rose-500/10",
  };

  const kpiCards = [
    { label: "FY2024E Revenue", value: fmtM(isl.totalRevenue[fy24Idx]), target: "$900M", status: getStatus(isl.totalRevenue[fy24Idx], 900, "up", 10), formula: "IS Total Revenue", link: "3-Statement tab" },
    { label: "EBITDA Margin", value: fmtPct(k.ebitdaMarginPct[fy24Idx]), target: "26%", status: getStatus(k.ebitdaMarginPct[fy24Idx], 26, "up", 5), formula: "EBITDA / Revenue", link: "3-Statement tab" },
    { label: "Free Cash Flow", value: fmtM(k.freeCashFlow[fy24Idx]), target: "$100M", status: getStatus(k.freeCashFlow[fy24Idx], 100, "up", 15), formula: "CFO - Capex", link: "3-Statement tab" },
    { label: "Debt / EBITDA", value: fmtX(k.debtToEbitda[fy24Idx]), target: "2.0x", status: getStatus(k.debtToEbitda[fy24Idx], 2.0, "down", 10), formula: "Total Debt / EBITDA", link: "3-Statement tab" },
    { label: "Current Ratio", value: fmtX(k.currentRatio[fy24Idx]), target: "2.0x", status: getStatus(k.currentRatio[fy24Idx], 2.0, "up", 10), formula: "CA / CL", link: "3-Statement tab" },
    { label: "Return on Equity", value: fmtPct(k.roe[fy24Idx]), target: "18%", status: getStatus(k.roe[fy24Idx], 18, "up", 10), formula: "NI / Total Equity", link: "3-Statement tab" },
  ];

  const trendRows = [
    { label: "Revenue ($M)", values: isl.totalRevenue, fmt: fmtM, trend: "up", source: "IS Total Revenue" },
    { label: "Revenue Growth %", values: k.revenueGrowthPct, fmt: fmtPct, trend: "up", source: "Rev[t]/Rev[t-1]-1" },
    { label: "EBITDA ($M)", values: isl.ebitda, fmt: fmtM, trend: "up", source: "GP - OpEx" },
    { label: "EBITDA Margin %", values: k.ebitdaMarginPct, fmt: fmtPct, trend: "up", source: "EBITDA/Revenue" },
    { label: "Net Income ($M)", values: isl.netIncome, fmt: fmtM, trend: "up", source: "EBT - Tax" },
    { label: "Net Margin %", values: k.netMarginPct, fmt: fmtPct, trend: "up", source: "NI/Revenue" },
    { label: "Total Assets ($M)", values: bs.totalAssets, fmt: fmtM, trend: "up", source: "BS Total Assets" },
    { label: "Total Debt ($M)", values: yrs.map((_: any, i: number) => totalDebt(i)), fmt: fmtM, trend: "down", source: "ST+LT Debt" },
    { label: "Debt / EBITDA (x)", values: k.debtToEbitda, fmt: fmtX, trend: "down", source: "Debt/EBITDA" },
    { label: "ROE %", values: k.roe, fmt: fmtPct, trend: "up", source: "NI/Equity" },
    { label: "ROA %", values: k.roa, fmt: fmtPct, trend: "up", source: "NI/Assets" },
    { label: "Current Ratio (x)", values: k.currentRatio, fmt: fmtX, trend: "up", source: "CA/CL" },
    { label: "FCF ($M)", values: k.freeCashFlow, fmt: fmtM, trend: "up", source: "CFO-Capex" },
  ];

  const maxRev = Math.max(...isl.totalRevenue);
  const maxEbitda = Math.max(...isl.ebitda);
  const maxDebtEbitda = Math.max(...k.debtToEbitda);
  const maxNI = Math.max(...isl.netIncome);

  return (
    <div className="space-y-4">
      <Card className="border-l-4 border-l-emerald-500 bg-emerald-500/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><BarChart3 className="size-5 text-emerald-600" /> Board Pack Dashboard</CardTitle>
          <CardDescription>Executive KPI Summary - {data.meta.entity} - KPIs vs target with traffic-light status</CardDescription>
        </CardHeader>
        <CardContent><p className="text-xs text-muted-foreground">All KPIs linked from the 3-Statement Model. Modify any assumption to see impact here.</p></CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        {kpiCards.map((kpi, i) => (
          <Card key={i} className={cn("border-l-4", kpi.status === "On Plan" ? "border-l-emerald-500" : kpi.status === "Watch" ? "border-l-amber-500" : "border-l-rose-500")}>
            <CardContent className="py-3">
              <div className="text-[10px] uppercase text-muted-foreground">{kpi.label}</div>
              <div className="text-xl font-bold mt-0.5">{kpi.value}</div>
              <div className="text-[9px] text-muted-foreground">Target: {kpi.target}</div>
              <Badge variant="outline" className={cn("text-[9px] mt-1", statusColors[kpi.status])}>{kpi.status}</Badge>
              <div className="text-[8px] text-muted-foreground mt-1 italic">{kpi.formula}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">KPI Trend - 8 Year Historical + Projection</CardTitle><CardDescription>FY2020A-FY2027E - All linked from 3-Statement Model</CardDescription></CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[11px]">
              <thead className="bg-emerald-700 text-white"><tr>
                <th className="px-2 py-1.5 text-left font-semibold sticky left-0 bg-emerald-700">KPI</th>
                {yrs.map((y: string) => <th key={y} className="px-2 py-1.5 text-right font-mono">{y}</th>)}
                <th className="px-2 py-1.5 text-center font-semibold">Trend</th>
                <th className="px-2 py-1.5 text-left font-semibold">Source</th>
              </tr></thead>
              <tbody>
                {trendRows.map((row, i) => {
                  const isUp = row.trend === "up";
                  const improving = isUp ? row.values[row.values.length-1] > row.values[0] : row.values[row.values.length-1] < row.values[0];
                  return (
                    <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                      <td className="px-2 py-1.5 font-medium sticky left-0 bg-inherit whitespace-nowrap">{row.label}</td>
                      {row.values.map((v: number, vi: number) => (
                        <td key={vi} className={cn("px-2 py-1.5 text-right font-mono", vi === fy24Idx && "bg-emerald-500/10 font-bold", vi > fy24Idx && "text-muted-foreground italic")}>{row.fmt(v)}</td>
                      ))}
                      <td className="px-2 py-1.5 text-center"><span className={cn("text-sm", improving ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>{isUp ? "Up" : "Down"}</span></td>
                      <td className="px-2 py-1.5 text-[9px] text-muted-foreground italic">{row.source}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Revenue, EBITDA & Net Income Trend ($M)</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { label: "Revenue", data: isl.totalRevenue, max: maxRev, color: "bg-blue-500", textCls: "text-blue-700 dark:text-blue-300" },
              { label: "EBITDA", data: isl.ebitda, max: maxEbitda, color: "bg-emerald-500", textCls: "text-emerald-700 dark:text-emerald-300" },
              { label: "Net Income", data: isl.netIncome, max: maxNI, color: "bg-violet-500", textCls: "text-violet-700 dark:text-violet-300" },
            ].map((chart, ci) => (
              <div key={ci}>
                <div className={cn("text-xs font-semibold mb-1", chart.textCls)}>{chart.label} ($M)</div>
                <div className="flex items-end gap-2 h-24">
                  {chart.data.map((v: number, i: number) => (
                    <div key={i} className="flex-1 flex flex-col items-center">
                      <div className="text-[8px] font-mono mb-0.5">{Math.round(v)}</div>
                      <div className={cn("w-full rounded-t", chart.color)} style={{ height: `${(v / chart.max) * 100}%`, minHeight: "4px" }} />
                      <div className="text-[8px] text-muted-foreground mt-0.5">{yrs[i].slice(2, 6)}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-amber-500">
        <CardHeader><CardTitle className="text-base">Leverage Trajectory - Debt / EBITDA (x)</CardTitle><CardDescription>Target: less than 3.0x - Deleveraging from 3.00x to 1.14x</CardDescription></CardHeader>
        <CardContent>
          <div className="flex items-end gap-2 h-24 mb-3">
            {k.debtToEbitda.map((d: number, i: number) => (
              <div key={i} className="flex-1 flex flex-col items-center">
                <div className="text-[9px] font-mono mb-0.5 font-bold">{d}x</div>
                <div className={cn("w-full rounded-t", d > 3.0 ? "bg-rose-500" : d > 2.0 ? "bg-amber-500" : "bg-emerald-500")} style={{ height: `${(d / maxDebtEbitda) * 100}%`, minHeight: "4px" }} />
                <div className="text-[8px] text-muted-foreground mt-0.5">{yrs[i].slice(2, 6)}</div>
              </div>
            ))}
          </div>
          <div className="flex gap-3 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1"><div className="size-2 rounded bg-rose-500" /> above 3.0x</span>
            <span className="flex items-center gap-1"><div className="size-2 rounded bg-amber-500" /> 2.0-3.0x</span>
            <span className="flex items-center gap-1"><div className="size-2 rounded bg-emerald-500" /> below 2.0x</span>
          </div>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-blue-500">
        <CardHeader><CardTitle className="text-base">Data Linkage - Board Pack from 3-Statement Model</CardTitle><CardDescription>All KPIs computed from 3-Statement Model. No manual entry.</CardDescription></CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2 text-xs">
            <div className="rounded border p-2">
              <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">IS Links</div>
              <div className="text-muted-foreground text-[10px] space-y-0.5">
                <div>Revenue: isl.totalRevenue[i]</div>
                <div>EBITDA: isl.ebitda[i]</div>
                <div>Net Income: isl.netIncome[i]</div>
                <div>EBITDA Margin: k.ebitdaMarginPct[i]</div>
              </div>
            </div>
            <div className="rounded border p-2">
              <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">BS Links</div>
              <div className="text-muted-foreground text-[10px] space-y-0.5">
                <div>Total Assets: bs.totalAssets[i]</div>
                <div>Total Debt: shortTermDebt + longTermDebt</div>
                <div>Current Ratio: k.currentRatio[i]</div>
                <div>ROE: k.roe[i]</div>
              </div>
            </div>
            <div className="rounded border p-2">
              <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">CF Links</div>
              <div className="text-muted-foreground text-[10px] space-y-0.5">
                <div>FCF: k.freeCashFlow[i] = CFO - Capex</div>
                <div>CFO: cf.cashFromOps[i] = NI + D&A + WC</div>
              </div>
            </div>
            <div className="rounded border p-2">
              <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">Cross-Statement KPIs</div>
              <div className="text-muted-foreground text-[10px] space-y-0.5">
                <div>Debt/EBITDA: Total Debt (BS) / EBITDA (IS)</div>
                <div>Revenue Growth: Rev[t]/Rev[t-1]-1</div>
                <div>Interest Coverage: EBITDA / Int Exp</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================
// LRP — 10-Year Long-Range Plan
// ============================================================
function LRPSection() {
  const [data, setData] = React.useState<any>(null);

  React.useEffect(() => {
    fetch("/api/lrp")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch(() => {});
  }, []);

  if (!data) return null;

  const yrs = data.years;
  const fmtM = (n: number) => `$${n.toFixed(1)}M`;
  const fmtX = (n: number) => `${n}x`;
  const fmtPct = (n: number) => `${n}%`;

  return (
    <div className="space-y-4">
      <Card className="border-l-4 border-l-emerald-500 bg-emerald-500/5">
        <CardHeader>
          <CardTitle className="text-base">{data.meta.title}</CardTitle>
          <CardDescription>{data.meta.subtitle}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground">{data.meta.description}</p>
          <p className="text-[10px] text-muted-foreground mt-1 italic">{data.meta.seedNote}</p>
        </CardContent>
      </Card>

      {/* LRP Assumptions Table */}
      <Card>
        <CardHeader><CardTitle className="text-base">LRP Assumptions — Strategic Driver Inputs (12 drivers × 10 years)</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[10px]">
              <thead className="bg-blue-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold sticky left-0 bg-blue-700">Driver</th>
                  {yrs.map((y: string) => <th key={y} className="px-1.5 py-1.5 text-right font-mono">{y}</th>)}
                </tr>
              </thead>
              <tbody>
                {data.assumptions.map((a: any, i: number) => (
                  <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1.5 font-medium text-blue-700 dark:text-blue-300 sticky left-0 bg-inherit">{a.driver}</td>
                    {a.values.map((v: number, vi: number) => (
                      <td key={vi} className="px-1.5 py-1.5 text-right font-mono text-[9px]">{v.toFixed(1)}%</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Seed values */}
      <Card>
        <CardHeader><CardTitle className="text-base">Seed Values — FY2024E (from 3-Statement Model)</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6 text-xs">
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Lending Rev</div><div className="font-mono font-bold">{fmtM(data.seed.lending)}</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Construction Rev</div><div className="font-mono font-bold">{fmtM(data.seed.construction)}</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Real Estate NOI</div><div className="font-mono font-bold">{fmtM(data.seed.realEstate)}</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">AI SaaS Rev</div><div className="font-mono font-bold">{fmtM(data.seed.aiSaaS)}</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Beg Total Debt</div><div className="font-mono font-bold">{fmtM(data.seed.totalDebt)}</div></div>
            <div className="rounded border p-2"><div className="text-[10px] text-muted-foreground">Beg Total Equity</div><div className="font-mono font-bold">{fmtM(data.seed.totalEquity)}</div></div>
          </div>
        </CardContent>
      </Card>

      {/* Projections Table — 24 rows × 10 years */}
      <Card>
        <CardHeader><CardTitle className="text-base">Projections — FY2025E to FY2034E ($M) — 24 line items × 10 years</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[9px]">
              <thead className="bg-emerald-700 text-white">
                <tr>
                  <th className="px-1.5 py-1.5 text-left font-semibold sticky left-0 bg-emerald-700">Line Item</th>
                  {yrs.map((y: string) => <th key={y} className="px-1 py-1.5 text-right font-mono">{y.slice(2)}</th>)}
                </tr>
              </thead>
              <tbody>
                {data.projections.map((r: any, i: number) => (
                  <tr key={i} className={cn("border-t",
                    r.isTotal && "bg-emerald-500/15 font-bold",
                    r.isSegment && "bg-muted/30",
                    !r.isTotal && !r.isSegment && i % 2 === 0 && "bg-muted/20"
                  )}>
                    <td className="px-1.5 py-1 font-medium sticky left-0 bg-inherit whitespace-nowrap">{r.isTotal ? <strong>{r.label}</strong> : r.label}</td>
                    {r.values.map((v: number, vi: number) => (
                      <td key={vi} className={cn("px-1 py-1 text-right font-mono",
                        r.isRatio && v < 2 ? "text-emerald-700 dark:text-emerald-300 font-bold" : "",
                        r.isPct && v > 20 && "text-emerald-700 dark:text-emerald-300 font-bold"
                      )}>
                        {r.isRatio ? fmtX(v) : r.isPct ? fmtPct(v) : fmtM(v)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Strategic Decision Points */}
      <Card className="border-l-4 border-l-amber-500">
        <CardHeader>
          <CardTitle className="text-base">Strategic Decision Points — Capital Allocation Framework</CardTitle>
          <CardDescription>5 decision triggers across 10-year horizon</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-[10px]">
              <thead className="bg-amber-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold">Decision</th>
                  <th className="px-2 py-1.5 text-center font-semibold">Trigger Year</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Threshold</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Current Trajectory</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {data.strategicDecisions.map((d: any, i: number) => (
                  <tr key={i} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1.5 font-semibold">{d.decision}</td>
                    <td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[9px] border-amber-500/30 text-amber-700 dark:text-amber-300">{d.triggerYear}</Badge></td>
                    <td className="px-2 py-1.5 text-[9px]">{d.threshold}</td>
                    <td className="px-2 py-1.5 text-[9px] text-muted-foreground italic">{d.currentTrajectory}</td>
                    <td className="px-2 py-1.5 text-[9px]">{d.action}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
