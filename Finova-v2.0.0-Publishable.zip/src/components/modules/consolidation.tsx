"use client";

import * as React from "react";
import { Layers, RefreshCw, CheckCircle2, FileText, FileSpreadsheet, Download, Building2 } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Entity = {
  id: string; name: string; industry: string; country: string; currency: string;
  revenue: number; expenses: number; netProfit: number;
};

type ConsolidationData = {
  entityCount: number;
  entities: Entity[];
  grossRevenue: number;
  grossExpense: number;
  grossNetProfit: number;
  intercompanyRevenue: number;
  intercompanyExpense: number;
  elimination: number;
  consolidated: {
    revenue: number; expenses: number; netProfit: number; margin: number;
    income: Array<{ category: string; amount: number }>;
    expense: Array<{ category: string; amount: number }>;
  };
  standard: string;
  note: string;
};

export function ConsolidationModule() {
  const companies = useAppStore((s) => s.companies);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [selectedIds, setSelectedIds] = React.useState<string[]>([]);
  const [data, setData] = React.useState<ConsolidationData | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [standard, setStandard] = React.useState("IFRS");

  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";

  // Pre-select the first 3 companies
  React.useEffect(() => {
    if (selectedIds.length === 0 && companies.length >= 2) {
      setSelectedIds(companies.slice(0, 3).map((c) => c.id));
    }
  }, [companies]);

  function toggle(id: string) {
    setSelectedIds((arr) => (arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]));
  }

  function consolidate() {
    if (selectedIds.length < 2) { toast.error("Select at least 2 companies to consolidate"); return; }
    setLoading(true);
    setData(null);
    fetch(`/api/consolidation?companyIds=${selectedIds.join(",")}`)
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }

  async function downloadExcel() {
    if (!data) return;
    const XLSX = await import("xlsx");
    const ws1 = XLSX.utils.json_to_sheet(data.entities.map(e => ({ Entity: e.name, Industry: e.industry, Country: e.country, Currency: e.currency, Revenue: e.revenue, Expenses: e.expenses, NetProfit: e.netProfit })));
    const ws2 = XLSX.utils.json_to_sheet([
      { Line: "Gross revenue (pre-elimination)", Amount: data.grossRevenue },
      { Line: "Gross expenses (pre-elimination)", Amount: data.grossExpense },
      { Line: "Gross net profit", Amount: data.grossNetProfit },
      { Line: "Intercompany revenue (eliminated)", Amount: -data.elimination },
      { Line: "Intercompany expense (eliminated)", Amount: -data.elimination },
      { Line: "Consolidated revenue", Amount: data.consolidated.revenue },
      { Line: "Consolidated expenses", Amount: data.consolidated.expenses },
      { Line: "Consolidated net profit", Amount: data.consolidated.netProfit },
      { Line: "Consolidated net margin %", Amount: data.consolidated.margin },
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws1, "Group Entities");
    XLSX.utils.book_append_sheet(wb, ws2, "Consolidated P&L");
    XLSX.writeFile(wb, `consolidation_${Date.now()}.xlsx`);
    toast.success("Excel downloaded");
  }

  function downloadPdf() {
    if (!data) return;
    toast.info("Use the Reports tab and switch the standard to view the consolidated PDF");
  }

  function fmt(n: number) { return `${sym}${Math.round(Math.abs(n)).toLocaleString()}`; }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Consolidation</h1>
          <p className="text-sm text-muted-foreground">
            Group reporting under <strong>IFRS 10</strong> and <strong>US GAAP ASC 810</strong>. Pick multiple entities, eliminate intercompany transactions, and produce consolidated P&L, Balance Sheet, Cash Flow and Equity.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={standard} onValueChange={setStandard}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="IFRS">IFRS 10</SelectItem>
              <SelectItem value="US-GAAP">US GAAP ASC 810</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Entity picker */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Group entities ({selectedIds.length} selected)</CardTitle>
          <CardDescription>Select at least 2 companies to consolidate</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
            {companies.map((c) => {
              const checked = selectedIds.includes(c.id);
              return (
                <label key={c.id} className={cn("flex items-start gap-3 rounded-md border p-3 cursor-pointer transition-colors", checked ? "border-emerald-500/40 bg-emerald-500/5" : "hover:bg-muted/40")}>
                  <Checkbox checked={checked} onCheckedChange={() => toggle(c.id)} className="mt-1" />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium truncate">{c.name}</div>
                    <div className="mt-0.5 text-[11px] text-muted-foreground">
                      {c.country} · {c.industry} · {c.currency}
                    </div>
                  </div>
                </label>
              );
            })}
          </div>
          <div className="mt-4 flex gap-2">
            <Button onClick={consolidate} disabled={loading || selectedIds.length < 2}>
              <Layers className="size-3.5" /> {loading ? "Consolidating…" : "Run consolidation"}
            </Button>
            <Button variant="outline" onClick={() => setSelectedIds([])} disabled={selectedIds.length === 0}>Clear</Button>
            <Button variant="outline" onClick={() => setSelectedIds(companies.map((c) => c.id))}>Select all</Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {loading && <Skeleton className="h-96 w-full" />}
      {!loading && data && (
        <>
          {/* Summary strip */}
          <div className="grid gap-3 md:grid-cols-4">
            <Card><CardContent className="py-3">
              <div className="text-xs text-muted-foreground">Group entities</div>
              <div className="text-xl font-bold">{data.entityCount}</div>
            </CardContent></Card>
            <Card><CardContent className="py-3">
              <div className="text-xs text-muted-foreground">Consolidated revenue</div>
              <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{fmt(data.consolidated.revenue)}</div>
            </CardContent></Card>
            <Card><CardContent className="py-3">
              <div className="text-xs text-muted-foreground">Consolidated net profit</div>
              <div className={cn("text-xl font-bold", data.consolidated.netProfit >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>{fmt(data.consolidated.netProfit)}</div>
            </CardContent></Card>
            <Card><CardContent className="py-3">
              <div className="text-xs text-muted-foreground">Intercompany eliminated</div>
              <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{fmt(data.elimination)}</div>
            </CardContent></Card>
          </div>

          {/* Group entity breakdown */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base">Group entities — standalone P&L</CardTitle>
                <CardDescription>Pre-elimination revenue and expenses for each group company</CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                    <tr className="text-left">
                      <th className="px-3 py-2 font-semibold">Entity</th>
                      <th className="px-3 py-2 font-semibold">Industry</th>
                      <th className="px-3 py-2 font-semibold">Country</th>
                      <th className="px-3 py-2 text-right font-semibold">Revenue</th>
                      <th className="px-3 py-2 text-right font-semibold">Expenses</th>
                      <th className="px-3 py-2 text-right font-semibold">Net Profit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.entities.map((e, i) => (
                      <tr key={e.id} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                        <td className="px-3 py-2 font-medium">{e.name}</td>
                        <td className="px-3 py-2 text-xs">{e.industry}</td>
                        <td className="px-3 py-2 text-xs">{e.country}</td>
                        <td className="px-3 py-2 text-right">{fmt(e.revenue)}</td>
                        <td className="px-3 py-2 text-right">{fmt(e.expenses)}</td>
                        <td className={cn("px-3 py-2 text-right font-medium", e.netProfit >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>{fmt(e.netProfit)}</td>
                      </tr>
                    ))}
                    <tr className="border-t border-t-2 bg-emerald-500/15 font-bold">
                      <td className="px-3 py-2" colSpan={3}>TOTAL (pre-elimination)</td>
                      <td className="px-3 py-2 text-right">{fmt(data.grossRevenue)}</td>
                      <td className="px-3 py-2 text-right">{fmt(data.grossExpense)}</td>
                      <td className="px-3 py-2 text-right">{fmt(data.grossNetProfit)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Eliminations */}
          <Card className="border-l-4 border-l-amber-500">
            <CardHeader>
              <CardTitle className="text-base">Intercompany Eliminations</CardTitle>
              <CardDescription>{data.standard}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-3">
                <div className="rounded-md border p-3">
                  <div className="text-xs text-muted-foreground">Intercompany revenue</div>
                  <div className="text-lg font-bold">{fmt(data.intercompanyRevenue)}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-xs text-muted-foreground">Intercompany expense</div>
                  <div className="text-lg font-bold">{fmt(data.intercompanyExpense)}</div>
                </div>
                <div className="rounded-md border bg-amber-500/10 p-3">
                  <div className="text-xs text-muted-foreground">Eliminated (Dr / Cr)</div>
                  <div className="text-lg font-bold text-amber-600 dark:text-amber-400">{fmt(data.elimination)}</div>
                </div>
              </div>
              <div className="mt-3 text-xs text-muted-foreground">{data.note}</div>
            </CardContent>
          </Card>

          {/* Consolidated P&L */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Consolidated Profit & Loss Statement</CardTitle>
                <CardDescription>After intercompany elimination · {standard} · {sym}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={downloadExcel}><FileSpreadsheet className="size-3.5" /> Excel</Button>
                <Button size="sm" onClick={downloadPdf}><FileText className="size-3.5" /> PDF</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-emerald-600 text-white">
                    <tr className="text-left">
                      <th className="px-3 py-2 font-semibold">Line item</th>
                      <th className="px-3 py-2 text-right font-semibold">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="bg-emerald-500/10 font-semibold text-emerald-700 dark:text-emerald-300">
                      <td className="px-3 py-2" colSpan={2}>REVENUE</td>
                    </tr>
                    {data.consolidated.income.map((r, i) => (
                      <tr key={r.category} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                        <td className="px-3 py-1.5 pl-6">{r.category}</td>
                        <td className="px-3 py-1.5 text-right">{fmt(r.amount)}</td>
                      </tr>
                    ))}
                    <tr className="border-t border-t-2 bg-emerald-500/15 font-bold">
                      <td className="px-3 py-2">Total consolidated revenue</td>
                      <td className="px-3 py-2 text-right">{fmt(data.consolidated.revenue)}</td>
                    </tr>
                    <tr className="bg-rose-500/10 font-semibold text-rose-700 dark:text-rose-300">
                      <td className="px-3 py-2" colSpan={2}>EXPENSES</td>
                    </tr>
                    {data.consolidated.expense.map((r, i) => (
                      <tr key={r.category} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                        <td className="px-3 py-1.5 pl-6">{r.category}</td>
                        <td className="px-3 py-1.5 text-right">{fmt(r.amount)}</td>
                      </tr>
                    ))}
                    <tr className="border-t border-t-2 bg-rose-500/15 font-bold">
                      <td className="px-3 py-2">Total consolidated expenses</td>
                      <td className="px-3 py-2 text-right">{fmt(data.consolidated.expenses)}</td>
                    </tr>
                    <tr className="border-t-2 bg-emerald-600 font-bold text-white">
                      <td className="px-3 py-2">CONSOLIDATED NET PROFIT</td>
                      <td className="px-3 py-2 text-right">{fmt(data.consolidated.netProfit)}</td>
                    </tr>
                    <tr className="bg-muted/40">
                      <td className="px-3 py-2 text-xs text-muted-foreground">Net margin</td>
                      <td className="px-3 py-2 text-right text-xs">{data.consolidated.margin.toFixed(2)}%</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Commentary */}
              <div className="mt-4 rounded-md bg-muted/30 p-4">
                <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Commentary</div>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  The consolidated group comprises <strong>{data.entityCount}</strong> entities across multiple jurisdictions. Gross revenue of <strong>{fmt(data.grossRevenue)}</strong> was reduced by <strong>{fmt(data.elimination)}</strong> of intercompany transactions eliminated in accordance with <strong>{data.standard}</strong>. The resulting consolidated revenue of <strong>{fmt(data.consolidated.revenue)}</strong> reflects only third-party (external) transactions. Consolidated net profit of <strong>{fmt(data.consolidated.netProfit)}</strong> represents a net margin of <strong>{data.consolidated.margin.toFixed(2)}%</strong>. Non-controlling interests and goodwill arising from acquisitions should be disclosed separately in the consolidated balance sheet and equity statement.
                </p>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
