"use client";

import * as React from "react";
import { Search, Zap, Globe, Cpu, Code, FileText, Calculator, Landmark, Receipt, BookOpen, TrendingUp, Languages, CheckCircle2, Lock, DollarSign } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { ConceptsAppliedPanel } from "@/components/concepts-applied-panel";

const USE_CASE_ICONS: Record<string, React.ElementType> = {
  "OCR & Document Processing": FileText,
  "Invoicing & Billing": Receipt,
  "Journal Entries & Accounting": BookOpen,
  "Financial Judgement": Calculator,
  "Complex Reasoning": Cpu,
  "Corporate Finance": TrendingUp,
  "Tax & Compliance": Landmark,
  "Coding & Development": Code,
  "General Finance": DollarSign,
  "Multi-language": Languages,
};

const USE_CASE_COLORS: Record<string, string> = {
  "OCR & Document Processing": "border-blue-500/30 text-blue-700 dark:text-blue-300 bg-blue-500/10",
  "Invoicing & Billing": "border-emerald-500/30 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10",
  "Journal Entries & Accounting": "border-violet-500/30 text-violet-700 dark:text-violet-300 bg-violet-500/10",
  "Financial Judgement": "border-amber-500/30 text-amber-700 dark:text-amber-300 bg-amber-500/10",
  "Complex Reasoning": "border-rose-500/30 text-rose-700 dark:text-rose-300 bg-rose-500/10",
  "Corporate Finance": "border-teal-500/30 text-teal-700 dark:text-teal-300 bg-teal-500/10",
  "Tax & Compliance": "border-orange-500/30 text-orange-700 dark:text-orange-300 bg-orange-500/10",
  "Coding & Development": "border-cyan-500/30 text-cyan-700 dark:text-cyan-300 bg-cyan-500/10",
  "General Finance": "border-slate-500/30 text-slate-700 dark:text-slate-300 bg-slate-500/10",
  "Multi-language": "border-pink-500/30 text-pink-700 dark:text-pink-300 bg-pink-500/10",
};

export function LLMHubModule() {
  const [data, setData] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [activeUseCase, setActiveUseCase] = React.useState<string>("All");
  const [showFreeOnly, setShowFreeOnly] = React.useState(false);

  React.useEffect(() => {
    fetch("/api/llm-hub")
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setData(d); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-6"><Skeleton className="h-96 w-full" /></div>;
  if (!data) return <div className="p-6 text-sm text-muted-foreground">No LLM data available.</div>;

  const stats = data.stats;
  const allModels = data.providers.flatMap((p: any) => p.models.map((m: any) => ({ ...m, providerName: p.name, providerId: p.id, apiKeyUrl: p.apiKeyUrl, apiBaseUrl: p.apiBaseUrl, notes: p.notes })));

  const filteredModels = allModels.filter((m: any) => {
    if (showFreeOnly && !m.freeTier) return false;
    if (activeUseCase !== "All" && !m.useCases.includes(activeUseCase)) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return m.name.toLowerCase().includes(q) || m.providerName.toLowerCase().includes(q) || m.strengths.toLowerCase().includes(q) || m.useCases.some((uc: string) => uc.toLowerCase().includes(q));
    }
    return true;
  });

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Zap className="size-6 text-violet-600" />
          LLM Hub — Connect to {stats.totalModels * 15}+ AI Models
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          {data.meta.description}
        </p>
      </div>

      {/* Stats strip */}
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-6">
        <Card className="border-l-4 border-l-violet-500"><CardContent className="py-3"><div className="text-[10px] uppercase text-muted-foreground">Providers</div><div className="text-xl font-bold">{stats.totalProviders}</div></CardContent></Card>
        <Card className="border-l-4 border-l-emerald-500"><CardContent className="py-3"><div className="text-[10px] uppercase text-muted-foreground">Models Listed</div><div className="text-xl font-bold">{stats.totalModels}</div></CardContent></Card>
        <Card className="border-l-4 border-l-blue-500"><CardContent className="py-3"><div className="text-[10px] uppercase text-muted-foreground">FREE Models</div><div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{stats.freeModels}</div></CardContent></Card>
        <Card className="border-l-4 border-l-amber-500"><CardContent className="py-3"><div className="text-[10px] uppercase text-muted-foreground">Open Source</div><div className="text-xl font-bold">{stats.openSourceModels}</div></CardContent></Card>
        <Card className="border-l-4 border-l-rose-500"><CardContent className="py-3"><div className="text-[10px] uppercase text-muted-foreground">Use Cases</div><div className="text-xl font-bold">{stats.useCasesCovered.length}</div></CardContent></Card>
        <Card className="border-l-4 border-l-teal-500"><CardContent className="py-3"><div className="text-[10px] uppercase text-muted-foreground">Free Providers</div><div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{data.providers.filter((p: any) => p.freeTierAvailable).length}</div></CardContent></Card>
      </div>

      {/* Search + filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
          <Input
            placeholder="Search models, providers, use cases..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-7"
          />
        </div>
        <Button
          variant={showFreeOnly ? "default" : "outline"}
          size="sm"
          onClick={() => setShowFreeOnly(!showFreeOnly)}
        >
          <CheckCircle2 className="size-3.5 mr-1" />
          Free Only ({stats.freeModels})
        </Button>
      </div>

      {/* Use case filter chips */}
      <div className="flex flex-wrap gap-1.5">
        <button onClick={() => setActiveUseCase("All")} className={cn("rounded-md border px-2.5 py-1 text-xs font-medium transition", activeUseCase === "All" ? "border-violet-500 bg-violet-500 text-white" : "bg-muted/30 hover:bg-muted/50")}>
          All Use Cases ({allModels.length})
        </button>
        {stats.useCasesCovered.map((uc: string) => {
          const Icon = USE_CASE_ICONS[uc] || Globe;
          const count = allModels.filter((m: any) => m.useCases.includes(uc)).length;
          return (
            <button
              key={uc}
              onClick={() => setActiveUseCase(uc)}
              className={cn(
                "rounded-md border px-2.5 py-1 text-xs font-medium transition flex items-center gap-1.5",
                activeUseCase === uc ? "border-violet-500 bg-violet-500 text-white" : cn(USE_CASE_COLORS[uc], "hover:opacity-80")
              )}
            >
              <Icon className="size-3" />
              {uc.split(" ")[0]} ({count})
            </button>
          );
        })}
      </div>

      {/* Active use case description */}
      {activeUseCase !== "All" && (
        <div className="rounded-md border-l-4 border-l-violet-500 bg-violet-500/5 p-3 text-xs text-muted-foreground">
          <strong className="text-violet-700 dark:text-violet-300">{activeUseCase}:</strong> {data.useCaseDescriptions[activeUseCase]}
        </div>
      )}

      {/* Model cards grid */}
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {filteredModels.map((m: any, i: number) => {
          const Icon = USE_CASE_ICONS[m.useCases[0]] || Cpu;
          return (
            <Card key={i} className={cn("border-l-4", m.freeTier ? "border-l-emerald-500" : "border-l-slate-400")}>
              <CardContent className="p-4 space-y-2">
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-sm font-bold">{m.name}</div>
                    <div className="text-[10px] text-muted-foreground">{m.providerName}</div>
                  </div>
                  <div className="flex flex-col gap-1 items-end">
                    {m.freeTier && <Badge variant="outline" className="text-[9px] border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10">FREE</Badge>}
                    {m.openSource && <Badge variant="outline" className="text-[9px] border-blue-500/40 text-blue-700 dark:text-blue-300 bg-blue-500/10">Open Source</Badge>}
                  </div>
                </div>

                {/* Use cases */}
                <div className="flex flex-wrap gap-1">
                  {m.useCases.map((uc: string) => {
                    const UCIcon = USE_CASE_ICONS[uc] || Globe;
                    return (
                      <Badge key={uc} variant="outline" className={cn("text-[8px]", USE_CASE_COLORS[uc])}>
                        <UCIcon className="size-2 mr-0.5" />
                        {uc.split(" ")[0]}
                      </Badge>
                    );
                  })}
                </div>

                {/* Strengths */}
                <div className="text-[10px] text-muted-foreground">{m.strengths}</div>

                {/* Specs */}
                <div className="grid grid-cols-3 gap-1 text-[9px]">
                  <div className="rounded bg-muted/30 p-1 text-center"><div className="text-muted-foreground">Context</div><div className="font-mono font-bold">{m.contextWindow}</div></div>
                  <div className="rounded bg-muted/30 p-1 text-center"><div className="text-muted-foreground">Input</div><div className="font-mono font-bold">{m.inputPrice}</div></div>
                  <div className="rounded bg-muted/30 p-1 text-center"><div className="text-muted-foreground">Output</div><div className="font-mono font-bold">{m.outputPrice}</div></div>
                </div>

                {/* API config */}
                <div className="text-[8px] text-muted-foreground border-t pt-1.5 space-y-0.5">
                  <div><span className="font-mono text-blue-600 dark:text-blue-400">API:</span> {m.apiBaseUrl}</div>
                  <div><span className="font-mono text-blue-600 dark:text-blue-400">Key:</span> {m.apiKeyEnv} <a href={m.apiKeyUrl} target="_blank" rel="noopener" className="text-violet-600 hover:underline ml-1">Get key →</a></div>
                </div>

                {/* Connect button */}
                <Button variant="outline" size="sm" className="w-full text-[10px]" onClick={() => {
                  // Save to localStorage for the agent chat to use
                  localStorage.setItem("llm_provider", m.providerId);
                  localStorage.setItem("llm_model", m.id);
                  localStorage.setItem("llm_endpoint", m.apiEndpoint);
                }}>
                  <Zap className="size-3 mr-1" />
                  Connect {m.name}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredModels.length === 0 && (
        <div className="text-center py-12 text-sm text-muted-foreground">
          No models match your filters. Try clearing the search or changing use case.
        </div>
      )}

      {/* Provider comparison table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Provider Comparison — All {stats.totalProviders} Providers</CardTitle>
          <CardDescription>Free tier availability, model count, and key notes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="bg-violet-700 text-white">
                <tr>
                  <th className="px-2 py-1.5 text-left font-semibold">Provider</th>
                  <th className="px-2 py-1.5 text-center font-semibold">Free Tier</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Models</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Free Models</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Where to Get Key</th>
                  <th className="px-2 py-1.5 text-left font-semibold">Notes</th>
                </tr>
              </thead>
              <tbody>
                {data.providers.map((p: any, i: number) => (
                  <tr key={p.id} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                    <td className="px-2 py-1.5 font-medium">{p.name}</td>
                    <td className="px-2 py-1.5 text-center">
                      {p.freeTierAvailable ? <Badge variant="outline" className="text-[9px] border-emerald-500/40 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10">Yes</Badge> : <span className="text-[9px] text-muted-foreground">No</span>}
                    </td>
                    <td className="px-2 py-1.5 text-right font-mono">{p.models.length}</td>
                    <td className="px-2 py-1.5 text-right font-mono text-emerald-700 dark:text-emerald-300">{p.models.filter((m: any) => m.freeTier).length}</td>
                    <td className="px-2 py-1.5"><a href={p.apiKeyUrl} target="_blank" rel="noopener" className="text-blue-600 hover:underline text-[10px]">{p.apiKeyUrl}</a></td>
                    <td className="px-2 py-1.5 text-[9px] text-muted-foreground">{p.notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Integration notes */}
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader>
          <CardTitle className="text-base">How to Connect — Integration Guide</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-xs">
          <div className="rounded border p-3">
            <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">1. Get an API Key</div>
            <div className="text-muted-foreground">Click "Get key" link on any model card above. Most free providers (Google, DeepSeek, Groq, Hugging Face, Cerebras) offer instant key generation with no credit card.</div>
          </div>
          <div className="rounded border p-3">
            <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">2. Set Environment Variable</div>
            <div className="text-muted-foreground">Add the key to your <code className="font-mono bg-muted px-1 rounded">.env</code> file using the env var name shown on each model card (e.g., <code className="font-mono bg-muted px-1 rounded">GOOGLE_AI_API_KEY=your_key</code>).</div>
          </div>
          <div className="rounded border p-3">
            <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">3. Click "Connect" on the Model</div>
            <div className="text-muted-foreground">Finova saves the selected model to localStorage. The AI Agents module (CEO/CFO/Accountant/Tax) will use the connected model for all chat interactions.</div>
          </div>
          <div className="rounded border p-3">
            <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1">4. For Local/Private Models (Ollama)</div>
            <div className="text-muted-foreground">Install <a href="https://ollama.ai" className="text-blue-600 hover:underline">Ollama</a>, run <code className="font-mono bg-muted px-1 rounded">ollama pull llama3.3</code>, then connect. 100% free, private, no API key needed. Best for sensitive financial data.</div>
          </div>
          <div className="rounded border p-3 bg-emerald-500/5">
            <div className="font-semibold text-emerald-700 dark:text-emerald-300 mb-1 flex items-center gap-1"><Lock className="size-3" /> Best Free Setup for Finance</div>
            <div className="text-muted-foreground">
              <strong>OCR + Invoice Processing:</strong> Google Gemini 2.0 Flash (free, 1M context, multimodal)<br/>
              <strong>Journal Entries:</strong> Groq Llama 3.1 8B (free, 800 tok/s)<br/>
              <strong>Complex Reasoning:</strong> DeepSeek R1 (free, matches o1)<br/>
              <strong>Corporate Finance:</strong> Groq Llama 3.3 70B (free, 500 tok/s)<br/>
              <strong>Tax & Compliance:</strong> DeepSeek R1 (free) or Perplexity Sonar (web search)<br/>
              <strong>Coding:</strong> Qwen 2.5 72B via Hugging Face (free)<br/>
              <strong>Private/Sensitive:</strong> Ollama Llama 3.3 70B (local, 100% free)
            </div>
          </div>
        </CardContent>
      </Card>

      <ConceptsAppliedPanel reportName="LLM Hub" />
    </div>
  );
}
