"use client";

import * as React from "react";
import { CreditCard, Plus, RefreshCw, Trash2, Landmark, Wallet, Building2, Lock, Unlock, Snowflake } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type BankAccount = {
  id: string;
  bankName: string;
  accountName: string;
  accountType: string;
  accountNumber: string;
  routingNumber?: string | null;
  currency: string;
  balance: number;
  creditLimit?: number | null;
  availableBalance?: number | null;
  status: string;
  createdAt: string;
};

const TYPE_ICON: Record<string, React.ElementType> = {
  checking: Wallet,
  savings: Landmark,
  credit_card: CreditCard,
  merchant: Building2,
  paypal: CreditCard,
};

const TYPE_COLOR: Record<string, string> = {
  checking: "bg-blue-500/15 text-blue-600 dark:text-blue-400",
  savings: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  credit_card: "bg-violet-500/15 text-violet-600 dark:text-violet-400",
  merchant: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  paypal: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400",
};

const BANKS = ["Chase", "Bank of America", "Wells Fargo", "Citibank", "HSBC", "Barclays", "Lloyds", "NatWest", "Deutsche Bank", "Commerzbank", "BNP Paribas", "Société Générale", "AIB", "Bank of Ireland", "ABN AMRO", "ING", "Santander", "BBVA", "Intesa Sanpaolo", "UniCredit", "Other"];

export function BankAccountsModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [accounts, setAccounts] = React.useState<BankAccount[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [addOpen, setAddOpen] = React.useState(false);

  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";

  function load() {
    setLoading(true);
    fetch(`/api/bank-accounts?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => { if (d.error) throw new Error(d.error); setAccounts(d.bankAccounts); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }
  React.useEffect(() => { load(); }, [activeCompanyId]);

  async function setStatus(acc: BankAccount, status: "active" | "frozen" | "closed") {
    setAccounts((arr) => arr.map((a) => (a.id === acc.id ? { ...a, status } : a)));
    try {
      const res = await fetch("/api/bank-accounts", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: acc.id, status }) });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`${acc.bankName} ${acc.accountNumber} → ${status}`);
    } catch (e: any) {
      toast.error(e.message);
      load();
    }
  }

  async function deleteAcc(acc: BankAccount) {
    setAccounts((arr) => arr.filter((a) => a.id !== acc.id));
    try {
      const res = await fetch("/api/bank-accounts", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: acc.id }) });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success("Account removed");
    } catch (e: any) {
      toast.error(e.message);
      load();
    }
  }

  const totalBalance = accounts.filter((a) => a.accountType !== "credit_card").reduce((s, a) => s + a.balance, 0);
  const totalDebt = accounts.filter((a) => a.accountType === "credit_card").reduce((s, a) => s + Math.abs(Math.min(a.balance, 0)), 0);
  const totalCreditLimit = accounts.filter((a) => a.accountType === "credit_card").reduce((s, a) => s + (a.creditLimit ?? 0), 0);
  const checkingCount = accounts.filter((a) => a.accountType === "checking").length;
  const savingsCount = accounts.filter((a) => a.accountType === "savings").length;
  const creditCount = accounts.filter((a) => a.accountType === "credit_card").length;

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Bank Accounts</h1>
          <p className="text-sm text-muted-foreground">
            Manage multiple banks, checking, savings, and credit cards per client. Account numbers are masked (last 4 only). Connect to Plaid in the Integrations tab for live feeds.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="size-3.5" /> Refresh</Button>
          <Button size="sm" onClick={() => setAddOpen(true)}><Plus className="size-3.5" /> Add Account</Button>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Total cash &amp; bank</div><div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{sym}{totalBalance.toLocaleString()}</div></CardContent></Card>
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Credit card debt</div><div className="text-xl font-bold text-rose-600 dark:text-rose-400">{sym}{totalDebt.toLocaleString()}</div></CardContent></Card>
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Credit limit (total)</div><div className="text-xl font-bold">{sym}{totalCreditLimit.toLocaleString()}</div></CardContent></Card>
        <Card><CardContent className="py-3"><div className="text-xs text-muted-foreground">Accounts</div><div className="text-xl font-bold">{accounts.length}</div><div className="text-[10px] text-muted-foreground">{checkingCount} checking · {savingsCount} savings · {creditCount} cards</div></CardContent></Card>
      </div>

      {/* Account cards */}
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {loading ? (
          Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-40 w-full" />)
        ) : accounts.length === 0 ? (
          <Card className="md:col-span-2 lg:col-span-3">
            <CardContent className="py-12 text-center">
              <CreditCard className="mx-auto size-8 text-muted-foreground" />
              <p className="mt-2 text-sm text-muted-foreground">No bank accounts yet. Click "Add Account" to record checking, savings, credit card, or merchant accounts.</p>
            </CardContent>
          </Card>
        ) : (
          accounts.map((acc) => {
            const Icon = TYPE_ICON[acc.accountType] ?? CreditCard;
            const color = TYPE_COLOR[acc.accountType] ?? "bg-muted text-muted-foreground";
            const isCredit = acc.accountType === "credit_card";
            const isFrozen = acc.status === "frozen";
            const isClosed = acc.status === "closed";
            return (
              <Card key={acc.id} className={cn("relative overflow-hidden", isFrozen && "opacity-75", isClosed && "opacity-50")}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className={cn("flex size-10 items-center justify-center rounded-md", color)}>
                      <Icon className="size-5" />
                    </div>
                    <div className="flex gap-1">
                      {isFrozen && <Badge variant="secondary" className="text-[10px]"><Snowflake className="size-3" /> Frozen</Badge>}
                      {isClosed && <Badge variant="secondary" className="text-[10px]"><Lock className="size-3" /> Closed</Badge>}
                      {acc.status === "active" && <Badge className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">Active</Badge>}
                    </div>
                  </div>
                  <div className="mt-3 text-sm font-semibold">{acc.bankName}</div>
                  <div className="text-xs text-muted-foreground">{acc.accountName}</div>
                  <div className="mt-2 font-mono text-lg tracking-wider">{acc.accountNumber}</div>
                  <div className="mt-2 flex items-end justify-between">
                    <div>
                      <div className="text-[10px] text-muted-foreground uppercase">{isCredit ? "Balance" : "Available"}</div>
                      <div className={cn("text-lg font-bold", isCredit && acc.balance < 0 ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400")}>
                        {sym}{Math.abs(acc.balance).toLocaleString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className="text-[10px] capitalize">{acc.accountType.replace("_", " ")}</Badge>
                      <div className="mt-1 text-[10px] text-muted-foreground">{acc.currency}</div>
                    </div>
                  </div>
                  {isCredit && acc.creditLimit && (
                    <div className="mt-2">
                      <div className="flex justify-between text-[10px] text-muted-foreground">
                        <span>Used {sym}{Math.abs(Math.min(acc.balance, 0)).toLocaleString()}</span>
                        <span>Limit {sym}{acc.creditLimit.toLocaleString()}</span>
                      </div>
                      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
                        <div className="h-full bg-rose-500" style={{ width: `${Math.min(100, (Math.abs(Math.min(acc.balance, 0)) / acc.creditLimit) * 100)}%` }} />
                      </div>
                    </div>
                  )}
                  <div className="mt-3 flex gap-1 border-t pt-3">
                    {acc.status === "active" && (
                      <Button size="sm" variant="ghost" onClick={() => setStatus(acc, "frozen")}><Snowflake className="size-3.5" /> Freeze</Button>
                    )}
                    {acc.status === "frozen" && (
                      <Button size="sm" variant="ghost" onClick={() => setStatus(acc, "active")}><Unlock className="size-3.5" /> Unfreeze</Button>
                    )}
                    {acc.status !== "closed" && (
                      <Button size="sm" variant="ghost" onClick={() => setStatus(acc, "closed")}><Lock className="size-3.5" /> Close</Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => deleteAcc(acc)}><Trash2 className="size-3.5" /></Button>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      <AddAccountDialog open={addOpen} onOpenChange={setAddOpen} companyId={activeCompanyId} currency={activeCompany?.currency ?? "USD"} onSaved={() => { setAddOpen(false); load(); }} />
    </div>
  );
}

function AddAccountDialog({ open, onOpenChange, companyId, currency, onSaved }: { open: boolean; onOpenChange: (b: boolean) => void; companyId: string; currency: string; onSaved: () => void }) {
  const [bankName, setBankName] = React.useState("Chase");
  const [accountName, setAccountName] = React.useState("");
  const [accountType, setAccountType] = React.useState("checking");
  const [accountNumber, setAccountNumber] = React.useState("");
  const [routingNumber, setRoutingNumber] = React.useState("");
  const [balance, setBalance] = React.useState("");
  const [creditLimit, setCreditLimit] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  async function save() {
    if (!bankName || !accountType) { toast.error("Bank name and account type required"); return; }
    setSaving(true);
    try {
      const res = await fetch("/api/bank-accounts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companyId, bankName, accountName: accountName || `${accountType} account`,
          accountType, accountNumber, routingNumber, currency,
          balance: Number(balance) || 0,
          creditLimit: accountType === "credit_card" ? Number(creditLimit) || 0 : null,
        }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`${bankName} ${accountType.replace("_", " ")} added`);
      setAccountNumber(""); setBalance(""); setCreditLimit(""); setAccountName("");
      onSaved();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Bank Account / Credit Card</DialogTitle>
          <DialogDescription>Account number is masked to last 4 digits automatically.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Bank</Label>
              <Select value={bankName} onValueChange={setBankName}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">{BANKS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Account type</Label>
              <Select value={accountType} onValueChange={setAccountType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="checking">Checking</SelectItem>
                  <SelectItem value="savings">Savings</SelectItem>
                  <SelectItem value="credit_card">Credit Card</SelectItem>
                  <SelectItem value="merchant">Merchant / Payment Processor</SelectItem>
                  <SelectItem value="paypal">PayPal / Digital Wallet</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="aname">Account name (optional)</Label>
            <Input id="aname" value={accountName} onChange={(e) => setAccountName(e.target.value)} placeholder="e.g. Operating, Payroll, Tax Reserve" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label htmlFor="anum">Account number</Label>
              <Input id="anum" value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} placeholder="1234 5678 9012" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="rnum">Routing # / Sort code</Label>
              <Input id="rnum" value={routingNumber} onChange={(e) => setRoutingNumber(e.target.value)} placeholder="021000021" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label htmlFor="bal">Current balance ({currency})</Label>
              <Input id="bal" type="number" value={balance} onChange={(e) => setBalance(e.target.value)} placeholder="0.00" />
              {accountType === "credit_card" && <div className="text-[10px] text-muted-foreground">Use negative for outstanding balance owed</div>}
            </div>
            {accountType === "credit_card" && (
              <div className="grid gap-2">
                <Label htmlFor="clim">Credit limit ({currency})</Label>
                <Input id="clim" type="number" value={creditLimit} onChange={(e) => setCreditLimit(e.target.value)} placeholder="10000" />
              </div>
            )}
          </div>
          <div className="rounded-md bg-muted/40 p-3 text-xs text-muted-foreground">
            Account number will be stored as <strong>••••{accountNumber.replace(/\s/g, "").slice(-4) || "0000"}</strong> (last 4 only). In production, full numbers are encrypted at rest with AES-256-GCM.
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || !bankName}>{saving ? "Adding…" : "Add account"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
