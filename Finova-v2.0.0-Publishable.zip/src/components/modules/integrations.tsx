"use client";

import * as React from "react";
import {
  Mail, BookOpen, Landmark, CreditCard, Waves, Plug, RefreshCw, CheckCircle2, XCircle,
  Plus, Settings2, ShoppingCart, Cloud, MessageSquare, ExternalLink, Key, ShieldCheck,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Integration = {
  id: string;
  provider: string;
  label: string;
  status: string;
  scope?: string | null;
  accountEmail?: string | null;
  lastSyncAt?: string | null;
};

type ProviderMeta = {
  icon: React.ElementType;
  name: string;
  description: string;
  category: string;
  authType: "oauth2" | "apiKey" | "manual";
  docsUrl: string;
  scopes?: string[];
  developerConsoleUrl?: string;
  redirectUriNote?: string;
  setupSteps: string[];
};

const PROVIDER_META: Record<string, ProviderMeta> = {
  gmail: {
    icon: Mail, name: "Gmail", description: "Read & send mail from the connected inbox. The AI triages invoices, statements and receipts.",
    category: "Email", authType: "oauth2",
    docsUrl: "https://developers.google.com/gmail/api/quickstart/js",
    developerConsoleUrl: "https://console.cloud.google.com/apis/credentials",
    scopes: ["https://www.googleapis.com/auth/gmail.readonly", "https://www.googleapis.com/auth/gmail.send", "https://www.googleapis.com/auth/gmail.modify"],
    redirectUriNote: "Add the redirect URI below as an Authorized Redirect URI in your Google Cloud Console OAuth client.",
    setupSteps: [
      "Open Google Cloud Console → APIs & Services → Credentials.",
      "Create an OAuth 2.0 Client ID (type: Web application).",
      "Add the redirect URI below to Authorized redirect URIs.",
      "Enable the Gmail API under Library.",
      "Paste the Client ID and Client Secret below and click Save.",
    ],
  },
  quickbooks: {
    icon: BookOpen, name: "QuickBooks Online", description: "Sync chart of accounts, invoices, bills and journal entries.",
    category: "Accounting (USA)", authType: "oauth2",
    docsUrl: "https://developer.intuit.com/app/developer/qbo/docs/develop",
    developerConsoleUrl: "https://developer.intuit.com/app/developer/myapps",
    scopes: ["com.intuit.quickbooks.accounting", "com.intuit.quickbooks.payment"],
    redirectUriNote: "Add the redirect URI below in your Intuit Developer app's Redirect URIs list.",
    setupSteps: [
      "Sign in to Intuit Developer and create a new app (Production or Sandbox).",
      "Under Keys & OAuth, copy the Client ID and Client Secret.",
      "Add the redirect URI below to the Redirect URIs list.",
      "Select the scopes accounting + payment.",
      "Paste credentials below and click Save.",
    ],
  },
  xero: {
    icon: BookOpen, name: "Xero", description: "Sync contacts, invoices, bank feeds and tracking categories.",
    category: "Accounting (UK/EU)", authType: "oauth2",
    docsUrl: "https://developer.xero.com/documentation/oauth2/auth-flow",
    developerConsoleUrl: "https://app.xero.com/app/manageapps",
    scopes: ["accounting.transactions", "accounting.settings", "accounting.contacts", "bankfeeds"],
    redirectUriNote: "Add the redirect URI below to your Xero app's OAuth 2.0 config.",
    setupSteps: [
      "Sign in to Xero Developer Portal and create a Custom Connection or OAuth 2.0 app.",
      "Copy the Client ID and Client Secret.",
      "Add the redirect URI below.",
      "Select scopes: accounting.transactions, accounting.settings, bankfeeds.",
      "Paste credentials below and click Save.",
    ],
  },
  sage: {
    icon: BookOpen, name: "Sage", description: "Sage 50 / Sage Business Cloud sync — ledgers, VAT returns, contacts.",
    category: "Accounting (UK)", authType: "oauth2",
    docsUrl: "https://developer.sage.com/accounting/reference/",
    developerConsoleUrl: "https://developer.sage.com/",
    scopes: ["sage.accounting.read", "sage.accounting.write"],
    redirectUriNote: "Register the redirect URI in your Sage Developer app.",
    setupSteps: [
      "Sign in to Sage Developer Portal and create an app.",
      "Copy the Client ID and Client Secret.",
      "Add the redirect URI below to Callback URLs.",
      "Request scopes for accounting read/write.",
      "Paste credentials below and click Save.",
    ],
  },
  wave: {
    icon: Waves, name: "Wave", description: "Free accounting + invoicing for SMBs and freelancers.",
    category: "Accounting", authType: "apiKey",
    docsUrl: "https://developer.waveapps.com/",
    developerConsoleUrl: "https://developer.waveapps.com/apps/register",
    setupSteps: [
      "Sign in to Wave Developer and register an application.",
      "Generate an API token / OAuth credentials.",
      "Paste the API key below and click Save.",
    ],
  },
  stripe: {
    icon: CreditCard, name: "Stripe", description: "Auto-import payouts, fees, charges and refunds.",
    category: "Payments", authType: "apiKey",
    docsUrl: "https://stripe.com/docs/api",
    developerConsoleUrl: "https://dashboard.stripe.com/apikeys",
    setupSteps: [
      "Open Stripe Dashboard → Developers → API keys.",
      "Copy the Secret key (starts with sk_live_ or sk_test_).",
      "Optionally copy the Restricted key for finer scope.",
      "Paste below and click Save.",
    ],
  },
  plaid: {
    icon: Landmark, name: "Plaid (Bank Feeds)", description: "Live balance and transaction feed from your business bank accounts.",
    category: "Banking", authType: "apiKey",
    docsUrl: "https://plaid.com/docs/api/",
    developerConsoleUrl: "https://dashboard.plaid.com/team/keys",
    setupSteps: [
      "Sign in to Plaid Dashboard → Team → API Keys.",
      "Copy the Client ID and Secret.",
      "Select environment: Production or Sandbox.",
      "Paste below and click Save.",
    ],
  },
  shopify: {
    icon: ShoppingCart, name: "Shopify", description: "Sync orders, refunds, payouts and inventory from your Shopify store.",
    category: "E-commerce", authType: "apiKey",
    docsUrl: "https://shopify.dev/docs/api/admin-rest",
    developerConsoleUrl: "https://partners.shopify.com/",
    setupSteps: [
      "Sign in to Shopify Partner dashboard and create an app.",
      "Install the app on your store and copy the Admin API access token.",
      "Note the shop domain (e.g. my-store.myshopify.com).",
      "Paste below and click Save.",
    ],
  },
  aws: {
    icon: Cloud, name: "AWS", description: "Pull invoice & cost-explorer data for R&D credit tracking and cost allocation.",
    category: "Infrastructure", authType: "apiKey",
    docsUrl: "https://docs.aws.amazon.com/IAM/latest/UserGuide/introduction.html",
    developerConsoleUrl: "https://console.aws.amazon.com/iam/",
    setupSteps: [
      "In AWS IAM, create a user with Cost Explorer read-only policy.",
      "Create an access key (Access Key ID + Secret Access Key).",
      "Paste below and click Save.",
    ],
  },
  zapier: {
    icon: Plug, name: "Zapier", description: "Wire Finova into 6,000+ apps via Zapier triggers and actions.",
    category: "Workflow", authType: "apiKey",
    docsUrl: "https://developer.zapier.com/",
    developerConsoleUrl: "https://developer.zapier.com/",
    setupSteps: [
      "Sign in to Zapier Developer and create a CLI app or use the visual builder.",
      "Generate a Developer API key.",
      "Paste below and click Save.",
    ],
  },
  slack: {
    icon: MessageSquare, name: "Slack", description: "Post reports and agent alerts to channels via incoming webhooks.",
    category: "Communication", authType: "apiKey",
    docsUrl: "https://api.slack.com/messaging/webhooks",
    developerConsoleUrl: "https://api.slack.com/apps",
    setupSteps: [
      "Create a Slack App (or use an existing one).",
      "Enable Incoming Webhooks and create one for the target channel.",
      "Copy the webhook URL (starts with https://hooks.slack.com/services/…).",
      "Paste below and click Save.",
    ],
  },
};

const AVAILABLE_PROVIDERS = Object.keys(PROVIDER_META);

export function IntegrationsModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const [items, setItems] = React.useState<Integration[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [connecting, setConnecting] = React.useState<string | null>(null);
  const [configFor, setConfigFor] = React.useState<Integration | null>(null);

  function load() {
    setLoading(true);
    fetch(`/api/integrations?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setItems(d.integrations);
      })
      .catch((e) => toast.error(`Failed to load: ${e.message}`))
      .finally(() => setLoading(false));
  }

  React.useEffect(() => { load(); }, [activeCompanyId]);

  async function setStatus(int: Integration, status: "connected" | "disconnected") {
    setItems((arr) => arr.map((i) => (i.id === int.id ? { ...i, status } : i)));
    try {
      const res = await fetch("/api/integrations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: int.id, status }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`${PROVIDER_META[int.provider]?.name ?? int.provider} ${status}`);
    } catch (e: any) {
      toast.error(e.message);
      setItems((arr) => arr.map((i) => (i.id === int.id ? { ...i, status: int.status } : i)));
    }
  }

  async function addProvider(provider: string) {
    setConnecting(provider);
    try {
      const res = await fetch("/api/integrations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyId: activeCompanyId, provider, label: PROVIDER_META[provider]?.name ?? provider }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`${PROVIDER_META[provider]?.name} added — click Configure to enter OAuth credentials`);
      load();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setConnecting(null);
    }
  }

  const connectedProviders = new Set(items.map((i) => i.provider));
  const available = AVAILABLE_PROVIDERS.filter((p) => !connectedProviders.has(p));

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Integrations</h1>
          <p className="text-sm text-muted-foreground">
            Link Gmail, accounting software, banks and other apps. Configure real OAuth credentials — the AI agents read & write across all of them.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load}>
          <RefreshCw className="size-3.5" />
          Refresh
        </Button>
      </div>

      <Tabs defaultValue="connected">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="connected">Connected ({items.length})</TabsTrigger>
          <TabsTrigger value="available">Available ({available.length})</TabsTrigger>
          <TabsTrigger value="guide">Setup Guide</TabsTrigger>
        </TabsList>

        {/* Connected */}
        <TabsContent value="connected" className="space-y-3">
          <Card>
            <CardHeader>
              <CardTitle>Connected</CardTitle>
              <CardDescription>{items.length} integration{items.length === 1 ? "" : "s"}</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-2">
              {loading ? (
                <div className="md:col-span-2 space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>
              ) : items.length === 0 ? (
                <p className="md:col-span-2 text-sm text-muted-foreground">No integrations yet — add one from the Available tab.</p>
              ) : (
                items.map((i) => {
                  const meta = PROVIDER_META[i.provider] ?? { icon: Plug, name: i.provider, description: "", category: "" };
                  const Icon = meta.icon;
                  const connected = i.status === "connected";
                  return (
                    <div key={i.id} className="flex items-start gap-3 rounded-md border p-4">
                      <div className={cn("flex size-10 shrink-0 items-center justify-center rounded-md", connected ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-muted text-muted-foreground")}>
                        <Icon className="size-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-semibold">{meta.name}</span>
                          <Badge variant="outline" className="text-[10px]">{meta.category}</Badge>
                          {connected ? (
                            <Badge className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"><CheckCircle2 className="size-3" /> Connected</Badge>
                          ) : (
                            <Badge variant="destructive" className="text-[10px]"><XCircle className="size-3" /> Disconnected</Badge>
                          )}
                        </div>
                        <div className="mt-1 text-xs text-muted-foreground">{i.label}</div>
                        {i.accountEmail && <div className="mt-0.5 text-xs text-muted-foreground">{i.accountEmail}</div>}
                        {i.lastSyncAt && (
                          <div className="mt-1 text-[11px] text-muted-foreground">Last sync: {new Date(i.lastSyncAt).toLocaleString()}</div>
                        )}
                        <div className="mt-2 flex items-center gap-2">
                          <Switch checked={connected} onCheckedChange={(v) => setStatus(i, v ? "connected" : "disconnected")} aria-label="Toggle integration" />
                          <Button size="sm" variant="outline" onClick={() => setConfigFor(i)}>
                            <Settings2 className="size-3.5" />
                            Configure
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Available */}
        <TabsContent value="available" className="space-y-3">
          <Card>
            <CardHeader>
              <CardTitle>Available</CardTitle>
              <CardDescription>Connect a new service — credentials are stored per-client and never echoed back.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {available.map((p) => {
                const meta = PROVIDER_META[p];
                const Icon = meta.icon;
                return (
                  <div key={p} className="flex flex-col gap-2 rounded-md border p-4">
                    <div className="flex items-center gap-2">
                      <div className="flex size-9 items-center justify-center rounded-md bg-muted text-muted-foreground">
                        <Icon className="size-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-semibold">{meta.name}</div>
                        <div className="text-[10px] text-muted-foreground">{meta.category}</div>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{meta.description}</p>
                    <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                      <ShieldCheck className="size-3" />
                      {meta.authType === "oauth2" ? "OAuth 2.0" : meta.authType === "apiKey" ? "API Key" : "Manual"}
                    </div>
                    <Button size="sm" className="mt-auto w-full" variant="outline" onClick={() => addProvider(p)} disabled={connecting === p}>
                      {connecting === p ? (<><RefreshCw className="size-3 animate-spin" /> Adding…</>) : (<><Plus className="size-3" /> Add</>)}
                    </Button>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Setup guide */}
        <TabsContent value="guide" className="space-y-3">
          <Card>
            <CardHeader>
              <CardTitle>Setup Guide</CardTitle>
              <CardDescription>Step-by-step instructions for each provider, plus the redirect URI to register.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="rounded-md border bg-muted/30 p-3">
                <div className="text-xs font-medium">Your OAuth Redirect URI</div>
                <div className="mt-1 font-mono text-xs">{typeof window !== "undefined" ? `${window.location.origin}/api/integrations/callback` : "/api/integrations/callback"}</div>
                <div className="mt-1 text-[11px] text-muted-foreground">Register this exact URL in the developer console of each OAuth provider below.</div>
              </div>
              {Object.entries(PROVIDER_META).map(([key, meta]) => {
                const Icon = meta.icon;
                return (
                  <details key={key} className="rounded-md border p-3">
                    <summary className="flex cursor-pointer items-center gap-2 text-sm font-medium">
                      <Icon className="size-4" />
                      {meta.name}
                      <Badge variant="outline" className="text-[10px] ml-auto">{meta.authType}</Badge>
                    </summary>
                    <div className="mt-3 space-y-2">
                      <div className="text-xs text-muted-foreground">{meta.description}</div>
                      <ol className="list-decimal space-y-1 pl-5 text-xs">
                        {meta.setupSteps.map((s, i) => <li key={i}>{s}</li>)}
                      </ol>
                      {meta.scopes && (
                        <div className="rounded bg-muted/40 p-2 text-[11px]">
                          <div className="font-medium">Required scopes</div>
                          <div className="mt-1 font-mono">{meta.scopes.join(", ")}</div>
                        </div>
                      )}
                      <a href={meta.docsUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 hover:underline">
                        <ExternalLink className="size-3" /> Provider docs
                      </a>
                      {meta.developerConsoleUrl && (
                        <a href={meta.developerConsoleUrl} target="_blank" rel="noopener noreferrer" className="ml-3 inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 hover:underline">
                          <Key className="size-3" /> Developer console
                        </a>
                      )}
                      {meta.redirectUriNote && (
                        <div className="rounded bg-amber-500/10 p-2 text-[11px] text-amber-700 dark:text-amber-300">{meta.redirectUriNote}</div>
                      )}
                    </div>
                  </details>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* How the AI uses each integration */}
      <Card>
        <CardHeader>
          <CardTitle>How the AI uses each integration</CardTitle>
          <CardDescription>The agents operate across all connected services from one chat</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          {[
            { p: "gmail", t: "Gmail", d: "Accountant agent watches the inbox for invoices and receipts, extracts amount + vendor, drafts a journal entry, and asks for approval." },
            { p: "quickbooks", t: "QuickBooks / Xero / Sage", d: "Accountant agent posts journal entries, reconciles bank feeds, and reads the trial balance." },
            { p: "stripe", t: "Stripe", d: "On every payout, the Accountant agent categorizes fees and net, then posts to the right revenue account." },
            { p: "plaid", t: "Plaid (Banks)", d: "CFO agent reads live balances and 90-day cash trend to power the runway calculation and daily cash report." },
            { p: "shopify", t: "Shopify", d: "For retail clients, the Accountant agent reconciles daily POS sales, returns and Shopify payouts." },
            { p: "aws", t: "AWS", d: "For AI / SaaS clients, the Tax agent tags compute spend toward the US R&D credit (Form 6765)." },
          ].map((x) => (
            <div key={x.p} className="rounded-md border p-3">
              <div className="text-sm font-medium">{x.t}</div>
              <div className="mt-1 text-xs text-muted-foreground">{x.d}</div>
            </div>
          ))}
        </CardContent>
      </Card>

      <ConfigDialog integration={configFor} onClose={() => setConfigFor(null)} />
    </div>
  );
}

function ConfigDialog({ integration, onClose }: { integration: Integration | null; onClose: () => void }) {
  const [clientId, setClientId] = React.useState("");
  const [clientSecret, setClientSecret] = React.useState("");
  const [apiKey, setApiKey] = React.useState("");
  const [redirectUri, setRedirectUri] = React.useState("");
  const [accountEmail, setAccountEmail] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (integration) {
      setClientId(""); setClientSecret(""); setApiKey(""); setRedirectUri("");
      setAccountEmail(integration.accountEmail ?? "");
    }
  }, [integration]);

  if (!integration) return null;
  const meta = PROVIDER_META[integration.provider] ?? { authType: "manual", name: integration.provider } as ProviderMeta;
  const isOAuth = meta.authType === "oauth2";

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/integrations/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: integration!.id,
          clientId: clientId || undefined,
          clientSecret: clientSecret || undefined,
          apiKey: apiKey || undefined,
          redirectUri: redirectUri || undefined,
          accountEmail: accountEmail || undefined,
        }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success(`${meta.name} credentials saved — marked as connected`);
      onClose();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!integration} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="size-4 text-emerald-500" />
            Configure {meta.name}
          </DialogTitle>
          <DialogDescription>
            Auth type: <strong className="font-medium">{meta.authType === "oauth2" ? "OAuth 2.0" : meta.authType === "apiKey" ? "API Key" : "Manual"}</strong>.
            Credentials are stored per-client and never echoed back to the browser.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-2">
          <div className="rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground">
            <div className="font-medium text-foreground">Setup steps</div>
            <ol className="mt-1 list-decimal space-y-0.5 pl-5">
              {meta.setupSteps.map((s, i) => <li key={i}>{s}</li>)}
            </ol>
            <div className="mt-2 flex flex-wrap gap-3">
              <a href={meta.docsUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:underline">
                <ExternalLink className="size-3" /> Docs
              </a>
              {meta.developerConsoleUrl && (
                <a href={meta.developerConsoleUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:underline">
                  <Key className="size-3" /> Developer console
                </a>
              )}
            </div>
          </div>

          {isOAuth && (
            <>
              <div className="grid gap-2">
                <Label htmlFor="cid">OAuth Client ID</Label>
                <Input id="cid" value={clientId} onChange={(e) => setClientId(e.target.value)} placeholder="your-client-id.apps.googleusercontent.com" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="csec">OAuth Client Secret</Label>
                <Input id="csec" type="password" value={clientSecret} onChange={(e) => setClientSecret(e.target.value)} placeholder="••••••••••••••••" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="ruri">Redirect URI (pre-filled)</Label>
                <Input
                  id="ruri"
                  value={redirectUri || (typeof window !== "undefined" ? `${window.location.origin}/api/integrations/callback` : "/api/integrations/callback")}
                  onChange={(e) => setRedirectUri(e.target.value)}
                  readOnly
                  className="font-mono text-xs"
                />
                <div className="text-[10px] text-muted-foreground">Register this URL in the developer console.</div>
              </div>
            </>
          )}
          {!isOAuth && (
            <div className="grid gap-2">
              <Label htmlFor="akey">API Key / Access Token</Label>
              <Textarea id="akey" value={apiKey} onChange={(e) => setApiKey(e.target.value)} rows={2} placeholder="sk_live_… or webhook URL or access token" className="font-mono text-xs" />
            </div>
          )}

          <div className="grid gap-2">
            <Label htmlFor="aemail">Account email (optional)</Label>
            <Input id="aemail" value={accountEmail} onChange={(e) => setAccountEmail(e.target.value)} placeholder="cfo@client.com" />
          </div>

          {meta.scopes && (
            <div className="rounded bg-muted/40 p-2 text-[11px]">
              <div className="font-medium">Required scopes</div>
              <div className="mt-1 font-mono">{meta.scopes.join(", ")}</div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving || (isOAuth ? !clientId || !clientSecret : !apiKey)}>
            {saving ? "Saving…" : "Save credentials"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
