"use client";

import * as React from "react";
import { Plus, Search, Filter, Download, RefreshCw } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Txn = {
  id: string;
  date: string;
  description: string;
  category: string;
  type: string;
  amount: number;
  currency: string;
  source: string;
  status: string;
};

const CATEGORIES = [
  "Product Revenue",
  "Service Revenue",
  "Subscription Revenue",
  "Consulting",
  "Interest Income",
  "COGS",
  "Payroll",
  "Rent",
  "Software",
  "Marketing",
  "Utilities",
  "Travel",
  "Tax",
  "Insurance",
  "Office Supplies",
];

const SOURCES = ["manual", "quickbooks", "xero", "sage", "stripe", "wave", "gmail", "plaid"];

export function TransactionsModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [transactions, setTransactions] = React.useState<Txn[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [filterType, setFilterType] = React.useState<string>("all");
  const [filterSource, setFilterSource] = React.useState<string>("all");
  const [filterCategory, setFilterCategory] = React.useState<string>("all");
  const [addOpen, setAddOpen] = React.useState(false);

  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";

  function load() {
    setLoading(true);
    const params = new URLSearchParams({ companyId: activeCompanyId });
    if (filterType !== "all") params.set("type", filterType);
    if (filterSource !== "all") params.set("source", filterSource);
    if (filterCategory !== "all") params.set("category", filterCategory);
    fetch(`/api/transactions?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setTransactions(d.transactions);
      })
      .catch((e) => toast.error(`Failed to load: ${e.message}`))
      .finally(() => setLoading(false));
  }

  React.useEffect(() => {
    load();
  }, [activeCompanyId, filterType, filterSource, filterCategory]);

  const filtered = React.useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return transactions;
    return transactions.filter(
      (t) =>
        t.description.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.source.toLowerCase().includes(q)
    );
  }, [transactions, search]);

  const totals = React.useMemo(() => {
    let income = 0,
      expense = 0;
    for (const t of filtered) {
      if (t.type === "income") income += t.amount;
      else expense += t.amount;
    }
    return { income, expense, net: income - expense, count: filtered.length };
  }, [filtered]);

  function exportCSV() {
    const rows = [
      ["Date", "Description", "Category", "Type", "Amount", "Currency", "Source", "Status"],
      ...filtered.map((t) => [
        new Date(t.date).toISOString().slice(0, 10),
        t.description,
        t.category,
        t.type,
        String(t.amount),
        t.currency,
        t.source,
        t.status,
      ]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `transactions_${activeCompanyId}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV exported");
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Transactions</h1>
          <p className="text-sm text-muted-foreground">
            Unified ledger across Gmail, accounting software and bank feeds.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={exportCSV}>
            <Download className="size-3.5" />
            Export CSV
          </Button>
          <Button variant="outline" size="sm" onClick={load}>
            <RefreshCw className="size-3.5" />
            Refresh
          </Button>
          <AddTransactionDialog
            open={addOpen}
            onOpenChange={setAddOpen}
            companyId={activeCompanyId}
            currency={activeCompany?.currency ?? "USD"}
            onAdded={() => {
              setAddOpen(false);
              load();
            }}
          />
        </div>
      </div>

      {/* Summary strip */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Records</div>
          <div className="text-xl font-bold">{totals.count}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Income</div>
          <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{sym}{totals.income.toLocaleString()}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Expenses</div>
          <div className="text-xl font-bold text-destructive">{sym}{totals.expense.toLocaleString()}</div>
        </CardContent></Card>
        <Card><CardContent className="py-3">
          <div className="text-xs text-muted-foreground">Net</div>
          <div className={cn("text-xl font-bold", totals.net >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>{sym}{totals.net.toLocaleString()}</div>
        </CardContent></Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Filters</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
            <Input
              placeholder="Search description…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8"
            />
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              <SelectItem value="income">Income</SelectItem>
              <SelectItem value="expense">Expense</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterSource} onValueChange={setFilterSource}>
            <SelectTrigger><SelectValue placeholder="Source" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All sources</SelectItem>
              {SOURCES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent className="max-h-72">
              <SelectItem value="all">All categories</SelectItem>
              {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle>Ledger</CardTitle>
          <CardDescription>{filtered.length} transactions</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-2">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : (
            <div className="max-h-[60vh] overflow-auto rounded-md border">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-muted/60 backdrop-blur">
                  <tr className="text-left text-xs text-muted-foreground">
                    <th className="px-3 py-2 font-medium">Date</th>
                    <th className="px-3 py-2 font-medium">Description</th>
                    <th className="px-3 py-2 font-medium">Category</th>
                    <th className="px-3 py-2 font-medium">Type</th>
                    <th className="px-3 py-2 font-medium">Source</th>
                    <th className="px-3 py-2 font-medium">Status</th>
                    <th className="px-3 py-2 text-right font-medium">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 && (
                    <tr><td colSpan={7} className="px-3 py-8 text-center text-muted-foreground">No transactions match these filters.</td></tr>
                  )}
                  {filtered.map((t) => (
                    <tr key={t.id} className="border-t hover:bg-muted/40">
                      <td className="px-3 py-2 text-xs text-muted-foreground">{new Date(t.date).toLocaleDateString()}</td>
                      <td className="px-3 py-2">{t.description}</td>
                      <td className="px-3 py-2 text-xs">{t.category}</td>
                      <td className="px-3 py-2">
                        <Badge variant={t.type === "income" ? "default" : "secondary"} className="text-[10px]">
                          {t.type}
                        </Badge>
                      </td>
                      <td className="px-3 py-2 text-xs capitalize">{t.source}</td>
                      <td className="px-3 py-2">
                        <Badge variant="outline" className="text-[10px]">{t.status}</Badge>
                      </td>
                      <td className={cn("px-3 py-2 text-right font-medium", t.type === "income" ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>
                        {t.type === "income" ? "+" : "-"}{sym}{t.amount.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function AddTransactionDialog({
  open,
  onOpenChange,
  companyId,
  currency,
  onAdded,
}: {
  open: boolean;
  onOpenChange: (b: boolean) => void;
  companyId: string;
  currency: string;
  onAdded: () => void;
}) {
  const [description, setDescription] = React.useState("");
  const [category, setCategory] = React.useState(CATEGORIES[5]);
  const [type, setType] = React.useState<"income" | "expense">("expense");
  const [amount, setAmount] = React.useState("");
  const [source, setSource] = React.useState("manual");
  const [date, setDate] = React.useState(new Date().toISOString().slice(0, 10));
  const [saving, setSaving] = React.useState(false);

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companyId,
          description,
          category,
          type,
          amount: Number(amount),
          currency,
          source,
          date,
        }),
      });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error ?? "Failed");
      toast.success("Transaction posted");
      setDescription("");
      setAmount("");
      onAdded();
    } catch (e: any) {
      toast.error(`Save failed: ${e.message}`);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="size-3.5" />
          Add Transaction
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Transaction</DialogTitle>
          <DialogDescription>Post a manual journal entry. AI agents can also create these via automations.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="desc">Description</Label>
            <Textarea id="desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="e.g. AWS infrastructure — March" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Type</Label>
              <Select value={type} onValueChange={(v) => setType(v as any)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Expense</SelectItem>
                  <SelectItem value="income">Income</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="grid gap-2">
              <Label htmlFor="amt">Amount ({currency})</Label>
              <Input id="amt" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" />
            </div>
            <div className="grid gap-2">
              <Label>Source</Label>
              <Select value={source} onValueChange={setSource}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{SOURCES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="date">Date</Label>
              <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || !description || !amount}>
            {saving ? "Posting…" : "Post transaction"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
