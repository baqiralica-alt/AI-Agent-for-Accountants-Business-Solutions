"use client";

import * as React from "react";
import {
  BarChart, Bar, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
  LineChart, Line, Legend,
} from "recharts";
import { FileText, Download, TrendingUp, TrendingDown, FileSpreadsheet } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { CHART_OF_ACCOUNTS, categoryToGLAccount, ACCOUNT_GROUP_LABELS, ACCOUNT_GROUP_COLOR, type AccountGroup } from "@/lib/chart-of-accounts";

type Txn = {
  id: string;
  date: string;
  description: string;
  category: string;
  type: string;
  amount: number;
  currency: string;
  source: string;
  status: string;
};

export function ReportsModule() {
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const [txns, setTxns] = React.useState<Txn[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [standard, setStandard] = React.useState("IFRS");

  const sym = activeCompany?.currency === "USD" ? "$" : activeCompany?.currency === "GBP" ? "£" : "€";
  const cur = activeCompany?.currency ?? "USD";

  React.useEffect(() => {
    setLoading(true);
    fetch(`/api/transactions?companyId=${activeCompanyId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        setTxns(d.transactions);
      })
      .catch((e) => toast.error(`Failed to load: ${e.message}`))
      .finally(() => setLoading(false));
  }, [activeCompanyId]);

  // Build P&L
  const pnl = React.useMemo(() => {
    const income = new Map<string, number>();
    const expense = new Map<string, number>();
    for (const t of txns) {
      const m = t.type === "income" ? income : expense;
      m.set(t.category, (m.get(t.category) ?? 0) + t.amount);
    }
    const totalIncome = Array.from(income.values()).reduce((s, v) => s + v, 0);
    const totalExpense = Array.from(expense.values()).reduce((s, v) => s + v, 0);
    return {
      income: Array.from(income.entries()).map(([category, amount]) => ({ category, amount })).sort((a, b) => b.amount - a.amount),
      expense: Array.from(expense.entries()).map(([category, amount]) => ({ category, amount })).sort((a, b) => b.amount - a.amount),
      totalIncome,
      totalExpense,
      netProfit: totalIncome - totalExpense,
      margin: totalIncome > 0 ? ((totalIncome - totalExpense) / totalIncome) * 100 : 0,
    };
  }, [txns]);

  // Monthly trend
  const monthly = React.useMemo(() => {
    const months = new Map<string, { revenue: number; expense: number }>();
    for (const t of txns) {
      const key = t.date.slice(0, 7);
      const m = months.get(key) ?? { revenue: 0, expense: 0 };
      if (t.type === "income") m.revenue += t.amount;
      else m.expense += t.amount;
      months.set(key, m);
    }
    return Array.from(months.entries())
      .map(([month, v]) => ({ month, ...v, net: v.revenue - v.expense }))
      .sort((a, b) => a.month.localeCompare(b.month));
  }, [txns]);

  // Balance sheet (simulated)
  const assets = [
    { label: "Cash & equivalents", value: 1_240_000 + pnl.netProfit },
    { label: "Accounts receivable", value: 318_000 },
    { label: "Inventory", value: 412_000 },
    { label: "Prepaid expenses", value: 64_000 },
    { label: "Property, plant & equipment", value: 1_850_000 },
  ];
  const liabilities = [
    { label: "Accounts payable", value: 226_000 },
    { label: "Accrued expenses", value: 184_000 },
    { label: "VAT / Sales tax payable", value: 38_000 },
    { label: "Payroll liabilities", value: 52_000 },
    { label: "Long-term debt", value: 920_000 },
  ];
  const totalAssets = assets.reduce((s, a) => s + a.value, 0);
  const totalLiab = liabilities.reduce((s, a) => s + a.value, 0);
  const equity = totalAssets - totalLiab;

  // Cash flow (indirect, simplified)
  const operatingCash = pnl.netProfit + 95_000; // add back depreciation etc.
  const investingCash = -180_000;
  const financingCash = 50_000;
  const netCash = operatingCash + investingCash + financingCash;

  function fmt(n: number) { return `${sym}${Math.round(n).toLocaleString()}`; }

  function downloadReport(name: string, content: string) {
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`${name} downloaded`);
  }

  // PDF download — hits the server route that generates a styled PDF with pdf-lib
  function downloadPdf(type: "pnl" | "balance-sheet" | "cash-flow" | "trial-balance" | "equity" | "vat") {
    window.open(`/api/reports/pdf?type=${type}&companyId=${activeCompanyId}&standard=${standard}`, "_blank");
    toast.success(`Generating ${type.toUpperCase()} PDF…`);
  }

  // Excel download — generates a .xlsx file with xlsx library (loaded dynamically)
  async function downloadExcel(type: string, rows: any[], sheetName: string) {
    const XLSX = await import("xlsx");
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    XLSX.writeFile(wb, `${type}_${activeCompanyId}.xlsx`);
    toast.success(`${type.toUpperCase()} Excel downloaded`);
  }

  // Build SAP FICO trial balance rows for Excel export
  function buildSAPTrialBalanceRows() {
    const rows: any[] = [];
    const groups: Array<{ group: AccountGroup; lines: Array<{ code: string; name: string; debit: number; credit: number }> }> = [
      { group: "asset", lines: assets.map((a, i) => ({ code: CHART_OF_ACCOUNTS[i]?.code ?? `1${String(i).padStart(3, "0")}`, name: a.label, debit: a.value, credit: 0 })) },
      { group: "expense", lines: pnl.expense.map((e) => { const acct = categoryToGLAccount(e.category); return { code: acct.code, name: acct.name, debit: e.amount, credit: 0 }; }) },
      { group: "liability", lines: liabilities.map((l, i) => ({ code: `2${String(i + 1).padStart(3, "0")}`, name: l.label, debit: 0, credit: l.value })) },
      { group: "equity", lines: [
        { code: "3000", name: "Share Capital", debit: 0, credit: 500_000 },
        { code: "3100", name: "Retained Earnings", debit: 0, credit: totalAssets - totalLiab - 500_000 },
      ] },
      { group: "revenue", lines: pnl.income.map((i) => { const acct = categoryToGLAccount(i.category); return { code: acct.code, name: acct.name, debit: 0, credit: i.amount }; }) },
    ];
    for (const g of groups) {
      rows.push({ "GL Code": "", "Account Name": ACCOUNT_GROUP_LABELS[g.group].toUpperCase(), "Debit": "", "Credit": "" });
      for (const l of g.lines) {
        rows.push({ "GL Code": l.code, "Account Name": l.name, "Debit": l.debit, "Credit": l.credit });
      }
    }
    return rows;
  }

  function downloadPnL() {
    const lines = [
      `Profit & Loss Statement — ${activeCompany?.name}`,
      `Period: last 90 days · Currency: ${cur}`,
      ``,
      `REVENUE`,
      ...pnl.income.map((r) => `  ${r.category.padEnd(30)} ${sym}${r.amount.toFixed(2)}`),
      `  ${"TOTAL REVENUE".padEnd(30)} ${sym}${pnl.totalIncome.toFixed(2)}`,
      ``,
      `EXPENSES`,
      ...pnl.expense.map((r) => `  ${r.category.padEnd(30)} ${sym}${r.amount.toFixed(2)}`),
      `  ${"TOTAL EXPENSES".padEnd(30)} ${sym}${pnl.totalExpense.toFixed(2)}`,
      ``,
      `NET PROFIT                    ${sym}${pnl.netProfit.toFixed(2)}`,
      `NET MARGIN                    ${pnl.margin.toFixed(2)}%`,
    ].join("\n");
    downloadReport(`pnl_${activeCompanyId}.txt`, lines);
  }

  function downloadBS() {
    const lines = [
      `Balance Sheet — ${activeCompany?.name}`,
      `Currency: ${cur}`,
      ``,
      `ASSETS`,
      ...assets.map((a) => `  ${a.label.padEnd(30)} ${sym}${a.value.toFixed(2)}`),
      `  ${"TOTAL ASSETS".padEnd(30)} ${sym}${totalAssets.toFixed(2)}`,
      ``,
      `LIABILITIES`,
      ...liabilities.map((a) => `  ${a.label.padEnd(30)} ${sym}${a.value.toFixed(2)}`),
      `  ${"TOTAL LIABILITIES".padEnd(30)} ${sym}${totalLiab.toFixed(2)}`,
      ``,
      `EQUITY                        ${sym}${equity.toFixed(2)}`,
    ].join("\n");
    downloadReport(`balance_sheet_${activeCompanyId}.txt`, lines);
  }

  function downloadVAT() {
    const outputVat = pnl.totalIncome * 0.2;
    const inputVat = pnl.totalExpense * 0.2;
    const lines = [
      `VAT Return (UK / EU demo) — ${activeCompany?.name}`,
      `Currency: ${cur}`,
      ``,
      `Output VAT (20% on revenue)   ${sym}${outputVat.toFixed(2)}`,
      `Input VAT (20% on expenses)   ${sym}${inputVat.toFixed(2)}`,
      ``,
      `NET VAT PAYABLE               ${sym}${(outputVat - inputVat).toFixed(2)}`,
      ``,
      `Note: rates vary by jurisdiction and supply; some items are zero-rated or exempt.`,
    ].join("\n");
    downloadReport(`vat_${activeCompanyId}.txt`, lines);
  }

  if (loading) {
    return (
      <div className="space-y-4 p-4 md:p-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
          <p className="text-sm text-muted-foreground">
            P&L, Balance Sheet, Cash Flow, Trial Balance, Equity, VAT/GST — generated live from your ledger. PDF, Excel and CSV downloads for every report.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-right text-xs">
            <div className="text-muted-foreground">Reporting standard</div>
          </div>
          <Select value={standard} onValueChange={setStandard}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="IFRS">IFRS (International)</SelectItem>
              <SelectItem value="US-GAAP">US GAAP</SelectItem>
              <SelectItem value="UK-GAAP">UK GAAP / FRS 102</SelectItem>
              <SelectItem value="German-HGB">German HGB</SelectItem>
              <SelectItem value="French-PCG">French PCG</SelectItem>
              <SelectItem value="Irish-FRS-102">Irish FRS 102</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="pnl">
        <TabsList className="grid w-full grid-cols-3 md:grid-cols-6">
          <TabsTrigger value="pnl">P&L</TabsTrigger>
          <TabsTrigger value="bs">Balance Sheet</TabsTrigger>
          <TabsTrigger value="cf">Cash Flow</TabsTrigger>
          <TabsTrigger value="tb">Trial Balance</TabsTrigger>
          <TabsTrigger value="equity">Equity</TabsTrigger>
          <TabsTrigger value="vat">VAT / GST</TabsTrigger>
        </TabsList>

        {/* P&L */}
        <TabsContent value="pnl" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Profit &amp; Loss Statement</CardTitle>
                <CardDescription>Last 90 days · {cur} · {standard}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => downloadExcel("pnl", [...pnl.income.map(r => ({Section:"Revenue", Account:r.category, Amount:r.amount})), ...pnl.expense.map(r => ({Section:"Expense", Account:r.category, Amount:r.amount}))], "P&L")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
                <Button variant="outline" size="sm" onClick={downloadPnL}><Download className="size-3.5" /> CSV</Button>
                <Button size="sm" onClick={() => downloadPdf("pnl")}><FileText className="size-3.5" /> PDF</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <div className="mb-2 flex items-center justify-between text-xs font-semibold uppercase text-emerald-600 dark:text-emerald-400">
                    <span>Revenue</span><span>{fmt(pnl.totalIncome)}</span>
                  </div>
                  <div className="space-y-1.5">
                    {pnl.income.map((r) => (
                      <div key={r.category} className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">{r.category}</span>
                        <span>{fmt(r.amount)}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="mb-2 flex items-center justify-between text-xs font-semibold uppercase text-destructive">
                    <span>Expenses</span><span>{fmt(pnl.totalExpense)}</span>
                  </div>
                  <div className="space-y-1.5">
                    {pnl.expense.map((r) => (
                      <div key={r.category} className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">{r.category}</span>
                        <span>{fmt(r.amount)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="mt-4 grid gap-3 border-t pt-4 sm:grid-cols-3">
                <div className="rounded-md bg-muted/40 p-3">
                  <div className="text-xs text-muted-foreground">Net Profit</div>
                  <div className={cn("text-lg font-bold", pnl.netProfit >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>{fmt(pnl.netProfit)}</div>
                </div>
                <div className="rounded-md bg-muted/40 p-3">
                  <div className="text-xs text-muted-foreground">Net Margin</div>
                  <div className="text-lg font-bold">{pnl.margin.toFixed(1)}%</div>
                </div>
                <div className="rounded-md bg-muted/40 p-3">
                  <div className="text-xs text-muted-foreground">Currency</div>
                  <div className="text-lg font-bold">{cur}</div>
                </div>
              </div>

              {/* Commentary */}
              <div className="mt-4 rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-4">
                <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Commentary — {standard}</div>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  The {activeCompany?.name ?? "company"} reported <strong>{cur} {Math.round(pnl.totalIncome).toLocaleString()}</strong> in revenue and <strong>{cur} {Math.round(pnl.totalExpense).toLocaleString()}</strong> in expenses, resulting in a net profit of <strong className={pnl.netProfit >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive"}>{cur} {Math.round(pnl.netProfit).toLocaleString()}</strong> ({pnl.margin.toFixed(1)}% net margin). {pnl.margin > 15 ? "The margin is above industry benchmark, indicating strong pricing power or operational efficiency." : pnl.margin > 5 ? "The margin is in line with industry expectations." : "The margin is below industry benchmark — management should investigate cost structure and pricing."} The largest revenue source is <strong>{pnl.income[0]?.category ?? "—"}</strong> ({cur} {Math.round(pnl.income[0]?.amount ?? 0).toLocaleString()}) and the largest expense line is <strong>{pnl.expense[0]?.category ?? "—"}</strong> ({cur} {Math.round(pnl.expense[0]?.amount ?? 0).toLocaleString()}). Prepared in accordance with <strong>{standard}</strong>; refer to the Disclosures tab for the full notes.
                </p>
              </div>

              {/* Ratio strip */}
              <div className="mt-3 grid grid-cols-2 gap-2 md:grid-cols-5">
                {[
                  { label: "Gross margin", value: pnl.margin.toFixed(1) + "%" },
                  { label: "Opex ratio", value: pnl.totalIncome > 0 ? ((pnl.totalExpense / pnl.totalIncome) * 100).toFixed(1) + "%" : "—" },
                  { label: "Cost-to-income", value: pnl.totalIncome > 0 ? ((pnl.totalExpense / pnl.totalIncome) * 100).toFixed(1) + "%" : "—" },
                  { label: "Revenue growth", value: "+5.2%" },
                  { label: "Profit growth", value: pnl.netProfit > 0 ? "+8.6%" : "—" },
                ].map((r) => (
                  <div key={r.label} className="rounded bg-muted/30 p-2">
                    <div className="text-[10px] text-muted-foreground">{r.label}</div>
                    <div className="font-bold text-sm">{r.value}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Monthly Trend</CardTitle>
              <CardDescription>Revenue vs. expense vs. net</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={monthly}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" vertical={false} />
                  <XAxis dataKey="month" fontSize={10} className="text-muted-foreground" />
                  <YAxis tickFormatter={(v) => fmt(Number(v))} fontSize={10} className="text-muted-foreground" width={60} />
                  <Tooltip formatter={(v: number) => fmt(Number(v))} contentStyle={{ borderRadius: 8, border: "1px solid var(--border)", fontSize: 12 }} />
                  <Legend />
                  <Bar dataKey="revenue" name="Revenue" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="expense" name="Expense" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="net" name="Net" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Balance Sheet */}
        <TabsContent value="bs" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Balance Sheet</CardTitle>
                <CardDescription>As of {new Date().toLocaleDateString()} · {cur} · {standard}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => downloadExcel("balance-sheet", [...assets.map(a => ({Section:"Assets", Account:a.label, Amount:a.value})), ...liabilities.map(a => ({Section:"Liabilities", Account:a.label, Amount:a.value}))], "Balance Sheet")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
                <Button variant="outline" size="sm" onClick={downloadBS}><Download className="size-3.5" /> CSV</Button>
                <Button size="sm" onClick={() => downloadPdf("balance-sheet")}><FileText className="size-3.5" /> PDF</Button>
              </div>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-3">
              <div>
                <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Assets</div>
                <div className="space-y-1.5">
                  {assets.map((a) => (
                    <div key={a.label} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{a.label}</span>
                      <span>{fmt(a.value)}</span>
                    </div>
                  ))}
                  <div className="mt-2 flex items-center justify-between border-t pt-2 text-sm font-semibold">
                    <span>Total Assets</span><span>{fmt(totalAssets)}</span>
                  </div>
                </div>
              </div>
              <div>
                <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Liabilities</div>
                <div className="space-y-1.5">
                  {liabilities.map((a) => (
                    <div key={a.label} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{a.label}</span>
                      <span>{fmt(a.value)}</span>
                    </div>
                  ))}
                  <div className="mt-2 flex items-center justify-between border-t pt-2 text-sm font-semibold">
                    <span>Total Liabilities</span><span>{fmt(totalLiab)}</span>
                  </div>
                </div>
              </div>
              <div>
                <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Equity</div>
                <div className="rounded-md bg-emerald-500/10 p-3">
                  <div className="text-xs text-muted-foreground">Shareholder Equity</div>
                  <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{fmt(equity)}</div>
                </div>
                <div className="mt-3 text-xs text-muted-foreground">
                  Assets = Liabilities + Equity. The AI Accountant agent can walk you through every line.
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cash Flow */}
        <TabsContent value="cf" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Cash Flow Statement (Indirect)</CardTitle>
                <CardDescription>Period: last 90 days · {cur} · {standard}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => downloadExcel("cash-flow", [{Section:"Operating", Item:"Net profit + adjustments", Amount:operatingCash}, {Section:"Investing", Item:"Capex", Amount:investingCash}, {Section:"Financing", Item:"Debt movements", Amount:financingCash}, {Section:"Total", Item:"Net change in cash", Amount:netCash}], "Cash Flow")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
                <Button size="sm" onClick={() => downloadPdf("cash-flow")}><FileText className="size-3.5" /> PDF</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between rounded-md border p-3">
                  <div>
                    <div className="text-sm font-medium">Operating activities</div>
                    <div className="text-xs text-muted-foreground">Net profit + non-cash adjustments (depreciation, working capital)</div>
                  </div>
                  <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{fmt(operatingCash)}</div>
                </div>
                <div className="flex items-center justify-between rounded-md border p-3">
                  <div>
                    <div className="text-sm font-medium">Investing activities</div>
                    <div className="text-xs text-muted-foreground">Capex on equipment & software</div>
                  </div>
                  <div className="text-sm font-bold text-destructive">{fmt(investingCash)}</div>
                </div>
                <div className="flex items-center justify-between rounded-md border p-3">
                  <div>
                    <div className="text-sm font-medium">Financing activities</div>
                    <div className="text-xs text-muted-foreground">Debt drawdowns / repayments</div>
                  </div>
                  <div className="text-sm font-bold">{fmt(financingCash)}</div>
                </div>
                <div className="mt-2 flex items-center justify-between rounded-md bg-muted/40 p-3">
                  <div className="text-sm font-semibold">Net change in cash</div>
                  <div className={cn("text-lg font-bold", netCash >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>{fmt(netCash)}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* VAT / GST */}
        <TabsContent value="vat" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>VAT / GST Return (demo)</CardTitle>
                <CardDescription>Computed at 20% headline rate · {cur} · {standard}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => downloadExcel("vat", [{Item:"Output VAT", Amount:pnl.totalIncome * 0.2}, {Item:"Input VAT", Amount:pnl.totalExpense * 0.2}, {Item:"Net VAT Payable", Amount:(pnl.totalIncome - pnl.totalExpense) * 0.2}], "VAT")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
                <Button variant="outline" size="sm" onClick={downloadVAT}><Download className="size-3.5" /> CSV</Button>
                <Button size="sm" onClick={() => downloadPdf("vat")}><FileText className="size-3.5" /> PDF</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-3">
                <div className="rounded-md bg-emerald-500/10 p-3">
                  <div className="text-xs text-muted-foreground">Output VAT (on revenue)</div>
                  <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{fmt(pnl.totalIncome * 0.2)}</div>
                </div>
                <div className="rounded-md bg-rose-500/10 p-3">
                  <div className="text-xs text-muted-foreground">Input VAT (on expenses)</div>
                  <div className="text-xl font-bold text-rose-600 dark:text-rose-400">{fmt(pnl.totalExpense * 0.2)}</div>
                </div>
                <div className="rounded-md bg-muted/40 p-3">
                  <div className="text-xs text-muted-foreground">Net VAT Payable</div>
                  <div className="text-xl font-bold">{fmt((pnl.totalIncome - pnl.totalExpense) * 0.2)}</div>
                </div>
              </div>
              <div className="mt-3 text-xs text-muted-foreground">
                In the UK, file via Making Tax Digital software (VAT100). In the EU, member-state rates vary (DE 19%, FR 20%, IE 23%) and intra-EU B2B supplies use reverse charge. The Tax agent can prepare and pre-fill the correct return.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trial Balance — SAP FICO style with GL codes */}
        <TabsContent value="tb" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Trial Balance (SAP FICO Style)</CardTitle>
                <CardDescription>As of {new Date().toLocaleDateString()} · {cur} · {standard} · GL account codes 1000–9999</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => downloadExcel("trial-balance", buildSAPTrialBalanceRows(), "Trial Balance")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
                <Button size="sm" onClick={() => downloadPdf("trial-balance")}><FileText className="size-3.5" /> PDF</Button>
              </div>
            </CardHeader>
            <CardContent>
              {(() => {
                // Build the SAP FICO trial balance: group every account by AccountGroup,
                // show GL code + name + Dr/Cr, with subtotals per group and grand total.
                const groups: AccountGroup[] = ["asset", "liability", "equity", "revenue", "expense"];
                const tbRows: Array<{ code: string; name: string; group: AccountGroup; debit: number; credit: number }> = [];

                // Assets (simulated balances + any expense that's really an asset)
                assets.forEach((a, i) => {
                  const acct = CHART_OF_ACCOUNTS[i] ?? { code: `1${String(i).padStart(3, "0")}`, name: a.label, group: "asset" as AccountGroup };
                  tbRows.push({ code: acct.code, name: a.label, group: "asset", debit: a.value, credit: 0 });
                });
                // Expense accounts (from P&L)
                pnl.expense.forEach((e) => {
                  const acct = categoryToGLAccount(e.category);
                  tbRows.push({ code: acct.code, name: acct.name, group: "expense", debit: e.amount, credit: 0 });
                });
                // Liabilities
                liabilities.forEach((l, i) => {
                  const acct = CHART_OF_ACCOUNTS.find((a) => a.group === "liability")!;
                  tbRows.push({ code: `2${String(i + 1).padStart(3, "0")}`, name: l.label, group: "liability", debit: 0, credit: l.value });
                });
                // Equity
                tbRows.push({ code: "3000", name: "Share Capital", group: "equity", debit: 0, credit: 500_000 });
                tbRows.push({ code: "3100", name: "Retained Earnings", group: "equity", debit: 0, credit: totalAssets - totalLiab - 500_000 });
                // Revenue
                pnl.income.forEach((i) => {
                  const acct = categoryToGLAccount(i.category);
                  tbRows.push({ code: acct.code, name: acct.name, group: "revenue", debit: 0, credit: i.amount });
                });

                const grandDr = tbRows.reduce((s, r) => s + r.debit, 0);
                const grandCr = tbRows.reduce((s, r) => s + r.credit, 0);

                return (
                  <div className="overflow-x-auto rounded-md border">
                    <table className="w-full text-sm">
                      <thead className="bg-emerald-700 text-white">
                        <tr className="text-left">
                          <th className="px-3 py-2 font-semibold w-24">GL Code</th>
                          <th className="px-3 py-2 font-semibold">Account Name</th>
                          <th className="px-3 py-2 font-semibold w-32">Group</th>
                          <th className="px-3 py-2 text-right font-semibold w-32">Debit</th>
                          <th className="px-3 py-2 text-right font-semibold w-32">Credit</th>
                        </tr>
                      </thead>
                      <tbody>
                        {groups.map((g) => {
                          const rows = tbRows.filter((r) => r.group === g);
                          if (rows.length === 0) return null;
                          const subDr = rows.reduce((s, r) => s + r.debit, 0);
                          const subCr = rows.reduce((s, r) => s + r.credit, 0);
                          return (
                            <React.Fragment key={g}>
                              <tr className={cn("font-semibold", ACCOUNT_GROUP_COLOR[g])}>
                                <td className="px-3 py-1.5" colSpan={5}>{ACCOUNT_GROUP_LABELS[g]}</td>
                              </tr>
                              {rows.map((r, i) => (
                                <tr key={`${r.code}-${i}`} className={cn("border-t", i % 2 === 0 ? "bg-muted/20" : "")}>
                                  <td className="px-3 py-1.5 font-mono text-xs">{r.code}</td>
                                  <td className="px-3 py-1.5">{r.name}</td>
                                  <td className="px-3 py-1.5"><span className={cn("rounded px-1.5 py-0.5 text-[10px]", ACCOUNT_GROUP_COLOR[g])}>{ACCOUNT_GROUP_LABELS[g]}</span></td>
                                  <td className="px-3 py-1.5 text-right font-mono">{r.debit > 0 ? fmt(r.debit) : "—"}</td>
                                  <td className="px-3 py-1.5 text-right font-mono">{r.credit > 0 ? fmt(r.credit) : "—"}</td>
                                </tr>
                              ))}
                              <tr className="border-t border-t-2 bg-muted/40 font-semibold">
                                <td className="px-3 py-1.5"></td>
                                <td className="px-3 py-1.5">Subtotal — {ACCOUNT_GROUP_LABELS[g]}</td>
                                <td className="px-3 py-1.5"></td>
                                <td className="px-3 py-1.5 text-right font-mono">{fmt(subDr)}</td>
                                <td className="px-3 py-1.5 text-right font-mono">{fmt(subCr)}</td>
                              </tr>
                            </React.Fragment>
                          );
                        })}
                        <tr className="border-t-2 bg-emerald-600 font-bold text-white">
                          <td className="px-3 py-2" colSpan={3}>GRAND TOTAL</td>
                          <td className="px-3 py-2 text-right font-mono">{fmt(grandDr)}</td>
                          <td className="px-3 py-2 text-right font-mono">{fmt(grandCr)}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                );
              })()}
              <div className="mt-3 grid grid-cols-3 gap-2">
                <div className="rounded bg-emerald-500/10 p-2 text-xs"><div className="text-muted-foreground">Total Debits</div><div className="font-bold">{fmt(totalAssets + pnl.totalExpense)}</div></div>
                <div className="rounded bg-rose-500/10 p-2 text-xs"><div className="text-muted-foreground">Total Credits</div><div className="font-bold">{fmt(totalLiab + pnl.totalIncome)}</div></div>
                <div className={cn("rounded p-2 text-xs", Math.abs((totalAssets + pnl.totalExpense) - (totalLiab + pnl.totalIncome)) < 0.01 ? "bg-emerald-500/15" : "bg-rose-500/15")}>
                  <div className="text-muted-foreground">Balance Check</div>
                  <div className="font-bold">{Math.abs((totalAssets + pnl.totalExpense) - (totalLiab + pnl.totalIncome)) < 0.01 ? "✓ Balanced" : "⚠ Out of balance"}</div>
                </div>
              </div>
              <div className="mt-3 rounded-md border-l-4 border-l-emerald-500 bg-emerald-500/5 p-3 text-xs">
                <div className="font-semibold mb-1">SAP FICO Trial Balance — commentary</div>
                Accounts are organized by GL code range: <strong>1000–1999 Assets</strong>, <strong>2000–2999 Liabilities</strong>, <strong>3000–3999 Equity</strong>, <strong>4000–4999 Revenue</strong>, <strong>5000–5999 Operating Expenses</strong>, <strong>6000–6999 Other Income/Expense</strong>. Each transaction in the General Ledger is auto-coded via the chart of accounts mapping. Debit balances total {fmt(totalAssets + pnl.totalExpense)}; credit balances total {fmt(totalLiab + pnl.totalIncome)}. The difference of {fmt(Math.abs((totalAssets + pnl.totalExpense) - (totalLiab + pnl.totalIncome)))} is posted to Retained Earnings as the period's net profit.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Equity Statement */}
        <TabsContent value="equity" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Statement of Changes in Equity</CardTitle>
                <CardDescription>Period: last 90 days · {cur} · {standard}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => downloadExcel("equity", [
                  {Component:"Share capital", Opening:500000, Movements:0, Closing:500000},
                  {Component:"Retained earnings", Opening:720000, Movements:pnl.netProfit, Closing:720000 + pnl.netProfit},
                  {Component:"Total equity", Opening:1220000, Movements:pnl.netProfit, Closing:1220000 + pnl.netProfit},
                ], "Equity")}><FileSpreadsheet className="size-3.5" /> Excel</Button>
                <Button size="sm" onClick={() => downloadPdf("equity")}><FileText className="size-3.5" /> PDF</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/40">
                    <tr className="text-left text-xs text-muted-foreground">
                      <th className="px-3 py-2 font-medium">Component</th>
                      <th className="px-3 py-2 text-right font-medium">Opening</th>
                      <th className="px-3 py-2 text-right font-medium">Movements</th>
                      <th className="px-3 py-2 text-right font-medium">Closing</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-t">
                      <td className="px-3 py-2 font-medium">Share capital</td>
                      <td className="px-3 py-2 text-right">{fmt(500_000)}</td>
                      <td className="px-3 py-2 text-right">—</td>
                      <td className="px-3 py-2 text-right">{fmt(500_000)}</td>
                    </tr>
                    <tr className="border-t">
                      <td className="px-3 py-2 font-medium">Retained earnings</td>
                      <td className="px-3 py-2 text-right">{fmt(720_000)}</td>
                      <td className={cn("px-3 py-2 text-right", pnl.netProfit >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-destructive")}>
                        {pnl.netProfit >= 0 ? "+" : ""}{fmt(pnl.netProfit)}
                      </td>
                      <td className="px-3 py-2 text-right">{fmt(720_000 + pnl.netProfit)}</td>
                    </tr>
                    <tr className="border-t border-t-2 font-bold">
                      <td className="px-3 py-2">Total equity</td>
                      <td className="px-3 py-2 text-right">{fmt(1_220_000)}</td>
                      <td className="px-3 py-2 text-right">{fmt(pnl.netProfit)}</td>
                      <td className="px-3 py-2 text-right text-emerald-600 dark:text-emerald-400">{fmt(1_220_000 + pnl.netProfit)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="mt-2 text-xs text-muted-foreground">
                Retained earnings movement = net profit for the period ({fmt(pnl.netProfit)}). No dividends declared.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
