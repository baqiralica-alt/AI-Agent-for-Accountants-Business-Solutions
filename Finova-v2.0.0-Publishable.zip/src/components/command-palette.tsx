"use client";

import * as React from "react";
import {
  LayoutDashboard, Bot, Users, Receipt, BookText, Workflow, Plug, Landmark, FileText,
  Building2, Search, CornerDownLeft, ArrowUp, ArrowDown,
} from "lucide-react";
import { Command as CommandPrimitive, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "@/components/ui/command";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useAppStore, type ModuleKey } from "@/lib/store";

const MODULES: Array<{ key: ModuleKey; label: string; icon: React.ElementType; hint: string }> = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, hint: "KPIs & cash flow" },
  { key: "agents", label: "AI Agents", icon: Bot, hint: "Chat with CEO/CFO/Accountant/Tax" },
  { key: "clients", label: "Clients", icon: Users, hint: "Switch or add a client" },
  { key: "transactions", label: "Transactions", icon: Receipt, hint: "Ledger & filters" },
  { key: "journal", label: "Journal Entries", icon: BookText, hint: "Dr/Cr double-entry" },
  { key: "automations", label: "Automations", icon: Workflow, hint: "Recurring tasks" },
  { key: "integrations", label: "Integrations", icon: Plug, hint: "Gmail, banks, software" },
  { key: "tax", label: "Tax Center", icon: Landmark, hint: "Filings & calculators" },
  { key: "reports", label: "Reports", icon: FileText, hint: "P&L / BS / CF / VAT" },
];

export function CommandPalette() {
  const open = useAppStore((s) => s.commandOpen);
  const setOpen = useAppStore((s) => s.setCommandOpen);
  const setActiveModule = useAppStore((s) => s.setActiveModule);
  const companies = useAppStore((s) => s.companies);
  const setActiveCompanyId = useAppStore((s) => s.setActiveCompanyId);

  function run(cb: () => void) {
    cb();
    setOpen(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="overflow-hidden p-0 shadow-lg max-w-2xl" aria-describedby="command-desc">
        <span id="command-desc" className="sr-only">Quick actions palette — jump to modules, switch clients, or open an agent.</span>
        <CommandPrimitive className="flex flex-col" loop>
          <CommandInput placeholder="Type a command or search — e.g. 'add client', 'tax calc', 'switch to Liffey'… " />
          <CommandList className="max-h-[60vh] overflow-y-auto">
            <CommandEmpty>No results found.</CommandEmpty>

            <CommandGroup heading="Navigate">
              {MODULES.map((m) => (
                <CommandItem key={m.key} value={`${m.label} ${m.hint} navigate`} onSelect={() => run(() => setActiveModule(m.key))}>
                  <m.icon className="size-4" />
                  <div className="flex-1">
                    <div className="text-sm">{m.label}</div>
                    <div className="text-[11px] text-muted-foreground">{m.hint}</div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>

            <CommandSeparator />

            <CommandGroup heading="Switch client">
              {companies.map((c) => (
                <CommandItem
                  key={c.id}
                  value={`switch client ${c.name} ${c.industry} ${c.country}`}
                  onSelect={() => run(() => { setActiveCompanyId(c.id); setActiveModule("dashboard"); })}
                >
                  <Building2 className="size-4" />
                  <div className="flex-1">
                    <div className="text-sm">{c.name}</div>
                    <div className="text-[11px] text-muted-foreground">{c.country} · {c.industry} · {c.currency}</div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>

            <CommandSeparator />

            <CommandGroup heading="Quick actions">
              <CommandItem value="add new client" onSelect={() => run(() => setActiveModule("clients"))}>
                <Users className="size-4" /> Add a new client
              </CommandItem>
              <CommandItem value="new journal entry" onSelect={() => run(() => setActiveModule("journal"))}>
                <BookText className="size-4" /> New journal entry
              </CommandItem>
              <CommandItem value="ask cfo agent" onSelect={() => run(() => setActiveModule("agents"))}>
                <Bot className="size-4" /> Ask the CFO agent
              </CommandItem>
              <CommandItem value="run tax calculator" onSelect={() => run(() => setActiveModule("tax"))}>
                <Landmark className="size-4" /> Run the tax calculator
              </CommandItem>
              <CommandItem value="connect gmail" onSelect={() => run(() => setActiveModule("integrations"))}>
                <Plug className="size-4" /> Connect Gmail / accounting software
              </CommandItem>
            </CommandGroup>

            <CommandSeparator />

            <div className="flex items-center justify-between px-3 py-2 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1"><Search className="size-3" /> Filter above</span>
              <span className="flex items-center gap-1"><CornerDownLeft className="size-3" /> to select · <ArrowUp className="size-3" /><ArrowDown className="size-3" /> to navigate</span>
            </div>
          </CommandList>
        </CommandPrimitive>
      </DialogContent>
    </Dialog>
  );
}
