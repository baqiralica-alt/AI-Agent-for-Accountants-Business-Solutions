"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import {
  LayoutDashboard,
  Bot,
  Receipt,
  BookText,
  Workflow,
  Plug,
  Landmark,
  FileText,
  Sun,
  Moon,
  Menu,
  Building2,
  Sparkles,
  Users,
  Command as CommandIcon,
  Upload,
  ReceiptText,
  Code2,
  HelpCircle,
  Layers,
  TrendingUp,
  BookOpen,
  CreditCard,
  Lock,
  AlertTriangle,
  Wallet,
  ChartLine,
  Zap,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAppStore, type ModuleKey } from "@/lib/store";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { CommandPalette } from "@/components/command-palette";

const NAV: Array<{ key: ModuleKey; label: string; icon: React.ElementType; description: string }> = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, description: "KPIs, cash flow, runway" },
  { key: "agents", label: "AI Agents", icon: Bot, description: "CEO / CFO / Accountant / Tax chat" },
  { key: "clients", label: "Clients", icon: Users, description: "Multi-client book of business" },
  { key: "transactions", label: "Transactions", icon: Receipt, description: "Ledger & reconciliation" },
  { key: "journal", label: "Journal Entries", icon: BookText, description: "Dr/Cr double-entry postings" },
  { key: "invoices", label: "Invoices", icon: ReceiptText, description: "Customer & vendor invoices (PDF)" },
  { key: "import", label: "Import Files", icon: Upload, description: "PDF / Excel / CSV → auto-post to GL" },
  { key: "automations", label: "Automations", icon: Workflow, description: "Recurring tasks & email rules" },
  { key: "integrations", label: "Integrations", icon: Plug, description: "Gmail, QuickBooks, Xero, banks" },
  { key: "api", label: "API & Webhooks", icon: Code2, description: "REST endpoints + event webhooks" },
  { key: "tax", label: "Tax Center", icon: Landmark, description: "USA / UK / EU / Canada filings & calculators" },
  { key: "payroll", label: "Payroll", icon: Wallet, description: "USA / UK / EU / Canada salary, deductions, JEs" },
  { key: "market-data", label: "Market Data", icon: ChartLine, description: "FX, rates, ERP, spreads, tax rates — live" },
  { key: "llm-hub", label: "LLM Hub", icon: Zap, description: "Connect to 300+ AI models — free tiers available" },
  { key: "reports", label: "Reports", icon: FileText, description: "P&L, BS, CF, TB (SAP FICO), Equity, VAT, OCI" },
  { key: "consolidation", label: "Consolidation", icon: Layers, description: "Group reporting — IFRS 10 / ASC 810" },
  { key: "corporate-finance", label: "Corporate Finance", icon: TrendingUp, description: "M&A · Valuation · FP&A · FMVA" },
  { key: "disclosures", label: "Disclosures", icon: BookOpen, description: "IAS 1 / US GAAP notes & commentary" },
  { key: "bank-accounts", label: "Bank Accounts", icon: CreditCard, description: "Banks, credit cards, multiple accounts" },
  { key: "help", label: "How to Use", icon: HelpCircle, description: "Plain-English getting started" },
];

function Logo() {
  return (
    <div className="flex items-center gap-2 px-2">
      <div className="flex size-9 items-center justify-center rounded-md bg-emerald-500 text-white shadow-sm">
        <Sparkles className="size-5" />
      </div>
      <div className="leading-tight">
        <div className="text-sm font-bold tracking-tight">Finova</div>
        <div className="text-[9px] text-muted-foreground">Finance · Accounting · AI Agents · USA/UK/EU</div>
      </div>
    </div>
  );
}

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const activeModule = useAppStore((s) => s.activeModule);
  const setActiveModule = useAppStore((s) => s.setActiveModule);
  return (
    <nav className="flex flex-col gap-1 px-2 py-3" aria-label="Primary">
      {NAV.map((item) => {
        const Icon = item.icon;
        const active = activeModule === item.key;
        return (
          <button
            key={item.key}
            onClick={() => {
              setActiveModule(item.key);
              onNavigate?.();
            }}
            className={cn(
              "group flex w-full items-start gap-3 rounded-md px-3 py-2 text-left transition-colors",
              active
                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            )}
          >
            <Icon className={cn("mt-0.5 size-4 shrink-0", active && "text-emerald-500")} />
            <div className="min-w-0 flex-1">
              <div className="text-sm font-medium leading-tight">{item.label}</div>
              <div className="truncate text-[11px] text-muted-foreground">{item.description}</div>
            </div>
          </button>
        );
      })}
    </nav>
  );
}

function CompanySwitcher() {
  const companies = useAppStore((s) => s.companies);
  const activeCompanyId = useAppStore((s) => s.activeCompanyId);
  const setActiveCompanyId = useAppStore((s) => s.setActiveCompanyId);
  const activeCompany = useAppStore((s) => s.activeCompany);

  if (companies.length === 0) {
    return (
      <div className="px-3 py-2 text-xs text-muted-foreground">Loading clients…</div>
    );
  }

  return (
    <div className="px-2">
      <Select value={activeCompanyId} onValueChange={setActiveCompanyId}>
        <SelectTrigger className="w-full">
          <div className="flex w-full items-center gap-2">
            <Building2 className="size-4 text-muted-foreground" />
            <SelectValue placeholder="Select client" />
          </div>
        </SelectTrigger>
        <SelectContent>
          {companies.map((c) => (
            <SelectItem key={c.id} value={c.id}>
              <div className="flex flex-col">
                <span className="text-sm font-medium">{c.name}</span>
                <span className="text-[10px] text-muted-foreground">
                  {c.country} · {c.industry} · {c.currency}
                </span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {activeCompany && (
        <div className="mt-1 px-1 text-[10px] text-muted-foreground">
          {activeCompany.industry} · Tax ID {activeCompany.taxId ?? "n/a"}
        </div>
      )}
    </div>
  );
}

function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);
  if (!mounted) {
    return <Button variant="ghost" size="icon" aria-label="Toggle theme"><Sun className="size-4" /></Button>;
  }
  return (
    <Button
      variant="ghost"
      size="icon"
      aria-label="Toggle theme"
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
    >
      {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
    </Button>
  );
}

function CommandBarButton() {
  const setCommandOpen = useAppStore((s) => s.setCommandOpen);
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={() => setCommandOpen(true)}
      className="hidden md:inline-flex"
      aria-label="Open command palette"
    >
      <CommandIcon className="size-3.5" />
      <span className="text-xs">Quick actions</span>
      <kbd className="ml-2 rounded border bg-muted px-1 text-[10px] font-mono">⌘K</kbd>
    </Button>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const isMobile = useIsMobile();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const activeCompany = useAppStore((s) => s.activeCompany);
  const setCommandOpen = useAppStore((s) => s.setCommandOpen);
  const setActiveModule = useAppStore((s) => s.setActiveModule);

  // Cmd/Ctrl+K to open command palette
  React.useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCommandOpen(true);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setCommandOpen]);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <CommandPalette />

      {/* Top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        {isMobile && (
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Open menu">
                <Menu className="size-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0">
              <SheetHeader className="border-b px-0 py-0">
                <SheetTitle className="m-0">
                  <Logo />
                </SheetTitle>
              </SheetHeader>
              <div className="flex h-[calc(100%-3.5rem)] flex-col">
                <div className="py-3"><CompanySwitcher /></div>
                <div className="flex-1 overflow-y-auto"><NavList onNavigate={() => setMobileOpen(false)} /></div>
              </div>
            </SheetContent>
          </Sheet>
        )}

        {!isMobile && <Logo />}

        <div className="ml-auto flex items-center gap-2">
          <CommandBarButton />
          {activeCompany && (
            <div className="hidden text-right md:block">
              <div className="text-xs font-medium leading-tight">{activeCompany.name}</div>
              <div className="text-[10px] text-muted-foreground">
                {activeCompany.country} · {activeCompany.currency} · {activeCompany.industry}
              </div>
            </div>
          )}
          <ThemeToggle />
        </div>
      </header>

      <div className="flex flex-1">
        {/* Desktop sidebar */}
        {!isMobile && (
          <aside className="sticky top-14 hidden h-[calc(100vh-3.5rem)] w-64 shrink-0 border-r bg-background md:block">
            <div className="flex h-full flex-col">
              <div className="py-3"><CompanySwitcher /></div>
              <div className="flex-1 overflow-y-auto"><NavList /></div>
              <div className="border-t p-3 text-[10px] text-muted-foreground">
                <div className="mb-1 flex items-center gap-1.5">
                  <Sparkles className="size-3 text-emerald-500" />
                  <span className="font-medium text-foreground">Finova</span>
                </div>
                <div>Advisory outputs — verify with a licensed local CPA before filing.</div>
              </div>
            </div>
          </aside>
        )}

        {/* Main */}
        <main className="min-w-0 flex-1">
          {activeCompany?.paymentStatus === "blocked" && (
            <div className="flex items-center gap-3 border-b border-rose-500/30 bg-rose-500/10 px-4 py-3 text-rose-700 dark:text-rose-300">
              <Lock className="size-5 shrink-0" />
              <div className="flex-1 text-sm">
                <strong>Client access blocked.</strong> Subscription is unpaid. Update payment status in the Clients tab to restore access for {activeCompany.name}.
              </div>
              <Button size="sm" variant="outline" onClick={() => setActiveModule("clients")}>Manage</Button>
            </div>
          )}
          {activeCompany?.paymentStatus === "overdue" && (
            <div className="flex items-center gap-3 border-b border-amber-500/30 bg-amber-500/10 px-4 py-3 text-amber-700 dark:text-amber-300">
              <AlertTriangle className="size-5 shrink-0" />
              <div className="flex-1 text-sm">
                <strong>Subscription overdue.</strong> Payment is past due for {activeCompany.name}. Access will be blocked if not resolved.
              </div>
              <Button size="sm" variant="outline" onClick={() => setActiveModule("clients")}>Update</Button>
            </div>
          )}
          {children}
        </main>
      </div>

      <footer className="mt-auto border-t bg-background px-4 py-4 text-center text-[11px] text-muted-foreground">
        Finova — Finance · Accounting · AI Agents. Accounting, decision-making, automation &amp; tax for Construction, Real Estate, Retail, SaaS, AI and Manufacturing across USA, UK &amp; EU.
        Outputs are advisory and should be reviewed by a licensed local adviser.
      </footer>
    </div>
  );
}
