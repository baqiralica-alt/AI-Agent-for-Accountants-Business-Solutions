import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Finova — Finance · Accounting · AI Agents · USA / UK / EU",
  description:
    "Finova — a complete AI accounting & finance platform for multi-client, multi-industry practices. CEOs/CFOs/Accountants/Tax agents work across Construction, Real Estate, Retail, SaaS, AI and Manufacturing in the USA, UK and EU.",
  keywords: [
    "Finova",
    "AI CFO",
    "AI accountant",
    "tax USA UK EU",
    "audit",
    "construction accounting",
    "real estate accounting",
    "retail accounting",
    "SaaS accounting",
    "AI startup R&D credit",
    "multi-client accounting",
    "QuickBooks AI",
    "Xero AI",
    "Gmail AI agent",
  ],
  authors: [{ name: "Finova" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
