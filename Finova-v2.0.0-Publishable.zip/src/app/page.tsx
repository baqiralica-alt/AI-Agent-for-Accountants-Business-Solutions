"use client";

import * as React from "react";
import { AppShell } from "@/components/app-shell";
import { DashboardModule } from "@/components/modules/dashboard";
import { AgentsModule } from "@/components/modules/agents";
import { ClientsModule } from "@/components/modules/clients";
import { TransactionsModule } from "@/components/modules/transactions";
import { JournalModule } from "@/components/modules/journal";
import { InvoicesModule } from "@/components/modules/invoices";
import { ImportModule } from "@/components/modules/import";
import { AutomationsModule } from "@/components/modules/automations";
import { IntegrationsModule } from "@/components/modules/integrations";
import { ApiModule } from "@/components/modules/api-webhooks";
import { TaxModule } from "@/components/modules/tax";
import { PayrollModule } from "@/components/modules/payroll";
import { MarketDataModule } from "@/components/modules/market-data";
import { LLMHubModule } from "@/components/modules/llm-hub";
import { ReportsModule } from "@/components/modules/financial-reports";
import { ConsolidationModule } from "@/components/modules/consolidation";
import { CorporateFinanceModule } from "@/components/modules/corporate-finance";
import { DisclosuresModule } from "@/components/modules/disclosures";
import { BankAccountsModule } from "@/components/modules/bank-accounts";
import { HelpModule } from "@/components/modules/help";
import { useAppStore } from "@/lib/store";

export default function Home() {
  const activeModule = useAppStore((s) => s.activeModule);
  const companies = useAppStore((s) => s.companies);
  const companiesLoaded = useAppStore((s) => s.companiesLoaded);
  const setCompanies = useAppStore((s) => s.setCompanies);
  const setCompaniesLoaded = useAppStore((s) => s.setCompaniesLoaded);
  const reloadCompaniesFlag = useAppStore((s) => s.reloadCompaniesFlag);

  React.useEffect(() => {
    fetch("/api/companies")
      .then((r) => r.json())
      .then((d) => {
        if (d.companies) setCompanies(d.companies);
      })
      .catch((e) => console.error("Failed to load companies", e))
      .finally(() => setCompaniesLoaded(true));
  }, [reloadCompaniesFlag, setCompanies, setCompaniesLoaded]);

  return (
    <AppShell>
      {activeModule === "dashboard" && <DashboardModule />}
      {activeModule === "agents" && <AgentsModule />}
      {activeModule === "clients" && <ClientsModule />}
      {activeModule === "transactions" && <TransactionsModule />}
      {activeModule === "journal" && <JournalModule />}
      {activeModule === "invoices" && <InvoicesModule />}
      {activeModule === "import" && <ImportModule />}
      {activeModule === "automations" && <AutomationsModule />}
      {activeModule === "integrations" && <IntegrationsModule />}
      {activeModule === "api" && <ApiModule />}
      {activeModule === "tax" && <TaxModule />}
      {activeModule === "payroll" && <PayrollModule />}
      {activeModule === "market-data" && <MarketDataModule />}
      {activeModule === "llm-hub" && <LLMHubModule />}
      {activeModule === "reports" && <ReportsModule />}
      {activeModule === "consolidation" && <ConsolidationModule />}
      {activeModule === "corporate-finance" && <CorporateFinanceModule />}
      {activeModule === "disclosures" && <DisclosuresModule />}
      {activeModule === "bank-accounts" && <BankAccountsModule />}
      {activeModule === "help" && <HelpModule />}
    </AppShell>
  );
}
