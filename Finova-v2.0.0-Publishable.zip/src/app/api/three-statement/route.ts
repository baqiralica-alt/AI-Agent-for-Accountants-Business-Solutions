import { NextResponse } from "next/server";
import { THREE_STATEMENT_MODEL, MODEL_META, ASSUMPTIONS, YEARS } from "@/lib/three-statement-model";

// GET /api/three-statement
// Returns the full 3-statement model (IS + BS + CF + KPIs) for Meridian Capital Holdings,
// driven by user-modifiable blue-cell assumptions. All formulas linked.

export async function GET() {
  return NextResponse.json({
    ...THREE_STATEMENT_MODEL,
    meta: MODEL_META,
    years: YEARS,
    assumptions: ASSUMPTIONS,
  });
}
