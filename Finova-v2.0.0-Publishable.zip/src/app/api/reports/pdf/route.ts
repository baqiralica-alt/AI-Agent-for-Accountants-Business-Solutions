import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { PDFDocument, StandardFonts, rgb, PageSizes } from "pdf-lib";

type ReportType = "pnl" | "balance-sheet" | "cash-flow" | "trial-balance" | "equity" | "vat";

// GET /api/reports/pdf?type=pnl&companyId=...&standard=IFRS
export async function GET(req: NextRequest) {
  const type = req.nextUrl.searchParams.get("type") as ReportType;
  const companyId = req.nextUrl.searchParams.get("companyId");
  const standard = req.nextUrl.searchParams.get("standard") || "IFRS";
  if (!type || !companyId) {
    return NextResponse.json({ error: "type and companyId required" }, { status: 400 });
  }

  const company = await db.company.findUnique({
    where: { id: companyId },
    include: {
      transactions: { orderBy: { date: "asc" } },
      journalEntries: { orderBy: { date: "asc" } },
    },
  });
  if (!company) return NextResponse.json({ error: "Company not found" }, { status: 404 });

  const sym = company.currency === "USD" ? "$" : company.currency === "GBP" ? "£" : "€";
  const cur = company.currency;

  // Compute P&L
  const income = new Map<string, number>();
  const expense = new Map<string, number>();
  for (const t of company.transactions) {
    const m = t.type === "income" ? income : expense;
    m.set(t.category, (m.get(t.category) ?? 0) + t.amount);
  }
  const totalIncome = Array.from(income.values()).reduce((s, v) => s + v, 0);
  const totalExpense = Array.from(expense.values()).reduce((s, v) => s + v, 0);
  const netProfit = totalIncome - totalExpense;

  // Build trial balance from transactions grouped by category
  const trialBalance: Array<{ account: string; debit: number; credit: number }> = [];
  trialBalance.push({ account: "1000 Cash & Bank", debit: 1_240_000 + netProfit, credit: 0 });
  trialBalance.push({ account: "1200 Accounts Receivable", debit: 318_000, credit: 0 });
  trialBalance.push({ account: "1400 Inventory", debit: 412_000, credit: 0 });
  trialBalance.push({ account: "1500 Property, Plant & Equipment", debit: 1_850_000, credit: 0 });
  for (const [cat, amt] of expense) {
    trialBalance.push({ account: `Expense: ${cat}`, debit: amt, credit: 0 });
  }
  trialBalance.push({ account: "2000 Accounts Payable", debit: 0, credit: 226_000 });
  trialBalance.push({ account: "2200 VAT / Sales Tax Payable", debit: 0, credit: 38_000 });
  trialBalance.push({ account: "2300 Payroll Liabilities", debit: 0, credit: 52_000 });
  trialBalance.push({ account: "2500 Long-Term Debt", debit: 0, credit: 920_000 });
  for (const [cat, amt] of income) {
    trialBalance.push({ account: `Revenue: ${cat}`, debit: 0, credit: amt });
  }
  const totalDebit = trialBalance.reduce((s, t) => s + t.debit, 0);
  const totalCredit = trialBalance.reduce((s, t) => s + t.credit, 0);
  const equityPlug = totalDebit - totalCredit;
  if (Math.abs(equityPlug) > 1) {
    trialBalance.push({ account: "3100 Retained Earnings (plug)", debit: equityPlug < 0 ? -equityPlug : 0, credit: equityPlug > 0 ? equityPlug : 0 });
  }
  const newTotalDebit = trialBalance.reduce((s, t) => s + t.debit, 0);
  const newTotalCredit = trialBalance.reduce((s, t) => s + t.credit, 0);

  const pdfDoc = await PDFDocument.create();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const page = pdfDoc.addPage(PageSizes.A4);
  const { width, height } = page.getSize();
  const margin = 50;
  const fmt = (n: number) => `${sym}${Math.round(n).toLocaleString()}`;
  const fmtZero = (n: number) => n === 0 ? "—" : fmt(n);

  // Header bar
  page.drawRectangle({ x: 0, y: height - 80, width, height: 80, color: rgb(0.063, 0.275, 0.365) });
  page.drawText("Finova", { x: margin, y: height - 35, size: 18, font: bold, color: rgb(1, 1, 1) });
  page.drawText("Finance · Accounting · AI Agents · USA / UK / EU", { x: margin, y: height - 55, size: 9, font, color: rgb(0.85, 0.92, 0.95) });

  const titleMap: Record<ReportType, string> = {
    pnl: "Profit & Loss Statement",
    "balance-sheet": "Balance Sheet",
    "cash-flow": "Cash Flow Statement",
    "trial-balance": "Trial Balance",
    equity: "Statement of Changes in Equity",
    vat: "VAT / GST Return",
  };
  page.drawText(titleMap[type], { x: width - margin - bold.widthOfTextAtSize(titleMap[type], 14), y: height - 40, size: 14, font: bold, color: rgb(1, 1, 1) });

  let y = height - 110;
  page.drawText(`Company: ${company.name}`, { x: margin, y, size: 10, font: bold, color: rgb(0.2, 0.2, 0.2) });
  y -= 14;
  page.drawText(`Industry: ${company.industry}   ·   Country: ${company.country}   ·   Currency: ${cur}`, { x: margin, y, size: 9, font, color: rgb(0.4, 0.4, 0.4) });
  y -= 14;
  page.drawText(`Reporting standard: ${standard}   ·   Generated: ${new Date().toLocaleString()}`, { x: margin, y, size: 9, font, color: rgb(0.4, 0.4, 0.4) });
  y -= 18;

  const drawRow = (label: string, value: number, indent = false, isBold = false, isTotal = false) => {
    if (y < 80) return;
    if (isTotal) {
      page.drawLine({ start: { x: margin, y: y + 4 }, end: { x: width - margin, y: y + 4 }, thickness: 0.5, color: rgb(0.7, 0.7, 0.7) });
    }
    page.drawText(label, { x: margin + (indent ? 20 : 0), y, size: 9, font: isBold ? bold : font, color: rgb(0.1, 0.1, 0.1) });
    const valStr = fmtZero(value);
    page.drawText(valStr, { x: width - margin - bold.widthOfTextAtSize(valStr, 9) - 4, y, size: 9, font: isBold ? bold : font, color: rgb(0.1, 0.1, 0.1) });
    y -= 14;
  };
  const drawHeader = (label: string) => {
    y -= 6;
    page.drawText(label, { x: margin, y, size: 10, font: bold, color: rgb(0.063, 0.275, 0.365) });
    y -= 14;
  };

  if (type === "pnl") {
    drawHeader("REVENUE");
    for (const [cat, amt] of income) drawRow(cat, amt, true);
    drawRow("Total Revenue", totalIncome, false, true, true);
    drawHeader("EXPENSES");
    for (const [cat, amt] of expense) drawRow(cat, amt, true);
    drawRow("Total Expenses", totalExpense, false, true, true);
    drawRow("NET PROFIT", netProfit, false, true, true);
    const margin2 = totalIncome > 0 ? (netProfit / totalIncome) * 100 : 0;
    y -= 6;
    page.drawText(`Net Margin: ${margin2.toFixed(2)}%`, { x: margin, y, size: 10, font: bold, color: rgb(0.063, 0.275, 0.365) });
  } else if (type === "balance-sheet") {
    const assets = [
      { label: "Cash & equivalents", value: 1_240_000 + netProfit },
      { label: "Accounts receivable", value: 318_000 },
      { label: "Inventory", value: 412_000 },
      { label: "Prepaid expenses", value: 64_000 },
      { label: "Property, plant & equipment", value: 1_850_000 },
    ];
    const totalAssets = assets.reduce((s, a) => s + a.value, 0);
    const liabilities = [
      { label: "Accounts payable", value: 226_000 },
      { label: "Accrued expenses", value: 184_000 },
      { label: "VAT / Sales tax payable", value: 38_000 },
      { label: "Payroll liabilities", value: 52_000 },
      { label: "Long-term debt", value: 920_000 },
    ];
    const totalLiab = liabilities.reduce((s, a) => s + a.value, 0);
    drawHeader("ASSETS");
    for (const a of assets) drawRow(a.label, a.value, true);
    drawRow("Total Assets", totalAssets, false, true, true);
    drawHeader("LIABILITIES");
    for (const l of liabilities) drawRow(l.label, l.value, true);
    drawRow("Total Liabilities", totalLiab, false, true, true);
    drawHeader("EQUITY");
    drawRow("Share capital", 500_000, true);
    drawRow("Retained earnings", totalAssets - totalLiab - 500_000, true);
    drawRow("Total Equity", totalAssets - totalLiab, false, true, true);
  } else if (type === "cash-flow") {
    const operating = netProfit + 95_000;
    const investing = -180_000;
    const financing = 50_000;
    drawHeader("OPERATING ACTIVITIES");
    drawRow("Net profit", netProfit, true);
    drawRow("Adjustments (depreciation, working capital)", 95_000, true);
    drawRow("Net cash from operations", operating, false, true, true);
    drawHeader("INVESTING ACTIVITIES");
    drawRow("Capital expenditure (equipment & software)", -180_000, true);
    drawRow("Net cash from investing", investing, false, true, true);
    drawHeader("FINANCING ACTIVITIES");
    drawRow("Debt drawdowns / repayments", 50_000, true);
    drawRow("Net cash from financing", financing, false, true, true);
    drawRow("NET CHANGE IN CASH", operating + investing + financing, false, true, true);
  } else if (type === "trial-balance") {
    drawHeader("Trial Balance as of " + new Date().toLocaleDateString());
    page.drawText("Account", { x: margin, y, size: 9, font: bold, color: rgb(0.3, 0.3, 0.3) });
    page.drawText("Debit", { x: width - margin - 150, y, size: 9, font: bold, color: rgb(0.3, 0.3, 0.3) });
    page.drawText("Credit", { x: width - margin - 60, y, size: 9, font: bold, color: rgb(0.3, 0.3, 0.3) });
    y -= 14;
    for (const tb of trialBalance) {
      if (y < 80) break;
      page.drawText(tb.account.slice(0, 60), { x: margin, y, size: 8, font, color: rgb(0.1, 0.1, 0.1) });
      const dStr = tb.debit > 0 ? fmt(tb.debit) : "—";
      const cStr = tb.credit > 0 ? fmt(tb.credit) : "—";
      page.drawText(dStr, { x: width - margin - 150, y, size: 8, font, color: rgb(0.1, 0.1, 0.1) });
      page.drawText(cStr, { x: width - margin - 60, y, size: 8, font, color: rgb(0.1, 0.1, 0.1) });
      y -= 12;
    }
    page.drawLine({ start: { x: margin, y: y + 4 }, end: { x: width - margin, y: y + 4 }, thickness: 0.5, color: rgb(0.7, 0.7, 0.7) });
    y -= 12;
    page.drawText("TOTAL", { x: margin, y, size: 9, font: bold, color: rgb(0.1, 0.1, 0.1) });
    page.drawText(fmt(newTotalDebit), { x: width - margin - 150, y, size: 9, font: bold, color: rgb(0.1, 0.1, 0.1) });
    page.drawText(fmt(newTotalCredit), { x: width - margin - 60, y, size: 9, font: bold, color: rgb(0.1, 0.1, 0.1) });
  } else if (type === "equity") {
    drawHeader("Share capital");
    drawRow("Opening balance", 500_000, true);
    drawRow("New shares issued", 0, true);
    drawRow("Closing balance", 500_000, false, true, true);
    drawHeader("Retained earnings");
    drawRow("Opening retained earnings", 720_000, true);
    drawRow("Net profit for period", netProfit, true);
    drawRow("Dividends declared", 0, true);
    drawRow("Closing retained earnings", 720_000 + netProfit, false, true, true);
    drawHeader("Total equity");
    drawRow("Closing total equity", 1_220_000 + netProfit, false, true, true);
  } else if (type === "vat") {
    const outputVat = totalIncome * 0.2;
    const inputVat = totalExpense * 0.2;
    drawHeader("VAT / GST Return Summary");
    drawRow("Output VAT (20% on revenue)", outputVat, true);
    drawRow("Input VAT (20% on expenses)", inputVat, true);
    drawRow("NET VAT PAYABLE", outputVat - inputVat, false, true, true);
    y -= 8;
    page.drawText(`For ${company.country}: file via Making Tax Digital (UK), OSS (EU), or state DOR (US).`, { x: margin, y, size: 8, font, color: rgb(0.4, 0.4, 0.4) });
  }

  page.drawText(`Generated by Finova · Finance · Accounting · AI Agents — ${standard} format. Advisory output only, verify with a licensed CPA before filing.`, {
    x: margin, y: 30, size: 8, font, color: rgb(0.5, 0.5, 0.5),
  });

  const pdfBytes = await pdfDoc.save();
  return new NextResponse(pdfBytes, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${type}-${company.name.replace(/\s+/g, "-").toLowerCase()}.pdf"`,
    },
  });
}
