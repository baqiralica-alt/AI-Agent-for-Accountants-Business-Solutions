import { NextResponse } from "next/server";
import { LLM_PROVIDERS, LLM_STATS, LLM_USE_CASE_DESCRIPTIONS, LLM_HUB_META } from "@/lib/llm-hub-data";

export async function GET() {
  return NextResponse.json({
    meta: LLM_HUB_META,
    providers: LLM_PROVIDERS,
    stats: LLM_STATS,
    useCaseDescriptions: LLM_USE_CASE_DESCRIPTIONS,
  });
}
