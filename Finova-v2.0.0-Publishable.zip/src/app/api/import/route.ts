import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import * as XLSX from "xlsx";
import type { ParsedTxn } from "@/lib/import-types";
import { categoryToGLAccount, glCodeForCategory } from "@/lib/chart-of-accounts";

type ParsedRow = {
  date?: string;
  description?: string;
  amount?: number;
  type?: "income" | "expense";
  category?: string;
  account?: string;
};

// Heuristic column matching — find the right column for date / description / amount / type
function mapColumns(rows: any[]): ParsedRow[] {
  if (rows.length === 0) return [];
  const sample = rows[0];
  const keys = Object.keys(sample);
  const lower = (s: string) => s.toLowerCase().trim();
  const findKey = (candidates: string[]) => keys.find((k) => candidates.some((c) => lower(k).includes(c)));

  const dateKey = findKey(["date", "txn", "transaction date", "posted", "post date", "value date"]);
  const descKey = findKey(["desc", "memo", "narrative", "detail", "name", "particular", "payee", "vendor"]);
  const amountKey = findKey(["amount", "value", "total", "credit/debit", "net"]);
  const creditKey = findKey(["credit", "deposit", "inflow"]);
  const debitKey = findKey(["debit", "withdrawal", "outflow"]);
  const categoryKey = findKey(["category", "type", "class"]);
  const accountKey = findKey(["account", "gl", "ledger"]);

  return rows.map((r) => {
    let amount: number | undefined;
    let type: "income" | "expense" | undefined;
    if (creditKey && debitKey) {
      const cr = Number(r[creditKey] ?? 0) || 0;
      const dr = Number(r[debitKey] ?? 0) || 0;
      if (cr > 0) { amount = cr; type = "income"; }
      else if (dr > 0) { amount = dr; type = "expense"; }
    }
    if (amount === undefined && amountKey) {
      const raw = String(r[amountKey] ?? "").replace(/[, $£€]/g, "").replace(/\((.*)\)/, "-$1");
      const n = Number(raw);
      if (!isNaN(n) && n !== 0) {
        amount = Math.abs(n);
        type = n > 0 ? "income" : "expense";
      }
    }
    return {
      date: dateKey ? String(r[dateKey] ?? "") : "",
      description: descKey ? String(r[descKey] ?? "") : "",
      amount,
      type,
      category: categoryKey ? String(r[categoryKey] ?? "") : undefined,
      account: accountKey ? String(r[accountKey] ?? "") : undefined,
    } as ParsedRow;
  }).filter((r) => r.amount !== undefined && r.amount > 0);
}

function parseCSV(text: string): any[] {
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) return [];
  const parseLine = (line: string): string[] => {
    const out: string[] = [];
    let cur = "";
    let inQuote = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQuote) {
        if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (ch === '"') inQuote = false;
        else cur += ch;
      } else {
        if (ch === '"') inQuote = true;
        else if (ch === ",") { out.push(cur); cur = ""; }
        else cur += ch;
      }
    }
    out.push(cur);
    return out;
  };
  const headers = parseLine(lines[0]).map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cells = parseLine(line);
    const obj: any = {};
    headers.forEach((h, i) => { obj[h] = cells[i]?.trim() ?? ""; });
    return obj;
  });
}

function parseDate(s: string): Date {
  if (!s) return new Date();
  const iso = new Date(s);
  if (!isNaN(iso.getTime())) return iso;
  const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (m) {
    const a = Number(m[1]), b = Number(m[2]);
    let year = Number(m[3]);
    if (year < 100) year += 2000;
    if (a > 12) return new Date(year, b - 1, a);
    return new Date(year, a - 1, b);
  }
  const serial = Number(s);
  if (!isNaN(serial) && serial > 30000 && serial < 60000) {
    return new Date(Date.UTC(1899, 11, 30) + serial * 24 * 60 * 60 * 1000);
  }
  return new Date();
}

function guessCategory(description: string): string {
  const d = description.toLowerCase();
  if (/payroll|salary|wage/.test(d)) return "Payroll";
  if (/aws|google cloud|azure|cloud|hosting|server/.test(d)) return "AWS infrastructure";
  if (/stripe|paypal|square|payout/.test(d)) return "Stripe payout";
  if (/rent|lease.*property/.test(d)) return "Office rent";
  if (/advertis|marketing|google ads|facebook/.test(d)) return "Marketing campaign spend";
  if (/travel|uber|flight|hotel|taxi/.test(d)) return "Travel expense";
  if (/utility|electric|water|gas.*bill/.test(d)) return "Utilities";
  if (/insurance/.test(d)) return "Insurance premium";
  if (/material|supply|inventory|cogs/.test(d)) return "Raw Materials";
  if (/refund/.test(d)) return "Refund processed";
  if (/fee|charge|interest/.test(d)) return "Bank fee";
  if (/invoice|payment received/.test(d)) return "Customer invoice paid";
  return "Office Supplies";
}

// Map file MIME type / extension → fileType
function detectFileType(fileName: string): string {
  const n = fileName.toLowerCase();
  if (n.endsWith(".pdf")) return "pdf";
  if (n.endsWith(".xlsx") || n.endsWith(".xls")) return "xlsx";
  if (n.endsWith(".csv")) return "csv";
  if (n.endsWith(".xml")) return "xml";
  if (n.endsWith(".json")) return "json";
  if (n.endsWith(".txt")) return "txt";
  if (n.endsWith(".docx")) return "docx";
  if (n.endsWith(".doc")) return "doc";
  if (n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp")) return "image";
  if (n.endsWith(".tsv")) return "csv";
  if (n.endsWith(".html") || n.endsWith(".htm")) return "html";
  return "unknown";
}

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const companyId = formData.get("companyId") as string;
    const file = formData.get("file") as File;
    if (!companyId || !file) {
      return NextResponse.json({ error: "companyId and file are required" }, { status: 400 });
    }
    const company = await db.company.findUnique({ where: { id: companyId } });
    if (!company) return NextResponse.json({ error: "Company not found" }, { status: 404 });

    const fileName = file.name;
    const fileType = detectFileType(fileName);

    // Create ImportedFile record
    const importedFile = await db.importedFile.create({
      data: { companyId, fileName, fileType, fileSize: file.size, status: "pending" },
    });

    let parsedRows: ParsedRow[] = [];
    let extractedText = "";
    let extractionMethod = "structured";

    // ---------- STRUCTURED PARSING ----------
    if (fileType === "csv" || fileType === "tsv") {
      const text = await file.text();
      extractedText = text.slice(0, 4000);
      parsedRows = mapColumns(parseCSV(text));
    } else if (fileType === "xlsx" || fileType === "xls") {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(Buffer.from(buf), { type: "buffer" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<any>(sheet, { defval: "" });
      extractedText = JSON.stringify(rows.slice(0, 10)).slice(0, 4000);
      parsedRows = mapColumns(rows);
    } else if (fileType === "json") {
      const text = await file.text();
      const data = JSON.parse(text);
      const arr = Array.isArray(data) ? data : Array.isArray(data.transactions) ? data.transactions : [data];
      extractedText = JSON.stringify(arr.slice(0, 10)).slice(0, 4000);
      parsedRows = mapColumns(arr);
    } else if (fileType === "xml") {
      const text = await file.text();
      extractedText = text.slice(0, 4000);
      const re = /<(?:Date|DATE|Amt|AMT|Amount|AMOUNT|Desc|DESC|Description|DESCRIPTION)>([^<]+)<\/(?:Date|DATE|Amt|AMT|Amount|AMOUNT|Desc|DESC|Description|DESCRIPTION)>/g;
      const found: Record<string, string> = {};
      let m;
      while ((m = re.exec(text)) !== null) {
        const key = m[0].slice(1, m[0].indexOf(">")).toLowerCase();
        found[key] = m[1];
      }
      if (found.date || found.amt) {
        const amt = Number(found.amt || "0");
        parsedRows = [{ date: found.date || "", description: found.desc || found.description || "Imported from XML", amount: Math.abs(amt), type: amt >= 0 ? "income" : "expense" }];
      }
    } else if (fileType === "html") {
      const text = await file.text();
      // Strip HTML tags, then try CSV parsing on what's left
      const stripped = text.replace(/<[^>]+>/g, ",").replace(/\n/g, "\n").replace(/,+/g, ",").trim();
      extractedText = stripped.slice(0, 4000);
      // Try parsing remaining text as CSV
      const lines = stripped.split("\n").filter((l) => l.trim().split(",").length >= 3);
      if (lines.length > 1) {
        const rows = lines.map((line) => {
          const cells = line.split(",");
          const obj: any = {};
          // Heuristic: assume cells in order
          if (cells[0]) obj.Date = cells[0];
          if (cells[1]) obj.Description = cells[1];
          if (cells[2]) obj.Amount = cells[2];
          return obj;
        });
        parsedRows = mapColumns(rows);
      }
    } else if (fileType === "pdf") {
      const pdfParse = (await import("pdf-parse")).default;
      const buf = await file.arrayBuffer();
      const pdfData = await pdfParse(Buffer.from(buf));
      extractedText = pdfData.text.slice(0, 6000);
      // Bank-statement PDFs: try regex for date, description, amount
      const lines = pdfData.text.split(/\r?\n/);
      const txnLine = /^(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})\s+(.+?)\s+(-?[\d,]+\.\d{2})$/;
      for (const line of lines) {
        const m = line.trim().match(txnLine);
        if (m) {
          const amt = Number(m[3].replace(/,/g, ""));
          parsedRows.push({ date: m[1], description: m[2].trim(), amount: Math.abs(amt), type: amt > 0 ? "income" : "expense" });
        }
      }
    } else if (fileType === "txt" || fileType === "docx" || fileType === "doc") {
      // Plain text or Word — read what we can
      let text: string;
      if (fileType === "docx") {
        // Try mammoth-style extraction (no extra dep); fall back to raw text
        try {
          const buf = await file.arrayBuffer();
          // .docx is a zip — extract just the document.xml
          const { execSync } = await import("child_process");
          // Skip and just read as text
          text = `Word document — ${fileName}. Please paste the contents into the AI Agent chat or upload as PDF/Excel/CSV for direct import.`;
        } catch {
          text = await file.text();
        }
      } else {
        text = await file.text();
      }
      extractedText = text.slice(0, 6000);
      // Try parsing as CSV / TSV first
      const maybeRows = parseCSV(text);
      if (maybeRows.length > 0) {
        parsedRows = mapColumns(maybeRows);
      } else {
        // Try regex on each line
        const lines = text.split(/\r?\n/);
        const txnLine = /(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}).*?(-?\$?[\d,]+\.\d{2})/g;
        for (const line of lines) {
          const m = [...line.matchAll(txnLine)];
          if (m.length > 0) {
            for (const match of m) {
              const amt = Number(match[2].replace(/[$,]/g, ""));
              const desc = line.replace(match[0], "").trim().slice(0, 80);
              if (amt > 0) {
                parsedRows.push({ date: match[1], description: desc || "Imported from text file", amount: Math.abs(amt), type: amt > 0 ? "expense" : "income" });
              }
            }
          }
        }
      }
    } else if (fileType === "image") {
      // Use z-ai vision API to extract transactions from a screenshot/photo of a receipt/statement
      const buf = await file.arrayBuffer();
      const base64 = Buffer.from(buf).toString("base64");
      const mime = fileName.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg";
      extractionMethod = "ai-vision";
      try {
        const ZAI = (await import("z-ai-web-dev-sdk")).default;
        const zai = await ZAI.create();
        const vision = await zai.chat.completions.createVision({
          messages: [{
            role: "user",
            content: [
              { type: "text", text: "You are an accounting data extractor. Read this receipt/bank statement/invoice image and extract every transaction as JSON. Output ONLY a JSON array (no markdown, no commentary) like: [{\"date\":\"YYYY-MM-DD\",\"description\":\"vendor name\",\"amount\":12.34,\"type\":\"expense\" or \"income\"}]. Use type=income for deposits/refunds received, type=expense for payments/charges." },
              { type: "image_url", image_url: { url: `data:${mime};base64,${base64}` } },
            ],
          }],
        });
        const content = vision.choices[0]?.message?.content ?? "[]";
        extractedText = content.slice(0, 4000);
        // Parse the JSON array from the response
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          const arr = JSON.parse(jsonMatch[0]);
          parsedRows = arr.map((r: any) => ({
            date: r.date, description: r.description, amount: Number(r.amount), type: r.type === "income" ? "income" : "expense", category: r.category,
          }));
        }
      } catch (e: any) {
        return NextResponse.json({
          importedFileId: importedFile.id, fileName, fileType, parsedCount: 0, postedCount: 0,
          extractedTextPreview: `AI vision extraction failed: ${e.message}. Please convert to CSV/Excel for direct import.`,
          message: "Image recognition unavailable. Please upload a CSV/Excel version of the data, or paste the text into the AI Agent chat.",
        });
      }
    }

    // ---------- FALLBACK: AI EXTRACTION ----------
    // If structured parsing found nothing but we have text, use the AI agent to read it
    if (parsedRows.length === 0 && extractedText && extractedText.length > 50) {
      extractionMethod = "ai-text";
      try {
        const ZAI = (await import("z-ai-web-dev-sdk")).default;
        const zai = await ZAI.create();
        const completion = await zai.chat.completions.create({
          messages: [
            { role: "assistant", content: "You are a financial data extractor. Read the user's text and extract every transaction as JSON. Output ONLY a JSON array (no markdown, no commentary) like: [{\"date\":\"YYYY-MM-DD\",\"description\":\"vendor name\",\"amount\":12.34,\"type\":\"expense\" or \"income\"}]. Use type=income for deposits/refunds, type=expense for payments/charges. If a date isn't clear, use today's date." },
            { role: "user", content: `Extract transactions from this text:\n\n${extractedText.slice(0, 5000)}` },
          ],
          thinking: { type: "disabled" },
          temperature: 0.1,
        });
        const content = completion.choices[0]?.message?.content ?? "[]";
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          const arr = JSON.parse(jsonMatch[0]);
          parsedRows = arr.map((r: any) => ({
            date: r.date, description: r.description, amount: Number(r.amount), type: r.type === "income" ? "income" : "expense", category: r.category,
          }));
        }
      } catch (e: any) {
        // AI failed too — return the text for manual review
        await db.importedFile.update({
          where: { id: importedFile.id },
          data: { status: "parsed", parsedCount: 0, summary: `Structured parse found 0 rows. AI extraction failed: ${e.message}.` },
        });
        return NextResponse.json({
          importedFileId: importedFile.id, fileName, fileType, parsedCount: 0, postedCount: 0,
          extractedTextPreview: extractedText.slice(0, 1500),
          message: `File parsed but no structured transactions detected via ${extractionMethod}. Paste the text into the AI Agent chat and ask the Accountant agent to extract transactions.`,
        });
      }
    }

    // ---------- POST TO GL ----------
    if (parsedRows.length === 0) {
      await db.importedFile.update({
        where: { id: importedFile.id },
        data: { status: "parsed", parsedCount: 0, summary: `No transactions detected via ${extractionMethod}.` },
      });
      return NextResponse.json({
        importedFileId: importedFile.id, fileName, fileType, parsedCount: 0, postedCount: 0,
        extractedTextPreview: extractedText.slice(0, 1500),
        message: `File parsed via ${extractionMethod} but no transactions detected. Try uploading the data as CSV/Excel, or paste the content into the AI Agent chat.`,
      });
    }

    let posted = 0;
    for (const row of parsedRows.slice(0, 500)) {
      if (!row.amount || row.amount <= 0) continue;
      const type = row.type ?? (row.amount > 0 ? "income" : "expense");
      const category = row.category || guessCategory(row.description || "");
      const glAccount = categoryToGLAccount(category);
      await db.transaction.create({
        data: {
          companyId,
          date: parseDate(row.date || ""),
          description: row.description || "Imported transaction",
          category,
          type,
          amount: row.amount,
          currency: company.currency,
          source: "import",
          status: "posted",
          glCode: glAccount.code,
        },
      });
      posted++;
    }

    await db.importedFile.update({
      where: { id: importedFile.id },
      data: { status: "posted", parsedCount: parsedRows.length, postedCount: posted, summary: `Imported ${posted} transactions from ${fileType.toUpperCase()} via ${extractionMethod}` },
    });

    return NextResponse.json({
      importedFileId: importedFile.id,
      fileName,
      fileType,
      extractionMethod,
      parsedCount: parsedRows.length,
      postedCount: posted,
      message: `Successfully imported ${posted} transactions to the GL via ${extractionMethod}. The Trial Balance, P&L, Balance Sheet, Cash Flow and Equity reports now reflect this data — each line posted to its SAP FICO GL account code.`,
      sampleRows: parsedRows.slice(0, 5).map((r) => ({
        ...r,
        glCode: categoryToGLAccount(r.category || guessCategory(r.description || "")).code,
        glAccount: categoryToGLAccount(r.category || guessCategory(r.description || "")).name,
      })),
    });
  } catch (err: any) {
    console.error("[/api/import] error:", err);
    return NextResponse.json({ error: "Import failed", detail: err?.message }, { status: 500 });
  }
}
