import { NextResponse } from "next/server";
import { CONCEPT_APPLICATIONS, CONCEPT_APPLICATION_STATS, CONCEPT_APPLICATION_META } from "@/lib/concepts-applied";

// GET /api/concepts-applied
// Returns the cross-reference matrix proving that every concept from the Concepts
// Glossary is applied in actual computations throughout the Finova app.

export async function GET() {
  return NextResponse.json({
    meta: CONCEPT_APPLICATION_META,
    applications: CONCEPT_APPLICATIONS,
    stats: CONCEPT_APPLICATION_STATS,
  });
}
