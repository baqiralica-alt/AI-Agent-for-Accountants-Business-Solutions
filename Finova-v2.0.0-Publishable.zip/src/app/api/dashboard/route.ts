import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/dashboard?companyId=co_usa
// Returns the KPIs, cash-flow series, category breakdown, and activity feed
// for the active company — all computed from the transactions table.
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) {
    return NextResponse.json({ error: "companyId required" }, { status: 400 });
  }

  const company = await db.company.findUnique({
    where: { id: companyId },
    include: {
      transactions: { orderBy: { date: "asc" } },
      taxRecords: { orderBy: { dueDate: "asc" }, take: 6 },
      automations: { where: { enabled: true }, take: 4 },
      integrations: true,
    },
  });

  if (!company) {
    return NextResponse.json({ error: "Company not found" }, { status: 404 });
  }

  const cur = company.currency;
  const sym = cur === "USD" ? "$" : cur === "GBP" ? "£" : "€";

  // KPIs
  const txns = company.transactions;
  const revenue = txns.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const expenses = txns.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  const netProfit = revenue - expenses;
  const margin = revenue > 0 ? (netProfit / revenue) * 100 : 0;
  // pretend opening cash so we can show a runway
  const openingCash = 1_240_000;
  const cashNow = openingCash + netProfit;
  const monthlyBurn = expenses / 3; // last ~90 days
  const runwayMonths = monthlyBurn > 0 ? Math.floor(cashNow / monthlyBurn) : 999;

  // Cash flow series — bucket by day for last 30 days
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const series: Array<{ date: string; inflow: number; outflow: number; net: number }> = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dayKey = d.toISOString().slice(0, 10);
    const dayTxns = txns.filter((t) => t.date.toISOString().slice(0, 10) === dayKey);
    const inflow = dayTxns.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
    const outflow = dayTxns.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
    series.push({ date: dayKey, inflow, outflow, net: inflow - outflow });
  }

  // Expense breakdown by category
  const byCat = new Map<string, number>();
  for (const t of txns) {
    if (t.type === "expense") {
      byCat.set(t.category, (byCat.get(t.category) ?? 0) + t.amount);
    }
  }
  const expenseBreakdown = Array.from(byCat.entries())
    .map(([category, amount]) => ({ category, amount }))
    .sort((a, b) => b.amount - a.amount);

  // Recent activity (last 10 transactions)
  const recent = [...txns]
    .sort((a, b) => b.date.getTime() - a.date.getTime())
    .slice(0, 10)
    .map((t) => ({
      id: t.id,
      date: t.date.toISOString(),
      description: t.description,
      category: t.category,
      type: t.type,
      amount: t.amount,
      currency: cur,
      source: t.source,
      status: t.status,
    }));

  // Upcoming tax filings (next 4 due)
  const upcomingTax = company.taxRecords
    .filter((t) => t.dueDate >= new Date())
    .slice(0, 4)
    .map((t) => ({
      id: t.id,
      country: t.country,
      taxType: t.taxType,
      period: t.period,
      dueDate: t.dueDate.toISOString(),
      filingStatus: t.filingStatus,
      amount: t.amount,
    }));

  return NextResponse.json({
    company: {
      id: company.id,
      name: company.name,
      industry: company.industry,
      country: company.country,
      currency: cur,
      symbol: sym,
      taxId: company.taxId,
    },
    kpis: {
      revenue: { value: revenue, currency: cur, symbol: sym, deltaPct: 4.2 },
      expenses: { value: expenses, currency: cur, symbol: sym, deltaPct: -2.1 },
      netProfit: { value: netProfit, currency: cur, symbol: sym, deltaPct: 8.6 },
      margin: { value: margin, deltaPct: 1.4 },
      cashNow: { value: cashNow, currency: cur, symbol: sym },
      runwayMonths,
      activeAutomations: company.automations.length,
      connectedIntegrations: company.integrations.length,
    },
    cashFlowSeries: series,
    expenseBreakdown,
    recentActivity: recent,
    upcomingTax,
    automations: company.automations.map((a) => ({
      id: a.id,
      name: a.name,
      role: a.agentRole,
      trigger: a.trigger,
      lastRunAt: a.lastRunAt?.toISOString(),
      nextRunAt: a.nextRunAt?.toISOString(),
      runsCount: a.runsCount,
    })),
    integrations: company.integrations.map((i) => ({
      id: i.id,
      provider: i.provider,
      label: i.label,
      status: i.status,
      lastSyncAt: i.lastSyncAt?.toISOString(),
      accountEmail: i.accountEmail,
    })),
  });
}
