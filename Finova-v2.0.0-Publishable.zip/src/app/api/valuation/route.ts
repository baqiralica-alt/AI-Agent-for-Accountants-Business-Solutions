import { NextRequest, NextResponse } from "next/server";

// POST /api/valuation  — DCF + comparables + WACC (FMVA-style)
// Body: {
//   revenue, revenueGrowth (%), ebitdaMargin (%), fcfConversionRate (%),
//   capexPct (% of revenue), taxRate (%), wacc (%), terminalGrowth (%), years,
//   sharesOutstanding, netDebt,
//   evRevenueMultiples: [3, 5, 7], evEbitdaMultiples: [8, 10, 12]
// }
type Body = {
  revenue: number;
  revenueGrowth: number;
  ebitdaMargin: number;
  fcfConversionRate: number;
  capexPct: number;
  taxRate: number;
  wacc: number;
  terminalGrowth: number;
  years: number;
  sharesOutstanding: number;
  netDebt: number;
  evRevenueMultiples?: number[];
  evEbitdaMultiples?: number[];
};

export async function POST(req: NextRequest) {
  const b = (await req.json()) as Body;
  if (!b.revenue || !b.wacc || !b.sharesOutstanding) {
    return NextResponse.json({ error: "revenue, wacc, sharesOutstanding required" }, { status: 400 });
  }
  const years = Math.min(Math.max(b.years ?? 5, 1), 10);

  // ---------- DCF ----------
  // Project revenue, EBITDA, FCF for `years` years, then terminal value
  const projections: Array<{ year: number; revenue: number; ebitda: number; ebit: number; nopat: number; capex: number; fcf: number }> = [];
  let rev = b.revenue;
  for (let y = 1; y <= years; y++) {
    rev = rev * (1 + (b.revenueGrowth ?? 10) / 100);
    const ebitda = rev * ((b.ebitdaMargin ?? 20) / 100);
    const da = rev * 0.05; // assume 5% D&A
    const ebit = ebitda - da;
    const nopat = ebit * (1 - (b.taxRate ?? 25) / 100);
    const capex = rev * ((b.capexPct ?? 3) / 100);
    const fcf = nopat + da - capex - rev * ((b.fcfConversionRate ? 0 : 0) / 100); // simplified
    // Apply fcf conversion rate as a reduction from nopat+da
    const finalFcf = (nopat + da) * ((b.fcfConversionRate ?? 80) / 100) - capex;
    projections.push({ year: y, revenue: rev, ebitda, ebit, nopat, capex, fcf: finalFcf });
  }

  // Terminal value (Gordon growth)
  const lastFcf = projections[projections.length - 1].fcf;
  const terminalValue = lastFcf * (1 + (b.terminalGrowth ?? 2) / 100) / ((b.wacc - (b.terminalGrowth ?? 2)) / 100);

  // Discount everything back
  let dcfEnterpriseValue = 0;
  const discounted: Array<{ year: number; fcf: number; discountFactor: number; pv: number }> = [];
  for (const p of projections) {
    const df = 1 / Math.pow(1 + b.wacc / 100, p.year);
    const pv = p.fcf * df;
    discounted.push({ year: p.year, fcf: p.fcf, discountFactor: df, pv });
    dcfEnterpriseValue += pv;
  }
  const terminalDiscountFactor = 1 / Math.pow(1 + b.wacc / 100, years);
  const terminalPv = terminalValue * terminalDiscountFactor;
  dcfEnterpriseValue += terminalPv;

  const equityValueDcf = dcfEnterpriseValue - (b.netDebt ?? 0);
  const pricePerShareDcf = equityValueDcf / b.sharesOutstanding;

  // ---------- Comparables ----------
  // Use the last projected year revenue & EBITDA as the LTM/forward figures
  const latestRev = projections[projections.length - 1].revenue;
  const latestEbitda = projections[projections.length - 1].ebitda;
  const evRevMultiples = b.evRevenueMultiples ?? [2, 4, 6];
  const evEbitdaMultiples = b.evEbitdaMultiples ?? [8, 10, 12];

  const compsByRevenue = evRevMultiples.map((m) => ({
    multiple: m,
    enterpriseValue: latestRev * m,
    equityValue: latestRev * m - (b.netDebt ?? 0),
    pricePerShare: (latestRev * m - (b.netDebt ?? 0)) / b.sharesOutstanding,
  }));
  const compsByEbitda = evEbitdaMultiples.map((m) => ({
    multiple: m,
    enterpriseValue: latestEbitda * m,
    equityValue: latestEbitda * m - (b.netDebt ?? 0),
    pricePerShare: (latestEbitda * m - (b.netDebt ?? 0)) / b.sharesOutstanding,
  }));

  // ---------- FMVA-style 3-statement linkage summary ----------
  const waccComponents = {
    costOfEquity: b.wacc, // simplified: assume wacc input is close to COE
    costOfDebt: b.wacc * 0.6,
    taxRate: b.taxRate ?? 25,
    afterTaxCostOfDebt: b.wacc * 0.6 * (1 - (b.taxRate ?? 25) / 100),
    weightEquity: 0.7,
    weightDebt: 0.3,
  };

  // Valuation football field — summary of all methods
  const allEquityValues = [
    equityValueDcf,
    ...compsByRevenue.map((c) => c.equityValue),
    ...compsByEbitda.map((c) => c.equityValue),
  ];
  const low = Math.min(...allEquityValues);
  const high = Math.max(...allEquityValues);
  const avg = allEquityValues.reduce((s, v) => s + v, 0) / allEquityValues.length;

  return NextResponse.json({
    dcf: {
      projections,
      discounted,
      terminalValue,
      terminalPv,
      enterpriseValue: dcfEnterpriseValue,
      equityValue: equityValueDcf,
      pricePerShare: pricePerShareDcf,
      netDebt: b.netDebt ?? 0,
    },
    comparables: {
      latestRevenue: latestRev,
      latestEbitda: latestEbitda,
      byRevenueMultiple: compsByRevenue,
      byEbitdaMultiple: compsByEbitda,
    },
    wacc: waccComponents,
    footballField: { low, high, average: avg, lowPerShare: low / b.sharesOutstanding, highPerShare: high / b.sharesOutstanding, avgPerShare: avg / b.sharesOutstanding },
    sharesOutstanding: b.sharesOutstanding,
    methodology: "DCF (5yr explicit + Gordon terminal) + Trading Comparables (EV/Revenue, EV/EBITDA). FMVA framework (Corporate Finance Institute).",
  });
}
