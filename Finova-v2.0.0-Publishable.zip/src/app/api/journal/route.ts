import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

type Line = { account: string; debit: number; credit: number; description?: string };

// GET /api/journal?companyId=...
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) {
    return NextResponse.json({ error: "companyId required" }, { status: 400 });
  }
  const entries = await db.journalEntry.findMany({
    where: { companyId },
    orderBy: { date: "desc" },
    take: 200,
  });
  return NextResponse.json({
    entries: entries.map((e) => ({
      id: e.id,
      date: e.date.toISOString(),
      memo: e.memo,
      reference: e.reference,
      source: e.source,
      postedBy: e.postedBy,
      lines: JSON.parse(e.linesJson) as Line[],
      totalDebit: e.totalDebit,
      totalCredit: e.totalCredit,
      status: e.status,
    })),
  });
}

// POST /api/journal  — create a double-entry posting with balance validation
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { companyId, date, memo, reference, lines, source, postedBy } = body as {
    companyId: string;
    date?: string;
    memo: string;
    reference?: string;
    lines: Line[];
    source?: string;
    postedBy?: string;
  };
  if (!companyId || !memo || !Array.isArray(lines) || lines.length < 2) {
    return NextResponse.json({ error: "companyId, memo, and at least 2 lines are required" }, { status: 400 });
  }
  // Validate every line has an account and a non-negative debit & credit
  for (const l of lines) {
    if (!l.account || typeof l.debit !== "number" || typeof l.credit !== "number") {
      return NextResponse.json({ error: `Invalid line: ${JSON.stringify(l)}` }, { status: 400 });
    }
    if (l.debit < 0 || l.credit < 0) {
      return NextResponse.json({ error: "Debit and credit must be non-negative" }, { status: 400 });
    }
    if (l.debit > 0 && l.credit > 0) {
      return NextResponse.json({ error: `Line "${l.account}" has both debit and credit — split into two lines` }, { status: 400 });
    }
  }
  const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
  const totalCredit = lines.reduce((s, l) => s + l.credit, 0);
  if (Math.abs(totalDebit - totalCredit) > 0.01) {
    return NextResponse.json({
      error: `Journal not balanced — Dr ${totalDebit} ≠ Cr ${totalCredit}`,
      totalDebit,
      totalCredit,
    }, { status: 400 });
  }

  const entry = await db.journalEntry.create({
    data: {
      companyId,
      date: date ? new Date(date) : new Date(),
      memo,
      reference: reference ?? null,
      source: source ?? "manual",
      postedBy: postedBy ?? "user",
      linesJson: JSON.stringify(lines),
      totalDebit,
      totalCredit,
      status: "posted",
    },
  });
  return NextResponse.json({ entry });
}
