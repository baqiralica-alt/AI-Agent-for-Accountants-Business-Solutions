import { NextRequest, NextResponse } from "next/server";
import { ALL_COUNTRY_PAYROLLS, PAYROLL_STATS } from "@/lib/payroll-data";

// GET /api/payroll
// Returns multi-country payroll data — USA, UK, EU (Germany), Canada.
// Each country includes:
//   - 3-6 fictitious employees with monthly payslip detail
//   - Per-employee deductions: income tax, social security, pension, healthcare
//   - Employer contributions and total employer cost
//   - Country totals: gross payroll, employee tax, employer contributions, net pay, employer cost
//   - Journal entry for monthly payroll posting
//   - Statutory laws and standards reference (per country)

export async function GET(_req: NextRequest) {
  return NextResponse.json({
    countries: ALL_COUNTRY_PAYROLLS,
    stats: PAYROLL_STATS,
    intro: "Comprehensive multi-country payroll computation per each jurisdiction's tax laws, social security, pension, and statutory deductions. Covers USA (FICA/FUTA/401k), UK (PAYE/NI/AE), Germany/EU (Lohnsteuer/Soli/SGB), and Canada (ITA/CPP/EI/EHT). Each payslip includes employee deductions, employer contributions, total employer cost, and the journal entry for posting.",
  });
}
