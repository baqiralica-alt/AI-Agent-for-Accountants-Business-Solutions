import { NextResponse } from "next/server";
import { MARKET_DATA_CATEGORIES, MARKET_DATA_STATS } from "@/lib/market-data";

// GET /api/market-data
// Returns the complete market data input set used across the app:
//   - FX rates (Fed H.10, ECB, ICE)
//   - Risk-free rates & policy rates (US Treasury, FRBNY SOFR, BoE SONIA, BoC CORRA)
//   - Equity risk premiums (Damodaran NYU Stern Nov 2026 update), size premiums (Kroll), industry betas
//   - Credit spreads & default rates (S&P 2025 Annual Default Study + Moody's CRE)
//   - Statutory tax rates (US, UK, Ireland, Singapore, UAE, Canada, Germany, France + OECD Pillar Two)
//
// All figures are sourced from primary trusted resources (central banks, treasuries, NYU Stern,
// S&P Global Ratings, Kroll) and refreshed as of November 20, 2026.

export async function GET() {
  return NextResponse.json({
    categories: MARKET_DATA_CATEGORIES,
    stats: MARKET_DATA_STATS,
    intro: "All key inputs for FP&A, lending, valuation, consolidation, and tax models. Blue cells are user-modifiable; source citations are required when changing inputs for audit purposes. Latest refresh: November 20, 2026.",
  });
}
