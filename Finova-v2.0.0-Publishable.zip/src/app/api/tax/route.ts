import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/tax?companyId=co_usa
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) {
    return NextResponse.json({ error: "companyId required" }, { status: 400 });
  }
  const records = await db.taxRecord.findMany({
    where: { companyId },
    orderBy: { dueDate: "asc" },
  });
  return NextResponse.json({
    taxRecords: records.map((t) => ({
      id: t.id,
      country: t.country,
      taxType: t.taxType,
      period: t.period,
      dueDate: t.dueDate.toISOString(),
      filingStatus: t.filingStatus,
      amount: t.amount,
      notes: t.notes,
    })),
  });
}

// POST /api/tax  { companyId, country, taxType, period, dueDate, amount, filingStatus? }
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { companyId, country, taxType, period, dueDate, amount, filingStatus } = body;
  if (!companyId || !country || !taxType || !period || !dueDate) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }
  const record = await db.taxRecord.create({
    data: {
      companyId,
      country,
      taxType,
      period,
      dueDate: new Date(dueDate),
      amount: amount ?? null,
      filingStatus: filingStatus ?? "pending",
    },
  });
  return NextResponse.json({ taxRecord: record });
}

// PATCH /api/tax  { id, filingStatus }
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { id, filingStatus } = body;
  if (!id || !filingStatus) {
    return NextResponse.json({ error: "id and filingStatus required" }, { status: 400 });
  }
  const updated = await db.taxRecord.update({
    where: { id },
    data: { filingStatus },
  });
  return NextResponse.json({ taxRecord: updated });
}
