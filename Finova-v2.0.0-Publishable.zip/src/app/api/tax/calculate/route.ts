import { NextRequest, NextResponse } from "next/server";

// POST /api/tax/calculate
// Body: { country, taxType, revenue, expenses, period }
// Returns jurisdiction-aware tax estimates. The numbers below are simplified
// headline rates for SMB planning — clearly labelled as advisory.
type CalcBody = {
  country: string;
  taxType: string;
  revenue: number;
  expenses: number;
  period?: string;
};

type Bracket = { upTo: number | null; rate: number };

// USA — federal corporation tax brackets (2025, simplified flat 21% federal + ~5% CA state for demo)
const US_FEDERAL_BRACKETS: Bracket[] = [
  { upTo: 50000, rate: 0.15 },
  { upTo: 75000, rate: 0.25 },
  { upTo: 100000, rate: 0.34 },
  { upTo: 335000, rate: 0.39 },
  { upTo: null, rate: 0.21 },
];

function progressiveTax(income: number, brackets: Bracket[]): number {
  let tax = 0;
  let prev = 0;
  for (const b of brackets) {
    const cap = b.upTo ?? Infinity;
    if (income <= prev) break;
    const slice = Math.min(income, cap) - prev;
    tax += slice * b.rate;
    prev = cap;
  }
  return tax;
}

// UK — Corporation Tax 19% if profits <= £50k, marginal taper up to 25% at £250k
function ukCorporationTax(profit: number): { rate: number; tax: number } {
  if (profit <= 50000) return { rate: 0.19, tax: profit * 0.19 };
  if (profit >= 250000) return { rate: 0.25, tax: profit * 0.25 };
  // marginal relief
  const upper = 250000;
  const standardTax = profit * 0.25;
  const relief = ((upper - profit) / (upper - 50000)) * (standardTax - profit * 0.19);
  const tax = standardTax - relief;
  return { rate: tax / profit, tax };
}

// Germany — Körperschaftsteuer 15% + solidarity 5.5% on the tax + local Gewerbesteuer (~14-15% heuristic)
function germanCorpTax(profit: number) {
  const koerp = profit * 0.15;
  const soli = koerp * 0.055;
  const gewerbe = profit * 0.14; // demo rate (Hebesatz varies by municipality)
  const total = koerp + soli + gewerbe;
  return { koerp, soli, gewerbe, total, effective: total / profit };
}

// France — IS: 15% to €42.5k, 25% above (for large companies; 15% on first €42.5k for SMEs)
function frenchCorpTax(profit: number) {
  if (profit <= 42500) return { tax: profit * 0.15, rate: 0.15 };
  return { tax: 42500 * 0.15 + (profit - 42500) * 0.25, rate: 0 };
}

// Ireland — CT 12.5% on trading income, 25% on non-trading
function irishCorpTax(profit: number) {
  return { tax: profit * 0.125, rate: 0.125 };
}

// Canada — Federal T2 Part I tax: 15% general / 9% small business deduction (SBD) on first $500k CCPC active business income
// Provincial tax (Ontario demo): 11.5% general / 3.2% small business rate
// Combined: 26.5% general / 12.2% small business (Ontario)
function canadaCorpTax(profit: number) {
  const sbdLimit = 500000; // small business deduction limit (CCPC active business income)
  if (profit <= sbdLimit) {
    // Small business combined rate (Ontario): 9% federal + 3.2% Ontario = 12.2%
    return { tax: profit * 0.122, rate: 0.122, type: "small business (Ontario combined)" };
  }
  // General combined rate (Ontario): 15% federal + 11.5% Ontario = 26.5%
  const smallBizTax = sbdLimit * 0.122;
  const generalTax = (profit - sbdLimit) * 0.265;
  return { tax: smallBizTax + generalTax, rate: (smallBizTax + generalTax) / profit, type: "mixed (Ontario combined)" };
}

function fmt(cur: string, n: number): string {
  const sym = cur === "USD" ? "$" : cur === "GBP" ? "£" : cur === "CAD" ? "C$" : "€";
  return `${sym}${Math.round(n).toLocaleString()}`;
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as CalcBody;
  const { country, taxType, revenue, expenses } = body;

  if (!country || !taxType || typeof revenue !== "number" || typeof expenses !== "number") {
    return NextResponse.json({ error: "country, taxType, revenue, expenses required" }, { status: 400 });
  }

  const profit = Math.max(0, revenue - expenses);
  const currency = country === "USA" ? "USD" : country === "UK" ? "GBP" : country === "Canada" ? "CAD" : "EUR";
  let result: any = { country, taxType, revenue, expenses, profit, currency };

  if (taxType === "corporation-tax" || taxType === "federal-income" || taxType === "corporation-income") {
    if (country === "USA") {
      const fed = progressiveTax(profit, US_FEDERAL_BRACKETS);
      const state = profit * 0.05; // demo CA flat 5%
      result = {
        ...result,
        lines: [
          { label: "Federal income tax", amount: fed, rate: `${((fed / profit) * 100).toFixed(1)}% effective` },
          { label: "State income tax (CA demo 5%)", amount: state, rate: "5.0%" },
        ],
        total: fed + state,
        formatted: {
          profit: fmt(currency, profit),
          federal: fmt(currency, fed),
          state: fmt(currency, state),
          total: fmt(currency, fed + state),
        },
      };
    } else if (country === "UK") {
      const { rate, tax } = ukCorporationTax(profit);
      result = {
        ...result,
        lines: [
          { label: "Corporation Tax (main rate 25%, small profits 19%)", amount: tax, rate: `${(rate * 100).toFixed(1)}% effective` },
        ],
        total: tax,
        formatted: { profit: fmt(currency, profit), total: fmt(currency, tax) },
      };
    } else if (country === "Germany") {
      const g = germanCorpTax(profit);
      result = {
        ...result,
        lines: [
          { label: "Körperschaftsteuer (15%)", amount: g.koerp, rate: "15%" },
          { label: "Solidaritätszuschlag (5.5% on KSt)", amount: g.soli, rate: "0.825%" },
          { label: "Gewerbesteuer (demo ~14%)", amount: g.gewerbe, rate: "~14% (varies by municipality)" },
        ],
        total: g.total,
        effectiveRate: g.effective,
        formatted: {
          profit: fmt(currency, profit),
          koerp: fmt(currency, g.koerp),
          soli: fmt(currency, g.soli),
          gewerbe: fmt(currency, g.gewerbe),
          total: fmt(currency, g.total),
        },
      };
    } else if (country === "France") {
      const { tax } = frenchCorpTax(profit);
      result = {
        ...result,
        lines: [
          { label: "Impôt sur les sociétés (IS) — 15% to €42.5k, 25% above", amount: tax, rate: `${((tax / profit) * 100).toFixed(1)}% effective` },
        ],
        total: tax,
        formatted: { profit: fmt(currency, profit), total: fmt(currency, tax) },
      };
    } else if (country === "Ireland") {
      const { tax } = irishCorpTax(profit);
      result = {
        ...result,
        lines: [
          { label: "Corporation Tax (12.5% trading income)", amount: tax, rate: "12.5%" },
        ],
        total: tax,
        formatted: { profit: fmt(currency, profit), total: fmt(currency, tax) },
      };
    } else if (country === "Canada") {
      const c = canadaCorpTax(profit);
      result = {
        ...result,
        lines: [
          { label: `T2 Part I Corporation Tax (${c.type})`, amount: c.tax, rate: `${(c.rate * 100).toFixed(2)}% effective` },
          { label: "Small Business Deduction limit (CCPC active)", amount: 500000, rate: "$500K @ 12.2% combined (Ontario)" },
          { label: "Federal rate (general)", amount: profit * 0.15, rate: "15% federal" },
          { label: "Ontario provincial rate (general)", amount: profit * 0.115, rate: "11.5% Ontario" },
        ],
        total: c.tax,
        effectiveRate: c.rate,
        formatted: {
          profit: fmt(currency, profit),
          total: fmt(currency, c.tax),
          federal: fmt(currency, profit * 0.15),
          ontario: fmt(currency, profit * 0.115),
        },
        note: "Canada T2 corporation tax: 15% federal general rate (9% SBD on first $500K CCPC active income) + provincial (Ontario demo 11.5% general / 3.2% SBD). HST/GST not included — separate consumption tax remittance.",
      };
    }
  } else if (taxType === "vat" || taxType === "sales-tax") {
    // VAT/sales tax is on revenue, not profit
    if (country === "USA") {
      const rate = 0.0725; // CA base sales tax demo
      const tax = revenue * rate;
      result = {
        ...result,
        lines: [
          { label: "Sales tax (CA demo 7.25%)", amount: tax, rate: "7.25%" },
        ],
        total: tax,
        formatted: { revenue: fmt(currency, revenue), total: fmt(currency, tax) },
      };
    } else if (country === "UK") {
      const rate = 0.2;
      const tax = revenue * rate;
      result = {
        ...result,
        lines: [
          { label: "Output VAT (standard 20%)", amount: tax, rate: "20%" },
        ],
        total: tax,
        formatted: { revenue: fmt(currency, revenue), total: fmt(currency, tax) },
        note: "Input VAT on expenses can be reclaimed. Net VAT payable = output - input.",
      };
    } else if (country === "Canada") {
      // HST/GST — Ontario HST 13% (5% GST + 8% Ontario provincial), Alberta GST 5% only, Quebec QST 9.975% + GST 5% = 14.975%
      const rate = 0.13; // Ontario HST demo
      const tax = revenue * rate;
      result = {
        ...result,
        lines: [
          { label: "HST Ontario (13% = 5% GST + 8% Ontario provincial)", amount: tax, rate: "13%" },
        ],
        total: tax,
        formatted: { revenue: fmt(currency, revenue), total: fmt(currency, tax) },
        note: "Canada HST/GST: ITCs (Input Tax Credits) reclaimable. Ontario HST 13%; Alberta GST 5% only (no PST); BC PST 7% + GST 5%; Quebec TVQ 9.975% + TPS 5%.",
      };
    } else {
      // EU standard VAT (varies — DE 19%, FR 20%, IE 23%)
      const map: Record<string, number> = { Germany: 0.19, France: 0.2, Ireland: 0.23 };
      const rate = map[country] ?? 0.19;
      const tax = revenue * rate;
      result = {
        ...result,
        lines: [
          { label: `Output VAT (${country} ${(rate * 100).toFixed(0)}%)`, amount: tax, rate: `${(rate * 100).toFixed(0)}%` },
        ],
        total: tax,
        formatted: { revenue: fmt(currency, revenue), total: fmt(currency, tax) },
        note: "EU VAT: input VAT is reclaimable; intra-EU B2B supplies may use reverse charge.",
      };
    }
  } else if (taxType === "payroll") {
    // Simplified payroll burden — employer side only
    if (country === "USA") {
      const futa = revenue * 0.006;
      const suta = revenue * 0.027;
      const medicare = revenue * 0.0145;
      const ssEmployer = revenue * 0.062;
      result = {
        ...result,
        lines: [
          { label: "FUTA (0.6%)", amount: futa, rate: "0.6%" },
          { label: "SUTA (demo 2.7%)", amount: suta, rate: "2.7%" },
          { label: "Social Security employer (6.2%)", amount: ssEmployer, rate: "6.2%" },
          { label: "Medicare employer (1.45%)", amount: medicare, rate: "1.45%" },
        ],
        total: futa + suta + medicare + ssEmployer,
        formatted: { total: fmt(currency, futa + suta + medicare + ssEmployer) },
        note: "Payroll taxes apply to wages, not revenue. Using revenue as a stand-in for demo purposes.",
      };
    } else if (country === "UK") {
      const ni = revenue * 0.138; // employer NI ~13.8%
      result = {
        ...result,
        lines: [{ label: "Employer NI (13.8%)", amount: ni, rate: "13.8%" }],
        total: ni,
        formatted: { total: fmt(currency, ni) },
      };
    } else if (country === "Canada") {
      const cpp = revenue * 0.0595;          // employer CPP 5.95% (matched)
      const ei = revenue * 0.0164 * 1.4;     // employer EI 1.4× employee 1.64% = 2.296%
      const eht = revenue * 0.0195;          // Ontario EHT 1.95% (above $1M exemption)
      const wsib = revenue * 0.02;           // WSIB demo 2%
      const total = cpp + ei + eht + wsib;
      result = {
        ...result,
        lines: [
          { label: "CPP employer match (5.95%)", amount: cpp, rate: "5.95%" },
          { label: "EI employer premium (1.4× employee 1.64%)", amount: ei, rate: "2.296%" },
          { label: "Ontario EHT (1.95%)", amount: eht, rate: "1.95%" },
          { label: "WSIB demo (2%)", amount: wsib, rate: "2%" },
        ],
        total,
        formatted: {
          total: fmt(currency, total),
          cpp: fmt(currency, cpp),
          ei: fmt(currency, ei),
          eht: fmt(currency, eht),
          wsib: fmt(currency, wsib),
        },
        note: "Canada employer payroll burden: CPP match (5.95%) + EI 1.4× multiplier + Ontario EHT (1.95%, $1M exemption) + WSIB (varies by industry).",
      };
    } else {
      const de = revenue * 0.19; // ~ employer social contributions ~19% of wage
      result = {
        ...result,
        lines: [{ label: "Employer social contributions (~19% demo)", amount: de, rate: "~19%" }],
        total: de,
        formatted: { total: fmt(currency, de) },
      };
    }
  } else {
    return NextResponse.json({ error: `Unknown taxType: ${taxType}` }, { status: 400 });
  }

  result.advisory = "Estimate for planning only. A licensed local CPA / tax adviser must sign off on the actual filing.";
  return NextResponse.json(result);
}
