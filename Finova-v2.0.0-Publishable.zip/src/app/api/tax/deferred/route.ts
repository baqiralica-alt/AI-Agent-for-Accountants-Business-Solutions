import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/tax/deferred?companyId=...
// Returns comprehensive deferred tax computation per IAS 12 (IFRS), ASC 740 (US GAAP),
// UK FRS 102/FRS 102 Section 1A, and EU (IFRS-EU as endorsed).
//
// Includes:
//  - Temporary differences schedule (PPE, Intangibles, Provisions, Pensions, OCI items)
//  - Deferred Tax Liability (DTL) and Deferred Tax Asset (DTA) calculation
//  - Movement schedule (opening, P&L charge, OCI charge, closing)
//  - Journal entries (current tax + deferred tax)
//  - Effective tax rate reconciliation
//  - Standards panel: IFRS IAS 12 · US GAAP ASC 740 · UK FRS 102 · EU IFRS-EU
//
// Fictitious data consistent with TechFlow Solutions UK Ltd FY2025:
//   - Accounting profit before tax: £646,711
//   - Taxable profit: £631,461
//   - Current tax (Corporation Tax @ 25%): £157,865
//   - Net deferred tax movement (P&L): £3,937.50 DTL increase
//   - Deferred tax on OCI: £837.50
//   - Total tax expense: £161,802.50

type TempDiff = {
  item: string;
  carryingAmount: number;       // accounting NBV
  taxBase: number;              // tax base
  temporaryDifference: number;  // carrying - taxBase (positive = taxable temp diff → DTL)
  dtl: number;                  // deferred tax LIABILITY (if temp diff > 0)
  dta: number;                  // deferred tax ASSET (if temp diff < 0)
  standard: string;             // IAS 12 / ASC 740 reference
  category: "P&L" | "OCI";      // routed to P&L tax expense or OCI
  note: string;
};

const UK_CT_RATE = 0.25; // UK Corporation Tax main rate FY2025

export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) {
    return NextResponse.json({ error: "companyId required" }, { status: 400 });
  }

  const company = await db.company.findUnique({ where: { id: companyId } });
  if (!company) {
    return NextResponse.json({ error: "Company not found" }, { status: 404 });
  }

  const currency = company.currency === "USD" ? "$" : company.currency === "GBP" ? "£" : "€";

  // ============ TEMPORARY DIFFERENCES SCHEDULE (fictitious, TechFlow FY2025) ============
  // Per IAS 12.15: recognise deferred tax on all temporary differences (subject to exemptions)
  // Per ASC 740-10-20: same principle, no initial recognition exception equivalent
  // Per FRS 102 Section 1A small co: deferred tax required on fair value revaluations &

  const tempDiffsPAndL: TempDiff[] = [
    {
      item: "Property, Plant & Equipment — accelerated capital allowances",
      carryingAmount: 9750,        // accounting NBV: cost £13,000 - accum dep £3,250
      taxBase: 0,                  // tax base: £0 (full AIA claimed year 1)
      temporaryDifference: 9750,   // taxable temporary difference → DTL
      dtl: 9750 * UK_CT_RATE,      // £2,437.50
      dta: 0,
      standard: "IAS 12.15 / FRS 102 s29 / ASC 740-10-20",
      category: "P&L",
      note: "AIA (Annual Investment Allowance) gives 100% tax relief on £13,000 PPE additions in year 1. Accounting depreciates over useful life (25% straight line). Reversing temporary difference will occur as tax NBV stays at £0 while accounting NBV depreciates to £0.",
    },
    {
      item: "Intangible Assets — software development capitalised",
      carryingAmount: 8000,        // accounting NBV: cost £12,000 - accum amort £4,000
      taxBase: 0,                  // tax base: £0 (AIA claimed on intangibles)
      temporaryDifference: 8000,   // taxable temporary difference → DTL
      dtl: 8000 * UK_CT_RATE,      // £2,000
      dta: 0,
      standard: "IAS 12.15 / FRS 102 s29 / ASC 740-10-20",
      category: "P&L",
      note: "Software development costs capitalised for accounting (amortised 33% straight line). AIA claimed in year 1 for tax. Tax NBV £0 vs accounting NBV £8,000.",
    },
    {
      item: "Accruals — expenses accrued not yet paid",
      carryingAmount: 2000,        // liability recognised in accounts
      taxBase: 0,                  // tax base: £0 (deductible when paid)
      temporaryDifference: -2000,  // deductible temporary difference → DTA
      dtl: 0,
      dta: 2000 * UK_CT_RATE,      // £500
      standard: "IAS 12.15 / FRS 102 s29 / ASC 740-10-20",
      category: "P&L",
      note: "Accruals (£2,000) recognised as expense in P&L but not yet tax deductible. UK tax deductibility follows the accruals basis for trading expense, but for non-trading provisions deductible only when paid. DTA recognised as reversal expected within 12 months.",
    },
    {
      item: "Bad debt provision (general, not specific — added back for tax)",
      carryingAmount: 2500,        // expense recognised in P&L
      taxBase: 0,                  // tax base: £0 (general provision NOT deductible; specific write-offs ARE)
      temporaryDifference: 2500,   // taxable temporary difference → DTL (will reverse when debt specifically written off)
      dtl: 2500 * UK_CT_RATE,      // £625 DTL
      dta: 0,
      standard: "IAS 12.15 / FRS 102 s29 / ASC 740-10-20",
      category: "P&L",
      note: "General bad debt provision £2,500 (not specifically identified). UK tax: general provisions are NOT deductible (CTA 2009 s36); only specific debts formally written off are deductible. Addback £2,500 in current tax computation; deferred tax £625 DTL recognised as temporary difference reverses when debt is specifically written off (then deductible for tax).",
    },
    {
      item: "Pension contributions — accrual vs cash paid",
      carryingAmount: 8280,        // accounting expense
      taxBase: 8280,               // tax deduction in year paid
      temporaryDifference: 0,      // no temp diff (paid in same period)
      dtl: 0,
      dta: 0,
      standard: "IAS 19 / IAS 12 / ASC 715 / ASC 740",
      category: "P&L",
      note: "Defined contribution pension scheme — expense recognised when employee renders service, paid monthly to provider. No temporary difference as cash paid within 9 months of year-end.",
    },
  ];

  // OCI-related deferred tax items (per IAS 12.91 — tax on OCI debited/credited to OCI, not P&L)
  const tempDiffsOci: TempDiff[] = [
    {
      item: "PPE Revaluation Surplus (IAS 16 revaluation model)",
      carryingAmount: 1200,        // OCI gain
      taxBase: 0,
      temporaryDifference: 1200,
      dtl: 1200 * UK_CT_RATE,      // £300 DTL
      dta: 0,
      standard: "IAS 12.91 / IAS 16 / ASC 740-20 (US GAAP — no revaluation)",
      category: "OCI",
      note: "Revaluation surplus £1,200 credited to OCI. Deferred tax £300 also recognised in OCI (not P&L). US GAAP does not allow revaluation model — no OCI impact.",
    },
    {
      item: "Pension Remeasurement Loss (IAS 19 remeasurement)",
      carryingAmount: -500,        // OCI loss
      taxBase: 0,
      temporaryDifference: -500,
      dtl: 0,
      dta: 500 * UK_CT_RATE,       // £125 DTA
      standard: "IAS 12.91 / IAS 19 / ASC 715",
      category: "OCI",
      note: "Actuarial loss £500 debited to OCI. Deferred tax asset £125 recognised in OCI. Under US GAAP, similar remeasurement also routed to OCI.",
    },
    {
      item: "Equity Instruments at FVOCI (IFRS 9 irrevocable election)",
      carryingAmount: 300,         // OCI gain
      taxBase: 0,
      temporaryDifference: 300,
      dtl: 300 * UK_CT_RATE,       // £75 DTL
      dta: 0,
      standard: "IAS 12.91 / IFRS 9 / ASC 321 (US GAAP — no FVOCI election)",
      category: "OCI",
      note: "Unrealised gain £300 on strategic equity investment held at FVOCI. Deferred tax £75 in OCI. US GAAP has no equivalent FVOCI election — gains/losses on equity securities are always in P&L.",
    },
    {
      item: "Foreign Currency Translation Differences (IAS 21)",
      carryingAmount: 1850,        // OCI gain
      taxBase: 0,
      temporaryDifference: 1850,
      dtl: 1850 * UK_CT_RATE,      // £462.50 DTL
      dta: 0,
      standard: "IAS 12.91 / IAS 21 / ASC 740-20 / ASC 830",
      category: "OCI",
      note: "FX translation gain £1,850 credited to OCI on EUR receivables and USD cash. Deferred tax £462.50 recognised in OCI. Will reverse when foreign operation is disposed of.",
    },
    {
      item: "Cash Flow Hedge — effective portion (IFRS 9)",
      carryingAmount: 500,         // OCI gain
      taxBase: 0,
      temporaryDifference: 500,
      dtl: 500 * UK_CT_RATE,       // £125 DTL
      dta: 0,
      standard: "IAS 12.91 / IFRS 9 / ASC 815",
      category: "OCI",
      note: "Effective portion of cash flow hedge £500 in OCI. Deferred tax £125 in OCI. Will reclassify to P&L (and tax to P&L) when hedged transaction affects earnings.",
    },
    {
      item: "Debt instruments at FVOCI",
      carryingAmount: 0,            // no debt instruments held
      taxBase: 0,
      temporaryDifference: 0,
      dtl: 0,
      dta: 0,
      standard: "IAS 12.91 / IFRS 9 / ASC 320",
      category: "OCI",
      note: "No debt instruments held at FVOCI at year-end. If held, gains/losses in OCI (recyclable) and deferred tax also in OCI.",
    },
  ];

  const allTempDiffs = [...tempDiffsPAndL, ...tempDiffsOci];

  // ============ DTL / DTA TOTALS ============
  const totalDtlPAndL = tempDiffsPAndL.reduce((s, t) => s + t.dtl, 0);          // £4,437.50
  const totalDtaPAndL = tempDiffsPAndL.reduce((s, t) => s + t.dta, 0);          // £500
  const netDtlPAndL = totalDtlPAndL - totalDtaPAndL;                            // £3,937.50

  const totalDtlOci = tempDiffsOci.reduce((s, t) => s + t.dtl, 0);              // £962.50
  const totalDtaOci = tempDiffsOci.reduce((s, t) => s + t.dta, 0);              // £125
  const netDtlOci = totalDtlOci - totalDtaOci;                                  // £837.50

  const totalDtl = totalDtlPAndL + totalDtlOci;                                 // £5,400
  const totalDta = totalDtaPAndL + totalDtaOci;                                 // £625
  const netDeferredTaxLiability = totalDtl - totalDta;                           // £4,775

  // ============ MOVEMENT SCHEDULE (opening + movements = closing) ============
  const movement = {
    openingDtl: 0,
    openingDta: 0,
    pAndLChargeDeferredTax: netDtlPAndL,        // £3,937.50 (increases DTL, increases tax expense)
    ociChargeDeferredTax: netDtlOci,            // £837.50 (increases DTL, debited to OCI)
    closingDtl: totalDtl,                       // £5,400
    closingDta: totalDta,                       // £625
    closingNetDeferredTaxLiability: netDeferredTaxLiability,  // £4,775
  };

  // ============ TAX RECONCILIATION (accounting profit → taxable profit → tax charge) ============
  const accountingProfitBeforeTax = 646711;
  const currentTaxAdjustments = [
    { item: "Add: Depreciation (accounting, non-deductible for tax)", amount: 3250, type: "addback" },
    { item: "Add: Amortisation (accounting, non-deductible for tax)", amount: 4000, type: "addback" },
    { item: "Add: General bad debt provision (not specifically identified — CTA 2009 s36)", amount: 2500, type: "addback" },
    { item: "Less: Capital Allowances (AIA — 100% relief on PPE + Intangibles)", amount: -25000, type: "deduction" },
  ];
  const taxableProfit = accountingProfitBeforeTax + currentTaxAdjustments.reduce((s, a) => s + a.amount, 0);  // £631,461
  const currentTax = taxableProfit * UK_CT_RATE;                                                                  // £157,865.25
  const deferredTaxPAndL = netDtlPAndL;                                                                            // £4,562.50
  const totalTaxExpensePAndL = currentTax + deferredTaxPAndL;                                                      // £162,427.75
  const effectiveTaxRate = totalTaxExpensePAndL / accountingProfitBeforeTax;                                       // ~25.09%

  // ============ JOURNAL ENTRIES (per IFRS / UK FRS 102 / US GAAP / EU IFRS-EU) ============
  // IFRS: Dr/Cr Income Tax Expense (P&L), Deferred Tax Liability (BS), Income Tax Payable (BS)
  // US GAAP: same account names — ASC 740 Income Tax Provision / Benefit
  // UK FRS 102: same account names — Section 29 Income Tax
  // EU IFRS-EU: identical to IFRS as endorsed by European Commission

  const journalEntries = [
    {
      jeNo: "JE-TAX-001",
      date: "2025-12-31",
      description: "Current Corporation Tax provision for FY2025 (per CT600 computation)",
      standard: "IAS 12.80 / FRS 102 s29 / ASC 740-30 / EU IFRS-EU",
      entries: [
        { account: "8000 — Corporation Tax (P&L expense)", debit: 157865.25, credit: 0 },
        { account: "2400 — Corporation Tax Payable (BS liability)", debit: 0, credit: 157865.25 },
      ],
      narrative: "Recognises the current tax obligation for FY2025 at the UK main rate of 25%. Per IAS 12.80, current tax is the amount expected to be paid to/recovered from tax authorities. The £157,865.25 liability is payable 9 months + 1 day after year-end (1 October 2026) per UK CT payment rules.",
    },
    {
      jeNo: "JE-TAX-002",
      date: "2025-12-31",
      description: "Deferred tax — PPE accelerated capital allowances (DTL increase)",
      standard: "IAS 12.15 / FRS 102 s29.10 / ASC 740-10-20",
      entries: [
        { account: "8000 — Corporation Tax (deferred portion, P&L)", debit: 2437.50, credit: 0 },
        { account: "2410 — Deferred Tax Liability (BS non-current)", debit: 0, credit: 2437.50 },
      ],
      narrative: "Recognises deferred tax liability on taxable temporary difference of £9,750 (PPE accounting NBV £9,750 vs tax NBV £0 after AIA). Reversing over remaining useful life as accounting depreciation continues while tax NBV stays at £0. DTL = £9,750 × 25% = £2,437.50.",
    },
    {
      jeNo: "JE-TAX-003",
      date: "2025-12-31",
      description: "Deferred tax — Intangible assets (software development capitalised)",
      standard: "IAS 12.15 / FRS 102 s29.10 / ASC 740-10-20",
      entries: [
        { account: "8000 — Corporation Tax (deferred portion, P&L)", debit: 2000, credit: 0 },
        { account: "2410 — Deferred Tax Liability (BS non-current)", debit: 0, credit: 2000 },
      ],
      narrative: "Recognises deferred tax liability on taxable temporary difference of £8,000 (intangible accounting NBV £8,000 vs tax NBV £0). DTL = £8,000 × 25% = £2,000. Reversing over remaining 2 years of accounting amortisation.",
    },
    {
      jeNo: "JE-TAX-004",
      date: "2025-12-31",
      description: "Deferred tax — General bad debt provision (DTL on taxable temporary difference)",
      standard: "IAS 12.15 / FRS 102 s29.10 / ASC 740-10-20 / CTA 2009 s36",
      entries: [
        { account: "8000 — Corporation Tax (deferred portion, P&L)", debit: 625, credit: 0 },
        { account: "2410 — Deferred Tax Liability (BS non-current)", debit: 0, credit: 625 },
      ],
      narrative: "General bad debt provision £2,500 added back for tax (not specifically identified per CTA 2009 s36). DTL = £2,500 × 25% = £625. Temporary difference reverses when the debt is specifically written off (at which point it becomes tax deductible).",
    },
    {
      jeNo: "JE-TAX-005",
      date: "2025-12-31",
      description: "Deferred tax — Accruals (DTA on deductible temporary difference)",
      standard: "IAS 12.34 / FRS 102 s29.10 / ASC 740-10-30",
      entries: [
        { account: "2420 — Deferred Tax Asset (BS current)", debit: 500, credit: 0 },
        { account: "8000 — Corporation Tax (deferred portion, P&L)", debit: 0, credit: 500 },
      ],
      narrative: "Recognises deferred tax asset on deductible temporary difference of £2,000 (accrual liability recognised but not yet tax deductible). DTA = £2,000 × 25% = £500. Probable that future taxable profit will be available (per IAS 12.34 — more-likely-than-not test). Reversal expected within 12 months as accruals are paid.",
    },
    {
      jeNo: "JE-TAX-006",
      date: "2025-12-31",
      description: "Deferred tax on OCI items — PPE revaluation surplus (IAS 16)",
      standard: "IAS 12.91 / IAS 16.39 / FRS 102 s29.12 / EU IFRS-EU",
      entries: [
        { account: "3200A — Accumulated OCI Reserve (equity)", debit: 300, credit: 0 },
        { account: "2410 — Deferred Tax Liability (BS non-current)", debit: 0, credit: 300 },
      ],
      narrative: "Deferred tax on PPE revaluation surplus £1,200 recognised in OCI (NOT P&L) per IAS 12.91. DTL = £1,200 × 25% = £300. Both the revaluation surplus (£1,200 gross) and the deferred tax (£300) are credited/debited to OCI, with net £900 to Accumulated OCI Reserve. US GAAP does not allow PPE revaluation — no equivalent entry.",
    },
    {
      jeNo: "JE-TAX-007",
      date: "2025-12-31",
      description: "Deferred tax on OCI items — Pension remeasurement loss (IAS 19)",
      standard: "IAS 12.91 / IAS 19.122A / FRS 102 s29.12 / ASC 715-30",
      entries: [
        { account: "2420 — Deferred Tax Asset (BS non-current)", debit: 125, credit: 0 },
        { account: "3200A — Accumulated OCI Reserve (equity)", debit: 0, credit: 125 },
      ],
      narrative: "Deferred tax asset on pension remeasurement loss £500 recognised in OCI per IAS 12.91. DTA = £500 × 25% = £125. Credited to Accumulated OCI Reserve, partially offsetting the £500 actuarial loss.",
    },
    {
      jeNo: "JE-TAX-008",
      date: "2025-12-31",
      description: "Deferred tax on OCI items — FVOCI equity instruments (IFRS 9)",
      standard: "IAS 12.91 / IFRS 9.5.7.5 / EU IFRS-EU",
      entries: [
        { account: "3200A — Accumulated OCI Reserve (equity)", debit: 75, credit: 0 },
        { account: "2410 — Deferred Tax Liability (BS non-current)", debit: 0, credit: 75 },
      ],
      narrative: "Deferred tax on FVOCI equity gain £300 (irrevocable election under IFRS 9.5.7.5). DTL = £300 × 25% = £75. Both the FVOCI gain and the deferred tax are routed to OCI per IAS 12.91. US GAAP has no FVOCI election for equity securities — gains/losses always in P&L.",
    },
    {
      jeNo: "JE-TAX-009",
      date: "2025-12-31",
      description: "Deferred tax on OCI items — FX translation (IAS 21)",
      standard: "IAS 12.91 / IAS 21.48C / FRS 102 s30 / ASC 740-20 / ASC 830",
      entries: [
        { account: "3200A — Accumulated OCI Reserve (equity)", debit: 462.50, credit: 0 },
        { account: "2410 — Deferred Tax Liability (BS non-current)", debit: 0, credit: 462.50 },
      ],
      narrative: "Deferred tax on FX translation gain £1,850 recognised in OCI per IAS 12.91. DTL = £1,850 × 25% = £462.50. Will reverse when foreign operation is disposed of or when the underlying receivables are settled.",
    },
    {
      jeNo: "JE-TAX-010",
      date: "2025-12-31",
      description: "Deferred tax on OCI items — Cash flow hedge effective portion (IFRS 9)",
      standard: "IAS 12.91 / IFRS 9.6.5.11 / ASC 815-30",
      entries: [
        { account: "3200A — Accumulated OCI Reserve (equity)", debit: 125, credit: 0 },
        { account: "2410 — Deferred Tax Liability (BS non-current)", debit: 0, credit: 125 },
      ],
      narrative: "Deferred tax on cash flow hedge gain £500 recognised in OCI per IAS 12.91. DTL = £500 × 25% = £125. Will reclassify to P&L (and tax to P&L) when hedged forecast transaction affects profit or loss.",
    },
  ];

  // Verification: total debits = total credits across all journal entries
  const totalDebitsAllJe = journalEntries.reduce(
    (sum, je) => sum + je.entries.reduce((s, e) => s + e.debit, 0), 0
  );
  const totalCreditsAllJe = journalEntries.reduce(
    (sum, je) => sum + je.entries.reduce((s, e) => s + e.credit, 0), 0
  );

  // ============ STANDARDS PANEL ============
  const standards = {
    ifrs: {
      label: "IFRS (IASB)",
      standard: "IAS 12 — Income Taxes",
      scope: "International. Recognises both current tax (expected payable) and deferred tax (temporary differences). DTL on taxable temp diffs, DTA on deductible temp diffs. Tax on OCI items routed to OCI per IAS 12.91. Initial recognition exemption (IAS 12.15(b)) for non-business-combination asset acquisitions that don't affect accounting/taxable profit.",
      color: "emerald",
    },
    usGaap: {
      label: "US GAAP (FASB)",
      standard: "ASC 740 — Income Taxes",
      scope: "US. Two-step model: current tax (estimated payable) + deferred tax (temporary differences). No initial recognition exception. Valuation allowance against DTAs if more-likely-than-not (>50%) not realisable. FIN 48 (ASC 740-10) uncertain tax positions: more-likely-than-not recognition threshold. Tax on OCI items routed to OCI.",
      color: "blue",
    },
    uk: {
      label: "UK FRS 102 (FRS 102 Section 1A small companies)",
      standard: "FRS 102 Section 29 — Income Tax",
      scope: "UK. Substantively converged with IAS 12. Section 1A small companies can simplify deferred tax on certain fair value revaluations but full deferred tax required on accelerated capital allowances, pension liabilities, and other reversing differences.",
      color: "amber",
    },
    eu: {
      label: "EU (IFRS-EU)",
      standard: "IAS 12 as endorsed by European Commission",
      scope: "EU. IAS 12 as endorsed for use in EU via IAS Regulation 1606/2002. Substantively identical to IAS 12 as issued by IASB. EU also recognises national tax codes (e.g., Germany KStG, France CGI, Ireland TCA) for current tax computation.",
      color: "violet",
    },
  };

  return NextResponse.json({
    company: {
      name: company.name,
      country: company.country,
      currency: company.currency,
      symbol: currency,
    },
    tempDiffsPAndL,
    tempDiffsOci,
    allTempDiffs,
    totals: {
      totalDtlPAndL,
      totalDtaPAndL,
      netDtlPAndL,
      totalDtlOci,
      totalDtaOci,
      netDtlOci,
      totalDtl,
      totalDta,
      netDeferredTaxLiability,
    },
    movement,
    reconciliation: {
      accountingProfitBeforeTax,
      currentTaxAdjustments,
      taxableProfit,
      currentTaxRate: UK_CT_RATE,
      currentTax,
      deferredTaxPAndL,
      deferredTaxOci: netDtlOci,
      totalTaxExpensePAndL,
      totalTaxExpenseIncludingOci: totalTaxExpensePAndL + netDtlOci,
      effectiveTaxRate,
      accountingProfitAfterTax: accountingProfitBeforeTax - totalTaxExpensePAndL,
    },
    journalEntries,
    jeVerification: {
      totalDebits: totalDebitsAllJe,
      totalCredits: totalCreditsAllJe,
      balanced: totalDebitsAllJe === totalCreditsAllJe,
    },
    standards,
    rates: {
      ukCtMainRate: UK_CT_RATE,
      ukSmallProfitsRate: 0.19,
      ukSmallProfitsThreshold: 50000,
      ukMainRateThreshold: 250000,
      usFederalRate: 0.21,
      germanKorpRate: 0.15,
      frenchIsRate: 0.25,
      irishTradingRate: 0.125,
    },
    disclosureNote: "Deferred tax is recognised on all temporary differences at the UK main CT rate of 25% (enacted at reporting date per IAS 12.47). DTLs for PPE and intangibles (£4,437.50 gross) reverse as accounting depreciation/amortisation continues while tax NBV remains at £0. DTA on accruals (£500) reverses within 12 months. Deferred tax on OCI items (£837.50) is recognised in OCI per IAS 12.91 and presented as a separate component of Accumulated OCI Reserve. Net deferred tax liability of £4,775 is classified as non-current. Standards applied: IAS 12 (IFRS), ASC 740 (US GAAP), FRS 102 Section 29 (UK), IFRS-EU (EU).",
  });
}
