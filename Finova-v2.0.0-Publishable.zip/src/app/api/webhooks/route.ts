import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { randomBytes } from "crypto";

// GET /api/webhooks?companyId=...
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) return NextResponse.json({ error: "companyId required" }, { status: 400 });
  const hooks = await db.webhook.findMany({
    where: { companyId },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({
    webhooks: hooks.map((h) => ({
      id: h.id,
      url: h.url,
      events: JSON.parse(h.eventsJson) as string[],
      enabled: h.enabled,
      secretMasked: h.secret.slice(0, 6) + "…" + h.secret.slice(-4),
      lastFiredAt: h.lastFiredAt?.toISOString() ?? null,
      lastStatus: h.lastStatus,
      deliveries: h.deliveries,
    })),
  });
}

// POST /api/webhooks  { companyId, url, events }
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { companyId, url, events } = body as { companyId: string; url: string; events: string[] };
  if (!companyId || !url || !Array.isArray(events) || events.length === 0) {
    return NextResponse.json({ error: "companyId, url, events are required" }, { status: 400 });
  }
  const secret = randomBytes(24).toString("hex");
  const hook = await db.webhook.create({
    data: { companyId, url, eventsJson: JSON.stringify(events), secret, enabled: true },
  });
  return NextResponse.json({
    webhook: { ...hook, events: JSON.parse(hook.eventsJson) },
    secret, // returned ONCE so user can copy it; never echoed again
  });
}

// PATCH /api/webhooks  { id, enabled }
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { id, enabled } = body;
  if (!id || typeof enabled !== "boolean") {
    return NextResponse.json({ error: "id and enabled required" }, { status: 400 });
  }
  const updated = await db.webhook.update({ where: { id }, data: { enabled } });
  return NextResponse.json({ webhook: updated });
}

// DELETE /api/webhooks  { id }
export async function DELETE(req: NextRequest) {
  const body = await req.json();
  const { id } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.webhook.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
