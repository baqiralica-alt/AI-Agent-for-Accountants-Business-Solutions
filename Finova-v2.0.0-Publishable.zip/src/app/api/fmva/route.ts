import { NextResponse } from "next/server";
import {
  WACC_COMPONENTS, WACC_RESULT,
  DCF_VALUATION,
  TRADING_COMPARABLES,
  PRECEDENT_TRANSACTIONS_DATA,
  SENSITIVITY_DATA,
  FOOTBALL_FIELD, FOOTBALL_FIELD_SUMMARY,
  LBO_ANALYSIS,
  MA_ANALYSIS,
  FMVA_REPORTS_INDEX,
  FMVA_META,
} from "@/lib/fmva-data";

// GET /api/fmva
// Returns the full FMVA® Reporting Framework with 9 valuation methodologies
// and the FMVA-Compliant Reports index.

export async function GET() {
  return NextResponse.json({
    meta: FMVA_META,
    wacc: { components: WACC_COMPONENTS, result: WACC_RESULT },
    dcf: DCF_VALUATION,
    tradingComps: TRADING_COMPARABLES,
    precedentTx: PRECEDENT_TRANSACTIONS_DATA,
    sensitivity: SENSITIVITY_DATA,
    footballField: { methods: FOOTBALL_FIELD, summary: FOOTBALL_FIELD_SUMMARY },
    lbo: LBO_ANALYSIS,
    maAccretion: MA_ANALYSIS,
    reportsIndex: FMVA_REPORTS_INDEX,
  });
}
