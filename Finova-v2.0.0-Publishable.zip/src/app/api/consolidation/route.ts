import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/consolidation?companyIds=a,b,c  → consolidated TB/P&L/BS across those entities
export async function GET(req: NextRequest) {
  const idsParam = req.nextUrl.searchParams.get("companyIds");
  if (!idsParam) return NextResponse.json({ error: "companyIds required (comma-separated)" }, { status: 400 });
  const companyIds = idsParam.split(",").map((s) => s.trim()).filter(Boolean);
  if (companyIds.length < 2) return NextResponse.json({ error: "Need at least 2 companies to consolidate" }, { status: 400 });

  const companies = await db.company.findMany({
    where: { id: { in: companyIds } },
    include: { transactions: true },
  });
  if (companies.length === 0) return NextResponse.json({ error: "No matching companies" }, { status: 404 });

  // Build a consolidated income map and expense map across all entities
  const income = new Map<string, number>();
  const expense = new Map<string, number>();
  let intercompanyRevenue = 0;
  let intercompanyExpense = 0;
  let grossRevenue = 0;
  let grossExpense = 0;

  for (const co of companies) {
    for (const t of co.transactions) {
      const isIC = /intercompany|inter-co|ic-|related party/i.test(t.description);
      if (t.type === "income") {
        income.set(t.category, (income.get(t.category) ?? 0) + t.amount);
        grossRevenue += t.amount;
        if (isIC) intercompanyRevenue += t.amount;
      } else {
        expense.set(t.category, (expense.get(t.category) ?? 0) + t.amount);
        grossExpense += t.amount;
        if (isIC) intercompanyExpense += t.amount;
      }
    }
  }

  // Intercompany elimination — assume 100% of "intercompany" tagged revenue is eliminated against intercompany expense
  const elimination = Math.min(intercompanyRevenue, intercompanyExpense);

  // Consolidated totals
  const totalRevenue = grossRevenue - elimination;
  const totalExpense = grossExpense - elimination;
  const netProfit = totalRevenue - totalExpense;
  const margin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  // Per-entity breakdown (for the "group companies" table)
  const entities = companies.map((c) => {
    const rev = c.transactions.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
    const exp = c.transactions.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
    return {
      id: c.id,
      name: c.name,
      industry: c.industry,
      country: c.country,
      currency: c.currency,
      revenue: rev,
      expenses: exp,
      netProfit: rev - exp,
    };
  });

  return NextResponse.json({
    entityCount: companies.length,
    entities,
    grossRevenue,
    grossExpense,
    grossNetProfit: grossRevenue - grossExpense,
    intercompanyRevenue,
    intercompanyExpense,
    elimination,
    consolidated: {
      revenue: totalRevenue,
      expenses: totalExpense,
      netProfit,
      margin,
      income: Array.from(income.entries()).map(([category, amount]) => ({ category, amount: isIntercompany(category) ? amount - elimination * (amount / grossRevenue) : amount })),
      expense: Array.from(expense.entries()).map(([category, amount]) => ({ category, amount })),
    },
    standard: "IFRS 10 / ASC 810",
    note: "Intercompany transactions eliminated against corresponding counterparty entries. Minority interest and goodwill from acquisitions are computed in the M&A module.",
  });
}

function isIntercompany(cat: string) {
  return /intercompany|inter-co|related/i.test(cat);
}
