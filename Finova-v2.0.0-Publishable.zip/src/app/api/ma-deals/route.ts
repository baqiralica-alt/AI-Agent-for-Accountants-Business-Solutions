import { NextResponse } from "next/server";
import { MA_DEALS, GOODWILL_ROLLFORWARD, AMORTIZATION_SCHEDULE, TOTAL_ANNUAL_AMORTIZATION, MA_PORTFOLIO_SUMMARY, MA_META } from "@/lib/ma-deals-data";

export async function GET() {
  return NextResponse.json({
    meta: MA_META,
    deals: MA_DEALS,
    goodwillRollforward: GOODWILL_ROLLFORWARD,
    amortizationSchedule: AMORTIZATION_SCHEDULE,
    totalAnnualAmortization: TOTAL_ANNUAL_AMORTIZATION,
    summary: MA_PORTFOLIO_SUMMARY,
  });
}
