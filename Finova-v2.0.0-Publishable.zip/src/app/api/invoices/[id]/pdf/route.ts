import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { PDFDocument, StandardFonts, rgb, PageSizes } from "pdf-lib";

// GET /api/invoices/[id]/pdf — generate a professional PDF
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const invoice = await db.invoice.findUnique({ where: { id }, include: { company: true } });
  if (!invoice) return NextResponse.json({ error: "Invoice not found" }, { status: 404 });

  const lines = JSON.parse(invoice.linesJson) as Array<{
    description: string; qty: number; unitPrice: number; taxRate: number; account?: string; total: number;
  }>;

  const pdfDoc = await PDFDocument.create();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const page = pdfDoc.addPage(PageSizes.A4);
  const { width, height } = page.getSize();
  const margin = 50;
  const sym = invoice.currency === "USD" ? "$" : invoice.currency === "GBP" ? "£" : "€";
  const isVendor = invoice.type === "vendor";
  const docTitle = isVendor ? "BILL FROM" : "INVOICE";

  // Header bar
  page.drawRectangle({
    x: 0, y: height - 80, width, height: 80,
    color: rgb(0.063, 0.275, 0.365), // emerald-tinted dark slate
  });
  // Brand name on left
  page.drawText(invoice.company.name, {
    x: margin, y: height - 35, size: 18, font: bold, color: rgb(1, 1, 1),
  });
  page.drawText("Finova · Finance · Accounting · AI Agents", {
    x: margin, y: height - 55, size: 9, font, color: rgb(0.85, 0.92, 0.95),
  });
  // Doc title on right
  page.drawText(docTitle, {
    x: width - margin - bold.widthOfTextAtSize(docTitle, 22), y: height - 40, size: 22, font: bold, color: rgb(1, 1, 1),
  });

  // Top section: parties + meta
  let y = height - 110;
  page.drawText(`${isVendor ? "Vendor" : "Customer"}`, { x: margin, y, size: 10, font: bold, color: rgb(0.4, 0.4, 0.4) });
  page.drawText(invoice.partyName, { x: margin, y: y - 14, size: 11, font, color: rgb(0, 0, 0) });
  if (invoice.partyAddress) page.drawText(invoice.partyAddress, { x: margin, y: y - 28, size: 9, font, color: rgb(0.3, 0.3, 0.3) });
  if (invoice.partyEmail) page.drawText(invoice.partyEmail, { x: margin, y: y - 42, size: 9, font, color: rgb(0.3, 0.3, 0.3) });

  // Meta on right
  const meta = [
    ["Invoice #", invoice.number],
    ["Date", new Date(invoice.date).toLocaleDateString()],
    ["Due Date", new Date(invoice.dueDate).toLocaleDateString()],
    ["Status", invoice.status.toUpperCase()],
    ["Template", invoice.template],
  ];
  let metaY = y;
  for (const [k, v] of meta) {
    page.drawText(k, { x: width - margin - 200, y: metaY, size: 9, font: bold, color: rgb(0.4, 0.4, 0.4) });
    page.drawText(String(v), { x: width - margin - 100, y: metaY, size: 9, font, color: rgb(0, 0, 0) });
    metaY -= 14;
  }

  // Lines table header
  y -= 80;
  const tableTop = y;
  const tableX = margin;
  const tableWidth = width - margin * 2;
  page.drawRectangle({ x: tableX, y: y - 14, width: tableWidth, height: 18, color: rgb(0.95, 0.96, 0.97) });
  const cols = [
    { label: "Description", x: tableX + 8, w: tableWidth * 0.45 },
    { label: "Qty", x: tableX + tableWidth * 0.45 + 8, w: tableWidth * 0.1 },
    { label: "Unit Price", x: tableX + tableWidth * 0.55 + 8, w: tableWidth * 0.15 },
    { label: "Tax", x: tableX + tableWidth * 0.70 + 8, w: tableWidth * 0.1 },
    { label: "Total", x: tableX + tableWidth * 0.80 + 8, w: tableWidth * 0.2 },
  ];
  for (const c of cols) {
    page.drawText(c.label, { x: c.x, y: y - 4, size: 9, font: bold, color: rgb(0.3, 0.3, 0.3) });
  }
  y -= 22;

  // Lines
  for (const line of lines) {
    if (y < 120) {
      // Add page break
      page.drawText(`... continued ...`, { x: margin, y: 40, size: 8, font, color: rgb(0.5, 0.5, 0.5) });
      // simple: stop rendering more lines if we run out of space
      break;
    }
    const desc = line.description.length > 60 ? line.description.slice(0, 57) + "…" : line.description;
    page.drawText(desc, { x: cols[0].x, y, size: 9, font, color: rgb(0.1, 0.1, 0.1) });
    page.drawText(String(line.qty), { x: cols[1].x, y, size: 9, font, color: rgb(0.1, 0.1, 0.1) });
    page.drawText(`${sym}${line.unitPrice.toFixed(2)}`, { x: cols[2].x, y, size: 9, font, color: rgb(0.1, 0.1, 0.1) });
    page.drawText(`${(line.taxRate || 0).toFixed(1)}%`, { x: cols[3].x, y, size: 9, font, color: rgb(0.1, 0.1, 0.1) });
    page.drawText(`${sym}${line.total.toFixed(2)}`, { x: cols[4].x, y, size: 9, font: bold, color: rgb(0.1, 0.1, 0.1) });
    y -= 16;
  }

  // Totals box
  y -= 16;
  const totalsX = width - margin - 200;
  const drawTotal = (label: string, value: string, isBold = false) => {
    page.drawText(label, { x: totalsX, y, size: 10, font: isBold ? bold : font, color: rgb(0.2, 0.2, 0.2) });
    page.drawText(value, { x: width - margin - bold.widthOfTextAtSize(value, 10) - 4, y, size: 10, font: isBold ? bold : font, color: rgb(0.1, 0.1, 0.1) });
    y -= 16;
  };
  drawTotal("Subtotal", `${sym}${invoice.subtotal.toFixed(2)}`);
  drawTotal("Tax", `${sym}${invoice.taxTotal.toFixed(2)}`);
  // Divider
  page.drawLine({ start: { x: totalsX, y: y + 8 }, end: { x: width - margin, y: y + 8 }, thickness: 0.5, color: rgb(0.7, 0.7, 0.7) });
  drawTotal("TOTAL", `${sym}${invoice.total.toFixed(2)}`, true);

  // Notes
  if (invoice.notes) {
    y -= 30;
    page.drawText("Notes:", { x: margin, y, size: 9, font: bold, color: rgb(0.3, 0.3, 0.3) });
    y -= 12;
    const lines2 = invoice.notes.split("\n").slice(0, 4);
    for (const ln of lines2) {
      page.drawText(ln.slice(0, 90), { x: margin, y, size: 9, font, color: rgb(0.3, 0.3, 0.3) });
      y -= 12;
    }
  }

  // Footer
  page.drawText(`Generated by Finova · Finance · Accounting · AI Agents — advisory outputs only, verify with a licensed CPA before filing.`, {
    x: margin, y: 30, size: 8, font, color: rgb(0.5, 0.5, 0.5),
  });

  const pdfBytes = await pdfDoc.save();
  const filename = `${invoice.type === "vendor" ? "bill" : "invoice"}-${invoice.number}.pdf`;
  return new NextResponse(pdfBytes, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${filename}"`,
    },
  });
}
