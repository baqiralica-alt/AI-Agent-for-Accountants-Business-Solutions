import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

type Line = { description: string; qty: number; unitPrice: number; taxRate: number; account?: string; total: number };

// GET /api/invoices?companyId=...&type=customer|vendor
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  const type = req.nextUrl.searchParams.get("type");
  if (!companyId) return NextResponse.json({ error: "companyId required" }, { status: 400 });
  const where: any = { companyId };
  if (type === "customer" || type === "vendor") where.type = type;
  const invoices = await db.invoice.findMany({
    where,
    orderBy: { date: "desc" },
    take: 200,
  });
  return NextResponse.json({
    invoices: invoices.map((i) => ({
      id: i.id,
      type: i.type,
      number: i.number,
      partyName: i.partyName,
      partyEmail: i.partyEmail,
      partyAddress: i.partyAddress,
      date: i.date.toISOString(),
      dueDate: i.dueDate.toISOString(),
      currency: i.currency,
      lines: JSON.parse(i.linesJson) as Line[],
      subtotal: i.subtotal,
      taxTotal: i.taxTotal,
      total: i.total,
      status: i.status,
      template: i.template,
      notes: i.notes,
    })),
  });
}

// POST /api/invoices  — create a new customer or vendor invoice
export async function POST(req: NextRequest) {
  const body = await req.json();
  const {
    companyId, type, number, partyName, partyEmail, partyAddress,
    date, dueDate, currency, lines, template, notes,
  } = body as {
    companyId: string;
    type: "customer" | "vendor";
    number: string;
    partyName: string;
    partyEmail?: string;
    partyAddress?: string;
    date?: string;
    dueDate?: string;
    currency?: string;
    lines: Line[];
    template?: string;
    notes?: string;
  };
  if (!companyId || !type || !number || !partyName || !Array.isArray(lines) || lines.length === 0) {
    return NextResponse.json({ error: "companyId, type, number, partyName, lines are required" }, { status: 400 });
  }
  const company = await db.company.findUnique({ where: { id: companyId } });
  if (!company) return NextResponse.json({ error: "Company not found" }, { status: 404 });

  const cur = currency || company.currency;
  const subtotal = lines.reduce((s, l) => s + (l.qty * l.unitPrice), 0);
  const taxTotal = lines.reduce((s, l) => s + (l.qty * l.unitPrice * (l.taxRate || 0) / 100), 0);
  const total = subtotal + taxTotal;

  const invoice = await db.invoice.create({
    data: {
      companyId,
      type,
      number,
      partyName,
      partyEmail: partyEmail ?? null,
      partyAddress: partyAddress ?? null,
      date: date ? new Date(date) : new Date(),
      dueDate: dueDate ? new Date(dueDate) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      currency: cur,
      linesJson: JSON.stringify(lines),
      subtotal,
      taxTotal,
      total,
      status: "draft",
      template: template || "standard",
      notes: notes ?? null,
    },
  });
  return NextResponse.json({ invoice });
}

// PATCH /api/invoices  { id, status }  — update invoice status (e.g. mark sent / paid)
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { id, status } = body;
  if (!id || !status) return NextResponse.json({ error: "id and status required" }, { status: 400 });
  const updated = await db.invoice.update({ where: { id }, data: { status } });
  return NextResponse.json({ invoice: updated });
}
