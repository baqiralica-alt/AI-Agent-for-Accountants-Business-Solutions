import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/disclosures?companyId=...&standard=IFRS
// Returns the IAS 1 / US GAAP disclosure notes for the company
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  const standard = req.nextUrl.searchParams.get("standard") || "IFRS";
  if (!companyId) return NextResponse.json({ error: "companyId required" }, { status: 400 });
  const notes = await db.disclosureNote.findMany({
    where: { companyId, standard },
    orderBy: { noteNumber: "asc" },
  });
  // If no notes seeded, return the standard IAS 1 / US GAAP templates
  if (notes.length === 0) {
    return NextResponse.json({ notes: defaultNotes(standard), seeded: false });
  }
  return NextResponse.json({ notes, seeded: true });
}

// POST /api/disclosures — save (upsert) a disclosure note
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { companyId, standard, noteNumber, title, body: noteBody } = body;
  if (!companyId || !standard || !title || !noteBody) {
    return NextResponse.json({ error: "companyId, standard, title, body required" }, { status: 400 });
  }
  // Check if a note with the same number exists for this company+standard
  const existing = await db.disclosureNote.findFirst({ where: { companyId, standard, noteNumber: Number(noteNumber) ?? 0 } });
  let note;
  if (existing) {
    note = await db.disclosureNote.update({ where: { id: existing.id }, data: { title, body: noteBody } });
  } else {
    note = await db.disclosureNote.create({
      data: {
        companyId,
        standard,
        noteNumber: Number(noteNumber) ?? Math.floor(Math.random() * 100),
        title,
        body: noteBody,
      },
    });
  }
  return NextResponse.json({ note });
}

function defaultNotes(standard: string) {
  if (standard === "US-GAAP") {
    return [
      { noteNumber: 1, title: "Basis of Presentation and Significant Accounting Policies", body: "These consolidated financial statements are prepared in accordance with U.S. Generally Accepted Accounting Principles (U.S. GAAP) as codified in the FASB Accounting Standards Codification (ASC). The Company's fiscal year ends December 31. The consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated." },
      { noteNumber: 2, title: "Revenue Recognition (ASC 606)", body: "Revenue is recognized when control of goods or services is transferred to customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services. The Company applies the five-step model: (1) identify the contract, (2) identify performance obligations, (3) determine transaction price, (4) allocate transaction price, (5) recognize revenue as performance obligations are satisfied." },
      { noteNumber: 3, title: "Leases (ASC 842)", body: "The Company recognizes right-of-use assets and lease liabilities for all leases with terms longer than 12 months. Operating lease expense is recognized on a straight-line basis. Finance lease interest is recognized using the effective interest method." },
      { noteNumber: 4, title: "Income Taxes (ASC 740)", body: "The Company accounts for income taxes using the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences of temporary differences between financial statement carrying amounts and tax bases. Valuation allowances are established when it is more likely than not that deferred tax assets will not be realized." },
      { noteNumber: 5, title: "Fair Value Measurements (ASC 820)", body: "Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants. The Company uses a three-tier hierarchy: Level 1 (quoted prices in active markets), Level 2 (observable inputs other than Level 1), Level 3 (unobservable inputs)." },
      { noteNumber: 6, title: "Business Combinations and Goodwill (ASC 805 / ASC 350)", body: "Business combinations are accounted for using the acquisition method. Goodwill is the excess of consideration transferred over the fair value of identifiable net assets acquired. Goodwill is not amortized but tested for impairment annually at the reporting unit level." },
      { noteNumber: 7, title: "Contingencies (ASC 450)", body: "The Company accrues for loss contingencies when it is probable that a liability has been incurred and the amount can be reasonably estimated. Disclosure is required when there is at least a reasonable possibility that a loss has been incurred." },
      { noteNumber: 8, title: "Subsequent Events (ASC 855)", body: "The Company evaluated subsequent events through the date these financial statements were issued. No material subsequent events have been identified that require adjustment or disclosure other than as set forth herein." },
      { noteNumber: 9, title: "Related Party Transactions (ASC 850)", body: "Transactions with related parties are disclosed including the nature of the relationship, the amounts involved, and the terms. The Company enters into transactions with affiliates on terms that management believes are no less favorable than could be obtained from unaffiliated parties." },
      { noteNumber: 10, title: "Segment Reporting (ASC 280)", body: "The Company's chief operating decision maker (CODM) reviews financial information on a consolidated basis. Operating segments are identified based on the discrete financial information reviewed by the CODM and the existence of segment managers whose performance is evaluated." },
    ];
  }
  if (standard === "UK-FRS-102") {
    // UK FRS 102 Section 1A — from TechFlow Solutions practice set
    return [
      { noteNumber: 1, title: "Accounting Policies (FRS 102 Section 1A)", body: "The financial statements have been prepared in accordance with FRS 102 Section 1A Small Entities. Revenue is recognised when services are rendered. PPE is depreciated at 25% straight line. Intangible assets are amortised at 33% straight line. The company is exempt from audit under Section 477A of the Companies Act 2006." },
      { noteNumber: 2, title: "Revenue", body: "Consulting, software subscription, and training income, net of VAT. Revenue is recognised when the significant risks and rewards of ownership have been transferred to the customer, which is when services are rendered and invoiced." },
      { noteNumber: 3, title: "Property, Plant and Equipment", body: "Additions: Computer equipment and office furniture. Depreciation at 25% straight line. Net book value = Cost less accumulated depreciation. AIA (Annual Investment Allowance) claimed for tax purposes up to £1,000,000 limit." },
      { noteNumber: 4, title: "Intangible Assets", body: "Software development costs capitalised. Amortisation at 33% straight line. Net book value = Cost less accumulated amortisation. Capitalised only when criteria met (technical feasibility, intention to complete, ability to use/sell, reliable measurement)." },
      { noteNumber: 5, title: "Trade Receivables", body: "Trade receivables per trial balance. Bad debt write-offs recognised when irrecoverable. All receivables due within 12 months. Provision for doubtful debts based on historical experience and individual assessment." },
      { noteNumber: 6, title: "Trade Payables", body: "Trade payables per trial balance. All payables due within 12 months. No amounts past due. Accruals recognised for services received but not yet invoiced." },
      { noteNumber: 7, title: "Corporation Tax", body: "Corporation Tax computed at 25% (main rate, profits >£250k) or 19% (small profits rate, ≤£50k) with marginal relief between. CT600 filing due 12 months after FY-end. Payment due 9 months + 1 day after FY-end. Capital Allowances: AIA £1,000,000, full expensing 100% for qualifying plant & machinery." },
      { noteNumber: 8, title: "Share Capital", body: "Ordinary shares of £1 each, fully paid. Allotment details disclosed. Rights attached to shares disclosed." },
      { noteNumber: 9, title: "Directors' Remuneration", body: "Directors' salary for the year disclosed. Employers' NI on directors' salary. Total directors' remuneration (salary + NI + pension). Disclosure required by Companies Act 2006 Section 412." },
      { noteNumber: 10, title: "Going Concern", body: "Financial statements prepared on a going concern basis. Director has assessed the company's ability to continue operating for at least 12 months from the date of signing. Positive indicators: profitable operations, positive cash flow, adequate facility headroom." },
      { noteNumber: 11, title: "Subsequent Events", body: "No material subsequent events have occurred between the balance sheet date and the date these financial statements were approved." },
      { noteNumber: 12, title: "Audit Exemption", body: "Small company exempt from audit under Section 477A of the Companies Act 2006. Members have not required an audit pursuant to Section 476." },
      { noteNumber: 13, title: "Employee Numbers", body: "Average number of employees during the year disclosed. Required by FRS 102 paragraph 1.26." },
      { noteNumber: 14, title: "Financial Instruments", body: "The company has financial instruments in the form of cash at bank, trade receivables and trade payables. No hedging instruments or derivatives held. Disclosure per FRS 102 Sections 11 and 12." },
      { noteNumber: 15, title: "Related Party Transactions", body: "No related party transactions other than directors' remuneration disclosed in Note 9. Required by FRS 102 Section 33." },
      { noteNumber: 16, title: "VAT Returns (VAT100)", body: "Quarterly VAT returns filed via Making Tax Digital (MTD). Box 1 = Output VAT (20% on sales). Box 4 = Input VAT (recoverable on purchases). Box 5 = Net VAT Payable (Box 1 - Box 4). Registration threshold £90,000." },
      { noteNumber: 17, title: "PAYE/NI (Payroll)", body: "Monthly FPS/EPS filed via HMRC RTI. PAYE: Personal allowance £12,570, Basic rate 20%, Higher rate 40%, Additional rate 45%. Employee NI 8%, Employer NI 13.8%. P60 issued by 19 April following tax year. Pension auto-enrolment: 5% employee + 3% employer minimum." },
      { noteNumber: 18, title: "Self Assessment (SA302)", body: "Director's SA302: Filing deadline 31 January (online). Payment deadline 31 January (balancing) + 31 July (payment on account). Dividend allowance £500. Dividend tax: 8.75% basic, 33.75% higher, 39.35% additional." },
      { noteNumber: 19, title: "Contingent Liabilities", body: "No contingent liabilities identified at the balance sheet date. Disclosure per FRS 102 Section 21." },
      { noteNumber: 20, title: "Post-Balance Sheet Events", body: "No material post-balance sheet events have occurred between the balance sheet date and the date these financial statements were approved. Per FRS 102 Section 32." },
    ];
  }
  // IFRS / IAS 1
  return [
    { noteNumber: 1, title: "Statement of Compliance and Basis of Preparation", body: "These consolidated financial statements have been prepared in accordance with International Financial Reporting Standards (IFRS) as issued by the IASB and as endorsed by the European Union. They comply with IAS 1 Presentation of Financial Statements. The financial statements are prepared on the historical cost basis except for certain financial instruments and pension liabilities measured at fair value. The functional and presentation currency is disclosed on the face of each primary statement." },
    { noteNumber: 2, title: "Significant Accounting Policies", body: "The principal accounting policies applied in the preparation of these consolidated financial statements are set out below. These policies have been consistently applied to all periods presented, unless otherwise stated. Subsidiaries are consolidated from the date control is obtained (IFRS 10) until the date such control is lost. Intercompany transactions, balances and unrealized gains on transactions between group companies are eliminated." },
    { noteNumber: 3, title: "Revenue Recognition (IFRS 15)", body: "Revenue is measured at the fair value of the consideration received or receivable, net of trade discounts, volume rebates and taxes. The Company recognizes revenue when (or as) it satisfies performance obligations by transferring control of goods or services to customers. For long-term contracts, revenue is recognized over time using the percentage-of-completion method (input method based on costs incurred)." },
    { noteNumber: 4, title: "Leases (IFRS 16)", body: "The Company, as lessee, recognizes a right-of-use asset and a lease liability at the lease commencement date. The lease liability is measured at the present value of remaining lease payments. The right-of-use asset is measured at cost less accumulated depreciation. Short-term leases (≤12 months) and low-value asset leases are expensed on a straight-line basis." },
    { noteNumber: 5, title: "Income Taxes (IAS 12)", body: "Income tax expense comprises current and deferred tax. Current tax is the expected payable on the taxable income for the year. Deferred tax is recognized in respect of temporary differences between the carrying amounts of assets and liabilities for financial reporting and tax purposes, using the liability method. Deferred tax assets are recognized only to the extent it is probable that future taxable profits will be available." },
    { noteNumber: 6, title: "Business Combinations and Goodwill (IFRS 3 / IAS 36)", body: "Business combinations are accounted for using the acquisition method. The acquirer measures the identifiable assets acquired, liabilities assumed and any non-controlling interest at fair value on the acquisition date. Goodwill is measured as the excess of the consideration transferred over the net of the acquisition-date fair values of identifiable assets acquired and liabilities assumed. Goodwill is not amortized but tested for impairment annually (IAS 36)." },
    { noteNumber: 7, title: "Financial Instruments (IFRS 9)", body: "Financial assets are classified and measured at amortized cost, fair value through other comprehensive income (FVOCI), or fair value through profit or loss (FVTPL) based on the business model and the contractual cash flow characteristics. Expected credit losses are measured using a forward-looking expected credit loss (ECL) model." },
    { noteNumber: 8, title: "Provisions and Contingencies (IAS 37)", body: "Provisions are recognized when a present obligation exists as a result of a past event, it is probable that an outflow of resources will be required, and a reliable estimate can be made. Contingent liabilities are not recognized but are disclosed unless the possibility of an outflow is remote. Contingent assets are not recognized but disclosed when an inflow is probable." },
    { noteNumber: 9, title: "Related Party Disclosures (IAS 24)", body: "Related parties include the Company's key management personnel, parent entities, subsidiaries, associates and joint ventures. Transactions with related parties are disclosed including the nature of the relationship, the amounts of transactions, outstanding balances, and commitments. Key management compensation is disclosed by category." },
    { noteNumber: 10, title: "Subsequent Events (IAS 10)", body: "Events after the reporting period that provide additional information about conditions existing at the reporting date are adjusted in the financial statements. Events that are non-adjusting are disclosed if material. The Company evaluated subsequent events through the date of authorization for issue." },
    { noteNumber: 11, title: "Operating Segments (IFRS 8)", body: "Operating segments are identified based on the internal reporting regularly reviewed by the chief operating decision maker (CODM) to allocate resources and assess performance. Segment results include revenue and expenses directly attributable to the segment and the relevant portion of corporate overhead. Segment assets and liabilities are disclosed where this information is provided to the CODM." },
    { noteNumber: 12, title: "Critical Judgments and Key Sources of Estimation Uncertainty", body: "The preparation of financial statements requires management to make judgments, estimates and assumptions that affect the reported amounts. Key estimates include: (a) recoverable amount of goodwill and intangible assets for impairment testing, (b) useful lives of property, plant and equipment, (c) provisions for litigation and warranties, (d) deferred tax asset recoverability, (e) fair value of financial instruments. Actual results may differ from these estimates." },
  ];
}
