import { NextResponse } from "next/server";
import { VARIANCE_ROWS, MONTHLY_TREND, VARIANCE_SUMMARY, VARIANCE_LAWS, VARIANCE_META } from "@/lib/budget-variance";

export async function GET() {
  return NextResponse.json({
    meta: VARIANCE_META,
    rows: VARIANCE_ROWS,
    monthlyTrend: MONTHLY_TREND,
    summary: VARIANCE_SUMMARY,
    laws: VARIANCE_LAWS,
  });
}
