import { NextResponse } from "next/server";
import {
  LOAN_PORTFOLIO,
  AMORTIZATION_SCHEDULES,
  PORTFOLIO_SUMMARY,
  COVENANT_MATRIX,
  LOAN_FORMULAS,
  LOAN_PORTFOLIO_META,
} from "@/lib/loan-portfolio";

// GET /api/loan-portfolio
// Returns the full loan portfolio with amortization schedules, covenant compliance matrix,
// portfolio summary, and formula reference.

export async function GET() {
  return NextResponse.json({
    loans: LOAN_PORTFOLIO,
    amortizationSchedules: AMORTIZATION_SCHEDULES,
    portfolioSummary: PORTFOLIO_SUMMARY,
    covenantMatrix: COVENANT_MATRIX,
    formulas: LOAN_FORMULAS,
    meta: LOAN_PORTFOLIO_META,
  });
}
