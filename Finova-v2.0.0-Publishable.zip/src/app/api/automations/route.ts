import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/automations?companyId=co_usa
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) {
    return NextResponse.json({ error: "companyId required" }, { status: 400 });
  }
  const automations = await db.automation.findMany({
    where: { companyId },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json({
    automations: automations.map((a) => ({
      id: a.id,
      name: a.name,
      description: a.description,
      trigger: a.trigger,
      action: a.action,
      agentRole: a.agentRole,
      enabled: a.enabled,
      lastRunAt: a.lastRunAt?.toISOString(),
      nextRunAt: a.nextRunAt?.toISOString(),
      runsCount: a.runsCount,
    })),
  });
}

// POST /api/automations  { companyId, name, description, trigger, action, agentRole }
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { companyId, name, description, trigger, action, agentRole } = body;
  if (!companyId || !name || !trigger || !agentRole) {
    return NextResponse.json({ error: "companyId, name, trigger, agentRole required" }, { status: 400 });
  }
  // Seed next run date based on trigger
  const now = new Date();
  const next = new Date(now);
  if (trigger === "daily") next.setDate(now.getDate() + 1);
  else if (trigger === "weekly") next.setDate(now.getDate() + 7);
  else if (trigger === "monthly") next.setMonth(now.getMonth() + 1);
  const created = await db.automation.create({
    data: {
      companyId,
      name,
      description: description || "",
      trigger,
      action: action || "send-report",
      agentRole,
      enabled: true,
      lastRunAt: now,
      nextRunAt: next,
      runsCount: 0,
    },
  });
  return NextResponse.json({ automation: created });
}

// PATCH /api/automations  { id, enabled }
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { id, enabled } = body;
  if (!id || typeof enabled !== "boolean") {
    return NextResponse.json({ error: "id and enabled required" }, { status: 400 });
  }
  const updated = await db.automation.update({
    where: { id },
    data: { enabled, lastRunAt: enabled ? new Date() : undefined },
  });
  return NextResponse.json({ automation: updated });
}
