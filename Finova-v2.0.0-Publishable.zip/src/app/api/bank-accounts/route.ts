import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/bank-accounts?companyId=...
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) return NextResponse.json({ error: "companyId required" }, { status: 400 });
  const accounts = await db.bankAccount.findMany({
    where: { companyId },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json({
    bankAccounts: accounts.map((a) => ({
      id: a.id,
      bankName: a.bankName,
      accountName: a.accountName,
      accountType: a.accountType,
      accountNumber: a.accountNumber, // already masked when stored
      routingNumber: a.routingNumber,
      currency: a.currency,
      balance: a.balance,
      creditLimit: a.creditLimit,
      availableBalance: a.availableBalance,
      plaidItemId: a.plaidItemId,
      status: a.status,
      createdAt: a.createdAt.toISOString(),
    })),
  });
}

// POST /api/bank-accounts — add a new bank account or credit card
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { companyId, bankName, accountName, accountType, accountNumber, routingNumber, currency, balance, creditLimit } = body;
  if (!companyId || !bankName || !accountType) {
    return NextResponse.json({ error: "companyId, bankName, accountType required" }, { status: 400 });
  }
  // Mask the account number — keep only last 4
  const raw = String(accountNumber ?? "").replace(/\s/g, "");
  const masked = raw.length > 4 ? `••••${raw.slice(-4)}` : raw || "••••0000";

  const account = await db.bankAccount.create({
    data: {
      companyId,
      bankName,
      accountName: accountName || `${accountType} account`,
      accountType,
      accountNumber: masked,
      routingNumber: routingNumber ?? null,
      currency: currency || "USD",
      balance: Number(balance) || 0,
      creditLimit: creditLimit ? Number(creditLimit) : null,
      availableBalance: accountType === "credit_card" ? Number(creditLimit || 0) - Math.abs(Number(balance) || 0) : Number(balance) || 0,
      status: "active",
    },
  });
  return NextResponse.json({ bankAccount: account });
}

// PATCH /api/bank-accounts { id, status }  — freeze / close
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { id, status, balance } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  if (status) data.status = status;
  if (typeof balance === "number") data.balance = balance;
  const updated = await db.bankAccount.update({ where: { id }, data });
  return NextResponse.json({ bankAccount: updated });
}

// DELETE /api/bank-accounts { id }
export async function DELETE(req: NextRequest) {
  const body = await req.json();
  const { id } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.bankAccount.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
