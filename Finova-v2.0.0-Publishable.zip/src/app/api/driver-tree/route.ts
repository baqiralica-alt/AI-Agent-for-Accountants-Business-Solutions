import { NextResponse } from "next/server";
import {
  SCENARIO_ASSUMPTIONS,
  SCENARIO_OUTPUTS,
  SCENARIO_COMPARISON,
  SENSITIVITY_TABLE,
  SENSITIVITY_TABLE_2,
  DRIVER_TREE,
  SCENARIO_LAWS,
  DRIVER_TREE_META,
} from "@/lib/driver-tree-scenarios";

// GET /api/driver-tree
// Returns the Driver Tree & Scenario Engine with 4 scenarios (Base/Bull/Bear/Stress),
// sensitivity tables, and 5-level driver tree.

export async function GET() {
  return NextResponse.json({
    meta: DRIVER_TREE_META,
    assumptions: SCENARIO_ASSUMPTIONS,
    outputs: SCENARIO_OUTPUTS,
    comparison: SCENARIO_COMPARISON,
    sensitivityTable1: SENSITIVITY_TABLE,
    sensitivityTable2: SENSITIVITY_TABLE_2,
    driverTree: DRIVER_TREE,
    laws: SCENARIO_LAWS,
  });
}
