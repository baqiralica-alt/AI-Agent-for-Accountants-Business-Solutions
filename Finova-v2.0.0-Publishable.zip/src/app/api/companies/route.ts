import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/companies — list all tenant clients
export async function GET() {
  const companies = await db.company.findMany({
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      industry: true,
      country: true,
      currency: true,
      taxId: true,
      paymentStatus: true,
      paymentDueDate: true,
      lastPaymentDate: true,
    },
  });
  return NextResponse.json({ companies });
}

// POST /api/companies — add a new client
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { name, industry, country, currency, taxId } = body;
  if (!name || !industry || !country) {
    return NextResponse.json({ error: "name, industry and country are required" }, { status: 400 });
  }
  const cur = currency || (country === "USA" ? "USD" : country === "UK" ? "GBP" : "EUR");
  const company = await db.company.create({
    data: { name, industry, country, currency: cur, taxId: taxId ?? null },
  });
  return NextResponse.json({ company });
}

// PATCH /api/companies  { id, paymentStatus, paymentDueDate, lastPaymentDate }
// Used by the practice to block / unblock a client when subscription is paid or overdue.
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { id, paymentStatus, paymentDueDate, lastPaymentDate } = body;
  if (!id || !paymentStatus) {
    return NextResponse.json({ error: "id and paymentStatus required" }, { status: 400 });
  }
  const data: any = { paymentStatus };
  if (paymentDueDate) data.paymentDueDate = new Date(paymentDueDate);
  if (lastPaymentDate) data.lastPaymentDate = new Date(lastPaymentDate);
  const updated = await db.company.update({ where: { id }, data });
  return NextResponse.json({ company: updated });
}
