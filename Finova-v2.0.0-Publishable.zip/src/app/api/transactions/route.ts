import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/transactions?companyId=co_usa
// POST /api/transactions  { companyId, date, description, category, type, amount, currency, source }
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  const category = req.nextUrl.searchParams.get("category");
  const source = req.nextUrl.searchParams.get("source");
  const type = req.nextUrl.searchParams.get("type");

  if (!companyId) {
    return NextResponse.json({ error: "companyId required" }, { status: 400 });
  }

  const where: any = { companyId };
  if (category && category !== "all") where.category = category;
  if (source && source !== "all") where.source = source;
  if (type && (type === "income" || type === "expense")) where.type = type;

  const txns = await db.transaction.findMany({
    where,
    orderBy: { date: "desc" },
    take: 200,
  });

  return NextResponse.json({
    transactions: txns.map((t) => ({
      id: t.id,
      date: t.date.toISOString(),
      description: t.description,
      category: t.category,
      type: t.type,
      amount: t.amount,
      currency: t.currency,
      source: t.source,
      status: t.status,
    })),
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { companyId, date, description, category, type, amount, currency, source } = body;

  if (!companyId || !description || !category || !type || typeof amount !== "number") {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  const txn = await db.transaction.create({
    data: {
      companyId,
      date: date ? new Date(date) : new Date(),
      description,
      category,
      type,
      amount,
      currency: currency || "USD",
      source: source || "manual",
      status: "posted",
    },
  });

  return NextResponse.json({ transaction: txn });
}
