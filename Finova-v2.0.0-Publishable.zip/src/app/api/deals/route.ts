import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/deals?companyId=...
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) return NextResponse.json({ error: "companyId required" }, { status: 400 });
  const deals = await db.deal.findMany({
    where: { acquirerId: companyId },
    orderBy: { dealDate: "desc" },
  });
  return NextResponse.json({
    deals: deals.map((d) => ({
      id: d.id,
      targetName: d.targetName,
      targetIndustry: d.targetIndustry,
      dealDate: d.dealDate.toISOString(),
      status: d.status,
      purchasePrice: d.purchasePrice,
      fairValueAssets: d.fairValueAssets,
      liabilitiesAssumed: d.liabilitiesAssumed,
      goodwill: d.goodwill,
      netIdentifiableAssets: d.fairValueAssets - d.liabilitiesAssumed,
      synergy: d.synergy,
      structure: d.structure,
      notes: d.notes,
    })),
  });
}

// POST /api/deals — create a new M&A deal with auto-computed goodwill (IFRS 3 / ASC 805)
export async function POST(req: NextRequest) {
  const body = await req.json();
  const {
    acquirerId, targetName, targetIndustry, dealDate, status,
    purchasePrice, fairValueAssets, liabilitiesAssumed, synergy, structure, notes,
  } = body;
  if (!acquirerId || !targetName || !purchasePrice || !fairValueAssets) {
    return NextResponse.json({ error: "acquirerId, targetName, purchasePrice, fairValueAssets are required" }, { status: 400 });
  }
  const liab = liabilitiesAssumed ?? 0;
  const netIdentifiable = fairValueAssets - liab;
  const goodwill = purchasePrice - netIdentifiable;

  const deal = await db.deal.create({
    data: {
      acquirerId,
      targetName,
      targetIndustry: targetIndustry ?? "—",
      dealDate: dealDate ? new Date(dealDate) : new Date(),
      status: status ?? "announced",
      purchasePrice: Number(purchasePrice),
      fairValueAssets: Number(fairValueAssets),
      liabilitiesAssumed: Number(liab),
      goodwill,
      synergy: synergy ?? null,
      structure: structure ?? "cash",
      notes: notes ?? null,
    },
  });
  return NextResponse.json({ deal, netIdentifiable, goodwill });
}
