import { NextResponse } from "next/server";
import { WACC_SECTION, DCF_SECTION, COMPS_SECTION, PRECEDENT_SECTION, SENSITIVITY_SECTION, FOOTBALL_FIELD_SECTION, VALUATION_LAWS, VALUATION_META, VALUATION_TARGETS } from "@/lib/valuation-reports";

export async function GET() {
  return NextResponse.json({
    meta: VALUATION_META,
    targets: VALUATION_TARGETS,
    sections: { wacc: WACC_SECTION, dcf: DCF_SECTION, comps: COMPS_SECTION, precedent: PRECEDENT_SECTION, sensitivity: SENSITIVITY_SECTION, footballField: FOOTBALL_FIELD_SECTION },
    laws: VALUATION_LAWS,
  });
}
