import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/integrations?companyId=co_usa
export async function GET(req: NextRequest) {
  const companyId = req.nextUrl.searchParams.get("companyId");
  if (!companyId) {
    return NextResponse.json({ error: "companyId required" }, { status: 400 });
  }
  const integrations = await db.integration.findMany({
    where: { companyId },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json({
    integrations: integrations.map((i) => ({
      id: i.id,
      provider: i.provider,
      label: i.label,
      status: i.status,
      scope: i.scope,
      accountEmail: i.accountEmail,
      lastSyncAt: i.lastSyncAt?.toISOString(),
    })),
  });
}

// POST /api/integrations  { companyId, provider, label }  — simulated OAuth connect
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { companyId, provider, label } = body;
  if (!companyId || !provider) {
    return NextResponse.json({ error: "companyId and provider required" }, { status: 400 });
  }
  const created = await db.integration.create({
    data: {
      companyId,
      provider,
      label: label || provider,
      status: "connected",
      lastSyncAt: new Date(),
    },
  });
  return NextResponse.json({ integration: created });
}

// PATCH /api/integrations { id, status }  — simulate connect / disconnect / sync
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { id, status } = body;
  if (!id || !status) {
    return NextResponse.json({ error: "id and status required" }, { status: 400 });
  }
  const updated = await db.integration.update({
    where: { id },
    data: { status, lastSyncAt: status === "connected" ? new Date() : undefined },
  });
  return NextResponse.json({ integration: updated });
}
