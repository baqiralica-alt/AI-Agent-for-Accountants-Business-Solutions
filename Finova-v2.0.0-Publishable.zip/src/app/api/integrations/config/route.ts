import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/integrations/config  { id, clientId?, clientSecret?, apiKey?, refreshToken?, redirectUri? }
// Saves real OAuth credentials (encrypted at rest in a production app) to the integration row.
// NOTE: in this demo, credentials are stored as JSON in the configJson column. In production,
// wrap with KMS / a secrets manager and never return secrets back to the client.
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { id, clientId, clientSecret, apiKey, refreshToken, redirectUri, accountEmail } = body;
  if (!id) {
    return NextResponse.json({ error: "id required" }, { status: 400 });
  }
  const existing = await db.integration.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json({ error: "Integration not found" }, { status: 404 });
  }
  const prev = existing.configJson ? JSON.parse(existing.configJson) : {};
  const nextConfig = {
    ...prev,
    ...(clientId !== undefined ? { clientId } : {}),
    ...(clientSecret !== undefined ? { clientSecret } : {}),
    ...(apiKey !== undefined ? { apiKey } : {}),
    ...(refreshToken !== undefined ? { refreshToken } : {}),
    ...(redirectUri !== undefined ? { redirectUri } : {}),
  };
  const updated = await db.integration.update({
    where: { id },
    data: {
      configJson: JSON.stringify(nextConfig),
      accountEmail: accountEmail ?? existing.accountEmail,
      status: "connected",
      lastSyncAt: new Date(),
    },
  });
  // Strip the secret fields before returning — never echo them back
  const safeConfig = {
    clientId: nextConfig.clientId ? `${nextConfig.clientId.slice(0, 4)}…${nextConfig.clientId.slice(-4)}` : null,
    hasClientSecret: Boolean(nextConfig.clientSecret),
    hasApiKey: Boolean(nextConfig.apiKey),
    hasRefreshToken: Boolean(nextConfig.refreshToken),
    redirectUri: nextConfig.redirectUri ?? null,
  };
  return NextResponse.json({ integration: { id: updated.id, status: updated.status, safeConfig } });
}
