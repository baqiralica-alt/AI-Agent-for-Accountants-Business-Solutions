import { NextResponse } from "next/server";
import { LRP_YEARS, LRP_ASSUMPTIONS_TABLE, LRP_PROJECTION_ROWS, LRP_SEED, LRP_STRATEGIC_DECISIONS, LRP_META } from "@/lib/lrp-data";

export async function GET() {
  return NextResponse.json({
    meta: LRP_META,
    years: LRP_YEARS,
    assumptions: LRP_ASSUMPTIONS_TABLE,
    projections: LRP_PROJECTION_ROWS,
    seed: LRP_SEED,
    strategicDecisions: LRP_STRATEGIC_DECISIONS,
  });
}
