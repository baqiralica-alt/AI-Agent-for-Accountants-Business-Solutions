#!/bin/bash
# ============================================================
#  Finova - CPA / CFO / Tax / Audit
#  One-click launcher for macOS / Linux
#  Double-click this file (or run: ./start.sh) to start the app
# ============================================================

set -e
cd "$(dirname "$0")"

echo ""
echo "  ============================================================"
echo "   Finova - CPA / CFO / Tax / Audit"
echo "   Starting the app on http://localhost:3000"
echo "  ============================================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "  [ERROR] Node.js is not installed."
    echo "  Please install Node.js from https://nodejs.org (LTS version)"
    echo "  Then run this script again."
    read -p "Press Enter to exit..."
    exit 1
fi

# Check if Bun is installed, fall back to npm
if command -v bun &> /dev/null; then
    echo "  Using Bun (faster)"
    CMD="bun"
else
    echo "  Using npm (Bun not found - that's OK, just slower)"
    CMD="npm"
fi

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo ""
    echo "  Installing dependencies (first run only - may take 2-3 minutes)..."
    $CMD install
fi

# Set up the database if it doesn't exist
if [ ! -f "db/custom.db" ]; then
    echo ""
    echo "  Setting up the database..."
    $CMD run db:push
    $CMD run scripts/seed.ts
fi

# Start the dev server
echo ""
echo "  Starting Finova..."
echo "  Once you see 'Ready', open your browser to http://localhost:3000"
echo "  Press Ctrl+C to stop the server."
echo ""

$CMD run dev
