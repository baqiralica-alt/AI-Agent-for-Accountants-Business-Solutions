# Finova — Finance · Accounting · AI Agents · USA/UK/EU/Canada

**Version 2.0.0** | Last Updated: November 23, 2026

> Comprehensive AI-powered accounting & finance platform with 21 modules, 33+ API endpoints, multi-jurisdictional reporting (IFRS / US GAAP / UK FRS 102 / EU IFRS-EU / Canada ASPE), and 300+ LLM model integrations.

## Features

### 21 Modules
1. **Dashboard** — KPIs, cash flow, runway
2. **AI Agents** — CEO / CFO / Accountant / Tax chat (powered by Z.ai or any LLM via LLM Hub)
3. **Clients** — Multi-client book of business (USA / UK / EU / Canada)
4. **Transactions** — Ledger & reconciliation
5. **Journal Entries** — Dr/Cr double-entry postings
6. **Invoices** — Customer & vendor invoices (PDF export)
7. **Import Files** — PDF / Excel / CSV → auto-post to GL
8. **Automations** — Recurring tasks & email rules
9. **Integrations** — Gmail, QuickBooks, Xero, banks
10. **API & Webhooks** — REST endpoints + event webhooks
11. **Tax Center** — Normal Tax + Deferred Tax (IAS 12 / ASC 740 / FRS 102 s29) with 10 journal entries
12. **Payroll** — USA (FICA/ERISA/ACA), UK (PAYE/NI/AE), Germany (Lohnsteuer/SGB), Canada (CPP/EI/ITA)
13. **Market Data** — 85 data points: FX, risk-free rates, ERP, credit spreads, tax rates (Fed/BoE/ECB sources)
14. **LLM Hub** — Connect to 300+ AI models across 15 providers (31 free models)
15. **Financial Reports** — 10 tabs: Concepts, GAAP vs IFRS, OCI, P&L, BS, CF, Trial Balance, Equity, VAT/Tax, Payroll
16. **Consolidation** — Group reporting (IFRS 10 / ASC 810)
17. **Corporate Finance** — 9 tabs: M&A, Valuation, FP&A, FMVA, 3-Statement, Scenario, Board Pack, LRP, Loans
18. **Disclosures** — IAS 1 / US GAAP notes (21 disclosure notes)
19. **Bank Accounts** — Banks, credit cards, multiple accounts
20. **How to Use** — Plain-English getting started
21. **Concepts Applied** — Cross-reference matrix (55 applications across 9 reports)

### Financial Reports (10 tabs)
- **Concepts Glossary** — 115 terms across 11 categories (the "laws" governing all reports)
- **GAAP vs IFRS** — 32 comparison rows across 13 areas (incl. Canada-specific)
- **OCI Report** — Statement of Comprehensive Income per IAS 1.82 / ASC 220
- **P&L** — Income Statement with OCI section (IAS 1 / FRS 102 / US GAAP)
- **Balance Sheet** — Statement of Financial Position (incl. Accumulated OCI Reserve)
- **Cash Flow** — Indirect Method per IAS 7 / ASC 230
- **Trial Balance** — 36 GL accounts, Dr = Cr = £2,965,683 (balanced)
- **Equity** — Statement of Changes in Equity (IAS 1.106)
- **VAT/Tax** — CT600, VAT100, SA302
- **Payroll** — December 2025 schedule with 6 employees

### Corporate Finance (9 tabs)
- **M&A** — 5 complex deals with full PPA, journal entries, scenarios
- **Valuation** — Multi-jurisdictional (USA/UK/EU/Canada) WACC, DCF, Comps, Precedent, Sensitivity, Football Field with PDF/Excel/CSV export
- **FP&A** — Budget vs Actual Variance Analysis (12 months, F/U flags)
- **FMVA** — 9 valuation methodologies (WACC, DCF, Comps, Precedent, Sensitivity, Football Field, LBO, M&A Accretion/Dilution)
- **3-Statement** — 8-year IS/BS/CF for Meridian Capital Holdings with linked formulas
- **Scenario Engine** — 4 scenarios (Base/Bull/Bear/Stress) × 14 drivers + 2 sensitivity tables
- **Board Pack** — Executive KPI dashboard with traffic-light status + 8-year trend
- **LRP** — 10-Year Long-Range Plan (FY2025E-FY2034E) with 5 strategic decision points
- **Loan Portfolio** — 8 loans with amortization schedules, DSCR/LTV/Debt Yield, ECL (PD×LGD×EAD)

### Multi-Jurisdictional Standards
- **IFRS** (IASB) — IAS 1, 7, 12, 16, 19, 21, 38, IFRS 3, 9, 10, 15, 16
- **US GAAP** (FASB ASC) — 210, 220, 230, 326, 350, 470, 715, 740, 805, 810, 815, 820, 830, 842
- **UK FRS 102** — s3, s6, s9, s10, s17, s29, s35
- **EU IFRS-EU** — IAS Regulation 1606/2002
- **Canada** — ASPE (Part II), IFRS-Canada (Part I), CPP Act, EI Act, ITA

## Tech Stack

- **Framework**: Next.js 16 (App Router, Turbopack)
- **Language**: TypeScript
- **Database**: SQLite via Prisma ORM
- **Styling**: Tailwind CSS + shadcn/ui
- **AI**: z-ai-web-dev-sdk (default) + 15 LLM providers via LLM Hub
- **Export**: xlsx (Excel), client-side PDF (print), CSV
- **Runtime**: Bun

## Quick Start

```bash
# Install dependencies
bun install   # or: npm install

# Set up database
npx prisma generate
npx prisma db push
bun run scripts/seed.ts   # seed demo data

# Start dev server
bun run dev   # or: npm run dev

# Open http://localhost:3000
```

## Environment Variables

```env
# Database
DATABASE_URL="file:./db/custom.db"

# AI Provider (default — Z.ai)
ZAI_API_KEY=your_zai_api_key

# Optional LLM Providers (configure via LLM Hub in the app)
GOOGLE_AI_API_KEY=
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
DEEPSEEK_API_KEY=
GROQ_API_KEY=
# ... see .env.example for all 15 providers
```

## Project Structure

```
src/
├── app/
│   ├── api/          # 33 API routes
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── modules/      # 21 module components
│   ├── ui/           # shadcn/ui components
│   ├── concepts-applied-panel.tsx
│   └── app-shell.tsx
├── lib/
│   ├── concepts-glossary.ts      # 115 terms
│   ├── concepts-applied.ts       # 55 applications
│   ├── gaap-vs-ifrs.ts           # 32 comparisons
│   ├── market-data.ts            # 85 data points
│   ├── payroll-data.ts           # 15 employees × 4 countries
│   ├── three-statement-model.ts  # 8-year IS/BS/CF
│   ├── loan-portfolio.ts         # 8 loans with amortization
│   ├── fmva-data.ts              # 9 valuation methodologies
│   ├── driver-tree-scenarios.ts  # 4 scenarios × 14 drivers
│   ├── budget-variance.ts        # Monthly variance analysis
│   ├── ma-deals-data.ts          # 5 M&A deals with PPA
│   ├── valuation-reports.ts      # Multi-jurisdictional valuation
│   ├── lrp-data.ts               # 10-year long-range plan
│   ├── llm-hub-data.ts           # 15 providers × 55 models
│   ├── knowledge-base.ts         # IAS1, FRS102, formulas, ratios
│   ├── chart-of-accounts.ts      # 80+ GL accounts
│   ├── store.ts                  # Zustand state management
│   └── db.ts                     # Prisma client
├── prisma/
│   └── schema.prisma             # 17 data models
└── public/
    └── logo.svg
```

## Mathematical Verification

| Check | Result |
|---|---|
| Trial Balance Dr = Cr | £2,965,683 = £2,965,683 ✓ |
| OCI Net = Gross − Tax | £2,512.50 = £3,350 − £837.50 ✓ |
| Total Comp Income = NI + OCI | £491,358.50 = £488,846 + £2,512.50 ✓ |
| Deferred Tax JEs Dr = Cr | £164,515.25 = £164,515.25 ✓ |
| WACC = (E/V×Re) + (D/V×Rd×(1−T)) | 8.65% = 0.80×9.59 + 0.20×4.91 ✓ |
| Loan DSCR = NOI / Annual Debt Service | Computed per loan ✓ |
| Expected Loss = PD × LGD × EAD | Computed per loan ✓ |

## Security

- All API keys stored in environment variables (never in code)
- Prisma ORM prevents SQL injection
- Input validation on all API endpoints
- No personal data in source code
- SQLite database file excluded from Git
- See [SECURITY.md](SECURITY.md) for full security policy

## Legal

- **License**: See [LICENSE](LICENSE)
- **Privacy Policy**: See [PRIVACY.md](PRIVACY.md)
- **Terms of Service**: See [TERMS.md](TERMS.md)
- **Security Policy**: See [SECURITY.md](SECURITY.md)
- **Contributing**: See [CONTRIBUTING.md](CONTRIBUTING.md)

## Compliance

This app implements reporting standards per:
- **USA**: IRC, ERISA, ACA, FLSA, ASC (FASB), SEC registrant requirements
- **UK**: ITEPA 2003, SSCBA 1992, PA 2008, CTA 2010, VATA 1994, FRS 102
- **EU**: IAS Regulation 1606/2002, EU VAT Directive 2006/112/EC, GDPR
- **Canada**: ITA, CPP Act, EI Act, Taxation Act 2007 (Ontario), ASPE, CPA Canada Handbook
- **International**: IFRS (IASB), OECD Pillar Two, Basel III

## Disclaimer

This software is for educational and professional assistance purposes. All financial data in the app is **fictional**. Always consult a licensed CPA, tax adviser, or financial professional before making business decisions based on any output from this software.

## Version History

| Version | Date | Changes |
|---|---|---|
| 2.0.0 | Nov 23, 2026 | Full multi-jurisdictional platform with 21 modules, LLM Hub, legal compliance |
| 1.0.0 | Nov 19, 2026 | Initial release with core accounting modules |
