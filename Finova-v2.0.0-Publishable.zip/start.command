#!/bin/bash
# macOS double-click launcher — opens Terminal automatically and runs start.sh
cd "$(dirname "$0")"
./start.sh
