@echo off
REM ============================================================
REM  Finova - CPA / CFO / Tax / Audit
REM  One-click launcher for Windows
REM  Double-click this file to start the app
REM ============================================================

setlocal
cd /d "%~dp0"

echo.
echo  ============================================================
echo   Finova - CPA / CFO / Tax / Audit
echo   Starting the app on http://localhost:3000
echo  ============================================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js is not installed.
    echo  Please install Node.js from https://nodejs.org (LTS version)
    echo  Then double-click this file again.
    pause
    exit /b 1
)

REM Check if Bun is installed, fall back to npm
where bun >nul 2>nul
if %errorlevel% neq 0 (
    echo  Using npm (Bun not found - that's OK, just slower)
    set CMD=npm
) else (
    echo  Using Bun (faster)
    set CMD=bun
)

REM Install dependencies if needed
if not exist "node_modules" (
    echo.
    echo  Installing dependencies (first run only - may take 2-3 minutes)...
    %CMD% install
)

REM Set up the database if it doesn't exist
if not exist "db\custom.db" (
    echo.
    echo  Setting up the database...
    %CMD% run db:push
    %CMD% run scripts\seed.ts
)

REM Start the dev server
echo.
echo  Starting Finova...
echo  Once you see "Ready", open your browser to http://localhost:3000
echo  Press Ctrl+C to stop the server.
echo.
%CMD% run dev

pause
