# Contributing to Finova

**Last Updated: November 23, 2026**

## Welcome

Thank you for your interest in contributing to Finova! This is an open-source finance and accounting platform built for professionals across USA, UK, EU, and Canada.

## How to Contribute

### 1. Fork & Clone
```bash
git clone https://github.com/yourusername/finova.git
cd finova
bun install
```

### 2. Create a Branch
```bash
git checkout -b feature/your-feature-name
```

### 3. Develop
- Follow existing code style (TypeScript, Tailwind, shadcn/ui)
- Add TypeScript types for all new code
- Test your changes in the browser
- Ensure no console errors

### 4. Submit a Pull Request
- Describe what your PR does
- Reference any related issues
- Include screenshots if UI changes

## Code Standards

### TypeScript
- All new files must be `.ts` or `.tsx`
- Use proper types (avoid `any` where possible)
- Follow Next.js 16 App Router patterns

### Financial Accuracy
- All financial calculations must be mathematically verified
- Cite the governing standard (IFRS / US GAAP / FRS 102 / ASPE)
- Include formula references in code comments
- All data must be clearly marked as fictional

### Multi-Jurisdictional
- Support USA, UK, EU, and Canada where applicable
- Cite specific laws/statutes (e.g., "ITEPA 2003 s.1", "IRC §3101")
- Use correct currency symbols ($ £ € C$)

## Reporting Issues

When reporting issues, include:
- Module name (e.g., "Financial Reports → P&L tab")
- Steps to reproduce
- Expected vs actual behavior
- Browser and OS

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
